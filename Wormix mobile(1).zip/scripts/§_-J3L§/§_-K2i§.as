package §_-J3L§
{
   import §_-A1K§.§_-TA§;
   import §_-N8§.§_-2C§;
   import §_-N8§.§_-o2w§;
   import flash.events.Event;
   import ru.pragmatix.wormix.messages.clans.request.PromoteRankInClanRequest;
   import ru.pragmatix.wormix.messages.clans.response.PromoteRankInClanResponse;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   import ru.pragmatix.wormix.weapons.ammo.DynamiteStick;
   import ru.pragmatix.wormix.weapons.ammo.type.dynamite.DynamiteBunch;
   
   public class §_-K2i§ extends Event
   {
      
      public static const CLICK:String = "MenuItemEvent_CLICK";
      
      public static const §_-W2R§:String = "MenuItemEvent_DOUBLE_CLICK";
      
      public static const ROLL_OVER:String = "MenuItemEvent_ROLL_OVER";
      
      public static const DISABLED:String = "MenuItemEvent_DISABLED";
      
      public function §_-K2i§(param1:String, param2:Boolean = false, param3:Boolean = false)
      {
         super(param1,param2,param3);
      }
      
      override public function clone() : Event
      {
         return new §_-K2i§(type,bubbles,cancelable);
      }
   }
}

