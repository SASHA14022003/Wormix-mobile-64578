package §_-F39§
{
   import §_-62§.§_-T1y§;
   import §_-A1K§.§_-7u§;
   import §_-A1K§.§_-TA§;
   import §_-CF§.§_-E19§;
   import §_-CF§.§_-x2t§;
   import §_-D3A§.§_-TZ§;
   import §_-G2H§.*;
   import §_-J3L§.§_-K2i§;
   import §_-N8§.§_-2C§;
   import §_-N8§.§_-o2w§;
   import §_-b1F§.§_-v2Q§;
   import §_-l1g§.§_-L3Q§;
   import §_-s20§.§_-d21§;
   import §_-x2Q§.§_-dU§;
   import flash.errors.IllegalOperationError;
   import flash.events.Event;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.messages.server.VerifyPaymentResult;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-Qi§;
   import ru.pragmatix.wormix.weapons.*;
   import starling.display.Sprite;
   import starling.events.Event;
   
   public class §_-r2l§
   {
      
      private static var §_-i1N§:§_-r2l§;
      
      private static var §_-S2w§:Array = [];
      
      private static var §_-z2f§:Array = [];
      
      private static var §_-Q17§:Array = [];
      
      public function §_-r2l§()
      {
         super();
         if(§_-i1N§ != null)
         {
            throw new IllegalOperationError();
         }
         §_-r2l§.§_-i1N§ = this;
      }
      
      public static function getInstance() : §_-r2l§
      {
         return §_-r2l§.§_-i1N§;
      }
      
      public static function init(param1:Array, param2:Array, param3:Array) : void
      {
         §_-r2l§.§_-S2w§ = param1;
         §_-r2l§.§_-z2f§ = param2;
         §_-r2l§.§_-Q17§ = param3;
      }
      
      public static function activate() : void
      {
         if(§_-X1j§.§_-12n§.scene)
         {
            §_-TZ§.addListener(§_-X1j§.§_-12n§.scene,§_-L3Q§.SOT,§_-S23§);
            §_-TZ§.addListener(§_-X1j§.§_-12n§.scene,§_-L3Q§.DAMAGE,§_-6J§);
         }
      }
      
      public static function deactivate() : void
      {
         if(§_-X1j§.§_-12n§.scene)
         {
            §_-TZ§.removeListener(§_-X1j§.§_-12n§.scene,§_-L3Q§.SOT,§_-S23§);
            §_-TZ§.removeListener(§_-X1j§.§_-12n§.scene,§_-L3Q§.DAMAGE,§_-6J§);
         }
      }
      
      private static function §_-S23§(param1:starling.events.Event) : void
      {
         var _loc2_:int = 0;
         var _loc3_:String = null;
         var _loc4_:String = null;
         if(Boolean(§_-X1j§.§_-12n§.gameMaster) && §_-X1j§.§_-12n§.isLearning)
         {
            return;
         }
         §_-a2W§.reset();
         if(Boolean(§_-X1j§.§_-12n§.gameMaster) && Boolean(§_-X1j§.§_-12n§.gameMaster.activeUnit))
         {
            _loc2_ = Math.random() * 1000 * §_-S2w§.length / 1000;
            _loc3_ = §_-X1j§.§_-12n§.gameMaster.activeUnit.record.getCharName();
            _loc3_ = _loc3_ ? _loc3_ : §_-33r§.§_-k2R§;
            _loc4_ = String(§_-S2w§[_loc2_]).replace("%source%",_loc3_);
            §_-a2W§.§_-1H§(_loc4_,true);
         }
      }
      
      private static function §_-6J§(param1:starling.events.Event, param2:§_-v2Q§) : void
      {
         var _loc3_:§_-01J§ = null;
         var _loc4_:§_-01J§ = null;
         var _loc5_:* = undefined;
         var _loc6_:int = 0;
         var _loc7_:String = null;
         var _loc8_:String = null;
         var _loc9_:String = null;
         if(Boolean(§_-X1j§.§_-12n§.gameMaster) && §_-X1j§.§_-12n§.isLearning)
         {
            return;
         }
         if(param2.source is §_-Qi§ && §_-Qi§(param2.source).owner is §_-01J§ && param2.victim is §_-01J§)
         {
            _loc3_ = §_-01J§(§_-Qi§(param2.source).owner);
            _loc4_ = §_-01J§(param2.victim);
            _loc5_ = _loc3_ == _loc4_ ? §_-Q17§ : §_-z2f§;
            _loc6_ = Math.random() * 1000 * _loc5_.length / 1000;
            _loc7_ = §_-01J§(§_-Qi§(param2.source).owner).record.getCharName();
            _loc7_ = _loc7_ ? _loc7_ : §_-33r§.§_-k2R§;
            _loc8_ = §_-01J§(param2.victim).record.getCharName();
            _loc8_ = _loc8_ ? _loc8_ : §_-33r§.§_-k2R§;
            _loc9_ = String(_loc5_[_loc6_]).replace("%source%",_loc7_).replace("%target%",_loc8_);
            §_-a2W§.§_-1H§(_loc9_);
         }
      }
      
      public function unwatch(param1:String) : void
      {
         super.unwatch(param1);
      }
   }
}

