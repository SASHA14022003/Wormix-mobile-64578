package §_-F39§
{
   import §_-Cl§.§_-L2z§;
   import §_-H2g§.§_-F0§;
   import §_-l1g§.§_-L3Q§;
   import §_-r1C§.§_-h2B§;
   import §_-x2Q§.§_-dU§;
   import com.greensock.TweenMax;
   import dragonBones.animation.WorldClock;
   import flash.geom.Rectangle;
   import flash.net.Socket;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.sets.ControlSets;
   import ru.pragmatix.wormix.gui.§_-fT§;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.Force;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.weapons.§_-5e§;
   import ru.pragmatix.wormix.weapons.ammo.BouncingTeleport;
   import ru.pragmatix.wormix.weapons.ammo.LaserRay;
   import starling.display.DisplayObjectContainer;
   import starling.display.Image;
   import starling.display.Quad;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.textures.Texture;
   
   public class §_-m1F§ extends §_-fT§ implements §_-F0§
   {
      
      private static var §_-1h§:Number;
      
      private static const §_-l2q§:Number = 30;
      
      private static var §_-v1U§:Number = 0.5;
      
      private var windContainer:Sprite;
      
      private var leftWind:Sprite;
      
      private var rightWind:Sprite;
      
      private var §_-Nm§:Sprite;
      
      private var §_-21n§:Vector.<Image>;
      
      private var §_-O2M§:Number;
      
      public function §_-m1F§(param1:DisplayObjectContainer)
      {
         super(param1);
         this.windContainer = param1.getChildByName("data") as Sprite;
         this.leftWind = this.windContainer.getChildByName("leftWind") as Sprite;
         this.rightWind = this.windContainer.getChildByName("rightWind") as Sprite;
         §_-1h§ = this.leftWind.width;
         this.§_-w3§();
         this.setWind(Force.WIND.ax);
         Force.WIND.addEventListener(§_-L3Q§.FORCE_CHANGED,this.§_-sb§);
      }
      
      override public function dispose() : void
      {
         WorldClock.clock.remove(this);
         TweenMax.killTweensOf(this.leftWind);
         TweenMax.killTweensOf(this.rightWind);
         TweenMax.killTweensOf(this.§_-Nm§.mask);
         if(Force.WIND.hasEventListener(§_-L3Q§.FORCE_CHANGED))
         {
            Force.WIND.removeEventListener(§_-L3Q§.FORCE_CHANGED,this.§_-sb§);
         }
         this.§_-Nm§.dispose();
         this.leftWind.dispose();
         this.rightWind.dispose();
         this.§_-Nm§.dispose();
         this.windContainer.dispose();
         this.§_-21n§ = null;
         super.dispose();
      }
      
      public function setWind(param1:Number) : void
      {
         var _loc2_:Number = param1 <= 0 ? 0 : Number(Math.min(param1,§_-v1U§));
         var _loc3_:Number = param1 >= 0 ? 0 : Number(Math.min(param1 * -1,§_-v1U§));
         var _loc4_:Number = §_-1h§ * Math.min(1,_loc2_ / §_-v1U§);
         var _loc5_:Number = §_-1h§ * Math.min(1,_loc3_ / §_-v1U§);
         var _loc6_:Number = this.leftWind.x - _loc5_ - this.§_-Nm§.x;
         var _loc7_:Number = this.rightWind.x + _loc4_ - this.§_-Nm§.x - _loc6_;
         TweenMax.to(this.rightWind,1,{"width":_loc4_});
         TweenMax.to(this.leftWind,1,{"width":_loc5_});
         TweenMax.to(this.§_-Nm§.mask,1,{"x":_loc6_});
         TweenMax.to(this.§_-Nm§.mask,1,{"width":_loc7_});
      }
      
      public function advanceTime(param1:Number) : void
      {
         var _loc4_:Image = null;
         var _loc2_:int = int(this.§_-21n§.length);
         var _loc3_:* = _loc2_;
         while(_loc3_--)
         {
            _loc4_ = this.§_-21n§[_loc3_];
            _loc4_.x += §_-l2q§ * _loc4_.scaleX * param1;
            if(_loc4_.x < 0 || _loc4_.x > this.§_-O2M§)
            {
               _loc4_.x -= Math.ceil(_loc2_ * 0.5) * _loc4_.width * _loc4_.scaleX;
            }
         }
      }
      
      private function §_-w3§() : void
      {
         var _loc3_:int = 0;
         var _loc5_:Image = null;
         this.§_-Nm§ = new Sprite();
         var _loc1_:Rectangle = this.windContainer.bounds;
         var _loc2_:Texture = §_-L2z§.getTexture("OneWindArrow_instance3");
         _loc3_ = Math.floor(_loc1_.width / _loc2_.width) - 2;
         this.§_-21n§ = new Vector.<Image>(_loc3_);
         var _loc4_:* = _loc3_;
         while(_loc4_--)
         {
            _loc5_ = new Image(_loc2_);
            _loc5_.alpha = 0.99;
            this.§_-Nm§.addChild(_loc5_);
            _loc5_.x = _loc5_.width * (_loc4_ + 1);
            _loc5_.y = -1;
            if(_loc4_ < _loc3_ * 0.5)
            {
               _loc5_.scaleX = -1;
            }
            this.§_-21n§[_loc4_] = _loc5_;
         }
         this.§_-O2M§ = _loc1_.width;
         this.§_-Nm§.mask = new Quad(this.§_-O2M§,_loc1_.height);
         this.§_-Nm§.alpha = 0.2;
         this.§_-Nm§.x = this.leftWind.x - this.leftWind.width;
         this.§_-Nm§.y = _loc1_.y;
         this.windContainer.addChild(this.§_-Nm§);
         WorldClock.clock.add(this);
      }
      
      public function §_-sb§(param1:Event) : void
      {
         this.setWind(Force.WIND.ax);
      }
   }
}

