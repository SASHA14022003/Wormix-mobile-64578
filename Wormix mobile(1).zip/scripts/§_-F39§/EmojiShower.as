package §_-F39§
{
   import §_-5Y§.§_-h2c§;
   import §_-b1F§.§_-G4§;
   import §_-l1K§.§_-W2f§;
   import §_-l2r§.§_-K1t§;
   import §_-m2s§.§_-R11§;
   import §_-r1C§.§_-h2B§;
   import com.greensock.TimelineLite;
   import com.greensock.TweenLite;
   import com.greensock.easing.Back;
   import com.hurlant.crypto.tls.§_-e1A§;
   import com.worlize.websocket.§_-ue§;
   import dragonBones.animation.WorldClock;
   import feathers.controls.NumericStepper;
   import flash.geom.Point;
   import flash.geom.Rectangle;
   import flash.utils.ByteArray;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.sets.ControlSets;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.messages.clans.structures.ClanChatMessageTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanNewsTO;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.GameObjectUtils;
   import ru.pragmatix.wormix.physics.HitTest;
   import ru.pragmatix.wormix.physics.model.UnitPhysicModel;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.utils.§_-g20§;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.BurningOil;
   import ru.pragmatix.wormix.weapons.ammo.ammoFactory.AmmosFactory;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.utils.Pool;
   import starling.utils.ScaleMode;
   
   public class EmojiShower
   {
      
      private var _binder:Binder;
      
      private var _target:DisplayObject;
      
      private var §_-OO§:TimelineLite = new TimelineLite();
      
      private var §_-R16§:Rectangle;
      
      private var §_-l2P§:Boolean;
      
      private var §_-D11§:Boolean;
      
      private var §_-x1z§:Sprite;
      
      public function EmojiShower(param1:DisplayObject, param2:Sprite, param3:Boolean, param4:Boolean)
      {
         super();
         this._target = param1;
         this.§_-x1z§ = param2;
         this.§_-l2P§ = param3;
         this.§_-D11§ = param4;
         this._binder = new Binder();
         var _loc5_:String = param4 ? "emoji_top" : "emoji_bottom";
         Application.uiBuilder.create(Application.assetManager.getObject(_loc5_),true,this._binder);
         this._binder._sticker.textureCache = §_-g20§.§_-W2i§();
         this._binder._sticker.scaleMode = ScaleMode.SHOW_ALL;
         this._binder._sticker.maintainAspectRatio = true;
         this._binder._container.scaleX = 0.001;
         this._binder._container.scaleY = 0.001;
         this._binder._sticker.addEventListener(Event.RESIZE,this.§_-y1R§);
         if(!param3)
         {
            this._binder._container.scaleX *= -1;
            this._binder._sticker.scaleX *= -1;
         }
         this.§_-R16§ = Pool.getRectangle();
      }
      
      private function §_-y1R§(param1:Event) : void
      {
         this._binder._sticker.alignPivot();
      }
      
      public function §_-C2k§(param1:String) : void
      {
         if(this.§_-OO§.active)
         {
            return;
         }
         var _loc2_:§_-R11§ = §_-R11§.§_-J1V§(param1);
         this._binder._sticker.source = §_-g20§.§_-3i§(_loc2_.§_-t1X§,_loc2_.§_-Wl§);
         var _loc3_:DisplayObject = this._binder._container;
         _loc3_.removeFromParent();
         if(this.§_-OO§)
         {
            this.§_-OO§.killTweensOf(_loc3_);
            this.§_-OO§.stop();
         }
         this.§_-OO§ = new TimelineLite({"onComplete":this.§_-W1R§});
         var _loc4_:Number = this.§_-l2P§ ? 0.001 : -0.001;
         var _loc5_:Number = 0.001;
         _loc3_.scaleX = _loc4_;
         _loc3_.scaleY = _loc5_;
         this.§_-R16§ = this._target.getBounds(Starling.current.stage,this.§_-R16§);
         this._binder._container.x = this.§_-l2P§ ? Number(this.§_-R16§.left) : Number(this.§_-R16§.right);
         this._binder._container.y = this.§_-D11§ ? Number(Math.max(this.§_-R16§.bottom,this.§_-R16§.bottom)) : Number(this.§_-R16§.bottom);
         this.§_-OO§.append(TweenLite.to(_loc3_,0.5,{
            "scaleX":_loc4_ * 1000,
            "scaleY":_loc5_ * 1000,
            "ease":Back.easeOut
         }));
         this.§_-OO§.append(TweenLite.to(_loc3_,0.5,{
            "scaleX":_loc4_,
            "scaleY":_loc5_,
            "ease":Back.easeIn
         }),1);
         this.§_-OO§.play();
         this.§_-x1z§.addChild(_loc3_);
      }
      
      private function §_-W1R§() : void
      {
         this._binder._container.removeFromParent();
      }
      
      public function dispose() : void
      {
         this.§_-R16§ = null;
         if(this.§_-OO§)
         {
            this.§_-OO§.killTweensOf(this._binder._container);
            this.§_-OO§.stop();
         }
         this._binder._sticker.removeEventListener(Event.RESIZE,this.§_-y1R§);
         this._binder._container.removeFromParent(true);
      }
      
      public function §_-c1v§(param1:Boolean) : void
      {
         if(this._binder)
         {
            this._binder._container.visible = param1;
         }
      }
   }
}

import feathers.controls.ImageLoader;
import starling.display.Sprite;

class Binder
{
   
   public var _container:Sprite;
   
   public var _sticker:ImageLoader;
   
   public function Binder()
   {
      super();
   }
}
