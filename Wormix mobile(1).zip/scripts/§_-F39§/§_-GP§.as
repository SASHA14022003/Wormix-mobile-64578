package §_-F39§
{
   import §_-31W§.§_-r26§;
   import §_-A2U§.§_-A23§;
   import §_-B2z§.§_-63i§;
   import §_-C3f§.§_-yG§;
   import §_-CF§.§_-E19§;
   import §_-DJ§.§_-fH§;
   import §_-Nq§.*;
   import §_-TF§.§_-y2n§;
   import §_-k2s§.§_-8c§;
   import §_-n1w§.*;
   import §_-q26§.*;
   import com.distriqt.extension.inappbilling.Purchase;
   import com.greensock.events.LoaderEvent;
   import feathers.core.ITextRenderer;
   import flash.errors.IllegalOperationError;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.ClanServiceResult;
   import ru.pragmatix.wormix.messages.clans.response.CommonClanResponse;
   import ru.pragmatix.wormix.messages.clans.response.LoginClanEnterAccount;
   import ru.pragmatix.wormix.messages.clans.structures.ClanMemberTO;
   import ru.pragmatix.wormix.messages.client.AppleVerifyReceipt;
   import ru.pragmatix.wormix.utils.§_-6A§;
   import starling.display.DisplayObject;
   import starling.display.Sprite;
   
   public class §_-GP§ extends §_-S2k§
   {
      
      private var text:ITextRenderer;
      
      private var textShadow:ITextRenderer;
      
      public function §_-GP§(param1:DisplayObject, param2:ITextRenderer = null, param3:ITextRenderer = null, param4:Boolean = false, param5:Number = 1, param6:Boolean = false)
      {
         super(param1 as Sprite,param4,param5,param6,false);
         if(param2)
         {
            this.text = param2;
         }
         else
         {
            this.text = getChildByName("text") as ITextRenderer;
         }
         if(param3)
         {
            this.textShadow = param3;
         }
         else
         {
            this.textShadow = getChildByName("textShadow") as ITextRenderer;
         }
      }
      
      override public function setValue(param1:Number) : void
      {
         param1 = Number(Math.max(0,param1));
         super.setValue(param1);
         this.text.text = Math.floor(param1).toString() + "/" + Math.floor(maxValue).toString();
         if(this.textShadow)
         {
            this.textShadow.text = Math.floor(param1).toString() + "/" + Math.floor(maxValue).toString();
         }
      }
      
      override protected function §_-A8§(param1:Number) : void
      {
         super.§_-A8§(param1);
         this.text.text = Math.floor(param1).toString() + "/" + Math.floor(maxValue).toString();
         if(this.textShadow)
         {
            this.textShadow.text = Math.floor(param1).toString() + "/" + Math.floor(maxValue).toString();
         }
      }
   }
}

