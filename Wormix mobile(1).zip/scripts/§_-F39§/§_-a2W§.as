package §_-F39§
{
   import §_-12a§.§_-lc§;
   import §_-RE§.§_-52p§;
   import §_-Vu§.*;
   import §_-Y1O§.*;
   import com.distriqt.extension.inappbilling.events.ProductEvent;
   import feathers.core.ITextRenderer;
   import flash.events.TimerEvent;
   import flash.utils.Timer;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.model.items.craft.§_-6S§;
   
   public class §_-a2W§
   {
      
      private static var queue:Array = new Array();
      
      private static var timer:Timer = null;
      
      private static var textField:ITextRenderer = null;
      
      public function §_-a2W§()
      {
         super();
      }
      
      public static function init(param1:ITextRenderer) : void
      {
         textField = param1;
         §_-731§();
      }
      
      public static function §_-1H§(param1:String, param2:Boolean = false) : void
      {
         if(param2)
         {
            reset();
         }
         queue.push(param1);
         if(timer == null)
         {
            timer = new Timer(10);
            timer.addEventListener(TimerEvent.TIMER,onTimer);
            timer.start();
         }
      }
      
      public static function reset() : void
      {
         queue = new Array();
         if(timer != null)
         {
            timer.stop();
            timer = null;
         }
         §_-731§();
      }
      
      private static function onTimer(param1:TimerEvent) : void
      {
         var _loc2_:String = null;
         §_-731§();
         if(queue.length > 0)
         {
            _loc2_ = queue.pop();
            timer.delay = 3000;
            if(textField)
            {
               textField = setText(_loc2_);
               textField.visible = true;
            }
         }
         else
         {
            timer.stop();
            timer = null;
         }
      }
      
      private static function §_-731§() : void
      {
         if(!textField)
         {
            return;
         }
         textField.text = "";
         textField.visible = false;
      }
      
      public static function setText(param1:String) : ITextRenderer
      {
         if(textField)
         {
            textField.text = param1;
         }
         return textField;
      }
   }
}

