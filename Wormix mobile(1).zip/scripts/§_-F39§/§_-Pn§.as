package §_-F39§
{
   import §_-62§.§_-G1p§;
   import §_-62§.§_-O2H§;
   import §_-B1y§.Cookie;
   import §_-B2z§.*;
   import §_-Cl§.§_-L2z§;
   import §_-L1w§.§_-CD§;
   import §_-P1z§.*;
   import §_-j22§.§_-5g§;
   import com.worlize.websocket.§_-Y2T§;
   import feathers.controls.Button;
   import feathers.skins.ImageSkin;
   import flash.geom.Rectangle;
   import flash.utils.ByteArray;
   import flash.utils.getQualifiedClassName;
   import ru.pragmatix.flox.logger.§_-11S§;
   import ru.pragmatix.flox.social.utils.storage.EncryptedLocalStorageCookie;
   import ru.pragmatix.flox.social.utils.storage.StorageType;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-Q2v§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.Waypoint;
   import ru.pragmatix.wormix.scene.interaction.SceneInteractionData;
   import starling.core.Starling;
   import starling.display.Image;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.textures.Texture;
   import starling.utils.Align;
   import starling.utils.Pool;
   import starling.utils.RectangleUtil;
   import starling.utils.ScaleMode;
   
   public class §_-Pn§
   {
      
      private static const §_-u2D§:Number = 0.99932861328125;
      
      private static const §_-O2S§:Number = 1.14019775390625;
      
      private static const §_-G3S§:Number = 96;
      
      private var button:Button;
      
      private var defaultIcon:Image;
      
      private var downIcon:Image;
      
      private var defaultTexture:Texture;
      
      private var §_-e1c§:Texture;
      
      private var §_-E3Z§:Texture;
      
      private var §_-GX§:Rectangle;
      
      public function §_-Pn§(param1:Button)
      {
         super();
         this.§_-GX§ = Pool.getRectangle();
         this.button = param1;
         var _loc2_:ImageSkin = (param1.defaultIcon is ImageSkin ? param1.defaultIcon : (param1.defaultIcon as Sprite).getChildAt(0)) as ImageSkin;
         this.defaultTexture = _loc2_.texture;
         this.§_-e1c§ = Texture.empty(4,4);
         this.§_-q1P§(param1);
      }
      
      private function §_-q1P§(param1:Button) : void
      {
         this.defaultIcon = new Image(this.defaultTexture);
         this.§_-as§(this.defaultIcon,§_-u2D§);
         this.downIcon = new Image(this.defaultTexture);
         this.§_-as§(this.downIcon,§_-O2S§);
         param1.defaultIcon = this.defaultIcon;
         param1.downIcon = this.downIcon;
      }
      
      private function §_-as§(param1:Image, param2:Number) : void
      {
         param1.width *= param2;
         param1.height *= param2;
      }
      
      public function §_-51g§(param1:int) : void
      {
         var _loc2_:§_-O2H§ = §_-G1p§.§_-I4§(param1);
         if(Boolean(_loc2_) && Boolean(_loc2_.§_-92P§()) && _loc2_.§_-92P§() != "")
         {
            this.§_-s2u§(§_-L2z§.getTexture(_loc2_.§_-92P§()));
         }
      }
      
      public function §_-n2O§(param1:String) : void
      {
         var _loc2_:Texture = §_-L2z§.getTexture(param1);
         this.§_-s2u§(_loc2_);
      }
      
      public function §_-Q2D§() : void
      {
         this.§_-s2u§(this.§_-e1c§);
      }
      
      private function §_-s2u§(param1:Texture) : void
      {
         if(!param1 || this.§_-E3Z§ == param1)
         {
            return;
         }
         this.§_-E3Z§ = param1;
         this.§_-b25§(this.defaultIcon,param1);
         this.§_-b25§(this.downIcon,param1);
         this.§_-as§(this.defaultIcon,§_-u2D§);
         this.§_-as§(this.downIcon,§_-O2S§);
         this.button.invalidate();
      }
      
      private function §_-b25§(param1:Image, param2:Texture) : void
      {
         var _loc3_:Rectangle = null;
         var _loc4_:Rectangle = null;
         param1.scale = 1;
         param1.texture = param2;
         param1.readjustSize();
         if(param2.width > §_-G3S§ || param2.height > §_-G3S§)
         {
            _loc3_ = Pool.getRectangle(0,0,param1.width,param1.height);
            _loc4_ = Pool.getRectangle(0,0,§_-G3S§,§_-G3S§);
            RectangleUtil.fit(_loc3_,_loc4_,ScaleMode.SHOW_ALL,false,this.§_-GX§);
            param1.width = this.§_-GX§.width;
            param1.height = this.§_-GX§.height;
            Pool.putRectangle(_loc3_);
            Pool.putRectangle(_loc4_);
         }
      }
      
      public function dispose() : void
      {
         if(this.button)
         {
            this.button.dispose();
            this.button = null;
         }
         if(this.defaultIcon)
         {
            this.defaultIcon.texture.dispose();
            this.defaultIcon.dispose();
            this.defaultIcon = null;
         }
         if(this.defaultTexture)
         {
            this.defaultTexture.dispose();
            this.defaultTexture = null;
         }
         Pool.putRectangle(this.§_-GX§);
         this.§_-GX§ = null;
      }
   }
}

