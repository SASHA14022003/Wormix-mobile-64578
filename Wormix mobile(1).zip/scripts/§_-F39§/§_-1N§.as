package §_-F39§
{
   import §_-51M§.Cat;
   import §_-63U§.§_-21K§;
   import §_-C3f§.§_-4I§;
   import §_-CF§.§_-E19§;
   import §_-D3A§.§_-TZ§;
   import §_-E1I§.§_-b2n§;
   import §_-SP§.§_-l8§;
   import §_-Tm§.§_-RF§;
   import §_-U1i§.§_-I3t§;
   import §_-Vg§.§_-K3K§;
   import §_-Z1K§.§_-q24§;
   import §_-k1u§.§_-2m§;
   import §_-k1u§.§_-Oi§;
   import §_-l1K§.§_-W2f§;
   import §_-l1g§.§_-L3Q§;
   import §_-w2i§.§_-Ia§;
   import feathers.controls.Button;
   import feathers.controls.Slider;
   import ru.pragmatix.wormix.Scene;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.sets.ControlSets;
   import ru.pragmatix.wormix.game.§_-eX§;
   import ru.pragmatix.wormix.gui.§_-Q2v§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.§_-P1h§;
   import ru.pragmatix.wormix.gui.menu.§_-g2i§;
   import ru.pragmatix.wormix.messages.clans.response.*;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.utils.StringUtil;
   import ru.pragmatix.wormix.utils.§_-Cq§;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.utils.ScaleMode;
   import starlingbuilder.extensions.uicomponents.ContainerButtonWithStates;
   
   public class §_-1N§ extends §_-g2i§
   {
      
      private var §_-p1A§:Array = [];
      
      private var §_-F2x§:§_-I3t§;
      
      public function §_-1N§(param1:DisplayObject)
      {
         super(param1 as DisplayObjectContainer);
         §_-X1j§.§_-12n§.addEventListener(Event.COMPLETE,this.onSceneCreated);
      }
      
      private function onSceneCreated(param1:Event) : void
      {
         §_-X1j§.§_-12n§.removeEventListener(Event.COMPLETE,this.onSceneCreated);
         var _loc2_:Scene = §_-X1j§.§_-12n§.scene;
         if(_loc2_)
         {
            §_-TZ§.addListener(_loc2_,§_-L3Q§.UNIT_ACTIVATION,this.§_-Vs§);
         }
      }
      
      override public function dispose() : void
      {
         super.dispose();
         var _loc1_:Scene = §_-X1j§.§_-12n§.scene;
         if(_loc1_)
         {
            §_-TZ§.addListener(_loc1_,§_-L3Q§.UNIT_ACTIVATION,this.§_-Vs§);
         }
      }
      
      private function §_-Vs§(param1:Event) : void
      {
         var _loc2_:§_-eX§ = §_-X1j§.§_-12n§.gameMaster;
         if(this.§_-F2x§)
         {
            this.§_-F2x§.removeEventListener(Event.CHANGE,this.§_-dN§);
            this.§_-F2x§ = null;
         }
         if(Boolean(_loc2_) && _loc2_.§_-E3b§())
         {
            this.§_-F2x§ = _loc2_.activeUnit.§_-F2x§;
            this.§_-F2x§.addEventListener(Event.CHANGE,this.§_-dN§);
         }
         this.§_-dN§(null);
      }
      
      private function §_-dN§(param1:Event) : void
      {
         if(param1 == null)
         {
            this.setData([]);
         }
         else
         {
            this.setData(this.§_-F2x§.hats);
         }
      }
      
      override public function setData(param1:Array) : void
      {
         var _loc4_:int = 0;
         var _loc5_:int = 0;
         if(this.§_-p1A§.length == 0 && param1.length == 0)
         {
            return;
         }
         var _loc2_:Array = [];
         var _loc3_:int = 0;
         while(_loc3_ < param1.length)
         {
            _loc2_.push(param1[_loc3_].getId());
            _loc3_++;
         }
         if(_loc2_.length == 0 && this.§_-p1A§.length > 0)
         {
            this.§_-p1A§ = [];
            super.setData(this.§_-p1A§);
            super.update();
         }
         for each(_loc4_ in _loc2_)
         {
            if(_loc2_.length != this.§_-p1A§.length || this.§_-p1A§.indexOf(_loc4_) == -1)
            {
               this.§_-p1A§ = [];
               _loc5_ = 0;
               while(_loc5_ < param1.length)
               {
                  this.§_-p1A§.push(param1[_loc5_].getId());
                  _loc5_++;
               }
               super.setData(param1);
               super.update();
            }
         }
      }
      
      override protected function §_-mt§() : Sprite
      {
         return §_-j2l§() as Sprite;
      }
      
      override protected function §_-LP§(param1:DisplayObject) : §_-P1h§
      {
         return new §_-R§(param1);
      }
      
      override protected function §_-O2y§() : void
      {
         §_-yp§ = false;
         §_-A1t§ = §_-l8§.CLICK;
         §_-jv§ = false;
         §_-L1i§ = true;
         super.§_-O2y§();
      }
      
      override public function hide() : void
      {
      }
      
      override protected function §_-b1H§() : void
      {
         var _loc1_:§_-eX§ = §_-X1j§.§_-12n§.gameMaster;
         if(!_loc1_)
         {
            return;
         }
         var _loc2_:§_-01J§ = _loc1_.activeUnit;
         if(Boolean(§_-T1W§ && _loc1_.§_-E3b§() && _loc1_.§_-42C§() && _loc2_.§_-vt§) && Boolean(this.§_-F2x§) && this.§_-F2x§.§_-mA§)
         {
            this.§_-F2x§.§_-F3N§();
            §_-RF§.fire(§_-RF§.§_-oT§,§_-p2w§().getId(),_loc2_);
            super.§_-b1H§();
         }
      }
      
      public function §_-Y1w§() : void
      {
         §_-T1W§ = false;
         this.§_-c1v§(true);
         §_-v12§(false);
         update();
      }
      
      public function §_-K3A§() : void
      {
         this.§_-c1v§(true);
         §_-T1W§ = true;
         §_-v12§(true);
         update();
      }
      
      override public function §_-c1v§(param1:Boolean) : void
      {
         super.§_-c1v§(param1);
      }
      
      public function §_-dR§(param1:Boolean = true) : void
      {
         var _loc2_:§_-R§ = null;
         for each(_loc2_ in cells)
         {
            _loc2_.§_-M1g§ = param1;
         }
      }
   }
}

