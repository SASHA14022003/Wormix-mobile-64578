package §_-F39§
{
   import §_-5Y§.§_-h2c§;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-zF§;
   import §_-K3q§.§_-L3A§;
   import §_-Y1Q§.§_-61Z§;
   import §_-zI§.§_-A1s§;
   import com.greensock.events.LoaderEvent;
   import flash.events.Event;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.menu.§_-3m§;
   import ru.pragmatix.wormix.gui.menu.§_-P1h§;
   import ru.pragmatix.wormix.messages.clans.main.server.ClanMemberStructure;
   import ru.pragmatix.wormix.messages.clans.structures.ClanChatMessageTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanNewsTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-i14§;
   import ru.pragmatix.wormix.utils.§_-6A§;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   
   public class §_-R§ extends §_-P1h§
   {
      
      private var icon:§_-3m§;
      
      private var §_-pG§:Boolean = false;
      
      public function §_-R§(param1:DisplayObject)
      {
         super(param1 as DisplayObjectContainer);
         §_-w1L§ = true;
         this.icon = new §_-3m§(getChildByName("icon"));
         this.icon.getContainer().x = 0;
         this.icon.getContainer().y = 0;
      }
      
      override public function setSelected(param1:Boolean) : void
      {
         if(!this.§_-pG§)
         {
            super.setSelected(param1);
         }
      }
      
      override public function setItem(param1:Object) : void
      {
         var _loc3_:§_-zF§ = null;
         super.setItem(param1);
         var _loc2_:§_-i14§ = param1 as §_-i14§;
         if(_loc2_)
         {
            _loc3_ = §_-G1p§.§_-12J§(_loc2_.hatId,§_-X1j§.§_-12n§.gameMaster.activeUnit.record.§_-P2e§());
            this.icon.setItem(_loc3_,0.9);
            §_-v12§(true);
            §_-tx§(false);
            return;
         }
         this.icon.setItem(null);
      }
      
      override public function dispose() : void
      {
         if(this.icon)
         {
            this.icon.dispose();
            this.icon = null;
         }
         super.dispose();
      }
      
      public function set §_-M1g§(param1:Boolean) : void
      {
         this.§_-pG§ = param1;
      }
   }
}

