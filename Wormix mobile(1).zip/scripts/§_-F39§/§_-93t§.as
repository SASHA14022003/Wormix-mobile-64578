package §_-F39§
{
   import §_-U1i§.§_-b1k§;
   import §_-Y1O§.§_-42h§;
   import §_-p24§.*;
   import §_-t1J§.§_-B2R§;
   import §_-z1g§.§_-F4§;
   import feathers.core.ITextRenderer;
   import ru.pragmatix.wormix.gui.§_-E2w§;
   import ru.pragmatix.wormix.weapons.render.IRenderer;
   import starling.display.DisplayObjectContainer;
   
   public class §_-93t§ extends §_-E2w§
   {
      
      private var §_-G3g§:int;
      
      private var txt:ITextRenderer;
      
      public function §_-93t§(param1:DisplayObjectContainer)
      {
         super(param1);
         this.txt = ITextRenderer(getChildByName("txt"));
         this.txt.text = "0";
         this.§_-G3g§ = y;
      }
      
      public function show(param1:int) : void
      {
         this.txt.visible = true;
         this.txt.text = param1.toString();
         §_-c1v§(true);
      }
      
      public function hide() : void
      {
         this.txt.visible = false;
      }
      
      public function set time(param1:int) : void
      {
         this.txt.text = param1.toString();
      }
      
      public function get time() : int
      {
         return parseInt(this.txt.text);
      }
   }
}

