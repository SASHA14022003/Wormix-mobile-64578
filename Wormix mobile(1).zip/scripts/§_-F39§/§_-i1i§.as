package §_-F39§
{
   import §_-937§.§_-BO§;
   import §_-D3A§.§_-TZ§;
   import §_-L1H§.§_-b2K§;
   import §_-Tm§.§_-RF§;
   import §_-Y1O§.§_-42h§;
   import §_-Y1O§.§_-V23§;
   import §_-l1g§.§_-L3Q§;
   import feathers.controls.LayoutGroup;
   import feathers.controls.text.TextFieldTextRenderer;
   import feathers.controls.text.TextInstanceCreator;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.VerticalAlign;
   import feathers.layout.VerticalLayout;
   import flash.text.TextFormatAlign;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.BunkerBusterMissile;
   import starling.events.Event;
   import starling.filters.DropShadowFilter;
   import starling.utils.Color;
   import starling.utils.Pool;
   
   public class §_-i1i§ extends LayoutGroup
   {
      
      private var §_-I38§:TextFieldTextRenderer;
      
      private var §_-6H§:TextFieldTextRenderer;
      
      private var §_-U1R§:DropShadowFilter;
      
      private var §_-q2L§:int;
      
      private var §_-E3B§:String;
      
      private var §_-I3G§:int;
      
      private var §_-w2H§:uint;
      
      private var §_-e1a§:Boolean;
      
      private var §_-m2V§:Boolean;
      
      public function §_-i1i§(param1:String, param2:int, param3:uint, param4:Boolean)
      {
         super();
         this.§_-E3B§ = param1;
         this.§_-I3G§ = param2;
         this.§_-w2H§ = param3;
         this.§_-e1a§ = param4;
         this.§_-q2L§ = §_-BO§.§_-EM§;
         pivotX = 100;
         pivotY = -15;
      }
      
      override public function dispose() : void
      {
         super.dispose();
         this.§_-U1R§.dispose();
         filter = null;
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         var _loc1_:VerticalLayout = new VerticalLayout();
         _loc1_.horizontalAlign = HorizontalAlign.CENTER;
         _loc1_.verticalAlign = VerticalAlign.BOTTOM;
         this.layout = _loc1_;
         this.§_-I38§ = TextInstanceCreator.createTextRenderer(16,Color.RED,TextFormatAlign.CENTER) as TextFieldTextRenderer;
         this.§_-I38§.width = 200;
         this.§_-I38§.updateSnapshotOnScaleChange = false;
         this.§_-I38§.wordWrap = true;
         this.§_-6H§ = TextInstanceCreator.createTextRenderer(16,Color.RED,TextFormatAlign.CENTER) as TextFieldTextRenderer;
         this.§_-6H§.width = 200;
         this.§_-6H§.updateSnapshotOnScaleChange = false;
         addChild(this.§_-I38§);
         addChild(this.§_-6H§);
         this.§_-U1R§ = new DropShadowFilter(1,0.785,0,0.9,0,1);
         this.filter = this.§_-U1R§;
      }
      
      override protected function draw() : void
      {
         super.draw();
         if(isInvalid(INVALIDATION_FLAG_DATA))
         {
            this.§_-I38§.text = this.§_-E3B§;
            this.§_-6H§.text = this.§_-I3G§.toString();
            this.§_-I38§.textFormat.color = this.§_-31l§(this.§_-w2H§);
            this.§_-6H§.textFormat.color = this.§_-31l§(this.§_-w2H§);
            invalidate(INVALIDATION_FLAG_SKIN);
         }
         if(isInvalid(INVALIDATION_FLAG_STATE))
         {
            if(this.§_-e1a§)
            {
               this.§_-I38§.visible = this.§_-q2L§ == §_-BO§.§_-EM§;
               this.§_-6H§.visible = this.§_-q2L§ != §_-BO§.§_-A3n§;
            }
            else
            {
               this.§_-I38§.visible = false;
               this.§_-6H§.visible = this.§_-q2L§ != §_-BO§.§_-A3n§;
            }
            invalidate(INVALIDATION_FLAG_SKIN);
         }
         if(isInvalid(INVALIDATION_FLAG_SKIN))
         {
            if(this.§_-U1R§)
            {
               this.§_-U1R§.cache();
            }
         }
      }
      
      override public function set visible(param1:Boolean) : void
      {
         var _loc2_:Boolean = this.§_-m2V§ ? false : param1;
         if(super.visible != _loc2_)
         {
            super.visible = _loc2_;
         }
      }
      
      public function get §_-W2s§() : Boolean
      {
         return this.§_-m2V§;
      }
      
      public function set §_-W2s§(param1:Boolean) : void
      {
         this.§_-m2V§ = param1;
      }
      
      private function §_-31l§(param1:int) : int
      {
         switch(param1)
         {
            case 0:
               return 9095240;
            case 1:
               return 16732526;
            case 2:
               return 16771137;
            case 3:
               return 3266303;
            default:
               return 0;
         }
      }
      
      public function set §_-H3g§(param1:int) : void
      {
         if(this.§_-I3G§ != param1)
         {
            this.§_-I3G§ = param1;
            invalidate(INVALIDATION_FLAG_DATA);
         }
      }
      
      public function set §_-w1f§(param1:int) : void
      {
         this.§_-q2L§ = param1;
         invalidate(INVALIDATION_FLAG_STATE);
      }
      
      public function §_-i13§() : void
      {
         invalidate(INVALIDATION_FLAG_SKIN);
      }
   }
}

