package §_-F39§
{
   import §_-12a§.KamikazeBuff;
   import §_-62§.*;
   import §_-B1y§.Cookie;
   import §_-B1y§.§_-83E§;
   import §_-B1y§.§_-bs§;
   import §_-B2z§.*;
   import §_-DJ§.§_-fH§;
   import §_-DJ§.§_-lq§;
   import §_-L1H§.§_-C3e§;
   import §_-P1z§.*;
   import §_-Tm§.§_-K1I§;
   import §_-Y1O§.§_-V23§;
   import §_-Y1O§.§_-y1o§;
   import §_-Y1b§.§_-81l§;
   import §_-j1w§.§_-L1x§;
   import §_-r1C§.§_-h2B§;
   import §_-s20§.§_-J2g§;
   import §_-s20§.§_-d21§;
   import §_-z1g§.§_-F4§;
   import feathers.controls.LayoutGroup;
   import feathers.controls.NumericStepper;
   import feathers.controls.ToggleButton;
   import flash.events.Event;
   import flash.events.IOErrorEvent;
   import flash.events.SecurityErrorEvent;
   import flash.geom.Point;
   import flash.utils.getDefinitionByName;
   import flash.utils.getQualifiedClassName;
   import flash.utils.setTimeout;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.client.SteamTransactionInitRequest;
   import ru.pragmatix.wormix.messages.server.SteamTransactionInitResponse;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   import ru.pragmatix.wormix.model.user.§_-r1d§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.weapons.Weapon;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   import starling.utils.Pool;
   
   public class §_-Ey§
   {
      
      private static var button:ToggleButton;
      
      private static var §_-y2d§:§_-lq§;
      
      private static const SHOW_WEAPON_TIPS:String = "SHOW_WEAPON_TIPS";
      
      private static const §_-H1Y§:String = "closed.weapon.tips";
      
      public function §_-Ey§(param1:ToggleButton = null, param2:LayoutGroup = null)
      {
         super();
         if(param1)
         {
            button = param1;
            button.addEventListener(starling.events.Event.TRIGGERED,§_-i1W§);
         }
         §_-y2d§ = new §_-lq§(param2);
         §_-y2d§.y = Application.§_-i1N§.stageHeight * 0.1;
         §_-y2d§.addEventListener(starling.events.Event.CHANGE,this.§_-R23§);
         §_-y2d§.hide();
      }
      
      private static function §_-i1W§(param1:starling.events.Event) : void
      {
         §_-h2B§.play(§_-d27§.§_-md§);
         setTimeout(§_-t11§,10);
      }
      
      private static function §_-Z1J§() : Boolean
      {
         return Cookie.§_-t2R§(SHOW_WEAPON_TIPS,false);
      }
      
      private static function §_-x2f§(param1:Boolean) : void
      {
         return Cookie.setValue(SHOW_WEAPON_TIPS,param1);
      }
      
      private static function §_-F1U§() : Boolean
      {
         return Application.userProfile.getLevel() <= §_-F4§.§_-QX§;
      }
      
      public static function §_-t11§() : void
      {
         if(button)
         {
            button.visible = §_-F1U§() && !§_-X1j§.§_-12n§.isLearning;
            §_-y2d§.§_-918§(!button.visible || !button.isEnabled || !button.isSelected);
            if(§_-X1j§.§_-12n§.isLearning)
            {
               §_-x2f§(true);
            }
            else
            {
               §_-x2f§(button.isSelected);
            }
         }
         else
         {
            §_-y2d§.§_-918§(!§_-Z1J§());
         }
      }
      
      public static function §_-r2x§() : void
      {
         §_-y2d§.§_-r2x§();
      }
      
      public static function §_-1H§(param1:String) : void
      {
         §_-y2d§.§_-1H§(param1);
      }
      
      public static function §_-s1m§() : void
      {
         §_-y2d§.§_-918§(true);
      }
      
      private function §_-R23§(param1:starling.events.Event) : void
      {
         Cookie.setValue(§_-H1Y§,§_-y2d§.§_-y14§);
      }
      
      public function §_-NI§(param1:Boolean) : void
      {
         if(button)
         {
            button.isEnabled = !param1;
         }
         §_-t11§();
      }
      
      public function §_-936§() : void
      {
         if(button)
         {
            button.isSelected = §_-Z1J§();
         }
         §_-y2d§.§_-y14§ = Cookie.getValue(§_-H1Y§,new Vector.<String>()) as Vector.<String>;
         §_-t11§();
      }
      
      public function dispose() : void
      {
         §_-y2d§.removeEventListener(starling.events.Event.CHANGE,this.§_-R23§);
         if(button)
         {
            button.removeEventListener(starling.events.Event.TRIGGERED,§_-i1W§);
            button.dispose();
            button = null;
         }
         if(§_-y2d§)
         {
            §_-y2d§.hide();
            §_-y2d§.dispose();
         }
         §_-y2d§ = null;
      }
   }
}

