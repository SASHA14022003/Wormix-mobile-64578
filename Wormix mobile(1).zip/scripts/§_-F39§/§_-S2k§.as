package §_-F39§
{
   import §_-31N§.§_-42G§;
   import §_-31Y§.§_-D3B§;
   import §_-D3A§.§_-TZ§;
   import §_-L1H§.§_-C3e§;
   import §_-Y1O§.*;
   import §_-l1K§.§_-cZ§;
   import §_-l1g§.§_-L3Q§;
   import §_-r1C§.§_-h2B§;
   import §_-x2Q§.§_-dU§;
   import §_-z1g§.§_-M2v§;
   import com.greensock.TweenMax;
   import com.greensock.events.LoaderEvent;
   import com.greensock.loading.LoaderStatus;
   import com.greensock.loading.core.*;
   import flash.events.Event;
   import flash.geom.ColorTransform;
   import flash.geom.Point;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.*;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.CollideType;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.LaserRay;
   import ru.pragmatix.wormix.weapons.ammo.phase.FirePhase;
   import starling.display.Quad;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.utils.Pool;
   
   public class §_-S2k§ extends §_-E2w§
   {
      
      protected var maxValue:Number;
      
      protected var maxWidth:Number;
      
      protected var value:Number = 0;
      
      protected var scrollRect:Quad;
      
      protected var §_-91h§:Boolean;
      
      protected var §_-s1X§:Object = {};
      
      private var §_-J1E§:Boolean;
      
      private var reverse:Boolean;
      
      public function §_-S2k§(param1:Sprite, param2:Boolean = false, param3:Number = 1, param4:Boolean = false, param5:Boolean = true)
      {
         super(param1);
         this.§_-J1E§ = param4;
         this.reverse = false;
         this.maxWidth = param1.width;
         if(param5)
         {
            this.scrollRect = new Quad(param1.width,param1.height);
            if(param1.scaleY < 0)
            {
               this.scrollRect.y = -this.scrollRect.y - param1.height;
            }
            param1.mask = this.scrollRect;
         }
         this.maxValue = param3;
         this.§_-91h§ = param2;
      }
      
      public function set §_-D26§(param1:Boolean) : void
      {
         this.reverse = param1;
      }
      
      public function §_-E2N§(param1:Number) : void
      {
         this.maxValue = param1;
      }
      
      public function setValue(param1:Number) : void
      {
         if(this.§_-91h§)
         {
            TweenMax.killTweensOf(this.§_-s1X§);
            this.§_-s1X§.value = this.value;
            TweenMax.to(this.§_-s1X§,1,{
               "value":param1,
               "onUpdate":this.update,
               "onUpdateParams":[this.§_-s1X§]
            });
         }
         else
         {
            this.§_-A8§(param1);
         }
      }
      
      private function update(param1:Object) : void
      {
         this.§_-A8§(param1.value);
      }
      
      protected function §_-A8§(param1:Number) : void
      {
         this.value = param1;
         var _loc2_:Sprite = getContainer() as Sprite;
         var _loc3_:Number = this.maxWidth * Math.min(1,param1 / this.maxValue);
         if(_loc2_)
         {
            if(this.scrollRect)
            {
               this.scrollRect.width = _loc3_;
               _loc2_.mask = this.scrollRect;
               if(this.reverse)
               {
                  _loc2_.mask.x -= this.scrollRect.width;
               }
               if(this.§_-J1E§)
               {
                  _loc2_.mask.x += this.maxWidth - this.scrollRect.width;
               }
            }
            else
            {
               if(this.§_-J1E§)
               {
                  _loc2_.x += _loc2_.width - _loc3_;
               }
               this.§_-z1Y§(_loc3_);
            }
            _loc2_.visible = param1 != 0;
         }
      }
      
      private function §_-z1Y§(param1:Number) : void
      {
         if(§_-j2l§().numChildren == 1)
         {
            §_-j2l§().getChildAt(0).width = param1;
         }
         container.width = param1;
      }
      
      public function getValue() : Number
      {
         return this.value;
      }
   }
}

