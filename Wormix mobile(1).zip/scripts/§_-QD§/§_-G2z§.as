package §_-QD§
{
   import §_-H16§.*;
   import §_-Vg§.*;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.messages.clans.request.PostToClanChatRequest;
   import ru.pragmatix.wormix.messages.clans.structures.ClanMemberTO;
   
   public class §_-G2z§
   {
      
      public static const §_-Y2A§:String = "players-rating-load-complete";
      
      public static const §_-S1V§:String = "players-rating-load-failed";
      
      public static const §_-g1A§:String = "clans-rating-load-complete";
      
      public static const §_-b20§:String = "clans-rating-load-failed";
      
      public function §_-G2z§()
      {
         super();
      }
   }
}

