package §_-H3§
{
   import §_-21p§.§_-4w§;
   import §_-31N§.§_-42G§;
   import §_-62§.*;
   import §_-82l§.§_-1I§;
   import §_-A1K§.§_-TA§;
   import §_-B2z§.§_-63i§;
   import §_-C3f§.§_-yG§;
   import §_-CF§.§_-x2t§;
   import §_-DJ§.§_-fH§;
   import §_-S§.*;
   import §_-T2h§.*;
   import §_-TF§.§_-P19§;
   import §_-Tm§.§_-K1I§;
   import §_-U1i§.§_-J1§;
   import §_-U1i§.§_-XA§;
   import §_-U1i§.§_-hK§;
   import §_-Y1O§.§_-V23§;
   import §_-Y1O§.§_-y1o§;
   import §_-Y1b§.§_-OP§;
   import §_-Z1K§.§_-q24§;
   import §_-Z1L§.§_-A2V§;
   import §_-b1F§.§_-G4§;
   import §_-d26§.§_-c2E§;
   import §_-jF§.BundleDescriptionFeatureRenderer;
   import §_-l1K§.§_-W2f§;
   import §_-l1g§.§_-L3Q§;
   import §_-p14§.§_-A3Y§;
   import §_-p14§.§_-pP§;
   import §_-q26§.*;
   import §_-r1C§.§_-h2B§;
   import §_-s20§.§_-6a§;
   import com.distriqt.extension.inappbilling.Product;
   import com.distriqt.extension.inappbilling.Purchase;
   import com.mesmotronic.ane.AndroidFullScreen;
   import feathers.controls.ScrollPolicy;
   import feathers.layout.VerticalLayout;
   import feathers.themes.styles.AlternateScrollBarStyles;
   import flash.events.Event;
   import flash.events.NativeWindowDisplayStateEvent;
   import flash.utils.ByteArray;
   import flash.utils.Dictionary;
   import flash.utils.IDataOutput;
   import ru.pragmatix.flox.logger.§_-93v§;
   import ru.pragmatix.wormix.controller.§_-D8§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.sets.ControlSets;
   import ru.pragmatix.wormix.fx.AnimationStatesRenderer;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.game.§_-eX§;
   import ru.pragmatix.wormix.game.ai.*;
   import ru.pragmatix.wormix.gui.§_-Q2v§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.request.TopClansRequest;
   import ru.pragmatix.wormix.messages.clans.response.TopClansResponse;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.client.GoogleValidateInappPurchase;
   import ru.pragmatix.wormix.messages.structures.ChatMessage;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   import ru.pragmatix.wormix.objects.*;
   import ru.pragmatix.wormix.physics.Force;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.pvp.messages.client.PvpActionEx;
   import ru.pragmatix.wormix.pvp.messages.client.PvpCommand;
   import ru.pragmatix.wormix.pvp.messages.client.PvpDropPlayer;
   import ru.pragmatix.wormix.pvp.messages.client.PvpEndTurn;
   import ru.pragmatix.wormix.pvp.messages.client.PvpEndTurnResponse;
   import ru.pragmatix.wormix.pvp.messages.client.PvpRetryCommandRequestClient;
   import ru.pragmatix.wormix.pvp.messages.ex.PvpBattleResult;
   import ru.pragmatix.wormix.pvp.messages.server.PvpEndBattle;
   import ru.pragmatix.wormix.pvp.messages.server.PvpRetryCommandRequestServer;
   import ru.pragmatix.wormix.pvp.messages.server.PvpStartTurn;
   import ru.pragmatix.wormix.pvp.messages.server.PvpSystemMessage;
   import ru.pragmatix.wormix.scene.SortingLayer;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.utils.StringUtil;
   import ru.pragmatix.wormix.utils.§_-J2h§;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.RunningSwine;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Image;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.utils.Pool;
   import starling.utils.SystemUtil;
   import starlingbuilder.engine.tween.WormixTweenBuilder;
   
   public class §_-D3w§
   {
      
      private static const §_-r2W§:uint = 3;
      
      private static const §_-H2j§:uint = 3 * 1000;
      
      private static const §_-B1j§:uint = 0;
      
      private static const §_-43w§:uint = 1;
      
      private static const §_-Z1R§:uint = 2;
      
      private var state:uint = 0;
      
      private var running:Boolean = false;
      
      private var §_-i2V§:Boolean = false;
      
      private var connection:§_-6a§;
      
      private var playerNum:int;
      
      private var §_-33a§:§_-pP§ = new §_-pP§();
      
      private var lastCommandNum:uint = 0;
      
      private var §_-o2s§:Array = [];
      
      private var §_-U2E§:uint = 0;
      
      private var §_-4m§:Array = [];
      
      private var §_-f1S§:Array = [];
      
      private var §_-Z1P§:uint = 0;
      
      private var §_-d1t§:Number = 0;
      
      public function §_-D3w§(param1:§_-6a§, param2:int)
      {
         super();
         this.connection = param1;
         this.playerNum = param2;
      }
      
      internal function §_-J1z§(param1:§_-6a§, param2:int) : void
      {
         if(this.running)
         {
            this.stop();
         }
         this.connection = param1;
         this.playerNum = param2;
      }
      
      private function reset() : void
      {
         this.lastCommandNum = 0;
         this.§_-o2s§ = [];
         this.§_-U2E§ = 0;
         this.state = §_-B1j§;
      }
      
      internal function run() : void
      {
         if(!this.running)
         {
            this.running = true;
            this.connection.addListener(PvpEndBattle,this.§_-wo§,false,0,true);
            this.connection.addListener(PvpRetryCommandRequestServer,this.§_-wo§,false,0,true);
            this.connection.addListener(PvpStartTurn,this.§_-wo§,false,0,true);
            this.connection.addListener(PvpSystemMessage,this.§_-wo§,false,0,true);
            if(this.state == §_-43w§ || this.§_-i2V§)
            {
               this.§_-r2Q§();
            }
            else if(this.state == §_-Z1R§)
            {
               this.§_-011§();
            }
            if(this.state != §_-43w§)
            {
               this.§_-R2e§();
            }
            this.§_-i2V§ = false;
         }
      }
      
      internal function stop() : void
      {
         if(this.running)
         {
            this.running = false;
            this.§_-i2V§ = true;
            this.connection.removeListener(PvpEndBattle,this.§_-wo§);
            this.connection.removeListener(PvpRetryCommandRequestServer,this.§_-wo§);
            this.connection.removeListener(PvpStartTurn,this.§_-wo§);
            this.connection.removeListener(PvpSystemMessage,this.§_-wo§);
         }
      }
      
      internal function §_-wo§(param1:§_-63i§) : void
      {
         var _loc3_:Function = null;
         var _loc2_:Object = param1.message;
         if(_loc2_ is PvpEndBattle)
         {
            _loc3_ = this.§_-C19§;
         }
         else if(_loc2_ is PvpRetryCommandRequestServer)
         {
            _loc3_ = this.§_-Q1J§;
         }
         else if(_loc2_ is PvpStartTurn)
         {
            _loc3_ = this.§_-L16§;
         }
         else if(_loc2_ is PvpSystemMessage)
         {
            _loc3_ = this.§_-J1Z§;
         }
         SystemUtil.executeWhenApplicationIsActive(_loc3_,param1);
      }
      
      internal function §_-iJ§() : void
      {
         this.state = §_-Z1R§;
         this.§_-o2s§ = [];
         this.§_-U2E§ = §_-X1j§.§_-12n§.gameMaster.§_-82g§();
         this.§_-L1b§();
         this.§_-011§();
         this.§_-632§();
         this.§_-33a§.reset();
         this.§_-33a§.run();
         §_-X1j§.§_-12n§.scene.addEventListener(§_-A3Y§.ACTION_PACKET,this.§_-k1P§);
      }
      
      internal function §_-qJ§(param1:Boolean) : void
      {
         this.state = §_-B1j§;
         this.§_-Z2q§();
         this.§_-33a§.stop();
         if(param1)
         {
            this.§_-33a§.§_-M1r§();
         }
         §_-X1j§.§_-12n§.scene.removeEventListener(§_-A3Y§.ACTION_PACKET,this.§_-k1P§);
      }
      
      internal function §_-R2§() : void
      {
         var _loc1_:§_-63i§ = null;
         this.state = §_-43w§;
         this.§_-L1b§();
         this.§_-r2Q§();
         this.§_-632§();
         this.§_-P1O§();
         for each(_loc1_ in this.§_-4m§)
         {
            if(_loc1_.message is PvpActionEx)
            {
               this.§_-i2h§(_loc1_);
            }
            else if(_loc1_.message is PvpEndTurn)
            {
               this.§_-k1E§(_loc1_);
            }
         }
         this.§_-4m§ = [];
      }
      
      internal function §_-A1C§() : void
      {
         if(this.state != §_-B1j§)
         {
            this.state = §_-B1j§;
            this.§_-R2e§();
            this.§_-qT§();
         }
      }
      
      internal function §_-u1X§(param1:Array, param2:Array, param3:Array, param4:Array, param5:Array, param6:int) : void
      {
         var _loc7_:PvpEndTurn = new PvpEndTurn();
         _loc7_.eliminated = param1;
         _loc7_.droppedUnits = param2;
         _loc7_.participantsHealthInPercent = param3;
         _loc7_.collectedReagents = param4;
         _loc7_.items = param5;
         _loc7_.battleState = param6;
         _loc7_.banType = §_-X1j§.§_-12n§.gameMaster.§_-4n§() != 0 ? int(§_-A2V§.§_-A2e§) : 0;
         this.§_-J3R§(_loc7_);
      }
      
      internal function §_-oo§(param1:Array, param2:Array, param3:Array, param4:Array, param5:Array, param6:int) : void
      {
         var _loc7_:PvpEndTurnResponse = new PvpEndTurnResponse();
         _loc7_.eliminated = param1;
         _loc7_.droppedUnits = param2;
         _loc7_.participantsHealthInPercent = param3;
         _loc7_.collectedReagents = param4;
         _loc7_.items = param5;
         _loc7_.battleState = param6;
         this.§_-J3R§(_loc7_);
      }
      
      internal function §_-sD§(param1:uint) : void
      {
         var _loc2_:PvpDropPlayer = null;
         if(this.running)
         {
            _loc2_ = new PvpDropPlayer();
            _loc2_.battleId = §_-X1j§.§_-12n§.§_-WN§().battleId;
            _loc2_.playerNum = this.playerNum;
            _loc2_.type = param1;
            this.connection.send(_loc2_);
         }
      }
      
      private function §_-011§() : void
      {
         if(this.connection)
         {
            this.connection.§_-Z2l§();
         }
      }
      
      private function §_-r2Q§() : void
      {
         this.connection.addListener(PvpActionEx,this.§_-i2h§,false,0,true);
         this.connection.addListener(PvpEndTurn,this.§_-k1E§,false,0,true);
      }
      
      private function §_-Z2q§() : void
      {
         if(Boolean(this.connection) && this.connection.§_-928§())
         {
            this.connection.§_-m1§();
         }
      }
      
      private function §_-qT§() : void
      {
         this.connection.removeListener(PvpActionEx,this.§_-i2h§);
         this.connection.removeListener(PvpEndTurn,this.§_-k1E§);
      }
      
      private function §_-i2h§(param1:§_-63i§) : void
      {
         var _loc3_:uint = 0;
         var _loc2_:PvpActionEx = PvpActionEx(param1.message);
         if(this.§_-52G§(_loc2_))
         {
            if(_loc2_.commandNum == this.lastCommandNum + 1)
            {
               ++this.lastCommandNum;
               _loc3_ = _loc2_.firstFrame;
               while(_loc3_ <= _loc2_.lastFrame)
               {
                  if(_loc2_.actionsByFrame[_loc3_])
                  {
                     §_-X1j§.§_-12n§.scene.dispatchEvent(new §_-K1I§(_loc2_.actionsByFrame[_loc3_],_loc3_));
                  }
                  _loc3_++;
               }
               §_-X1j§.§_-12n§.scene.dispatchEvent(§_-K1I§.empty(_loc2_.lastFrame));
            }
            else if(_loc2_.commandNum > this.lastCommandNum + 1)
            {
               §_-X1j§.§_-12n§.§_-q2B§("Неправильный номер команды",§_-1I§.TEXT,null);
               if(this.§_-47§())
               {
                  this.§_-2s§();
               }
            }
         }
         else
         {
            §_-X1j§.§_-12n§.§_-q2B§("Неправильный фрейм команды",§_-1I§.TEXT,null);
         }
      }
      
      private function §_-k1E§(param1:§_-63i§) : void
      {
         var _loc3_:int = 0;
         var _loc2_:PvpEndTurn = PvpEndTurn(param1.message);
         if(this.§_-52G§(_loc2_))
         {
            if(_loc2_.commandNum == this.lastCommandNum + 1)
            {
               if(!§_-X1j§.§_-12n§.scene.gameObjectProcessor.§_-01t§())
               {
                  §_-X1j§.§_-12n§.scene.gameObjectProcessor.§_-01O§(_loc2_.forced);
                  this.§_-Z1P§ = 0;
               }
            }
            else if(_loc2_.commandNum > this.lastCommandNum + 1)
            {
               §_-X1j§.§_-12n§.§_-q2B§("Неправильный номер команды окончания боя",§_-1I§.TEXT,null);
               if(this.§_-47§())
               {
                  this.§_-2s§();
               }
            }
            else
            {
               _loc3_ = int(this.§_-o2s§.length);
               if(_loc3_ > 0 && this.§_-o2s§[_loc3_ - 1] is PvpEndTurnResponse)
               {
                  this.connection.send(this.§_-o2s§[_loc3_ - 1]);
               }
            }
         }
         else
         {
            §_-X1j§.§_-12n§.§_-q2B§("Неправильный фрейм команды окончания боя",§_-1I§.TEXT,null);
         }
      }
      
      private function §_-52G§(param1:PvpCommand) : Boolean
      {
         var cmd:PvpCommand = param1;
         try
         {
            return cmd.battleId == §_-X1j§.§_-12n§.§_-WN§().battleId && cmd.turnNum == §_-X1j§.§_-12n§.gameMaster.§_-82g§();
         }
         catch(e:Error)
         {
         }
         return false;
      }
      
      private function §_-k1P§(param1:§_-A3Y§) : void
      {
         this.§_-J3R§(new PvpActionEx(param1.firstFrame,param1.lastFrame,param1.bulk));
      }
      
      private function §_-J3R§(param1:PvpCommand) : void
      {
         this.§_-o2s§.push(param1);
         param1.battleId = §_-X1j§.§_-12n§.§_-WN§().battleId;
         param1.turnNum = §_-X1j§.§_-12n§.gameMaster.§_-82g§();
         param1.commandNum = ++this.lastCommandNum;
         param1.playerNum = this.playerNum;
         if(this.running)
         {
            this.connection.send(param1);
         }
      }
      
      private function §_-47§() : Boolean
      {
         return this.§_-Z1P§ < §_-r2W§ && new Date().getTime() - this.§_-d1t§ > §_-H2j§;
      }
      
      private function §_-2s§() : void
      {
         var _loc1_:PvpRetryCommandRequestClient = new PvpRetryCommandRequestClient();
         _loc1_.battleId = §_-X1j§.§_-12n§.§_-WN§().battleId;
         _loc1_.turnNum = §_-X1j§.§_-12n§.gameMaster.§_-82g§();
         _loc1_.commandNum = this.lastCommandNum;
         if(this.running)
         {
            this.connection.send(_loc1_);
            ++this.§_-Z1P§;
            this.§_-d1t§ = new Date().getTime();
         }
      }
      
      internal function §_-L1b§() : void
      {
         if(§_-X1j§.§_-12n§.gameMaster.§_-82g§() == 1)
         {
            this.lastCommandNum = 0;
         }
         else
         {
            this.lastCommandNum = 1;
         }
      }
      
      private function §_-C19§(param1:§_-63i§) : void
      {
         var _loc3_:§_-J1§ = null;
         var _loc4_:§_-XA§ = null;
         var _loc5_:int = 0;
         var _loc2_:PvpEndBattle = PvpEndBattle(param1.message);
         §_-J2h§.§_-n1V§(this + ".onPvpEndBattle: " + _loc2_);
         if(_loc2_.battleId == §_-X1j§.§_-12n§.§_-WN§().battleId)
         {
            _loc3_ = §_-J1§.§_-23m§;
            _loc4_ = §_-XA§.§_-d2r§;
            _loc5_ = _loc2_.battleResult;
            if(_loc5_ != PvpBattleResult.NOT_WINNER.type)
            {
               if(!_loc2_.confirmed)
               {
                  if(_loc5_ != PvpBattleResult.DRAW_SHUTDOWN.type)
                  {
                     _loc4_ = §_-XA§.DESYNC;
                  }
                  else
                  {
                     _loc4_ = §_-XA§.§_-w2n§;
                  }
                  _loc3_ = §_-J1§.DRAW_GAME;
               }
               else if(_loc5_ == PvpBattleResult.WINNER.type)
               {
                  _loc3_ = §_-J1§.WINNER;
               }
               else if(_loc5_ == PvpBattleResult.DRAW_GAME.type)
               {
                  _loc3_ = §_-J1§.DRAW_GAME;
               }
               else if(_loc5_ == PvpBattleResult.DRAW_DESYNC.type || _loc5_ == PvpBattleResult.DRAW_SHUTDOWN.type)
               {
                  _loc3_ = §_-J1§.DRAW_GAME;
                  _loc4_ = §_-XA§.DESYNC;
               }
            }
            §_-X1j§.§_-12n§.§_-Q2l§(_loc3_,_loc4_,_loc2_.awards);
         }
      }
      
      private function §_-Q1J§(param1:§_-63i§) : void
      {
         var _loc4_:int = 0;
         var _loc5_:uint = 0;
         var _loc6_:uint = 0;
         var _loc7_:int = 0;
         var _loc8_:uint = 0;
         var _loc2_:PvpRetryCommandRequestServer = PvpRetryCommandRequestServer(param1.message);
         var _loc3_:String = "";
         for each(_loc4_ in _loc2_.commandNums)
         {
            _loc3_ = _loc3_ + (_loc3_ != "" ? "," : "") + _loc4_;
         }
         if(this.running && _loc2_.battleId == §_-X1j§.§_-12n§.§_-WN§().battleId && _loc2_.turnNum == this.§_-U2E§)
         {
            if(_loc2_.commandNums.length == 2 && _loc2_.commandNums[1] == -1)
            {
               _loc6_ = _loc5_ = this.§_-U2E§ != 1 ? uint(_loc2_.commandNums[0] - 2) : uint(_loc2_.commandNums[0] - 1);
               while(_loc6_ < this.§_-o2s§.length)
               {
                  this.connection.send(this.§_-o2s§[_loc6_]);
                  _loc6_++;
               }
            }
            else
            {
               for each(_loc7_ in _loc2_.commandNums)
               {
                  _loc8_ = this.§_-U2E§ != 1 ? uint(_loc7_ - 2) : uint(_loc7_ - 1);
                  if(_loc8_ >= 0 && _loc8_ < this.§_-o2s§.length)
                  {
                     this.connection.send(this.§_-o2s§[_loc8_]);
                  }
               }
            }
         }
      }
      
      private function §_-L16§(param1:§_-63i§) : void
      {
         var _loc5_:uint = 0;
         var _loc6_:uint = 0;
         var _loc7_:uint = 0;
         var _loc2_:PvpStartTurn = PvpStartTurn(param1.message);
         var _loc3_:§_-eX§ = §_-X1j§.§_-12n§.gameMaster;
         var _loc4_:§_-D8§ = §_-X1j§.§_-12n§;
         if(Boolean(_loc3_) && Boolean(_loc4_))
         {
            _loc5_ = _loc3_.§_-82g§();
            _loc6_ = _loc5_ + 1;
            _loc7_ = _loc4_.§_-WN§().battleId;
            if(_loc2_.battleId == _loc7_ && _loc2_.turnNum == _loc6_)
            {
               §_-X1j§.§_-12n§.scene.gameObjectProcessor.§_-42D§();
            }
            else if(_loc2_.turnNum != _loc6_)
            {
               §_-X1j§.§_-12n§.§_-q2B§("Получен неправильный номер хода (" + _loc2_.turnNum + ")",§_-1I§.TEXT,null);
            }
         }
      }
      
      private function §_-J1Z§(param1:§_-63i§) : void
      {
         var _loc5_:§_-V23§ = null;
         var _loc2_:PvpSystemMessage = PvpSystemMessage(param1.message);
         var _loc3_:UserProfile = §_-X1j§.§_-12n§.§_-V2F§(_loc2_.playerNum);
         var _loc4_:String = "#" + (_loc2_.playerNum + 1) + " (" + (_loc3_ ? §_-J2h§.§_-j7§(_loc3_.getCharName()) : "N/A") + ")";
         if(§_-X1j§.§_-12n§.gameMaster)
         {
            §_-X1j§.§_-12n§.§_-q2B§(_loc2_.toChatString().replace("%1",_loc4_),§_-1I§.TEXT,null);
            if(_loc2_.isPlayerDropped())
            {
               if(_loc2_.playerNum == this.playerNum)
               {
                  §_-X1j§.§_-12n§.§_-Q2l§(§_-J1§.§_-23m§,§_-XA§.SERVER_SAID_I_AM_CHEATER);
               }
               else
               {
                  _loc5_ = §_-X1j§.§_-12n§.gameMaster.§_-vJ§(_loc3_);
                  if(_loc5_)
                  {
                     _loc5_.§_-m1r§(true);
                  }
               }
            }
         }
         else
         {
            this.§_-f1S§.push(param1);
         }
      }
      
      private function §_-632§() : void
      {
         var _loc1_:§_-63i§ = null;
         for each(_loc1_ in this.§_-f1S§)
         {
            this.§_-J1Z§(_loc1_);
         }
         this.§_-f1S§ = [];
      }
      
      internal function §_-R2e§() : void
      {
         this.connection.addListener(PvpActionEx,this.§_-I3O§,false,0,true);
         this.connection.addListener(PvpEndTurn,this.§_-I3O§,false,0,true);
      }
      
      internal function §_-P1O§() : void
      {
         this.connection.removeListener(PvpActionEx,this.§_-I3O§);
         this.connection.removeListener(PvpEndTurn,this.§_-I3O§);
      }
      
      private function §_-I3O§(param1:§_-63i§) : void
      {
         this.§_-4m§.push(param1);
      }
      
      internal function §_-u1I§() : uint
      {
         return this.lastCommandNum;
      }
   }
}

