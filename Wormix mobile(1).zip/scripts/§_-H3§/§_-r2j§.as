package §_-H3§
{
   import §_-5Y§.§_-h2c§;
   import §_-63U§.*;
   import §_-73d§.§_-pT§;
   import §_-91B§.§_-z2l§;
   import §_-A1K§.§_-TA§;
   import §_-B1y§.Cookie;
   import §_-B1y§.§_-MQ§;
   import §_-B1y§.§_-bs§;
   import §_-B2z§.*;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-73y§;
   import §_-DJ§.§_-Es§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-F2Q§.GestureEvent;
   import §_-L1H§.§_-C3e§;
   import §_-SP§.§_-M4§;
   import §_-U1i§.§_-81M§;
   import §_-U1i§.§_-O2i§;
   import §_-W§.§_-ix§;
   import §_-Y1O§.*;
   import §_-Y1Q§.§_-61Z§;
   import §_-Y1b§.§_-jH§;
   import §_-Y1b§.§_-s2Z§;
   import §_-b1R§.§_-Bx§;
   import §_-dS§.§_-D3a§;
   import §_-g2r§.§_-03A§;
   import §_-j1w§.§_-B2i§;
   import §_-j22§.§_-5g§;
   import §_-l1K§.*;
   import §_-l1g§.§_-L3Q§;
   import §_-l2r§.§_-K1t§;
   import §_-m1g§.§_-K2W§;
   import §_-n1w§.*;
   import §_-s20§.§_-J2g§;
   import §_-u2J§.§_-T1K§;
   import §_-z1g§.§_-82X§;
   import flash.display.BitmapData;
   import flash.display.Shape;
   import flash.errors.IllegalOperationError;
   import flash.events.Event;
   import flash.geom.Point;
   import flash.utils.ByteArray;
   import flash.utils.getQualifiedClassName;
   import org.gestouch.core.GestureState;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.SelectMapMenu;
   import ru.pragmatix.wormix.messages.clans.main.server.GetJoinClansMainRequest;
   import ru.pragmatix.wormix.messages.clans.response.GetJoinClansMainResponse;
   import ru.pragmatix.wormix.messages.clans.structures.ClanChatMessageTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanNewsTO;
   import ru.pragmatix.wormix.messages.structures.HeroicMissionStructure;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.Direction;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.physics.model.IPhysicModel;
   import ru.pragmatix.wormix.pvp.messages.ex.BattleCreated;
   import ru.pragmatix.wormix.pvp.messages.ex.BattleCreationFailure;
   import ru.pragmatix.wormix.pvp.messages.ex.CallToBattle;
   import ru.pragmatix.wormix.pvp.messages.ex.CallToBattleResultType;
   import ru.pragmatix.wormix.pvp.messages.ex.CreateBattleRequest;
   import ru.pragmatix.wormix.pvp.messages.ex.PvpBattleType;
   import ru.pragmatix.wormix.pvp.messages.server.BattleLoginError;
   import ru.pragmatix.wormix.pvp.messages.server.PvpSystemMessage;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.weapons.*;
   import starling.display.DisplayObject;
   import starling.display.Image;
   import starling.events.Event;
   import starling.textures.Texture;
   import starling.utils.Pool;
   import starling.utils.SystemUtil;
   
   public class §_-r2j§ extends §_-I1V§
   {
      
      private static const §_-B1o§:uint = 1;
      
      private static const §_-H2C§:uint = 2;
      
      private var battleType:PvpBattleType;
      
      private var friendSocialNetId:uint = 0;
      
      private var §_-n2X§:Vector.<UserProfile> = new Vector.<UserProfile>(0);
      
      private var §_-02U§:Vector.<UserProfile> = new Vector.<UserProfile>(0);
      
      private var §_-hZ§:Vector.<uint> = new Vector.<uint>(0);
      
      private var §_-L2f§:Vector.<uint> = new Vector.<uint>(0);
      
      private var callee:UserProfile;
      
      private var §_-rG§:§_-Es§;
      
      private var §_-UL§:§_-Es§;
      
      private var §_-k1J§:§_-Es§;
      
      private var §_-A15§:Boolean = false;
      
      public function §_-r2j§()
      {
         super();
         §_-c2I§();
         this.§_-D3b§();
      }
      
      override public function dispose() : void
      {
         super.dispose();
         this.battleType = null;
         this.§_-n2X§ = null;
         this.§_-02U§ = null;
         this.§_-hZ§ = null;
         this.§_-L2f§ = null;
         if(this.§_-rG§)
         {
            this.§_-rG§.dispose();
         }
         this.§_-rG§ = null;
         if(this.§_-UL§)
         {
            if(this.§_-UL§.hasEventListener(§_-T1K§.CANCEL_BATTLE_REQUEST))
            {
               this.§_-UL§.removeEventListener(§_-T1K§.CANCEL_BATTLE_REQUEST,this.§_-z13§);
            }
            this.§_-UL§.dispose();
            this.§_-UL§ = null;
         }
      }
      
      public function isReady() : Boolean
      {
         return state == READY;
      }
      
      public function §_-N2s§(param1:UserProfile, param2:Boolean = false) : Boolean
      {
         if(state == READY && !Application.§_-dv§())
         {
            Application.§_-a1k§(true);
            info = new §_-O2i§(§_-81M§.§_-A1W§);
            info.online = true;
            info.§_-wA§ = Server.§_-O2A§(§_-c1G§.PVP);
            this.§_-02U§ = new <UserProfile>[param1];
            this.§_-L2f§ = new <uint>[param1.getId()];
            this.friendSocialNetId = uint(param1.§_-V1K§()) || §_-X1j§.§_-It§.getPlatformType().servercode;
            this.§_-n2X§ = new <UserProfile>[Application.userProfile];
            this.§_-hZ§ = new <uint>[Application.userProfile.getId()];
            this.callee = param1;
            this.§_-A15§ = param2;
            this.battleType = PvpBattleType.FRIEND_PVP;
            §_-J2l§.§_-u2b§.show(this.§_-62E§);
            return true;
         }
         §_-fH§.§_-h2r§(§_-s2a§.§_-K3t§(§_-s2a§.TITLE_ERROR),§_-s2a§.§_-K3t§(§_-s2a§.CURRENT_USER_ALREADY_IN_BATTLE));
         return false;
      }
      
      public function §_-N1O§(param1:UserProfile) : Boolean
      {
         if(state == READY && !Application.§_-dv§())
         {
            §_-J2l§.§_-u2b§.show();
            Application.§_-a1k§(true);
            info = new §_-O2i§(§_-81M§.§_-Y1C§);
            info.online = true;
            info.§_-wA§ = Server.§_-O2A§(§_-c1G§.PVP);
            info.wager = §_-82X§.valueOf(§_-K2W§.§_-Ss§);
            this.§_-L2f§ = §_-Av§;
            §§push(this);
            var _temp_2:* = new <uint>[Application.userProfile.getId(),param1.getId()];
            §§pop().§_-hZ§ = new <uint>[Application.userProfile.getId(),param1.getId()];
            this.friendSocialNetId = uint(param1.§_-V1K§()) || §_-X1j§.§_-It§.getPlatformType().servercode;
            this.callee = param1;
            this.battleType = info.wager.battleType;
            info.mapId = §_-X1j§.§_-H15§.§_-43Y§(§_-81M§.§_-A1W§);
            info.§_-oR§ = true;
            info.isAllyFriendOrClanmate = true;
            connect(info.§_-wA§,this.§_-J16§,this.§_-nD§);
            return true;
         }
         §_-fH§.§_-h2r§(§_-s2a§.§_-K3t§(§_-s2a§.TITLE_ERROR),§_-s2a§.§_-K3t§(§_-s2a§.CURRENT_USER_ALREADY_IN_BATTLE));
         return false;
      }
      
      public function §_-22K§(param1:UserProfile, param2:uint) : Boolean
      {
         var _loc3_:Class = null;
         if(state == READY && !Application.§_-dv§())
         {
            Application.§_-a1k§(true);
            _loc3_ = §_-N1V§.§_-I39§.§_-N1i§().getRecord(param2).getClass();
            info = this.§_-h16§(param1,new _loc3_(),[param2]);
            info.isAllyFriendOrClanmate = true;
            info.§_-D3W§ = §_-X1j§.§_-A24§.§_-X2A§();
            this.friendSocialNetId = uint(param1.§_-V1K§()) || §_-X1j§.§_-It§.getPlatformType().servercode;
            connect(info.§_-wA§,this.§_-J16§,this.§_-nD§);
            return true;
         }
         §_-fH§.§_-h2r§(§_-s2a§.TITLE_ERROR,§_-s2a§.CURRENT_USER_ALREADY_IN_BATTLE);
         return false;
      }
      
      public function §_-Q1g§(param1:UserProfile, param2:HeroicMissionStructure) : Boolean
      {
         var _loc3_:§_-jH§ = null;
         if(state == READY && !Application.§_-dv§())
         {
            §_-J2l§.§_-u2b§.show();
            Application.§_-a1k§(true);
            _loc3_ = new §_-jH§(param2.mapId,param2.bossId1,param2.bossId2);
            info = this.§_-h16§(param1,_loc3_,[param2.bossId1,param2.bossId2]);
            this.friendSocialNetId = uint(param1.§_-V1K§()) || §_-X1j§.§_-It§.getPlatformType().servercode;
            info.isAllyFriendOrClanmate = true;
            §_-Bx§.§_-O2o§(_loc3_,§_-bs§.§_-d1Z§(this.connectToBattle,this,[this.§_-J16§]));
            return true;
         }
         §_-fH§.§_-h2r§(§_-s2a§.§_-K3t§(§_-s2a§.TITLE_ERROR),§_-s2a§.§_-K3t§(§_-s2a§.CURRENT_USER_ALREADY_IN_BATTLE),§_-fH§.§_-1B§,§_-t16§);
         return false;
      }
      
      public function §_-f27§(param1:uint) : Boolean
      {
         var _loc2_:Class = null;
         if(state == READY && !Application.§_-dv§())
         {
            Application.§_-a1k§(true);
            _loc2_ = §_-N1V§.§_-I39§.§_-N1i§().getRecord(param1).getClass();
            info = this.makeScenarioForRandomPartner(new _loc2_(),[param1]);
            info.§_-D3W§ = §_-X1j§.§_-A24§.§_-X2A§();
            connect(info.§_-wA§,this.sendBattleRequestForRandomPartner,this.§_-nD§);
            return true;
         }
         §_-fH§.§_-h2r§(§_-s2a§.TITLE_ERROR,§_-s2a§.CURRENT_USER_ALREADY_IN_BATTLE);
         return false;
      }
      
      public function §_-j1F§(param1:HeroicMissionStructure) : Boolean
      {
         var rec:HeroicMissionStructure = param1;
         if(state == READY && !Application.§_-dv§())
         {
            Application.§_-a1k§(true);
            §_-J2l§.§_-u2b§.show(function():void
            {
               var _loc1_:§_-jH§ = new §_-jH§(rec.mapId,rec.bossId1,rec.bossId2);
               info = makeScenarioForRandomPartner(_loc1_,[rec.bossId1,rec.bossId2]);
               info.isAllyFriendOrClanmate = false;
               §_-Bx§.§_-O2o§(_loc1_,§_-bs§.§_-d1Z§(connectToBattle,this,[sendBattleRequestForRandomPartner]));
            });
            return true;
         }
         §_-fH§.§_-h2r§(§_-s2a§.§_-K3t§(§_-s2a§.TITLE_ERROR),§_-s2a§.§_-K3t§(§_-s2a§.CURRENT_USER_ALREADY_IN_BATTLE),§_-fH§.§_-1B§,§_-t16§);
         return false;
      }
      
      public function get friendInPair() : UserProfile
      {
         return this.callee;
      }
      
      public function set friendInPair(param1:UserProfile) : void
      {
         this.callee = param1;
      }
      
      private function connectToBattle(param1:Function) : void
      {
         connect(info.§_-wA§,param1,this.§_-nD§);
      }
      
      private function sendBattleRequestForRandomPartner() : void
      {
         changeState(§_-H2C§);
         this.§_-k2b§();
         var _loc1_:§_-82X§ = info.wager ? info.wager : §_-82X§.§_-F1d§;
         var _loc2_:CreateBattleRequest = §_-wv§(info.mapId,info.§_-oR§,_loc1_,info.missionIds,this.§_-L2f§,this.§_-hZ§);
         §_-c1K§.send(_loc2_);
         §_-LG§();
         §_-J2l§.§_-u2b§.hide();
      }
      
      private function §_-k2b§() : void
      {
         if(!this.§_-k1J§)
         {
            this.§_-k1J§ = new §_-Es§(§_-Es§.§_-kR§,§_-lm§,true);
            this.§_-k1J§.addEventListener(§_-T1K§.CANCEL_BATTLE_REQUEST,function(param1:starling.events.Event):void
            {
               cancelBattle();
            });
         }
         this.§_-k1J§.show();
      }
      
      override protected function §_-Y1S§(param1:uint) : void
      {
         super.§_-Y1S§(param1);
         if(param1 == READY)
         {
            if(Boolean(this.§_-rG§) && this.§_-rG§.§_-h1C§())
            {
               this.§_-rG§.hide();
            }
            if(Boolean(this.§_-UL§) && this.§_-UL§.§_-h1C§())
            {
               this.§_-UL§.hide();
            }
            if(Boolean(this.§_-k1J§) && this.§_-k1J§.§_-h1C§())
            {
               this.§_-k1J§.hide();
            }
         }
      }
      
      private function makeScenarioForRandomPartner(param1:§_-s2Z§, param2:Array) : §_-O2i§
      {
         var _loc4_:uint = 0;
         var _loc3_:§_-O2i§ = new §_-O2i§(§_-81M§.§_-K23§);
         _loc3_.online = true;
         _loc3_.§_-wA§ = Server.§_-O2A§(§_-c1G§.PVP);
         _loc3_.wager = §_-82X§.valueOf(§_-K2W§.PVE_PARTNER);
         _loc3_.scenario = param1;
         _loc3_.mapId = param1.map.id;
         §§push(_loc3_);
         §§pop().setProfiles(new <UserProfile>[Application.userProfile],new <uint>[0]);
         this.§_-L2f§ = §_-Av§;
         this.§_-hZ§ = new <uint>[Application.userProfile.getId()];
         this.battleType = PvpBattleType.PVE_PARTNER;
         this.callee = null;
         for each(_loc4_ in param2)
         {
            _loc3_.missionIds.push(_loc4_);
         }
         return _loc3_;
      }
      
      private function §_-h16§(param1:UserProfile, param2:§_-s2Z§, param3:Array) : §_-O2i§
      {
         var _loc5_:uint = 0;
         var _loc4_:§_-O2i§ = new §_-O2i§(§_-81M§.§_-K23§);
         _loc4_.online = true;
         _loc4_.§_-wA§ = Server.§_-O2A§(§_-c1G§.PVP);
         _loc4_.wager = §_-82X§.valueOf(§_-K2W§.PVE_FRIEND);
         _loc4_.scenario = param2;
         _loc4_.mapId = param2.map.id;
         this.§_-L2f§ = §_-Av§;
         this.§_-hZ§ = new <uint>[Application.userProfile.getId(),param1.getId()];
         this.callee = param1;
         this.battleType = PvpBattleType.PVE_FRIEND;
         for each(_loc5_ in param3)
         {
            _loc4_.missionIds.push(_loc5_);
         }
         return _loc4_;
      }
      
      override protected function §_-D3b§() : void
      {
         super.§_-D3b§();
         this.battleType = null;
         this.§_-n2X§ = §_-52l§;
         this.§_-02U§ = §_-52l§;
         this.§_-hZ§ = §_-Av§;
         this.§_-L2f§ = §_-Av§;
         this.friendSocialNetId = 0;
         this.§_-A15§ = false;
      }
      
      private function §_-62E§() : void
      {
         changeState(§_-B1o§);
         var _loc1_:§_-73y§ = new SelectMapMenu();
         _loc1_.addEventListener(§_-M4§.MENU_OK_ACTION,this.§_-q4§);
         _loc1_.addEventListener(§_-M4§.WINDOW_CANCEL,this.§_-w2R§);
         _loc1_.show();
         §_-J2l§.§_-u2b§.hide();
      }
      
      private function §_-q4§(param1:starling.events.Event) : void
      {
         var _loc2_:§_-D3a§ = §_-D3a§(param1.data);
         info.mapId = _loc2_ ? _loc2_.id : §_-X1j§.§_-H15§.§_-43Y§(§_-81M§.§_-A1W§);
         info.§_-oR§ = _loc2_ == null;
         §_-J2l§.§_-u2b§.show(connect,info.§_-wA§,this.§_-J16§,this.§_-nD§);
      }
      
      override protected function §_-nD§() : void
      {
         §_-J2l§.§_-u2b§.hide();
         §_-J2l§.§_-m1I§();
         super.§_-nD§();
      }
      
      private function §_-w2R§(param1:starling.events.Event) : void
      {
         changeState(READY);
      }
      
      private function §_-J16§() : void
      {
         changeState(§_-H2C§);
         this.§_-aN§(this.callee);
         var _loc1_:§_-82X§ = info.wager ? info.wager : §_-82X§.§_-F1d§;
         var _loc2_:CreateBattleRequest = §_-wv§(info.mapId,info.§_-oR§,_loc1_,info.missionIds,this.§_-L2f§,this.§_-hZ§,this.friendSocialNetId);
         §_-c1K§.send(_loc2_);
         §_-c1K§.addListener(CallToBattle,this.§_-F2Y§,false,0,true);
         §_-c1K§.addListener(BattleCreationFailure,§_-oN§,false,0,true);
         §_-c1K§.addListener(BattleLoginError,§_-f2n§,false,0,true);
         §_-J2l§.§_-u2b§.hide();
      }
      
      private function §_-aN§(param1:UserProfile) : void
      {
         if(!this.§_-rG§)
         {
            this.§_-rG§ = new §_-Es§(§_-Es§.§_-I2v§,§_-lm§,false);
            this.§_-rG§.addEventListener(§_-T1K§.CANCEL_BATTLE_REQUEST,this.§_-z13§);
         }
         if(param1)
         {
            this.§_-rG§.§_-82v§(param1);
         }
         this.§_-rG§.show();
      }
      
      private function §_-z13§(param1:starling.events.Event) : void
      {
         cancelBattle();
      }
      
      private function §_-Jk§() : void
      {
         if(!this.§_-UL§)
         {
            this.§_-UL§ = new §_-Es§(§_-Es§.§_-kR§,§_-lm§,false);
            this.§_-UL§.addEventListener(§_-T1K§.CANCEL_BATTLE_REQUEST,this.§_-z13§);
         }
         this.§_-UL§.show();
      }
      
      override protected function §_-5K§(param1:uint) : void
      {
         super.§_-5K§(param1);
         if(param1 == §_-H2C§)
         {
            §_-c1K§.removeListener(CallToBattle,this.§_-F2Y§);
            §_-c1K§.removeListener(BattleCreationFailure,§_-oN§);
            §_-c1K§.removeListener(BattleLoginError,§_-f2n§);
         }
      }
      
      private function §_-F2Y§(param1:§_-63i§) : void
      {
         var e:§_-63i§ = param1;
         SystemUtil.executeWhenApplicationIsActive(function():void
         {
            if(!§_-c1K§ || !info)
            {
               return;
            }
            var _loc1_:CallToBattle = CallToBattle(e.message);
            info.battleId = _loc1_.battleId;
            §_-LG§();
            §_-U2s§(_loc1_.participantStructs);
         });
      }
      
      override protected function §_-015§(param1:§_-63i§) : void
      {
         var _loc6_:UserProfile = null;
         var _loc2_:BattleCreationFailure = BattleCreationFailure(param1.message);
         var _loc3_:Boolean = §_-N1V§.postController.§_-Ez§();
         var _loc4_:Boolean = _loc2_.reason == CallToBattleResultType.BUSY || _loc2_.reason == CallToBattleResultType.OFFLINE;
         var _loc5_:String = _loc2_.reason.remoteFailureReason;
         if(_loc3_ && _loc4_ && Boolean(this.callee))
         {
            _loc5_ += "<br>" + §_-s2a§.§_-K3t§(§_-s2a§.VIRAL_QUESTION_CHALLENGE_POST);
            _loc6_ = this.callee;
            §_-fH§.§_-q1a§(§_-s2a§.§_-K3t§(§_-s2a§.BATTLE_REQUEST_TITLE),_loc5_,§_-fH§.§_-X2g§,§_-bs§.§_-d1Z§(this.§_-y1N§,this,[_loc6_]),null);
         }
         else
         {
            §_-fH§.§_-q1a§(§_-s2a§.§_-K3t§(§_-s2a§.TITLE_ATTENTION),_loc5_);
         }
         changeState(READY);
      }
      
      private function §_-y1N§(param1:UserProfile) : void
      {
         §_-N1V§.postController.callToPvp(Application.userProfile,param1);
      }
      
      override protected function §_-rn§(param1:§_-63i§) : void
      {
         var _loc2_:BattleCreated = null;
         if(info)
         {
            changeState(§_-83l§);
            _loc2_ = BattleCreated(param1.message);
            info.seed = _loc2_.seed;
            info.battleId = _loc2_.battleId;
            info.mapId = _loc2_.mapId;
            info.reagentsForBattle = §_-b1L§.§_-n2§(_loc2_.reagentsForBattle);
            info.preCalculatedPoints = _loc2_.preCalculatedPoints;
            §_-U2s§(_loc2_.playerStructs);
            §_-41G§.load(info.mapId,false,false,info.§_-83I§().concat(info.§_-b2W§()) as Vector.<UserProfile>,this.§_-lt§,§_-QA§);
         }
         else
         {
            §_-QA§();
         }
      }
      
      private function §_-lt§(param1:§_-03A§) : void
      {
         var _loc2_:§_-O2i§ = null;
         if(state == §_-83l§)
         {
            _loc2_ = info;
            _loc2_.mapRecord = param1.mapRecord;
            _loc2_.§_-u2Y§ = param1.§_-JV§();
            §_-j2n§ = false;
            changeState(READY);
            §_-X1j§.§_-12n§.§_-j4§(_loc2_,§_-c1K§);
         }
         else
         {
            §_-J2l§.§_-m1I§();
         }
      }
      
      override protected function §_-is§(param1:§_-63i§) : void
      {
         var _loc2_:PvpSystemMessage = PvpSystemMessage(param1.message);
         if(_loc2_.type == PvpSystemMessage.PLAYER_JOINED_TO_BATTLE)
         {
            if(Boolean(this.§_-rG§) && this.§_-rG§.§_-h1C§())
            {
               this.§_-rG§.hide();
            }
         }
         this.§_-Jk§();
      }
   }
}

