package §_-H3§
{
   import §_-22z§.§_-f1b§;
   import §_-2k§.*;
   import §_-31W§.AchievLevelUpMessage;
   import §_-51j§.*;
   import §_-5Y§.ChatInputPanel;
   import §_-5Y§.§_-h2c§;
   import §_-62§.*;
   import §_-79§.§_-ps§;
   import §_-82l§.§_-A2Y§;
   import §_-A1K§.§_-6L§;
   import §_-A1K§.§_-TA§;
   import §_-A1K§.§_-U11§;
   import §_-B2z§.Server;
   import §_-B2z§.§_-63i§;
   import §_-B2z§.§_-c1G§;
   import §_-CF§.§_-p2U§;
   import §_-DJ§.BattleOfferDialog;
   import §_-DJ§.BossBattleOfferDialog;
   import §_-DJ§.§_-Es§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-T2G§;
   import §_-DJ§.§_-fH§;
   import §_-DJ§.§_-zb§;
   import §_-E1I§.§_-b2n§;
   import §_-L1H§.§_-b2K§;
   import §_-P1z§.*;
   import §_-RE§.§_-qW§;
   import §_-U1i§.§_-81M§;
   import §_-U1i§.§_-O2i§;
   import §_-Vg§.*;
   import §_-Y1b§.§_-22N§;
   import §_-Y1b§.§_-OP§;
   import §_-YF§.§_-Zi§;
   import §_-YF§.§_-q2v§;
   import §_-b1F§.§_-G4§;
   import §_-b1F§.§_-v2Q§;
   import §_-b1R§.§_-Bx§;
   import §_-b1R§.§_-C3P§;
   import §_-g2r§.§_-03A§;
   import §_-hO§.AttackDodgedEvent;
   import §_-j1w§.§_-L1x§;
   import §_-j22§.§_-5g§;
   import §_-k1u§.§_-2m§;
   import §_-k1u§.§_-F3H§;
   import §_-k1u§.§_-Oi§;
   import §_-l1K§.§_-d2j§;
   import §_-l1g§.§_-L3Q§;
   import §_-l2r§.§_-K1t§;
   import §_-m2s§.§_-R11§;
   import §_-o14§.§_-Dd§;
   import §_-p14§.§_-pP§;
   import §_-r1C§.§_-h2B§;
   import §_-s20§.§_-6a§;
   import §_-s20§.§_-J2g§;
   import §_-u1P§.ShopResultEvent;
   import §_-u2J§.§_-T1K§;
   import §_-w§.§_-63m§;
   import §_-w2W§.§_-21w§;
   import §_-w2i§.§_-Zd§;
   import §_-x2Q§.§_-dU§;
   import §_-z1g§.§_-82X§;
   import §_-zI§.§_-A1s§;
   import com.greensock.TweenMax;
   import com.hurlant.crypto.tls.§_-F16§;
   import com.hurlant.crypto.tls.§_-Tx§;
   import com.hurlant.crypto.tls.§_-a2D§;
   import dragonBones.animation.WorldClock;
   import feathers.controls.Button;
   import feathers.controls.text.TextFormatUtils;
   import feathers.core.FeathersControl;
   import feathers.core.IFeathersControl;
   import feathers.data.ListCollection;
   import feathers.layout.AnchorLayout;
   import feathers.layout.ILayoutDisplayObject;
   import feathers.layout.LayoutBoundsResult;
   import feathers.layout.VerticalAlign;
   import feathers.layout.ViewPortBounds;
   import feathers.themes.FontColor;
   import feathers.themes.FontName;
   import feathers.themes.FontSize;
   import flash.text.TextFormatAlign;
   import flash.utils.ByteArray;
   import flash.utils.IDataOutput;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.sets.ControlSets;
   import ru.pragmatix.wormix.gui.§_-K2Y§;
   import ru.pragmatix.wormix.gui.§_-Q2v§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.server.VerifyPaymentResult;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.objects.§_-Qi§;
   import ru.pragmatix.wormix.objects.§_-V1L§;
   import ru.pragmatix.wormix.physics.CollideType;
   import ru.pragmatix.wormix.physics.Force;
   import ru.pragmatix.wormix.physics.model.NotStuckingPhysicModel;
   import ru.pragmatix.wormix.physics.model.PhysParams;
   import ru.pragmatix.wormix.pvp.messages.ex.BattleCreated;
   import ru.pragmatix.wormix.pvp.messages.ex.CallToBattle;
   import ru.pragmatix.wormix.pvp.messages.ex.JoinToBattle;
   import ru.pragmatix.wormix.pvp.messages.ex.RejectBattleOffer;
   import ru.pragmatix.wormix.pvp.messages.server.PvpSystemMessage;
   import ru.pragmatix.wormix.scene.SortingLayer;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.weapons.Weapon;
   import ru.pragmatix.wormix.weapons.ammo.feats.IFrameFeat;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.events.Event;
   import starling.utils.SystemUtil;
   
   public class §_-S1P§ extends §_-I1V§
   {
      
      private var §_-xN§:BattleOfferDialog;
      
      private var §_-UL§:§_-Es§;
      
      private var §_-Qk§:§_-Zi§;
      
      private var message:§_-K2Y§;
      
      private var §_-91f§:Boolean = true;
      
      private var §_-a15§:Vector.<uint>;
      
      private var §_-33N§:§_-O2i§;
      
      private var §_-I2D§:§_-O2i§;
      
      private var §_-N16§:CallToBattle;
      
      private var §_-Cm§:Boolean = false;
      
      private var §_-g2z§:uint;
      
      private var §_-L25§:Boolean = false;
      
      public function §_-S1P§()
      {
         super();
         §_-c2I§();
         §_-J2g§.§_-o1R§(CallToBattle,this.§_-F2Y§);
         if(§_-X1j§.§_-82T§.§_-I9§().equals(§_-p2U§.§_-qr§))
         {
            this.message = §_-J2l§.§_-J3x§(true,{
               "text":{
                  "text":§_-s2a§.§_-K3t§(§_-s2a§.ENEMY_WAITING_MSG),
                  "fontSize":18
               },
               "descr":§_-s2a§.§_-K3t§(§_-s2a§.BATTLE_ENEMY_DATA_LOAD)
            });
         }
         else
         {
            this.message = §_-J2l§.§_-J3x§(true,{
               "text":{"text":§_-s2a§.§_-K3t§(§_-s2a§.ENEMY_WAITING_MSG)},
               "descr":§_-s2a§.§_-K3t§(§_-s2a§.BATTLE_ENEMY_DATA_LOAD)
            });
         }
         this.§_-Qk§ = new §_-Zi§();
      }
      
      private static function §_-I31§(param1:uint) : void
      {
         §_-J2l§.§_-m1I§();
         §_-fH§.§_-h2r§(§_-s2a§.§_-K3t§(§_-s2a§.TITLE_ERROR),§_-s2a§.§_-K3t§(§_-s2a§.MSG_ERROR_LOAD_ROOM_RES));
      }
      
      private static function §_-v5§() : void
      {
         §_-J2l§.§_-m1I§();
         §_-fH§.§_-h2r§(§_-s2a§.§_-K3t§(§_-s2a§.TITLE_ERROR),§_-s2a§.§_-K3t§(§_-s2a§.MSG_ERROR_LOAD_ROOM_RES));
      }
      
      override public function dispose() : void
      {
         super.dispose();
         if(this.§_-L25§)
         {
            Starling.juggler.removeByID(this.§_-g2z§);
            this.§_-L25§ = false;
         }
         §_-J2g§.§_-fy§(CallToBattle,this.§_-F2Y§);
         if(this.§_-xN§)
         {
            if(this.§_-xN§.hasEventListener(§_-T1K§.ACCEPT_BATTLE_OFFER))
            {
               this.§_-xN§.removeEventListener(§_-T1K§.ACCEPT_BATTLE_OFFER,this.§_-h2n§);
            }
            if(this.§_-xN§.hasEventListener(§_-T1K§.DECLINE_BATTLE_OFFER))
            {
               this.§_-xN§.removeEventListener(§_-T1K§.DECLINE_BATTLE_OFFER,this.§_-bN§);
            }
            this.§_-xN§.dispose();
            this.§_-xN§ = null;
         }
         if(this.§_-UL§)
         {
            this.§_-UL§.dispose();
         }
         this.§_-UL§ = null;
         if(this.§_-Qk§)
         {
            this.§_-Qk§.dispose();
         }
         this.§_-Qk§ = null;
         if(this.message)
         {
            this.message.dispose();
         }
         this.message = null;
      }
      
      private function §_-F2Y§(param1:§_-63i§) : void
      {
         var callFromSameEnemy:Boolean;
         var userBusy:Boolean = false;
         var e:§_-63i§ = param1;
         var msg:CallToBattle = CallToBattle(e.message);
         if(!msg || !msg.missionIds)
         {
            return;
         }
         callFromSameEnemy = Boolean(this.§_-N16§) && this.§_-N16§.profileId == msg.profileId;
         if(state == READY)
         {
            userBusy = Application.§_-dv§();
            if(Application.isUserIgnoring() || !msg.battleWager.isAvailable(Application.userProfile))
            {
               info = new §_-O2i§(§_-81M§.§_-A1W§);
               info.online = true;
               info.battleId = msg.battleId;
               this.§_-91f§ = true;
               connect(Server.§_-O2A§(§_-c1G§.PVP),this.§_-S4§,this.§_-nD§);
               return;
            }
            info = §_-O2i§.§_-J2S§(msg);
            info.online = true;
            info.mapId = msg.mapId;
            info.battleId = msg.battleId;
            info.§_-53U§(msg.missionIds);
            info.wager = msg.battleWager;
            if(info.§_-Dy§())
            {
               this.§_-a15§ = new <uint>[msg.missionIds[0],msg.missionIds[1]];
            }
            else if(info.isCoopBoss())
            {
               this.§_-a15§ = new <uint>[msg.missionIds[0]];
               info.§_-D3W§ = §_-X1j§.§_-A24§.§_-X2A§();
            }
            this.§_-91f§ = false;
            if(!userBusy || callFromSameEnemy)
            {
               Application.§_-a1k§(true);
               this.§_-N16§ = msg;
               this.§_-91f§ = true;
               §_-U2s§(msg.participantStructs);
               if(§_-33r§.§_-kg§(Application.userProfile,info.§_-D1h§()))
               {
                  if(!this.§_-Cm§)
                  {
                     this.§_-Cm§ = true;
                     SystemUtil.executeWhenApplicationIsActive(function():void
                     {
                        §_-h2B§.play(§_-d27§.§_-p1C§);
                        if(message)
                        {
                           message.show();
                        }
                        §_-rp§(info);
                        §_-Cm§ = false;
                     });
                  }
               }
               else
               {
                  Application.§_-a1k§(false);
                  this.§_-Ic§();
               }
            }
            else
            {
               this.§_-Ic§();
            }
         }
         else if(!§_-6a§.isOpened)
         {
            info = new §_-O2i§(§_-81M§.§_-A1W§);
            info.battleId = msg.battleId;
            §_-Q1h§ = false;
            this.§_-91f§ = false;
            §_-52i§();
            connect(Server.§_-O2A§(§_-c1G§.PVP),this.§_-S4§,this.§_-nD§);
         }
      }
      
      override protected function §_-Y1S§(param1:uint) : void
      {
         super.§_-Y1S§(param1);
         if(param1 == READY)
         {
            if(Boolean(this.§_-xN§) && this.§_-xN§.§_-h1C§())
            {
               this.§_-xN§.hide();
            }
            if(Boolean(this.§_-UL§) && this.§_-UL§.§_-h1C§())
            {
               this.§_-UL§.hide();
            }
         }
      }
      
      private function §_-rp§(param1:§_-O2i§) : void
      {
         var _loc3_:String = null;
         if(this.§_-830§(param1))
         {
            this.§_-Ic§();
            return;
         }
         if(this.§_-xN§)
         {
            this.§_-M2e§();
            this.§_-xN§.hide();
            this.§_-xN§.dispose();
            this.§_-xN§ = null;
         }
         var _loc2_:Boolean = param1.battleType == §_-81M§.§_-K23§;
         this.§_-xN§ = _loc2_ ? new BossBattleOfferDialog() : new BattleOfferDialog();
         switch(param1.battleType)
         {
            case §_-81M§.§_-Y1C§:
               if(Boolean(param1.wager) && §_-82X§.valueOf(param1.wager.id) == §_-82X§.WAGER_4)
               {
                  _loc3_ = §_-s2a§.BATTLE_2X2_OFFER_TITLE;
                  break;
               }
               _loc3_ = §_-s2a§.BATTLE_OFFER_TITLE;
               break;
            case §_-81M§.§_-K23§:
               if(Boolean(this.§_-a15§) && this.§_-a15§.length > 1)
               {
                  (this.§_-xN§ as BossBattleOfferDialog).§_-8A§(this.§_-a15§[0],this.§_-a15§[1]);
                  break;
               }
               if(Boolean(this.§_-a15§) && this.§_-a15§.length == 1)
               {
                  (this.§_-xN§ as BossBattleOfferDialog).§_-8A§(this.§_-a15§[0]);
               }
               break;
            default:
               _loc3_ = §_-s2a§.BATTLE_OFFER_TITLE;
         }
         this.§_-xN§.setMap(param1.§_-oR§ ? 0 : int(param1.mapId));
         if(param1.§_-Dy§())
         {
            _loc3_ = §_-s2a§.BATTLE_BOSS_OFFER_TITLE;
         }
         this.§_-xN§.§_-A1e§(_loc3_);
         var _loc4_:UserProfile = param1.§_-83I§().length > 0 ? param1.§_-83I§()[0] : param1.§_-b2W§()[0];
         this.§_-Qk§.§_-I3W§([_loc4_],this.§_-WY§);
         this.§_-33N§ = null;
      }
      
      private function §_-830§(param1:§_-O2i§) : Boolean
      {
         if(param1.battleType == §_-81M§.§_-Y1C§)
         {
            return Application.userProfile.§_-n26§().length < param1.wager.§_-HA§ || Application.userProfile.getLevel() < param1.wager.minLevel;
         }
         return false;
      }
      
      private function §_-WY§(param1:Array, param2:Boolean) : void
      {
         this.message.hide();
         if(state == READY && !§_-X1j§.§_-12n§.inBattle)
         {
            this.§_-xN§.§_-82v§(param1[0]);
            §_-X1j§.§_-12n§.friendInPair = param1[0];
            this.§_-xN§.addEventListener(§_-T1K§.ACCEPT_BATTLE_OFFER,this.§_-h2n§);
            this.§_-xN§.addEventListener(§_-T1K§.DECLINE_BATTLE_OFFER,this.§_-bN§);
            this.§_-xN§.show(true);
         }
         else
         {
            if(this.§_-xN§)
            {
               this.§_-xN§.hide();
            }
            §_-Q1h§ = false;
            this.§_-91f§ = false;
            connect(Server.§_-O2A§(§_-c1G§.PVP),this.§_-S4§,this.§_-nD§);
         }
      }
      
      private function §_-Jk§() : void
      {
         if(!this.§_-UL§)
         {
            this.§_-UL§ = new §_-Es§(§_-Es§.§_-kR§,§_-lm§,false);
            this.§_-UL§.addEventListener(§_-T1K§.CANCEL_BATTLE_REQUEST,function(param1:Event):void
            {
               cancelBattle();
            });
         }
         this.§_-UL§.show();
      }
      
      private function §_-M2e§() : void
      {
         if(this.§_-xN§)
         {
            this.§_-xN§.removeEventListener(§_-T1K§.ACCEPT_BATTLE_OFFER,this.§_-h2n§);
            this.§_-xN§.removeEventListener(§_-T1K§.DECLINE_BATTLE_OFFER,this.§_-bN§);
         }
      }
      
      private function §_-h2n§(param1:Event) : void
      {
         this.§_-M2e§();
         var _loc2_:§_-zb§ = §_-zb§.§_-L22§;
         if(_loc2_)
         {
            _loc2_.hide();
         }
         §_-YQ§.removeAllPopUps();
         §_-T2G§.§_-912§();
         if(Boolean(info) && §_-33r§.§_-kg§(Application.userProfile,info.§_-D1h§()))
         {
            Application.§_-E1k§.§_-MO§(§_-21w§.§_-G31§,this.§_-Xx§);
         }
         else
         {
            this.§_-L1u§();
         }
      }
      
      private function §_-Xx§() : void
      {
         if(!info)
         {
            return;
         }
         if(info.scenario is §_-22N§)
         {
            if(Boolean(info.missionIds) && Boolean(info.missionIds.length > 1) && !§_-qW§.getInstance().isInitialized())
            {
               this.§_-M1s§();
            }
            else
            {
               this.§_-Nj§();
            }
            §_-C3P§.§_-a1r§();
         }
         else
         {
            this.§_-C3N§();
         }
      }
      
      private function §_-M1s§() : void
      {
         §_-X1j§.§_-A24§.§_-I3T§(this.§_-Nj§,§_-I31§,§_-v5§);
      }
      
      private function §_-Nj§() : void
      {
         §_-Bx§.§_-O2o§(§_-22N§(info.scenario),this.§_-C3N§);
      }
      
      private function §_-C3N§() : void
      {
         §_-J2l§.§_-m1I§();
         §_-J2l§.§_-e1L§(§_-s2a§.BATTLE_INIT);
         connect(info.§_-wA§,this.§_-X3§,this.§_-nD§);
      }
      
      private function §_-bN§(param1:Event = null) : void
      {
         this.§_-M2e§();
         var _loc2_:BattleOfferDialog = param1.currentTarget as BattleOfferDialog;
         if(_loc2_)
         {
            _loc2_.hide();
         }
         this.§_-Ic§();
      }
      
      private function §_-Ic§() : void
      {
         if(this.isDisposed())
         {
            return;
         }
         §_-X1j§.§_-12n§.friendInPair = null;
         if(this.message)
         {
            this.message.hide();
         }
         if(info)
         {
            this.§_-I2D§ = info;
            try
            {
               this.§_-EP§(this.§_-I2D§.§_-wA§,this.§_-X2I§,this.§_-Pw§);
            }
            catch(e:Error)
            {
            }
         }
      }
      
      private function §_-Pw§() : void
      {
         this.§_-g2z§ = Starling.juggler.repeatCall(this.§_-EP§,2,0,this.§_-I2D§.§_-wA§,this.§_-X2I§,null);
         this.§_-L25§ = true;
      }
      
      private function §_-EP§(param1:Server, param2:Function, param3:Function) : void
      {
         if(!§_-c1K§ || !§_-c1K§.§_-928§() && !this.isDisposed())
         {
            connect(param1,param2,param3);
         }
      }
      
      private function §_-X2I§() : void
      {
         if(this.§_-L25§)
         {
            Starling.juggler.removeByID(this.§_-g2z§);
            this.§_-L25§ = false;
         }
         if(!this.§_-I2D§)
         {
            return;
         }
         var _loc1_:RejectBattleOffer = new RejectBattleOffer();
         §_-22§(_loc1_);
         _loc1_.battleId = this.§_-I2D§.battleId;
         _loc1_.manual = this.§_-91f§;
         if(§_-c1K§)
         {
            §_-c1K§.send(_loc1_);
         }
         this.§_-I2D§ = null;
         changeState(READY);
      }
      
      private function §_-L1u§() : void
      {
         this.§_-Ic§();
         §_-fH§.§_-q1a§(§_-s2a§.§_-K3t§(§_-s2a§.TITLE_BATTLE_OFFER_PROFILE_REJECT),§_-s2a§.§_-K3t§(§_-s2a§.BATTLE_OFFER_PROFILE_REJECT));
      }
      
      override protected function §_-nD§() : void
      {
         super.§_-nD§();
      }
      
      private function §_-X3§() : void
      {
         var _loc1_:JoinToBattle = null;
         if(info)
         {
            §_-J2l§.§_-e1L§(§_-s2a§.BATTLE_PVP_LOGIN);
            _loc1_ = new JoinToBattle();
            §_-22§(_loc1_);
            _loc1_.battleId = info.battleId;
            §_-c1K§.send(_loc1_);
            §_-LG§();
         }
         else
         {
            §_-J2l§.§_-m1I§();
            this.§_-nD§();
         }
      }
      
      private function §_-S4§() : void
      {
         if(!info)
         {
            return;
         }
         var _loc1_:RejectBattleOffer = new RejectBattleOffer();
         §_-22§(_loc1_);
         _loc1_.battleId = info.battleId;
         _loc1_.manual = this.§_-91f§;
         §_-c1K§.send(_loc1_);
         changeState(READY);
      }
      
      override protected function §_-rn§(param1:§_-63i§) : void
      {
         changeState(§_-83l§);
         var _loc2_:BattleCreated = BattleCreated(param1.message);
         info.seed = _loc2_.seed;
         info.battleId = _loc2_.battleId;
         info.mapId = _loc2_.mapId;
         info.preCalculatedPoints = _loc2_.preCalculatedPoints;
         if(_loc2_.wager != §_-82X§.§_-F1d§)
         {
            info.wager = _loc2_.wager;
         }
         info.reagentsForBattle = §_-b1L§.§_-n2§(_loc2_.reagentsForBattle);
         §_-U2s§(_loc2_.playerStructs);
         §_-41G§.load(info.mapId,false,false,info.§_-83I§().concat(info.§_-b2W§()) as Vector.<UserProfile>,this.§_-lt§,§_-QA§);
      }
      
      private function §_-lt§(param1:§_-03A§) : void
      {
         var _loc2_:§_-O2i§ = null;
         if(state == §_-83l§)
         {
            _loc2_ = info;
            _loc2_.mapRecord = param1.mapRecord;
            _loc2_.§_-u2Y§ = param1.§_-JV§();
            §_-j2n§ = false;
            changeState(READY);
            §_-X1j§.§_-12n§.§_-j4§(_loc2_,§_-c1K§);
         }
      }
      
      override protected function §_-is§(param1:§_-63i§) : void
      {
         var _loc2_:PvpSystemMessage = PvpSystemMessage(param1.message);
         §_-J2l§.§_-m1I§();
         this.§_-Jk§();
      }
      
      override protected function §_-D3b§() : void
      {
         this.§_-N16§ = null;
         super.§_-D3b§();
      }
      
      private function isDisposed() : Boolean
      {
         return §_-41G§ == null;
      }
   }
}

