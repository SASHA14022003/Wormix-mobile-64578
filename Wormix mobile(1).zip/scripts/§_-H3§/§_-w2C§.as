package §_-H3§
{
   import §_-D3A§.§_-TZ§;
   import §_-U1i§.§_-O2i§;
   import §_-l1g§.§_-L3Q§;
   import §_-x2Q§.§_-dU§;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   
   public class §_-w2C§
   {
      
      public var info:§_-O2i§;
      
      public var onSuccess:Function;
      
      public var onFail:Function;
      
      public function §_-w2C§(param1:§_-O2i§, param2:Function, param3:Function)
      {
         super();
         this.info = param1;
         this.onSuccess = param2;
         this.onFail = param3;
      }
   }
}

