package
{
   import §_-Ta§.VipInfoView;
   import §_-YF§.§_-L29§;
   import §_-f1Q§.*;
   import §_-l1K§.§_-F3m§;
   import §_-l1K§.§_-I7§;
   import §_-l1K§.§_-m2§;
   import com.hurlant.math.*;
   import com.hurlant.util.der.§_-p1B§;
   import feathers.controls.Panel;
   import flash.display.Loader;
   import flash.display.Sprite;
   import flash.events.Event;
   import flash.geom.Rectangle;
   import flash.net.URLRequest;
   import ru.pragmatix.wormix.messages.clans.request.PostClanNewsRequest;
   import ru.pragmatix.wormix.messages.clans.response.PostClanNewsResponse;
   import ru.pragmatix.wormix.objects.*;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   import starling.utils.Pool;
   import starling.utils.RectangleUtil;
   import starling.utils.ScaleMode;
   import starling.utils.SystemUtil;
   
   use namespace bi_internal;
   
   public class §_-32r§ extends Sprite
   {
      
      private var §_-S2q§:Loader;
      
      public function §_-32r§()
      {
         super();
         var _loc1_:String = §_-L29§.§_-f1N§("preloader/preloader_back.jpg");
         var _loc2_:URLRequest = new URLRequest(_loc1_);
         this.§_-S2q§ = new Loader();
         this.§_-S2q§.load(_loc2_);
         addChild(this.§_-S2q§);
         this.§_-S2q§.contentLoaderInfo.addEventListener(flash.events.Event.COMPLETE,this.§_-63y§);
         addEventListener(flash.events.Event.ADDED_TO_STAGE,this.§_-63y§);
      }
      
      private function §_-63y§(param1:flash.events.Event) : void
      {
         var _loc2_:Rectangle = null;
         var _loc3_:Rectangle = null;
         var _loc4_:Rectangle = null;
         if(stage)
         {
            _loc2_ = Pool.getRectangle(0,0,this.§_-S2q§.width,this.§_-S2q§.height);
            _loc3_ = Pool.getRectangle(0,0,stage.stageWidth,stage.stageHeight);
            _loc4_ = RectangleUtil.fit(_loc2_,_loc3_,ScaleMode.NO_BORDER);
            this.§_-S2q§.x = _loc4_.x;
            this.§_-S2q§.y = _loc4_.y;
            this.§_-S2q§.width = _loc4_.width;
            this.§_-S2q§.height = _loc4_.height;
            Pool.putRectangle(_loc2_);
            Pool.putRectangle(_loc3_);
            Pool.putRectangle(_loc4_);
         }
      }
   }
}

