package §_-K3q§
{
   import §_-3D§.§_-E3x§;
   import §_-3D§.§_-a2b§;
   import §_-5Y§.§_-h2c§;
   import §_-91A§.§_-N2O§;
   import §_-C3f§.§_-yG§;
   import §_-CF§.§_-E19§;
   import §_-CF§.§_-x2t§;
   import §_-D3A§.§_-TZ§;
   import §_-TF§.§_-P19§;
   import §_-Vg§.§_-X7§;
   import §_-hO§.§_-BY§;
   import §_-l1K§.§_-W2f§;
   import §_-l1g§.§_-L3Q§;
   import §_-r1C§.§_-h2B§;
   import §_-zI§.§_-A1s§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.main.server.ClanMemberStructure;
   import ru.pragmatix.wormix.messages.clans.structures.ClanChatMessageTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanNewsTO;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.objects.*;
   import ru.pragmatix.wormix.physics.Force;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.physics.model.PhysParams;
   import ru.pragmatix.wormix.utils.§_-6A§;
   import starling.display.DisplayObject;
   import starling.display.Sprite;
   import starling.events.Event;
   
   public class §_-L3A§ extends §_-F3o§ implements §_-N2O§
   {
      
      private var tier:§_-A1s§;
      
      private var §_-DY§:uint;
      
      private var §_-SQ§:Vector.<§_-8K§>;
      
      private var §_-V4§:Vector.<§_-8K§>;
      
      private var §_-91Q§:uint = 200;
      
      private var clanEmblem:Vector.<uint>;
      
      private var §_-Bj§:§_-X7§;
      
      public function §_-L3A§(param1:int, param2:int, param3:§_-01J§, param4:§_-A1s§, param5:Vector.<uint>)
      {
         var sprite:Sprite;
         var unit:§_-8K§ = null;
         var x:int = param1;
         var y:int = param2;
         var owner:§_-01J§ = param3;
         var tier:§_-A1s§ = param4;
         var clanEmblem:Vector.<uint> = param5;
         this.§_-SQ§ = new Vector.<§_-8K§>(0);
         this.§_-V4§ = new Vector.<§_-8K§>(0);
         super();
         this.§_-DY§ = owner.squad.getNumber();
         this.tier = tier;
         this.clanEmblem = clanEmblem;
         this.§_-Bj§ = new §_-X7§();
         this.§_-Bj§.setData(clanEmblem,tier);
         sprite = new Sprite();
         sprite.addChild(this.§_-Bj§);
         this.§_-Bj§.y = 5;
         §_-z1H§ = sprite;
         this.x = x;
         this.y = y;
         §_-Nt§ = true;
         §_-TZ§.addListener(this,§_-L3Q§.§_-Qw§,defaultOnDamaged);
         physParams.addForce(Force.GRAVITY);
         physParams.collidesWith = PhysParams.COLLIDES_WITH_GROUND;
         addEventListener(§_-L3Q§.§_-o13§,function(param1:Event):void
         {
            if(speed > 3)
            {
               §_-h2B§.play(§_-d27§.BONUS);
            }
         });
         if(tier.§_-b24§())
         {
            for each(unit in owner.squad.getUnits())
            {
               unit.buffs.place(new §_-a2b§(tier));
               this.§_-V4§.push(unit);
            }
         }
         §_-X1j§.§_-12n§.scene.gameObjectProcessor.§_-L2X§(this,true);
      }
      
      public static function create(param1:int, param2:int, param3:§_-01J§) : §_-L3A§
      {
         var _loc6_:§_-A1s§ = null;
         var _loc4_:§_-L3A§ = null;
         var _loc5_:ClanMemberStructure = param3.record.clanMember;
         if((Boolean(_loc5_)) && _loc5_.clanId != 0)
         {
            _loc6_ = §_-6A§.§_-oy§(_loc5_.prevSeasonTopPlace);
            if(_loc6_ != null)
            {
               _loc4_ = new §_-L3A§(param1,param2,param3,_loc6_,_loc5_.clanEmblem);
            }
         }
         return _loc4_;
      }
      
      override public function nextState() : void
      {
         super.nextState();
         if(§_-X1j§.§_-12n§.scene.gameObjectProcessor.§_-O1C§() % 10 == 0)
         {
            this.§_-K3e§();
         }
      }
      
      private function §_-K3e§() : void
      {
         var _loc3_:§_-8K§ = null;
         var _loc1_:Vector.<§_-01J§> = Physics.getUnitsInCircle(x,y,this.§_-91Q§);
         var _loc2_:Vector.<§_-8K§> = new Vector.<§_-8K§>(0);
         for each(_loc3_ in _loc1_)
         {
            if(_loc3_.squad.getNumber() == this.§_-DY§)
            {
               if(this.§_-SQ§.indexOf(_loc3_) == -1)
               {
                  _loc3_.buffs.place(new §_-E3x§(this.tier));
               }
               _loc2_.push(_loc3_);
            }
         }
         for each(_loc3_ in this.§_-SQ§)
         {
            if(!_loc3_.disposed && _loc2_.indexOf(_loc3_) == -1)
            {
               _loc3_.buffs.§_-e1z§(§_-E3x§.NAME);
            }
         }
         this.§_-SQ§ = _loc2_;
      }
      
      override public function defaultOnDisposed(param1:Event = null) : void
      {
         var _loc2_:§_-8K§ = null;
         for each(_loc2_ in this.§_-SQ§)
         {
            if(!_loc2_.disposed)
            {
               _loc2_.buffs.§_-e1z§(§_-E3x§.NAME);
            }
         }
         if(this.tier.§_-b24§())
         {
            for each(_loc2_ in this.§_-V4§)
            {
               if(!_loc2_.disposed)
               {
                  _loc2_.buffs.§_-e1z§(§_-a2b§.NAME);
               }
            }
         }
         this.tier = null;
         this.§_-Bj§.dispose();
         super.defaultOnDisposed(param1);
         §_-TZ§.removeListener(this,§_-L3Q§.§_-Qw§,defaultOnDamaged);
      }
      
      public function §_-Xo§() : DisplayObject
      {
         if(!disposed && Boolean(this.tier))
         {
            return new §_-P19§(this.tier.name,this.tier.description);
         }
         return null;
      }
      
      public function §_-b2T§() : void
      {
         dispatchEventWith(§_-BY§.HIDE);
      }
      
      public function §_-Xb§() : DisplayObject
      {
         return §_-z1H§;
      }
      
      public function §_-k1K§() : void
      {
      }
   }
}

