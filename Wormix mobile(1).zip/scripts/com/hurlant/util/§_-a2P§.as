package com.hurlant.util
{
   import §_-31N§.§_-Yy§;
   import §_-A1K§.§_-6L§;
   import §_-A1K§.§_-U11§;
   import §_-CF§.§_-E19§;
   import §_-CF§.§_-x2t§;
   import §_-DJ§.§_-fH§;
   import §_-rM§.§_-61j§;
   import §_-s20§.§_-J2g§;
   import §_-z1g§.§_-5c§;
   import com.hurlant.math.BigInteger;
   import flash.net.LocalConnection;
   import flash.system.System;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import ru.pragmatix.wormix.game.ai.§_-de§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.client.PumpReactionRate;
   import ru.pragmatix.wormix.objects.Direction;
   
   public class §_-a2P§
   {
      
      public function §_-a2P§()
      {
         super();
      }
      
      public static function gc() : void
      {
         try
         {
            new LocalConnection().connect("foo");
            new LocalConnection().connect("foo");
         }
         catch(e:*)
         {
         }
      }
      
      public static function get §_-I2N§() : uint
      {
         return System.totalMemory;
      }
   }
}

