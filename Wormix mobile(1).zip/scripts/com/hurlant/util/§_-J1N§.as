package com.hurlant.util
{
   import §_-931§.§_-sz§;
   import §_-A2U§.§_-A23§;
   import §_-B1y§.§_-bs§;
   import §_-Cl§.*;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-R2I§.§_-u2V§;
   import §_-RE§.§_-D3v§;
   import §_-RE§.§_-r2q§;
   import §_-hO§.§_-03k§;
   import §_-p18§.§_-vd§;
   import §_-r1C§.§_-h2B§;
   import §_-s20§.§_-J2g§;
   import §_-u2J§.§_-T1K§;
   import §_-w2W§.§_-v27§;
   import §_-z1g§.§_-82X§;
   import com.distriqt.extension.cloudstorage.CloudStorage;
   import com.hurlant.crypto.tls.§_-F16§;
   import com.hurlant.crypto.tls.§_-Tx§;
   import com.hurlant.crypto.tls.§_-a2D§;
   import feathers.controls.Button;
   import feathers.controls.ToggleButton;
   import flash.utils.ByteArray;
   import ru.pragmatix.flox.social.utils.id.MobilePlatformAccountController;
   import ru.pragmatix.flox.social.utils.id.UserIdType;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.§_-738§;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.items.craft.*;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.objects.§_-Qi§;
   import ru.pragmatix.wormix.pvp.messages.ex.CallToBattle;
   import ru.pragmatix.wormix.utils.FrameTimer;
   import ru.pragmatix.wormix.weapons.ammo.VerticalDrillMissile;
   import ru.pragmatix.wormix.weapons.ammo.VerticalDrillStanding;
   import starling.core.Starling;
   import starling.display.Sprite;
   import starling.events.Event;
   
   public class §_-J1N§
   {
      
      public function §_-J1N§()
      {
         super();
      }
      
      public static function §_-n2u§(param1:String) : ByteArray
      {
         var _loc3_:* = 0;
         param1 = param1.replace(/\s|:/gm,"");
         var _loc2_:ByteArray = new ByteArray();
         if((param1.length & 1) == 1)
         {
            param1 = "0" + param1;
         }
         _loc3_ = 0;
         while(_loc3_ < param1.length)
         {
            _loc2_[_loc3_ / 2] = parseInt(param1.substr(_loc3_,2),16);
            _loc3_ += 2;
         }
         return _loc2_;
      }
      
      public static function §_-z2W§(param1:ByteArray, param2:Boolean = false) : String
      {
         var _loc4_:* = 0;
         var _loc3_:String = "";
         _loc4_ = 0;
         while(_loc4_ < param1.length)
         {
            _loc3_ += ("0" + param1[_loc4_].toString(16)).substr(-2,2);
            if(param2)
            {
               if(_loc4_ < param1.length - 1)
               {
                  _loc3_ += ":";
               }
            }
            _loc4_++;
         }
         return _loc3_;
      }
      
      public static function toString(param1:String) : String
      {
         var _loc2_:ByteArray = §_-n2u§(param1);
         return _loc2_.readUTFBytes(_loc2_.length);
      }
      
      public static function fromString(param1:String, param2:Boolean = false) : String
      {
         var _loc3_:ByteArray = new ByteArray();
         _loc3_.writeUTFBytes(param1);
         return §_-z2W§(_loc3_,param2);
      }
   }
}

