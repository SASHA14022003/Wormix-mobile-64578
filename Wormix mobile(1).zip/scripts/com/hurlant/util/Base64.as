package com.hurlant.util
{
   import §_-5Y§.§_-h2c§;
   import §_-62§.§_-O2H§;
   import §_-73I§.§_-q15§;
   import §_-82a§.§_-pp§;
   import §_-CF§.§_-x2t§;
   import §_-G2H§.*;
   import §_-TF§.§_-y2n§;
   import §_-Ta§.*;
   import §_-Vg§.*;
   import §_-Y1Q§.§_-aG§;
   import §_-YF§.§_-q2v§;
   import §_-Z1L§.§_-A2V§;
   import §_-Z1L§.§_-H1K§;
   import §_-fo§.§_-21L§;
   import §_-fo§.§_-r5§;
   import §_-k2s§.§_-8c§;
   import §_-k2s§.§_-Go§;
   import §_-kP§.*;
   import §_-l2r§.§_-K1t§;
   import §_-o14§.§_-Dd§;
   import §_-qH§.§_-AC§;
   import §_-r1C§.§_-h2B§;
   import §_-sQ§.§_-H3D§;
   import §_-w§.§_-63m§;
   import §_-x2Q§.§_-dU§;
   import com.greensock.loading.*;
   import com.greensock.loading.core.LoaderCore;
   import com.hurlant.crypto.tls.§_-F16§;
   import com.hurlant.crypto.tls.§_-Tx§;
   import com.hurlant.crypto.tls.§_-a2D§;
   import com.hurlant.math.BigInteger;
   import dragonBones.animation.WorldClock;
   import feathers.controls.text.TextFieldTextRenderer;
   import feathers.controls.text.TextInstanceCreator;
   import feathers.themes.FontColor;
   import feathers.themes.FontSize;
   import flash.geom.Point;
   import flash.text.TextField;
   import flash.text.TextFormatAlign;
   import flash.utils.ByteArray;
   import flash.utils.setTimeout;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.flox.social.model.PaymentOption;
   import ru.pragmatix.flox.social.response.SocialResponse;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.response.*;
   import ru.pragmatix.wormix.messages.clans.structures.ClanChatMessageTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanNewsTO;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.scene.SortingLayer;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.*;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Image;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.utils.Color;
   import starling.utils.Pool;
   
   public class Base64
   {
      
      private static const _encodeChars:Vector.<int> = InitEncoreChar();
      
      private static const _decodeChars:Vector.<int> = InitDecodeChar();
      
      public function Base64()
      {
         super();
      }
      
      public static function encodeByteArray(param1:ByteArray) : String
      {
         var _loc2_:int = 0;
         var _loc6_:ByteArray = new ByteArray();
         _loc6_.length = (2 + param1.length - (param1.length + 2) % 3) * 4 / 3;
         var _loc5_:int = 0;
         var _loc3_:int = param1.length % 3;
         var _loc4_:int = param1.length - _loc3_;
         while(_loc5_ < _loc4_)
         {
            _loc2_ = param1[_loc5_++] << 16 | param1[_loc5_++] << 8 | param1[_loc5_++];
            _loc2_ = _encodeChars[_loc2_ >>> 18] << 24 | _encodeChars[_loc2_ >>> 12 & 0x3F] << 16 | _encodeChars[_loc2_ >>> 6 & 0x3F] << 8 | _encodeChars[_loc2_ & 0x3F];
            _loc6_.writeInt(_loc2_);
         }
         if(_loc3_ == 1)
         {
            _loc2_ = int(param1[_loc5_]);
            _loc2_ = _encodeChars[_loc2_ >>> 2] << 24 | _encodeChars[(_loc2_ & 3) << 4] << 16 | 0x3D00 | 0x3D;
            _loc6_.writeInt(_loc2_);
         }
         else if(_loc3_ == 2)
         {
            _loc2_ = param1[_loc5_++] << 8 | param1[_loc5_];
            _loc2_ = _encodeChars[_loc2_ >>> 10] << 24 | _encodeChars[_loc2_ >>> 4 & 0x3F] << 16 | _encodeChars[(_loc2_ & 0x0F) << 2] << 8 | 0x3D;
            _loc6_.writeInt(_loc2_);
         }
         _loc6_.position = 0;
         return _loc6_.readUTFBytes(_loc6_.length);
      }
      
      public static function decodeToByteArray(param1:String) : ByteArray
      {
         var _loc3_:int = 0;
         var _loc4_:int = 0;
         var _loc7_:int = 0;
         var _loc5_:int = 0;
         var _loc9_:int = 0;
         var _loc6_:int = 0;
         var _loc8_:ByteArray = null;
         _loc6_ = int(param1.length);
         _loc9_ = 0;
         _loc8_ = new ByteArray();
         var _loc2_:ByteArray = new ByteArray();
         _loc2_.writeUTFBytes(param1);
         while(_loc9_ < _loc6_)
         {
            do
            {
               _loc3_ = _decodeChars[_loc2_[_loc9_++]];
            }
            while(_loc9_ < _loc6_ && _loc3_ == -1);
            if(_loc3_ == -1)
            {
               break;
            }
            do
            {
               _loc4_ = _decodeChars[_loc2_[_loc9_++]];
            }
            while(_loc9_ < _loc6_ && _loc4_ == -1);
            if(_loc4_ == -1)
            {
               break;
            }
            _loc8_.writeByte(_loc3_ << 2 | (_loc4_ & 0x30) >> 4);
            do
            {
               _loc7_ = int(_loc2_[_loc9_++]);
               if(_loc7_ == 61)
               {
                  return _loc8_;
               }
               _loc7_ = _decodeChars[_loc7_];
            }
            while(_loc9_ < _loc6_ && _loc7_ == -1);
            if(_loc7_ == -1)
            {
               break;
            }
            _loc8_.writeByte((_loc4_ & 0x0F) << 4 | (_loc7_ & 0x3C) >> 2);
            do
            {
               _loc5_ = int(_loc2_[_loc9_++]);
               if(_loc5_ == 61)
               {
                  return _loc8_;
               }
               _loc5_ = _decodeChars[_loc5_];
            }
            while(_loc9_ < _loc6_ && _loc5_ == -1);
            if(_loc5_ == -1)
            {
               break;
            }
            _loc8_.writeByte((_loc7_ & 3) << 6 | _loc5_);
         }
         _loc8_.position = 0;
         return _loc8_;
      }
      
      public static function encode(param1:String) : String
      {
         var _loc2_:ByteArray = new ByteArray();
         _loc2_.writeUTFBytes(param1);
         return encodeByteArray(_loc2_);
      }
      
      public static function decode(param1:String) : String
      {
         var _loc2_:ByteArray = decodeToByteArray(param1);
         return _loc2_.readUTFBytes(_loc2_.length);
      }
      
      public static function InitEncoreChar() : Vector.<int>
      {
         var _loc3_:int = 0;
         var _loc2_:Vector.<int> = new Vector.<int>();
         var _loc1_:String = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
         _loc3_ = 0;
         while(_loc3_ < 64)
         {
            _loc2_.push(_loc1_.charCodeAt(_loc3_));
            _loc3_++;
         }
         return _loc2_;
      }
      
      public static function InitDecodeChar() : Vector.<int>
      {
         var _loc1_:Vector.<int> = new Vector.<int>();
         _loc1_.push(-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,62,-1,-1,-1,63,52,53,54,55,56,57,58,59,60,61,-1,-1,-1,-1,-1,-1,-1,0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,-1,-1,-1,-1,-1,-1,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,-1,-1,-1,-1,-2,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1);
         return _loc1_;
      }
   }
}

