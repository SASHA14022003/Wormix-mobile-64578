package com.hurlant.util
{
   import §_-5Y§.*;
   import §_-62§.§_-a3§;
   import §_-73d§.§_-x2C§;
   import §_-CF§.§_-E19§;
   import §_-DJ§.§_-J2l§;
   import §_-Ly§.§_-81L§;
   import §_-l1K§.§_-d2j§;
   import §_-r1C§.§_-h2B§;
   import com.hurlant.math.*;
   import feathers.data.ListCollection;
   import flash.utils.ByteArray;
   import ru.pragmatix.flox.social.model.PaymentOption;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import starling.events.Event;
   
   use namespace bi_internal;
   
   public class §_-F2L§
   {
      
      public function §_-F2L§()
      {
         super();
      }
      
      public static function equals(param1:ByteArray, param2:ByteArray) : Boolean
      {
         var _loc4_:int = 0;
         if(param1.length != param2.length)
         {
            return false;
         }
         var _loc3_:int = int(param1.length);
         _loc4_ = 0;
         while(_loc4_ < _loc3_)
         {
            if(param1[_loc4_] != param2[_loc4_])
            {
               return false;
            }
            _loc4_++;
         }
         return true;
      }
   }
}

