package com.hurlant.util.der
{
   import §_-31N§.§_-42G§;
   import §_-31Y§.§_-D3B§;
   import §_-5Y§.*;
   import §_-62§.§_-W1r§;
   import §_-62§.§_-a3§;
   import §_-A1K§.§_-7u§;
   import §_-B1y§.§_-F1P§;
   import §_-B1y§.§_-bs§;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-J2l§;
   import §_-F39§.*;
   import §_-L1H§.§_-C3e§;
   import §_-gG§.§_-M2S§;
   import §_-l1g§.§_-L3Q§;
   import §_-r1C§.§_-h2B§;
   import §_-rM§.§_-61j§;
   import §_-w2i§.§_-Ia§;
   import §_-z1g§.§_-4l§;
   import §_-z1g§.§_-522§;
   import §_-z1g§.§_-M2v§;
   import feathers.controls.text.TextFieldTextRenderer;
   import feathers.controls.text.TextInstanceCreator;
   import feathers.core.ITextRenderer;
   import feathers.themes.FontSize;
   import flash.display.Bitmap;
   import flash.display.BitmapData;
   import flash.text.TextFormatAlign;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.sets.ControlSets;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.gui.*;
   import ru.pragmatix.wormix.messages.server.ShowSystemMessage;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.social.common.post.*;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.LaserRay;
   import ru.pragmatix.wormix.weapons.ammo.StaticCharge;
   
   public class §_-b1U§ implements §_-W13§
   {
      
      protected var type:uint;
      
      protected var len:uint;
      
      protected var str:String;
      
      public function §_-b1U§(param1:uint, param2:uint)
      {
         super();
         this.type = param1;
         this.len = param2;
      }
      
      public function getLength() : uint
      {
         return len;
      }
      
      public function getType() : uint
      {
         return type;
      }
      
      public function setString(param1:String) : void
      {
         str = param1;
      }
      
      public function getString() : String
      {
         return str;
      }
      
      public function toString() : String
      {
         return §_-p1B§.§_-nF§ + str;
      }
      
      public function §_-VH§() : ByteArray
      {
         return null;
      }
   }
}

