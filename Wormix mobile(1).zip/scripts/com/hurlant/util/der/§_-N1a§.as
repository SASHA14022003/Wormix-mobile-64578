package com.hurlant.util.der
{
   import §_-F39§.§_-a2W§;
   import §_-Y1b§.§_-OP§;
   import com.hurlant.util.§_-J1N§;
   import flash.geom.Rectangle;
   import flash.utils.ByteArray;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.weapons.ammo.type.blocker.HealBlocker;
   import starling.display.Image;
   import starling.utils.Pool;
   import starling.utils.RectangleUtil;
   
   public class §_-N1a§
   {
      
      public static const §_-p2o§:Array = [{
         "name":"signedCertificate",
         "extract":true,
         "value":[{
            "name":"versionHolder",
            "optional":true,
            "value":[{"name":"version"}],
            "defaultValue":(function():Sequence
            {
               var _loc2_:Sequence = new Sequence(0,0);
               var _loc1_:§_-q2P§ = new §_-q2P§(2,1,§_-J1N§.§_-n2u§("00"));
               _loc2_.push(_loc1_);
               _loc2_.version = _loc1_;
               return _loc2_;
            })()
         },{"name":"serialNumber"},{
            "name":"signature",
            "value":[{"name":"algorithmId"}]
         },{
            "name":"issuer",
            "extract":true,
            "value":[{"name":"type"},{"name":"value"}]
         },{
            "name":"validity",
            "value":[{"name":"notBefore"},{"name":"notAfter"}]
         },{
            "name":"subject",
            "extract":true,
            "value":[]
         },{
            "name":"subjectPublicKeyInfo",
            "value":[{
               "name":"algorithm",
               "value":[{"name":"algorithmId"}]
            },{"name":"subjectPublicKey"}]
         },{
            "name":"extensions",
            "value":[]
         }]
      },{
         "name":"algorithmIdentifier",
         "value":[{"name":"algorithmId"}]
      },{
         "name":"encrypted",
         "value":null
      }];
      
      public static const §_-hD§:Array = [{
         "name":"tbsCertificate",
         "value":[{
            "name":"tag0",
            "value":[{"name":"version"}]
         },{"name":"serialNumber"},{"name":"signature"},{
            "name":"issuer",
            "value":[{"name":"type"},{"name":"value"}]
         },{
            "name":"validity",
            "value":[{"name":"notBefore"},{"name":"notAfter"}]
         },{"name":"subject"},{
            "name":"subjectPublicKeyInfo",
            "value":[{"name":"algorithm"},{"name":"subjectPublicKey"}]
         },{"name":"issuerUniqueID"},{"name":"subjectUniqueID"},{"name":"extensions"}]
      },{"name":"signatureAlgorithm"},{"name":"signatureValue"}];
      
      public static const §_-Yf§:Array = [{"name":"modulus"},{"name":"publicExponent"}];
      
      public static const §_-n2o§:Array = [{
         "name":"algorithm",
         "value":[{"name":"algorithmId"}]
      },{"name":"hash"}];
      
      public function §_-N1a§()
      {
         super();
      }
   }
}

