package com.hurlant.util.der
{
   import §_-12a§.§_-6p§;
   import §_-31N§.§_-42G§;
   import §_-51M§.Cat;
   import §_-62§.§_-T1y§;
   import §_-62§.§_-zF§;
   import §_-A1K§.§_-7u§;
   import §_-B1y§.§_-bs§;
   import §_-D3A§.§_-TZ§;
   import §_-Ly§.§_-81L§;
   import §_-Y1O§.§_-V23§;
   import §_-Y1b§.*;
   import §_-ZP§.§_-YG§;
   import §_-g2e§.§_-q2Z§;
   import §_-l1g§.§_-L3Q§;
   import §_-n1w§.*;
   import §_-nE§.SelectCraftWeaponScreen;
   import §_-nE§.§_-p16§;
   import §_-r1C§.§_-h2B§;
   import §_-w2i§.§_-Zd§;
   import com.distriqt.extension.inappbilling.Purchase;
   import com.greensock.*;
   import com.greensock.events.LoaderEvent;
   import com.greensock.loading.core.*;
   import com.greensock.plugins.*;
   import flash.display.DisplayObject;
   import flash.events.Event;
   import flash.filters.ColorMatrixFilter;
   import flash.utils.ByteArray;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.flox.social.model.PaymentOption;
   import ru.pragmatix.wormix.controller.§_-C2c§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.messages.clans.request.ClanSummaryRequest;
   import ru.pragmatix.wormix.messages.clans.request.DeleteClanRequest;
   import ru.pragmatix.wormix.messages.clans.response.ClanSummaryResponse;
   import ru.pragmatix.wormix.messages.clans.response.DeleteClanResponse;
   import ru.pragmatix.wormix.messages.server.VerifyPaymentResult;
   import ru.pragmatix.wormix.objects.Direction;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.utils.§_-72u§;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   
   public class §_-l1b§ implements §_-W13§
   {
      
      private var type:uint;
      
      private var len:uint;
      
      private var §_-ob§:Array;
      
      public function §_-l1b§(param1:uint, param2:uint, param3:*)
      {
         super();
         this.type = param1;
         this.len = param2;
         if(param3 is ByteArray)
         {
            parse(param3 as ByteArray);
         }
         else
         {
            if(!(param3 is String))
            {
               throw new Error("Invalid call to new ObjectIdentifier");
            }
            §_-u12§(param3 as String);
         }
      }
      
      private function §_-u12§(param1:String) : void
      {
         §_-ob§ = param1.split(".");
      }
      
      private function parse(param1:ByteArray) : void
      {
         var _loc3_:Boolean = false;
         var _loc5_:uint = uint(param1.readUnsignedByte());
         var _loc4_:Array = [];
         _loc4_.push(uint(_loc5_ / 40));
         _loc4_.push(uint(_loc5_ % 40));
         var _loc2_:uint = 0;
         while(param1.bytesAvailable > 0)
         {
            _loc5_ = uint(param1.readUnsignedByte());
            _loc3_ = (_loc5_ & 0x80) == 0;
            _loc5_ &= 127;
            _loc2_ = _loc2_ * 128 + _loc5_;
            if(_loc3_)
            {
               _loc4_.push(_loc2_);
               _loc2_ = 0;
            }
         }
         §_-ob§ = _loc4_;
      }
      
      public function getLength() : uint
      {
         return len;
      }
      
      public function getType() : uint
      {
         return type;
      }
      
      public function §_-VH§() : ByteArray
      {
         var _loc4_:int = 0;
         var _loc1_:int = 0;
         var _loc3_:Array = [];
         _loc3_[0] = §_-ob§[0] * 40 + §_-ob§[1];
         _loc4_ = 2;
         while(_loc4_ < §_-ob§.length)
         {
            _loc1_ = int(parseInt(§_-ob§[_loc4_]));
            if(_loc1_ < 128)
            {
               _loc3_.push(_loc1_);
            }
            else if(_loc1_ < 16384)
            {
               _loc3_.push(_loc1_ >> 7 | 0x80);
               _loc3_.push(_loc1_ & 0x7F);
            }
            else if(_loc1_ < 2097152)
            {
               _loc3_.push(_loc1_ >> 14 | 0x80);
               _loc3_.push(_loc1_ >> 7 & 0x7F | 0x80);
               _loc3_.push(_loc1_ & 0x7F);
            }
            else
            {
               if(_loc1_ >= 268435456)
               {
                  throw new Error("OID element bigger than we thought. :(");
               }
               _loc3_.push(_loc1_ >> 21 | 0x80);
               _loc3_.push(_loc1_ >> 14 & 0x7F | 0x80);
               _loc3_.push(_loc1_ >> 7 & 0x7F | 0x80);
               _loc3_.push(_loc1_ & 0x7F);
            }
            _loc4_++;
         }
         len = _loc3_.length;
         if(type == 0)
         {
            type = 6;
         }
         _loc3_.unshift(len);
         _loc3_.unshift(type);
         var _loc2_:ByteArray = new ByteArray();
         _loc4_ = 0;
         while(_loc4_ < _loc3_.length)
         {
            _loc2_[_loc4_] = _loc3_[_loc4_];
            _loc4_++;
         }
         return _loc2_;
      }
      
      public function toString() : String
      {
         return §_-p1B§.§_-nF§ + §_-ob§.join(".");
      }
      
      public function dump() : String
      {
         return "OID[" + type + "][" + len + "][" + toString() + "]";
      }
   }
}

