package com.hurlant.util.der
{
   import §_-62§.§_-O2H§;
   import §_-A1K§.§_-TA§;
   import §_-F2Q§.GestureEvent;
   import §_-Ly§.§_-81L§;
   import §_-N8§.§_-o2w§;
   import §_-TF§.§_-q1j§;
   import §_-l1K§.*;
   import §_-o14§.*;
   import §_-r1C§.§_-h2B§;
   import §_-t2x§.§_-53b§;
   import §_-t2x§.§_-H12§;
   import §_-t2x§.§_-nH§;
   import §_-t2x§.§_-v2c§;
   import §_-t2x§.§_-w1o§;
   import config.§_-vR§;
   import dragonBones.animation.WorldClock;
   import flash.geom.Point;
   import flash.utils.ByteArray;
   import org.gestouch.core.GestureState;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.EffectType;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.messages.structures.WeaponStructure;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.platform.§_-WK§;
   import ru.pragmatix.wormix.utils.MathUtil;
   import starling.display.DisplayObject;
   import starling.events.Event;
   import starling.utils.Pool;
   import starling.utils.SystemUtil;
   
   public class §_-p1B§
   {
      
      public static var §_-nF§:String = "";
      
      public function §_-p1B§()
      {
         super();
      }
      
      public static function parse(param1:ByteArray, param2:* = null) : §_-W13§
      {
         var _loc4_:int = 0;
         var _loc5_:ByteArray = null;
         var _loc18_:int = 0;
         var _loc7_:Sequence = null;
         var _loc21_:Array = null;
         var _loc12_:Object = null;
         var _loc13_:Boolean = false;
         var _loc15_:Boolean = false;
         var _loc17_:String = null;
         var _loc19_:* = undefined;
         var _loc14_:int = 0;
         var _loc3_:ByteArray = null;
         var _loc20_:§_-W13§ = null;
         var _loc16_:§_-93y§ = null;
         var _loc10_:§_-cz§ = null;
         var _loc22_:§_-b1U§ = null;
         var _loc8_:§_-p29§ = null;
         var _loc11_:int = int(param1.readUnsignedByte());
         var _loc6_:Boolean = (_loc11_ & 0x20) != 0;
         _loc11_ &= 31;
         var _loc9_:int = int(param1.readUnsignedByte());
         if(_loc9_ >= 128)
         {
            _loc4_ = _loc9_ & 0x7F;
            _loc9_ = 0;
            while(_loc4_ > 0)
            {
               _loc9_ = _loc9_ << 8 | param1.readUnsignedByte();
               _loc4_--;
            }
         }
         var _loc23_:int = _loc11_;
         switch(_loc23_)
         {
            case 0:
            case 16:
               break;
            case 17:
               _loc18_ = int(param1.position);
               _loc16_ = new §_-93y§(_loc11_,_loc9_);
               while(param1.position < _loc18_ + _loc9_)
               {
                  _loc16_.push(§_-p1B§.parse(param1));
               }
               return _loc16_;
            case 2:
               _loc5_ = new ByteArray();
               param1.readBytes(_loc5_,0,_loc9_);
               _loc5_.position = 0;
               return new §_-q2P§(_loc11_,_loc9_,_loc5_);
            case 6:
               _loc5_ = new ByteArray();
               param1.readBytes(_loc5_,0,_loc9_);
               _loc5_.position = 0;
               return new §_-l1b§(_loc11_,_loc9_,_loc5_);
            default:
               switch(_loc23_)
               {
                  default:
                     trace("I DONT KNOW HOW TO HANDLE DER stuff of TYPE " + _loc11_);
                  case 4:
                     §§goto(addr02d8);
                  case 5:
                     return null;
                  case 19:
                     _loc22_ = new §_-b1U§(_loc11_,_loc9_);
                     _loc22_.setString(param1.readMultiByte(_loc9_,"US-ASCII"));
                     return _loc22_;
                  case 34:
                  case 20:
                     break;
                  case 23:
                     _loc8_ = new §_-p29§(_loc11_,_loc9_);
                     _loc8_.§_-d2i§(param1.readMultiByte(_loc9_,"US-ASCII"));
                     return _loc8_;
               }
               _loc22_ = new §_-b1U§(_loc11_,_loc9_);
               _loc22_.setString(param1.readMultiByte(_loc9_,"latin1"));
               return _loc22_;
            case 3:
               if(param1[param1.position] == 0)
               {
                  param1.position++;
                  _loc9_--;
               }
               addr02d8:
               _loc10_ = new §_-cz§(_loc11_,_loc9_);
               param1.readBytes(_loc10_,0,_loc9_);
               return _loc10_;
         }
         _loc18_ = int(param1.position);
         _loc7_ = new Sequence(_loc11_,_loc9_);
         _loc21_ = param2 as Array;
         if(_loc21_ != null)
         {
            _loc21_ = _loc21_.concat();
         }
         while(param1.position < _loc18_ + _loc9_)
         {
            _loc12_ = null;
            if(_loc21_ != null)
            {
               _loc12_ = _loc21_.shift();
            }
            if(_loc12_ != null)
            {
               while(_loc12_ && _loc12_.optional)
               {
                  _loc13_ = _loc12_.value is Array;
                  _loc15_ = §_-T2E§(param1);
                  if(_loc13_ == _loc15_)
                  {
                     break;
                  }
                  _loc7_.push(_loc12_.defaultValue);
                  _loc7_[_loc12_.name] = _loc12_.defaultValue;
                  _loc12_ = _loc21_.shift();
               }
            }
            if(_loc12_ != null)
            {
               _loc17_ = _loc12_.name;
               _loc19_ = _loc12_.value;
               if(_loc12_.extract)
               {
                  _loc14_ = §_-H3u§(param1);
                  _loc3_ = new ByteArray();
                  _loc3_.writeBytes(param1,param1.position,_loc14_);
                  _loc7_[_loc17_ + "_bin"] = _loc3_;
               }
               _loc20_ = §_-p1B§.parse(param1,_loc19_);
               _loc7_.push(_loc20_);
               _loc7_[_loc17_] = _loc20_;
            }
            else
            {
               _loc7_.push(§_-p1B§.parse(param1));
            }
         }
         return _loc7_;
      }
      
      private static function §_-H3u§(param1:ByteArray) : int
      {
         var _loc2_:int = 0;
         var _loc3_:uint = uint(param1.position);
         param1.position++;
         var _loc4_:int = int(param1.readUnsignedByte());
         if(_loc4_ >= 128)
         {
            _loc2_ = _loc4_ & 0x7F;
            _loc4_ = 0;
            while(_loc2_ > 0)
            {
               _loc4_ = _loc4_ << 8 | param1.readUnsignedByte();
               _loc2_--;
            }
         }
         _loc4_ += param1.position - _loc3_;
         param1.position = _loc3_;
         return _loc4_;
      }
      
      private static function §_-T2E§(param1:ByteArray) : Boolean
      {
         var _loc2_:int = int(param1[param1.position]);
         return (_loc2_ & 0x20) != 0;
      }
      
      public static function §_-33M§(param1:int, param2:ByteArray) : ByteArray
      {
         var _loc3_:ByteArray = new ByteArray();
         _loc3_.writeByte(param1);
         var _loc4_:int = int(param2.length);
         if(_loc4_ < 128)
         {
            _loc3_.writeByte(_loc4_);
         }
         else if(_loc4_ < 256)
         {
            _loc3_.writeByte(129);
            _loc3_.writeByte(_loc4_);
         }
         else if(_loc4_ < 65536)
         {
            _loc3_.writeByte(130);
            _loc3_.writeByte(_loc4_ >> 8);
            _loc3_.writeByte(_loc4_);
         }
         else if(_loc4_ < 16777216)
         {
            _loc3_.writeByte(131);
            _loc3_.writeByte(_loc4_ >> 16);
            _loc3_.writeByte(_loc4_ >> 8);
            _loc3_.writeByte(_loc4_);
         }
         else
         {
            _loc3_.writeByte(132);
            _loc3_.writeByte(_loc4_ >> 24);
            _loc3_.writeByte(_loc4_ >> 16);
            _loc3_.writeByte(_loc4_ >> 8);
            _loc3_.writeByte(_loc4_);
         }
         _loc3_.writeBytes(param2);
         _loc3_.position = 0;
         return _loc3_;
      }
   }
}

