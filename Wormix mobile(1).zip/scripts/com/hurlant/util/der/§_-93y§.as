package com.hurlant.util.der
{
   public dynamic class §_-93y§ extends Sequence implements §_-W13§
   {
      
      public function §_-93y§(param1:uint = 49, param2:uint = 0)
      {
         super(param1,param2);
      }
      
      override public function toString() : String
      {
         var _loc2_:String = §_-p1B§.§_-nF§;
         §_-p1B§.§_-nF§ += "    ";
         var _loc1_:String = join("\n");
         §_-p1B§.§_-nF§ = _loc2_;
         return §_-p1B§.§_-nF§ + "Set[" + type + "][" + len + "][\n" + _loc1_ + "\n" + _loc2_ + "]";
      }
   }
}

