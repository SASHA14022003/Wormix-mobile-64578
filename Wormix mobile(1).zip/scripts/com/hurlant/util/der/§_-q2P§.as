package com.hurlant.util.der
{
   import §_-5Y§.§_-t2O§;
   import §_-62§.§_-O2H§;
   import §_-D3A§.§_-TZ§;
   import §_-Ly§.§_-81L§;
   import §_-l1g§.§_-L3Q§;
   import §_-r1C§.§_-h2B§;
   import com.hurlant.math.BigInteger;
   import feathers.controls.text.TextFieldTextRenderer;
   import feathers.controls.text.TextInstanceCreator;
   import feathers.themes.FontSize;
   import flash.text.TextFormatAlign;
   import flash.utils.ByteArray;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.structures.ClanChatMessageTO;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   import ru.pragmatix.wormix.utils.§_-TT§;
   import ru.pragmatix.wormix.weapons.*;
   import starling.display.DisplayObject;
   import starling.events.Event;
   
   public class §_-q2P§ extends BigInteger implements §_-W13§
   {
      
      private var type:uint;
      
      private var len:uint;
      
      public function §_-q2P§(param1:uint, param2:uint, param3:ByteArray)
      {
         this.type = param1;
         this.len = param2;
         super(param3);
      }
      
      public function getLength() : uint
      {
         return len;
      }
      
      public function getType() : uint
      {
         return type;
      }
      
      override public function toString(param1:Number = 0) : String
      {
         return §_-p1B§.§_-nF§ + "Integer[" + type + "][" + len + "][" + super.toString(16) + "]";
      }
      
      public function §_-VH§() : ByteArray
      {
         return null;
      }
   }
}

