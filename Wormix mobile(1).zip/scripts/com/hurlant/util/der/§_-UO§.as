package com.hurlant.util.der
{
   import §_-Bv§.§_-G3P§;
   import §_-DJ§.§_-J2l§;
   import §_-l1K§.§_-cZ§;
   import §_-l1g§.§_-L3Q§;
   import com.distriqt.extension.cloudstorage.events.KeyValueStoreEvent;
   import com.hurlant.util.Base64;
   import com.mesmotronic.ane.AndroidID;
   import feathers.controls.text.TextInstanceCreator;
   import feathers.core.ITextRenderer;
   import feathers.core.PopUpManager;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.VerticalAlign;
   import feathers.themes.FontColor;
   import feathers.themes.FontSize;
   import flash.text.TextFormatAlign;
   import flash.utils.ByteArray;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.weapons.Weapon;
   import starling.display.DisplayObject;
   
   public class §_-UO§
   {
      
      private static const §_-91W§:String = "-----BEGIN RSA PRIVATE KEY-----";
      
      private static const §_-v1C§:String = "-----END RSA PRIVATE KEY-----";
      
      private static const §_-33k§:String = "-----BEGIN PUBLIC KEY-----";
      
      private static const §_-g12§:String = "-----END PUBLIC KEY-----";
      
      private static const §_-JE§:String = "-----BEGIN CERTIFICATE-----";
      
      private static const §_-J5§:String = "-----END CERTIFICATE-----";
      
      public function §_-UO§()
      {
         super();
      }
      
      public static function §_-5h§(param1:String) : §_-G3P§
      {
         var _loc3_:Array = null;
         var _loc2_:ByteArray = §_-P1L§("-----BEGIN RSA PRIVATE KEY-----","-----END RSA PRIVATE KEY-----",param1);
         if(_loc2_ == null)
         {
            return null;
         }
         var _loc4_:§_-W13§ = §_-p1B§.parse(_loc2_);
         if(_loc4_ is Array)
         {
            _loc3_ = _loc4_ as Array;
            return new §_-G3P§(_loc3_[1],_loc3_[2].valueOf(),_loc3_[3],_loc3_[4],_loc3_[5],_loc3_[6],_loc3_[7],_loc3_[8]);
         }
         return null;
      }
      
      public static function §_-B3e§(param1:String) : §_-G3P§
      {
         var _loc3_:Array = null;
         var _loc2_:ByteArray = §_-P1L§("-----BEGIN PUBLIC KEY-----","-----END PUBLIC KEY-----",param1);
         if(_loc2_ == null)
         {
            return null;
         }
         var _loc4_:§_-W13§ = §_-p1B§.parse(_loc2_);
         if(_loc4_ is Array)
         {
            _loc3_ = _loc4_ as Array;
            if(_loc3_[0][0].toString() != "1.2.840.113549.1.1.1")
            {
               return null;
            }
            _loc3_[1].position = 1;
            _loc4_ = §_-p1B§.parse(_loc3_[1]);
            if(_loc4_ is Array)
            {
               _loc3_ = _loc4_ as Array;
               return new §_-G3P§(_loc3_[0],_loc3_[1]);
            }
            return null;
         }
         return null;
      }
      
      public static function §_-K3S§(param1:String) : ByteArray
      {
         return §_-P1L§("-----BEGIN CERTIFICATE-----","-----END CERTIFICATE-----",param1);
      }
      
      private static function §_-P1L§(param1:String, param2:String, param3:String) : ByteArray
      {
         var _loc6_:int = int(param3.indexOf(param1));
         if(_loc6_ == -1)
         {
            return null;
         }
         _loc6_ += param1.length;
         var _loc5_:int = int(param3.indexOf(param2));
         if(_loc5_ == -1)
         {
            return null;
         }
         var _loc4_:String = param3.substring(_loc6_,_loc5_);
         _loc4_ = _loc4_.replace(/\s/gm,"");
         return Base64.decodeToByteArray(_loc4_);
      }
   }
}

