package com.hurlant.util.der
{
   import §_-79§.§_-ps§;
   import §_-B1y§.*;
   import §_-CF§.§_-E19§;
   import §_-CF§.§_-x2t§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-Ly§.§_-81L§;
   import §_-RE§.§_-52p§;
   import §_-Vg§.*;
   import §_-nE§.SelectCraftWeaponScreen;
   import §_-nE§.§_-p16§;
   import §_-r1C§.§_-h2B§;
   import §_-u1T§.§_-33B§;
   import §_-z1g§.§_-5c§;
   import com.greensock.*;
   import com.greensock.plugins.*;
   import flash.filters.BlurFilter;
   import flash.utils.ByteArray;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.request.PostToClanChatRequest;
   import ru.pragmatix.wormix.messages.clans.request.login.LoginClanBase;
   import ru.pragmatix.wormix.messages.clans.structures.ClanMemberTO;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.utils.MathUtil;
   import starling.display.Image;
   import starling.events.Event;
   
   public dynamic class Sequence extends Array implements §_-W13§
   {
      
      protected var type:uint;
      
      protected var len:uint;
      
      public function Sequence(param1:uint = 48, param2:uint = 0)
      {
         super();
         this.type = param1;
         this.len = param2;
      }
      
      public function getLength() : uint
      {
         return len;
      }
      
      public function getType() : uint
      {
         return type;
      }
      
      public function §_-VH§() : ByteArray
      {
         var _loc3_:int = 0;
         var _loc1_:§_-W13§ = null;
         var _loc2_:ByteArray = new ByteArray();
         _loc3_ = 0;
         while(_loc3_ < length)
         {
            _loc1_ = this[_loc3_];
            if(_loc1_ == null)
            {
               _loc2_.writeByte(5);
               _loc2_.writeByte(0);
            }
            else
            {
               _loc2_.writeBytes(_loc1_.§_-VH§());
            }
            _loc3_++;
         }
         return §_-p1B§.§_-33M§(type,_loc2_);
      }
      
      public function toString() : String
      {
         var _loc5_:int = 0;
         var _loc4_:Boolean = false;
         var _loc2_:String = §_-p1B§.§_-nF§;
         §_-p1B§.§_-nF§ += "    ";
         var _loc1_:String = "";
         _loc5_ = 0;
         while(_loc5_ < length)
         {
            if(this[_loc5_] != null)
            {
               _loc4_ = false;
               for(var _loc3_ in this)
               {
                  if(_loc5_.toString() != _loc3_ && this[_loc5_] == this[_loc3_])
                  {
                     _loc1_ += _loc3_ + ": " + this[_loc5_] + "\n";
                     _loc4_ = true;
                     break;
                  }
               }
               if(!_loc4_)
               {
                  _loc1_ += this[_loc5_] + "\n";
               }
            }
            _loc5_++;
         }
         §_-p1B§.§_-nF§ = _loc2_;
         return §_-p1B§.§_-nF§ + "Sequence[" + type + "][" + len + "][\n" + _loc1_ + "\n" + _loc2_ + "]";
      }
      
      public function §_-83G§(param1:String) : §_-W13§
      {
         var _loc3_:* = undefined;
         var _loc5_:* = undefined;
         var _loc2_:§_-l1b§ = null;
         for each(var _loc4_ in this)
         {
            if(_loc4_ is §_-93y§)
            {
               _loc3_ = _loc4_[0];
               if(_loc3_ is Sequence)
               {
                  _loc5_ = _loc3_[0];
                  if(_loc5_ is §_-l1b§)
                  {
                     _loc2_ = _loc5_ as §_-l1b§;
                     if(_loc2_.toString() == param1)
                     {
                        return _loc3_[1] as §_-W13§;
                     }
                  }
               }
            }
         }
         return null;
      }
   }
}

