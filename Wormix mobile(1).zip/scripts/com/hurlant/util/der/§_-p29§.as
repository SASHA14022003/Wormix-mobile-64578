package com.hurlant.util.der
{
   import §_-H3§.*;
   import §_-g2r§.§_-03A§;
   import feathers.controls.ImageLoader;
   import feathers.controls.text.TextInstanceCreator;
   import feathers.core.ITextRenderer;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.VerticalAlign;
   import feathers.themes.FontColor;
   import feathers.themes.FontSize;
   import flash.errors.IllegalOperationError;
   import flash.geom.Point;
   import flash.text.TextFormatAlign;
   import flash.utils.ByteArray;
   import ru.pragmatix.flox.logger.*;
   import ru.pragmatix.wormix.fx.EffectType;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.messages.client.StartBattle;
   import ru.pragmatix.wormix.objects.*;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.weapons.ammo.GuardingBot;
   import starling.display.DisplayObject;
   import starling.utils.ScaleMode;
   
   public class §_-p29§ implements §_-W13§
   {
      
      protected var type:uint;
      
      protected var len:uint;
      
      public var date:Date;
      
      public function §_-p29§(param1:uint, param2:uint)
      {
         super();
         this.type = param1;
         this.len = param2;
      }
      
      public function getLength() : uint
      {
         return len;
      }
      
      public function getType() : uint
      {
         return type;
      }
      
      public function §_-d2i§(param1:String) : void
      {
         var _loc4_:uint = uint(parseInt(param1.substr(0,2)));
         if(_loc4_ < 50)
         {
            _loc4_ += 2000;
         }
         else
         {
            _loc4_ += 1900;
         }
         var _loc3_:uint = uint(parseInt(param1.substr(2,2)));
         var _loc6_:uint = uint(parseInt(param1.substr(4,2)));
         var _loc5_:uint = uint(parseInt(param1.substr(6,2)));
         var _loc2_:uint = uint(parseInt(param1.substr(8,2)));
         date = new Date(_loc4_,_loc3_ - 1,_loc6_,_loc5_,_loc2_);
      }
      
      public function toString() : String
      {
         return §_-p1B§.§_-nF§ + "UTCTime[" + type + "][" + len + "][" + date + "]";
      }
      
      public function §_-VH§() : ByteArray
      {
         return null;
      }
   }
}

