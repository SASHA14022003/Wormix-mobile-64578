package com.hurlant.util.der
{
   import flash.geom.Point;
   import ru.pragmatix.wormix.weapons.Weapon;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   import starling.utils.Pool;
   
   public class §_-3a§
   {
      
      public static const §_-32A§:String = "1.2.840.113549.1.1.1";
      
      public static const MD2_WITH_RSA_ENCRYPTION:String = "1.2.840.113549.1.1.2";
      
      public static const MD5_WITH_RSA_ENCRYPTION:String = "1.2.840.113549.1.1.4";
      
      public static const SHA1_WITH_RSA_ENCRYPTION:String = "1.2.840.113549.1.1.5";
      
      public static const MD2_ALGORITHM:String = "1.2.840.113549.2.2";
      
      public static const MD5_ALGORITHM:String = "1.2.840.113549.2.5";
      
      public static const §_-u1y§:String = "1.2.840.10040.4.1";
      
      public static const §_-2h§:String = "1.2.840.10040.4.3";
      
      public static const §_-71J§:String = "1.2.840.10046.2.1";
      
      public static const SHA1_ALGORITHM:String = "1.3.14.3.2.26";
      
      public static const §_-E16§:String = "2.5.4.3";
      
      public static const §_-Bk§:String = "2.5.4.4";
      
      public static const §_-Q20§:String = "2.5.4.6";
      
      public static const §_-71U§:String = "2.5.4.7";
      
      public static const §_-F2g§:String = "2.5.4.8";
      
      public static const §_-b1A§:String = "2.5.4.10";
      
      public static const §_-Eu§:String = "2.5.4.11";
      
      public static const §_-T29§:String = "2.5.4.12";
      
      public function §_-3a§()
      {
         super();
      }
   }
}

