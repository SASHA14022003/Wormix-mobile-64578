package com.hurlant.util.der
{
   import flash.utils.ByteArray;
   
   public interface §_-W13§
   {
      
      function getType() : uint;
      
      function getLength() : uint;
      
      function §_-VH§() : ByteArray;
   }
}

