package com.hurlant.util.der
{
   import §_-12W§.*;
   import §_-21p§.§_-4w§;
   import §_-CF§.§_-E19§;
   import §_-L2F§.§_-D2p§;
   import §_-RE§.§_-D3v§;
   import §_-RE§.§_-r2q§;
   import §_-YF§.§_-q2v§;
   import §_-j1w§.§_-B2i§;
   import §_-l1g§.§_-T2N§;
   import §_-l2r§.§_-K1t§;
   import §_-r1C§.§_-h2B§;
   import com.hurlant.util.§_-J1N§;
   import dragonBones.animation.WorldClock;
   import flash.utils.ByteArray;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-A16§;
   import ru.pragmatix.wormix.pvp.messages.ex.*;
   import ru.pragmatix.wormix.utils.§_-MN§;
   import starling.events.Event;
   
   public class §_-cz§ extends ByteArray implements §_-W13§
   {
      
      private var type:uint;
      
      private var len:uint;
      
      public function §_-cz§(param1:uint = 4, param2:uint = 0)
      {
         super();
         this.type = param1;
         this.len = param2;
      }
      
      public function getLength() : uint
      {
         return len;
      }
      
      public function getType() : uint
      {
         return type;
      }
      
      public function §_-VH§() : ByteArray
      {
         return §_-p1B§.§_-33M§(type,this);
      }
      
      override public function toString() : String
      {
         return §_-p1B§.§_-nF§ + "ByteString[" + type + "][" + len + "][" + §_-J1N§.§_-z2W§(this) + "]";
      }
   }
}

