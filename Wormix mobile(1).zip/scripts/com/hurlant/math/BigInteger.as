package com.hurlant.math
{
   import §_-02q§.§_-4s§;
   import §_-21A§.ChooseFriendForBossMenu;
   import §_-21p§.§_-4w§;
   import §_-22z§.§_-f1b§;
   import §_-31N§.§_-42G§;
   import §_-31W§.*;
   import §_-31Y§.§_-D3B§;
   import §_-43V§.Random;
   import §_-51j§.*;
   import §_-5Y§.§_-h2c§;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-O2H§;
   import §_-62§.§_-T1y§;
   import §_-62§.§_-W1r§;
   import §_-73d§.§_-V19§;
   import §_-73d§.§_-x2C§;
   import §_-82l§.§_-A2Y§;
   import §_-92a§.§_-Y2Y§;
   import §_-931§.§_-02O§;
   import §_-937§.§_-n1b§;
   import §_-9e§.§_-73e§;
   import §_-9e§.§_-8O§;
   import §_-A1K§.§_-6L§;
   import §_-A1K§.§_-7u§;
   import §_-A1K§.§_-TA§;
   import §_-A1K§.§_-U11§;
   import §_-A2U§.§_-A23§;
   import §_-B1y§.*;
   import §_-CF§.§_-p2U§;
   import §_-CF§.§_-x2t§;
   import §_-Cl§.*;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-E1I§.§_-b2n§;
   import §_-F2Q§.GestureEvent;
   import §_-G2H§.§_-527§;
   import §_-H2g§.§_-di§;
   import §_-H3§.*;
   import §_-J3L§.§_-K2i§;
   import §_-L1H§.§_-C3e§;
   import §_-L1H§.§_-b2K§;
   import §_-L2F§.§_-D2p§;
   import §_-Ly§.§_-81L§;
   import §_-N8§.*;
   import §_-P1B§.§_-F1q§;
   import §_-P1z§.*;
   import §_-RE§.§_-D3v§;
   import §_-RE§.§_-r2q§;
   import §_-TF§.§_-F1B§;
   import §_-TF§.§_-q1j§;
   import §_-Ty§.*;
   import §_-U1i§.§_-J1§;
   import §_-U1i§.§_-O2i§;
   import §_-Vg§.ClanEditView;
   import §_-Y1O§.*;
   import §_-Y1Q§.§_-61Z§;
   import §_-Y1Q§.§_-F1g§;
   import §_-Y1Q§.§_-aG§;
   import §_-Y1Q§.§_-tc§;
   import §_-Y1b§.§_-81l§;
   import §_-Y1b§.§_-OP§;
   import §_-YF§.§_-Zi§;
   import §_-YF§.§_-q2v§;
   import §_-Z1L§.§_-A2V§;
   import §_-Z1L§.§_-H1K§;
   import §_-b1F§.*;
   import §_-fo§.*;
   import §_-j1w§.§_-B2i§;
   import §_-j1w§.§_-L1x§;
   import §_-j22§.§_-5g§;
   import §_-jF§.§_-82f§;
   import §_-k1u§.§_-2m§;
   import §_-k1u§.§_-F3H§;
   import §_-k1u§.§_-Oi§;
   import §_-k1u§.§_-Vr§;
   import §_-l1K§.*;
   import §_-l1g§.§_-L3Q§;
   import §_-l2r§.§_-K1t§;
   import §_-m2s§.§_-R11§;
   import §_-o14§.§_-Dd§;
   import §_-p18§.§_-vd§;
   import §_-p24§.*;
   import §_-r1C§.§_-V1R§;
   import §_-r1C§.§_-h2B§;
   import §_-r1C§.§_-t1R§;
   import §_-rM§.§_-61j§;
   import §_-s20§.§_-J2g§;
   import §_-s20§.§_-d21§;
   import §_-sQ§.§_-H3D§;
   import §_-u13§.MD5;
   import §_-u13§.SHA1;
   import §_-u1P§.ShopResultEvent;
   import §_-v2t§.§_-43O§;
   import §_-w§.§_-63m§;
   import §_-w2i§.§_-Ia§;
   import §_-wD§.*;
   import §_-z1g§.§_-13d§;
   import §_-z1g§.§_-M2v§;
   import §_-z1g§.§_-lp§;
   import §_-z1g§.§_-y1S§;
   import §_-zI§.§_-8D§;
   import §_-zI§.§_-92Q§;
   import §_-zI§.§_-F3q§;
   import com.distriqt.extension.application.Application;
   import com.distriqt.extension.application.events.DeviceOrientationEvent;
   import com.distriqt.extension.cloudstorage.events.KeyValueStoreEvent;
   import com.distriqt.extension.inappbilling.InAppBilling;
   import com.greensock.*;
   import com.greensock.events.LoaderEvent;
   import com.greensock.events.TweenEvent;
   import com.greensock.loading.LoaderMax;
   import com.greensock.loading.display.ContentDisplay;
   import com.greensock.plugins.*;
   import com.hurlant.util.§_-J1N§;
   import com.hurlant.util.§_-a2P§;
   import com.mesmotronic.ane.AndroidID;
   import config.§_-V2w§;
   import config.§_-x1p§;
   import dragonBones.animation.WorldClock;
   import feathers.controls.Button;
   import feathers.controls.LayoutGroup;
   import feathers.controls.NumericStepper;
   import feathers.controls.ToggleButton;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import feathers.controls.text.TextFieldTextRenderer;
   import feathers.controls.text.TextInstanceCreator;
   import feathers.core.FeathersControl;
   import feathers.core.ITextRenderer;
   import feathers.data.ListCollection;
   import feathers.events.FeathersEventType;
   import feathers.layout.AnchorLayout;
   import feathers.layout.AnchorLayoutData;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.HorizontalLayout;
   import feathers.layout.HorizontalLayoutData;
   import feathers.layout.VerticalAlign;
   import feathers.layout.VerticalLayout;
   import flash.events.Event;
   import flash.geom.Point;
   import flash.net.Socket;
   import flash.text.TextField;
   import flash.text.TextFormat;
   import flash.text.TextFormatAlign;
   import flash.utils.ByteArray;
   import flash.utils.Dictionary;
   import flash.utils.IDataInput;
   import flash.utils.IDataOutput;
   import flash.utils.getTimer;
   import org.gestouch.core.GestureState;
   import ru.pragmatix.flox.gui.controls.§_-zi§;
   import ru.pragmatix.flox.logger.§_-93v§;
   import ru.pragmatix.flox.serialization.§_-616§;
   import ru.pragmatix.wormix.Scene;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controller.§_-m1o§;
   import ru.pragmatix.wormix.fonts.FontColor;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.game.§_-eX§;
   import ru.pragmatix.wormix.game.ai.*;
   import ru.pragmatix.wormix.gui.§_-E2w§;
   import ru.pragmatix.wormix.gui.§_-Q2v§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.§_-738§;
   import ru.pragmatix.wormix.gui.screenOverlay.view.*;
   import ru.pragmatix.wormix.messages.clans.main.server.GetJoinClansMainRequest;
   import ru.pragmatix.wormix.messages.clans.request.TopClansRequest;
   import ru.pragmatix.wormix.messages.clans.request.login.LoginClanBase;
   import ru.pragmatix.wormix.messages.clans.response.GetJoinClansMainResponse;
   import ru.pragmatix.wormix.messages.clans.response.PromoteRankInClanResponse;
   import ru.pragmatix.wormix.messages.clans.response.TopClansResponse;
   import ru.pragmatix.wormix.messages.clans.structures.ClanChatMessageTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.client.GetDailyBonus;
   import ru.pragmatix.wormix.messages.server.GetDailyBonusResult;
   import ru.pragmatix.wormix.messages.server.IncomingPayment;
   import ru.pragmatix.wormix.messages.server.ShopResult;
   import ru.pragmatix.wormix.messages.structures.EndBattleStructure;
   import ru.pragmatix.wormix.messages.structures.GenericAwardStructure;
   import ru.pragmatix.wormix.messages.structures.RestrictionItemStructure;
   import ru.pragmatix.wormix.messages.structures.SelectStuffStructure;
   import ru.pragmatix.wormix.messages.structures.TemporalStuffStructure;
   import ru.pragmatix.wormix.messages.structures.WeaponStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.items.craft.§_-6S§;
   import ru.pragmatix.wormix.model.rewards.§_-P2q§;
   import ru.pragmatix.wormix.model.user.*;
   import ru.pragmatix.wormix.objects.*;
   import ru.pragmatix.wormix.physics.Force;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.physics.model.IPhysicModel;
   import ru.pragmatix.wormix.pvp.messages.ex.CallToBattle;
   import ru.pragmatix.wormix.pvp.messages.ex.JoinToBattle;
   import ru.pragmatix.wormix.pvp.messages.server.PvpRetryCommandRequestServer;
   import ru.pragmatix.wormix.pvp.messages.structures.PositionStructure;
   import ru.pragmatix.wormix.scene.SortingLayer;
   import ru.pragmatix.wormix.serialization.SerializationUtils;
   import ru.pragmatix.wormix.serialization.server.*;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.social.common.post.*;
   import ru.pragmatix.wormix.utils.*;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.DamageType;
   import ru.pragmatix.wormix.weapons.ammo.LaserRay;
   import ru.pragmatix.wormix.weapons.ammo.LightningBullet;
   import ru.pragmatix.wormix.weapons.ammo.ammoFactory.AmmosFactory;
   import ru.pragmatix.wormix.weapons.ammo.ammoFactory.IPooledAmmo;
   import ru.pragmatix.wormix.weapons.ammo.feats.IFrameFeat;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.extensions.ParticleAura;
   import starling.filters.DropShadowFilter;
   import starling.utils.Color;
   import starling.utils.Pool;
   import starling.utils.SystemUtil;
   import starlingbuilder.extensions.uicomponents.CustomLabel;
   
   use namespace bi_internal;
   
   public class BigInteger
   {
      
      public static const §_-U1C§:int = 30;
      
      public static const §_-t1Z§:int = 1073741824;
      
      public static const §_-N2j§:int = 1073741823;
      
      public static const §_-r2O§:int = 52;
      
      public static const F1:int = 22;
      
      public static const F2:int = 8;
      
      public static const §_-23x§:Number = Math.pow(2,52);
      
      public static const ZERO:BigInteger = §_-Z0§(0);
      
      public static const ONE:BigInteger = §_-Z0§(1);
      
      public static const §_-L1t§:Array = [2,3,5,7,11,13,17,19,23,29,31,37,41,43,47,53,59,61,67,71,73,79,83,89,97,101,103,107,109,113,127,131,137,139,149,151,157,163,167,173,179,181,191,193,197,199,211,223,227,229,233,239,241,251,257,263,269,271,277,281,283,293,307,311,313,317,331,337,347,349,353,359,367,373,379,383,389,397,401,409,419,421,431,433,439,443,449,457,461,463,467,479,487,491,499,503,509];
      
      public static const §_-f1X§:int = 67108864 / §_-L1t§[§_-L1t§.length - 1];
      
      public var t:int;
      
      bi_internal var s:int;
      
      bi_internal var a:Array;
      
      public function BigInteger(param1:* = null, param2:int = 0, param3:Boolean = false)
      {
         var _loc5_:ByteArray = null;
         var _loc4_:int = 0;
         super();
         bi_internal::a = [];
         if(param1 is String)
         {
            if(param2 && param2 != 16)
            {
               throw new Error("BigInteger construction with radix!=16 is not supported.");
            }
            param1 = §_-J1N§.§_-n2u§(param1);
            param2 = 0;
         }
         if(param1 is ByteArray)
         {
            _loc5_ = param1 as ByteArray;
            _loc4_ = int(param2 || _loc5_.length - _loc5_.position);
            bi_internal::§_-z2W§(_loc5_,_loc4_,param3);
         }
      }
      
      public static function §_-Z0§(param1:int) : BigInteger
      {
         var _loc2_:BigInteger = new BigInteger();
         _loc2_.§_-O2E§(param1);
         return _loc2_;
      }
      
      public function dispose() : void
      {
         var _loc2_:* = 0;
         var _loc1_:Random = new Random();
         _loc2_ = 0;
         while(_loc2_ < a.length)
         {
            a[_loc2_] = _loc1_.§_-S1T§();
            delete a[_loc2_];
            _loc2_++;
         }
         a = null;
         t = 0;
         s = 0;
         §_-a2P§.gc();
      }
      
      public function toString(param1:Number = 16) : String
      {
         var _loc6_:int = 0;
         if(s < 0)
         {
            return "-" + §_-D3U§().toString(param1);
         }
         switch(param1)
         {
            case 2:
               _loc6_ = 1;
               break;
            case 4:
               _loc6_ = 2;
               break;
            case 8:
               _loc6_ = 3;
               break;
            case 16:
               _loc6_ = 4;
               break;
            case 32:
               _loc6_ = 5;
         }
         var _loc7_:int = (1 << _loc6_) - 1;
         var _loc2_:int = 0;
         var _loc5_:Boolean = false;
         var _loc3_:String = "";
         var _loc8_:int = t;
         var _loc4_:int = 30 - _loc8_ * 30 % _loc6_;
         if(_loc8_-- > 0)
         {
            if(_loc4_ < 30 && (_loc2_ = a[_loc8_] >> _loc4_) > 0)
            {
               _loc5_ = true;
               _loc3_ = _loc2_.toString(36);
            }
            while(_loc8_ >= 0)
            {
               if(_loc4_ < _loc6_)
               {
                  _loc2_ = (a[_loc8_] & (1 << _loc4_) - 1) << _loc6_ - _loc4_;
                  _loc2_ |= a[--_loc8_] >> (_loc4_ += 30 - _loc6_);
               }
               else
               {
                  _loc2_ = a[_loc8_] >> (_loc4_ -= _loc6_) & _loc7_;
                  if(_loc4_ <= 0)
                  {
                     _loc4_ += 30;
                     _loc8_--;
                  }
               }
               if(_loc2_ > 0)
               {
                  _loc5_ = true;
               }
               if(_loc5_)
               {
                  _loc3_ += _loc2_.toString(36);
               }
            }
         }
         return _loc5_ ? _loc3_ : "0";
      }
      
      public function §_-n2u§(param1:ByteArray) : uint
      {
         var _loc6_:int = 0;
         _loc6_ = 8;
         var _loc7_:int = 0;
         _loc7_ = 255;
         var _loc2_:int = 0;
         var _loc8_:int = t;
         var _loc4_:int = 30 - _loc8_ * 30 % 8;
         var _loc5_:Boolean = false;
         var _loc3_:int = 0;
         if(_loc8_-- > 0)
         {
            if(_loc4_ < 30 && (_loc2_ = a[_loc8_] >> _loc4_) > 0)
            {
               _loc5_ = true;
               param1.writeByte(_loc2_);
               _loc3_++;
            }
            while(_loc8_ >= 0)
            {
               if(_loc4_ < 8)
               {
                  _loc2_ = (a[_loc8_] & (1 << _loc4_) - 1) << 8 - _loc4_;
                  _loc2_ |= a[--_loc8_] >> (_loc4_ += 30 - 8);
               }
               else
               {
                  _loc2_ = a[_loc8_] >> (_loc4_ -= 8) & 0xFF;
                  if(_loc4_ <= 0)
                  {
                     _loc4_ += 30;
                     _loc8_--;
                  }
               }
               if(_loc2_ > 0)
               {
                  _loc5_ = true;
               }
               if(_loc5_)
               {
                  param1.writeByte(_loc2_);
                  _loc3_++;
               }
            }
         }
         return _loc3_;
      }
      
      public function valueOf() : Number
      {
         var _loc3_:* = 0;
         if(s == -1)
         {
            return -§_-D3U§().valueOf();
         }
         var _loc1_:Number = 1;
         var _loc2_:Number = 0;
         _loc3_ = 0;
         while(_loc3_ < t)
         {
            _loc2_ += a[_loc3_] * _loc1_;
            _loc1_ *= 1073741824;
            _loc3_++;
         }
         return _loc2_;
      }
      
      public function §_-D3U§() : BigInteger
      {
         var _loc1_:BigInteger = §_-iP§();
         ZERO.§_-D7§(this,_loc1_);
         return _loc1_;
      }
      
      public function abs() : BigInteger
      {
         return s < 0 ? §_-D3U§() : this;
      }
      
      public function §_-v1n§(param1:BigInteger) : int
      {
         var _loc2_:int = s - param1.s;
         if(_loc2_ != 0)
         {
            return _loc2_;
         }
         var _loc3_:int = t;
         _loc2_ = _loc3_ - param1.t;
         if(_loc2_ != 0)
         {
            return _loc2_;
         }
         while(--_loc3_ >= 0)
         {
            _loc2_ = a[_loc3_] - param1.a[_loc3_];
            if(_loc2_ != 0)
            {
               return _loc2_;
            }
         }
         return 0;
      }
      
      bi_internal function §_-XI§(param1:int) : int
      {
         var _loc2_:int = 0;
         var _loc3_:int = 1;
         _loc2_ = param1 >>> 16;
         if(_loc2_ != 0)
         {
            param1 = _loc2_;
            _loc3_ += 16;
         }
         _loc2_ = param1 >> 8;
         if(_loc2_ != 0)
         {
            param1 = _loc2_;
            _loc3_ += 8;
         }
         _loc2_ = param1 >> 4;
         if(_loc2_ != 0)
         {
            param1 = _loc2_;
            _loc3_ += 4;
         }
         _loc2_ = param1 >> 2;
         if(_loc2_ != 0)
         {
            param1 = _loc2_;
            _loc3_ += 2;
         }
         _loc2_ = param1 >> 1;
         if(_loc2_ != 0)
         {
            param1 = _loc2_;
            _loc3_ += 1;
         }
         return _loc3_;
      }
      
      public function §_-L1J§() : int
      {
         if(t <= 0)
         {
            return 0;
         }
         return 30 * (t - 1) + §_-XI§(a[t - 1] ^ s & 0x3FFFFFFF);
      }
      
      public function mod(param1:BigInteger) : BigInteger
      {
         var _loc2_:BigInteger = §_-iP§();
         abs().§_-03h§(param1,null,_loc2_);
         if(s < 0 && _loc2_.§_-v1n§(ZERO) > 0)
         {
            param1.§_-D7§(_loc2_,_loc2_);
         }
         return _loc2_;
      }
      
      public function §_-9L§(param1:int, param2:BigInteger) : BigInteger
      {
         var _loc3_:§_-i1s§ = null;
         if(param1 < 256 || param2.§_-rR§())
         {
            _loc3_ = new §_-f1c§(param2);
         }
         else
         {
            _loc3_ = new §_-B2D§(param2);
         }
         return exp(param1,_loc3_);
      }
      
      bi_internal function copyTo(param1:BigInteger) : void
      {
         var _loc2_:int = 0;
         _loc2_ = t - 1;
         while(_loc2_ >= 0)
         {
            param1.a[_loc2_] = a[_loc2_];
            _loc2_--;
         }
         param1.t = t;
         param1.s = s;
      }
      
      bi_internal function §_-O2E§(param1:int) : void
      {
         t = 1;
         s = param1 < 0 ? -1 : 0;
         if(param1 > 0)
         {
            a[0] = param1;
         }
         else if(param1 < -1)
         {
            a[0] = param1 + 1073741824;
         }
         else
         {
            t = 0;
         }
      }
      
      bi_internal function §_-z2W§(param1:ByteArray, param2:int, param3:Boolean = false) : void
      {
         var _loc6_:int = 0;
         _loc6_ = 8;
         var _loc7_:int = 0;
         var _loc4_:int = int(param1.position);
         var _loc8_:int = _loc4_ + param2;
         var _loc5_:int = 0;
         t = 0;
         s = 0;
         while(--_loc8_ >= _loc4_)
         {
            _loc7_ = int(_loc8_ < param1.length ? param1[_loc8_] : 0);
            if(_loc5_ == 0)
            {
               a[t++] = _loc7_;
            }
            else if(_loc5_ + 8 > 30)
            {
               var _loc9_:* = t - 1;
               var _loc10_:* = a[_loc9_] | (_loc7_ & (1 << 30 - _loc5_) - 1) << _loc5_;
               a[_loc9_] = _loc10_;
               §§push(a);
               var _temp_6:* = t;
               t = _temp_6 + 1;
               §§pop()[_temp_6] = _loc7_ >> 30 - _loc5_;
            }
            else
            {
               _loc10_ = t - 1;
               _loc9_ = a[_loc10_] | _loc7_ << _loc5_;
               a[_loc10_] = _loc9_;
            }
            _loc5_ += 8;
            if(_loc5_ >= 30)
            {
               _loc5_ -= 30;
            }
         }
         if(!param3 && (param1[0] & 0x80) == 128)
         {
            s = -1;
            if(_loc5_ > 0)
            {
               _loc9_ = t - 1;
               _loc10_ = a[_loc9_] | (1 << 30 - _loc5_) - 1 << _loc5_;
               a[_loc9_] = _loc10_;
            }
         }
         clamp();
         param1.position = Math.min(_loc4_ + param2,param1.length);
      }
      
      bi_internal function clamp() : void
      {
         var _loc1_:int = s & 0x3FFFFFFF;
         while(t > 0 && a[t - 1] == _loc1_)
         {
            t = t - 1;
         }
      }
      
      bi_internal function §_-bD§(param1:int, param2:BigInteger) : void
      {
         var _loc3_:int = 0;
         _loc3_ = t - 1;
         while(_loc3_ >= 0)
         {
            param2.a[_loc3_ + param1] = a[_loc3_];
            _loc3_--;
         }
         _loc3_ = param1 - 1;
         while(_loc3_ >= 0)
         {
            param2.a[_loc3_] = 0;
            _loc3_--;
         }
         param2.t = t + param1;
         param2.s = s;
      }
      
      bi_internal function §_-kL§(param1:int, param2:BigInteger) : void
      {
         var _loc3_:int = 0;
         _loc3_ = param1;
         while(_loc3_ < t)
         {
            param2.a[_loc3_ - param1] = a[_loc3_];
            _loc3_++;
         }
         param2.t = Math.max(t - param1,0);
         param2.s = s;
      }
      
      bi_internal function §_-Y1B§(param1:int, param2:BigInteger) : void
      {
         var _loc8_:int = 0;
         var _loc6_:int = param1 % 30;
         var _loc3_:int = 30 - _loc6_;
         var _loc5_:int = (1 << _loc3_) - 1;
         var _loc7_:int = param1 / 30;
         var _loc4_:int = s << _loc6_ & 0x3FFFFFFF;
         _loc8_ = t - 1;
         while(_loc8_ >= 0)
         {
            param2.a[_loc8_ + _loc7_ + 1] = a[_loc8_] >> _loc3_ | _loc4_;
            _loc4_ = (a[_loc8_] & _loc5_) << _loc6_;
            _loc8_--;
         }
         _loc8_ = _loc7_ - 1;
         while(_loc8_ >= 0)
         {
            param2.a[_loc8_] = 0;
            _loc8_--;
         }
         param2.a[_loc7_] = _loc4_;
         param2.t = t + _loc7_ + 1;
         param2.s = s;
         param2.clamp();
      }
      
      bi_internal function §_-Bf§(param1:int, param2:BigInteger) : void
      {
         var _loc7_:int = 0;
         param2.s = s;
         var _loc6_:int = param1 / 30;
         if(_loc6_ >= t)
         {
            param2.t = 0;
            return;
         }
         var _loc5_:int = param1 % 30;
         var _loc3_:int = 30 - _loc5_;
         var _loc4_:int = (1 << _loc5_) - 1;
         param2.a[0] = a[_loc6_] >> _loc5_;
         _loc7_ = _loc6_ + 1;
         while(_loc7_ < t)
         {
            var _loc8_:* = _loc7_ - _loc6_ - 1;
            var _loc9_:* = param2.a[_loc8_] | (a[_loc7_] & _loc4_) << _loc3_;
            param2.a[_loc8_] = _loc9_;
            param2.a[_loc7_ - _loc6_] = a[_loc7_] >> _loc5_;
            _loc7_++;
         }
         if(_loc5_ > 0)
         {
            _loc9_ = t - _loc6_ - 1;
            _loc8_ = param2.a[_loc9_] | (s & _loc4_) << _loc3_;
            param2.a[_loc9_] = _loc8_;
         }
         param2.t = t - _loc6_;
         param2.clamp();
      }
      
      bi_internal function §_-D7§(param1:BigInteger, param2:BigInteger) : void
      {
         var _loc5_:int = 0;
         var _loc3_:int = 0;
         var _loc4_:int = int(Math.min(param1.t,t));
         while(_loc5_ < _loc4_)
         {
            _loc3_ += a[_loc5_] - param1.a[_loc5_];
            param2.a[_loc5_++] = _loc3_ & 0x3FFFFFFF;
            _loc3_ >>= 30;
         }
         if(param1.t < t)
         {
            _loc3_ -= param1.s;
            while(_loc5_ < t)
            {
               _loc3_ += a[_loc5_];
               param2.a[_loc5_++] = _loc3_ & 0x3FFFFFFF;
               _loc3_ >>= 30;
            }
            _loc3_ += s;
         }
         else
         {
            _loc3_ += s;
            while(_loc5_ < param1.t)
            {
               _loc3_ -= param1.a[_loc5_];
               param2.a[_loc5_++] = _loc3_ & 0x3FFFFFFF;
               _loc3_ >>= 30;
            }
            _loc3_ -= param1.s;
         }
         param2.s = _loc3_ < 0 ? -1 : 0;
         if(_loc3_ < -1)
         {
            param2.a[_loc5_++] = 1073741824 + _loc3_;
         }
         else if(_loc3_ > 0)
         {
            param2.a[_loc5_++] = _loc3_;
         }
         param2.t = _loc5_;
         param2.clamp();
      }
      
      bi_internal function am(param1:int, param2:int, param3:BigInteger, param4:int, param5:int, param6:int) : int
      {
         var _loc9_:int = 0;
         var _loc11_:int = 0;
         var _loc10_:int = 0;
         var _loc8_:int = param2 & 0x7FFF;
         var _loc7_:int = param2 >> 15;
         while(--param6 >= 0)
         {
            _loc9_ = a[param1] & 0x7FFF;
            _loc11_ = a[param1++] >> 15;
            _loc10_ = _loc7_ * _loc9_ + _loc11_ * _loc8_;
            _loc9_ = _loc8_ * _loc9_ + ((_loc10_ & 0x7FFF) << 15) + param3.a[param4] + (param5 & 0x3FFFFFFF);
            param5 = (_loc9_ >>> 30) + (_loc10_ >>> 15) + _loc7_ * _loc11_ + (param5 >>> 30);
            param3.a[param4++] = _loc9_ & 0x3FFFFFFF;
         }
         return param5;
      }
      
      bi_internal function §_-n29§(param1:BigInteger, param2:BigInteger) : void
      {
         var _loc5_:BigInteger = abs();
         var _loc3_:BigInteger = param1.abs();
         var _loc4_:int = _loc5_.t;
         param2.t = _loc4_ + _loc3_.t;
         while(--_loc4_ >= 0)
         {
            param2.a[_loc4_] = 0;
         }
         _loc4_ = 0;
         while(_loc4_ < _loc3_.t)
         {
            param2.a[_loc4_ + _loc5_.t] = _loc5_.am(0,_loc3_.a[_loc4_],param2,_loc4_,0,_loc5_.t);
            _loc4_++;
         }
         param2.s = 0;
         param2.clamp();
         if(s != param1.s)
         {
            ZERO.§_-D7§(param2,param2);
         }
      }
      
      bi_internal function §_-I3k§(param1:BigInteger) : void
      {
         var _loc2_:int = 0;
         var _loc4_:BigInteger = abs();
         var _loc3_:int = param1.t = 2 * _loc4_.t;
         while(--_loc3_ >= 0)
         {
            param1.a[_loc3_] = 0;
         }
         _loc3_ = 0;
         while(_loc3_ < _loc4_.t - 1)
         {
            _loc2_ = _loc4_.am(_loc3_,_loc4_.a[_loc3_],param1,2 * _loc3_,0,1);
            var _loc5_:Number = _loc3_ + _loc4_.t;
            var _loc6_:Number = param1.a[_loc5_] + _loc4_.am(_loc3_ + 1,2 * _loc4_.a[_loc3_],param1,2 * _loc3_ + 1,_loc2_,_loc4_.t - _loc3_ - 1);
            param1.a[_loc5_] = _loc6_;
            if(_loc6_ >= 1073741824)
            {
               _loc6_ = _loc3_ + _loc4_.t;
               _loc5_ = param1.a[_loc6_] - 1073741824;
               param1.a[_loc6_] = _loc5_;
               param1.a[_loc3_ + _loc4_.t + 1] = 1;
            }
            _loc3_++;
         }
         if(param1.t > 0)
         {
            _loc5_ = param1.t - 1;
            _loc6_ = param1.a[_loc5_] + _loc4_.am(_loc3_,_loc4_.a[_loc3_],param1,2 * _loc3_,0,1);
            param1.a[_loc5_] = _loc6_;
         }
         param1.s = 0;
         param1.clamp();
      }
      
      bi_internal function §_-03h§(param1:BigInteger, param2:BigInteger = null, param3:BigInteger = null) : void
      {
         var _loc9_:int = 0;
         var _loc17_:BigInteger = param1.abs();
         if(_loc17_.t <= 0)
         {
            return;
         }
         var _loc16_:BigInteger = abs();
         if(_loc16_.t < _loc17_.t)
         {
            if(param2 != null)
            {
               param2.§_-O2E§(0);
            }
            if(param3 != null)
            {
               copyTo(param3);
            }
            return;
         }
         if(param3 == null)
         {
            param3 = §_-iP§();
         }
         var _loc19_:BigInteger = §_-iP§();
         var _loc5_:int = s;
         var _loc6_:int = param1.s;
         var _loc18_:int = 30 - §_-XI§(_loc17_.a[_loc17_.t - 1]);
         if(_loc18_ > 0)
         {
            _loc17_.§_-Y1B§(_loc18_,_loc19_);
            _loc16_.§_-Y1B§(_loc18_,param3);
         }
         else
         {
            _loc17_.copyTo(_loc19_);
            _loc16_.copyTo(param3);
         }
         var _loc15_:int = _loc19_.t;
         var _loc7_:int = int(_loc19_.a[_loc15_ - 1]);
         if(_loc7_ == 0)
         {
            return;
         }
         var _loc14_:Number = _loc7_ * (1 << 22) + (_loc15_ > 1 ? _loc19_.a[_loc15_ - 2] >> 8 : 0);
         var _loc11_:Number = §_-23x§ / _loc14_;
         var _loc12_:Number = (1 << 22) / _loc14_;
         var _loc4_:Number = 256;
         var _loc10_:int = param3.t;
         var _loc8_:int = _loc10_ - _loc15_;
         var _loc13_:BigInteger = param2 == null ? §_-iP§() : param2;
         _loc19_.§_-bD§(_loc8_,_loc13_);
         if(param3.§_-v1n§(_loc13_) >= 0)
         {
            param3.a[param3.t++] = 1;
            param3.§_-D7§(_loc13_,param3);
         }
         ONE.§_-bD§(_loc15_,_loc13_);
         _loc13_.§_-D7§(_loc19_,_loc19_);
         while(_loc19_.t < _loc15_)
         {
            _loc19_.(_loc19_.t++,false);
         }
         while(--_loc8_ >= 0)
         {
            _loc9_ = int(param3.a[--_loc10_] == _loc7_ ? 1073741823 : Number(param3.a[_loc10_]) * _loc11_ + (Number(param3.a[_loc10_ - 1]) + _loc4_) * _loc12_);
            param3.a[_loc10_] += _loc19_.am(0,_loc9_,param3,_loc8_,0,_loc15_);
            if(_loc21_ < _loc9_)
            {
               _loc19_.§_-bD§(_loc8_,_loc13_);
               param3.§_-D7§(_loc13_,param3);
               while(param3.a[_loc10_] < --_loc9_)
               {
                  param3.§_-D7§(_loc13_,param3);
               }
            }
         }
         if(param2 != null)
         {
            param3.§_-kL§(_loc15_,param2);
            if(_loc5_ != _loc6_)
            {
               ZERO.§_-D7§(param2,param2);
            }
         }
         param3.t = _loc15_;
         param3.clamp();
         if(_loc18_ > 0)
         {
            param3.§_-Bf§(_loc18_,param3);
         }
         if(_loc5_ < 0)
         {
            ZERO.§_-D7§(param3,param3);
         }
      }
      
      bi_internal function §_-1Z§() : int
      {
         if(t < 1)
         {
            return 0;
         }
         var _loc2_:int = int(a[0]);
         if((_loc2_ & 1) == 0)
         {
            return 0;
         }
         var _loc1_:int = _loc2_ & 3;
         _loc1_ = _loc1_ * (2 - (_loc2_ & 0x0F) * _loc1_) & 0x0F;
         _loc1_ = _loc1_ * (2 - (_loc2_ & 0xFF) * _loc1_) & 0xFF;
         _loc1_ = _loc1_ * (2 - ((_loc2_ & 0xFFFF) * _loc1_ & 0xFFFF)) & 0xFFFF;
         _loc1_ = _loc1_ * (2 - _loc2_ * _loc1_ % 1073741824) % 1073741824;
         return _loc1_ > 0 ? 1073741824 - _loc1_ : -_loc1_;
      }
      
      bi_internal function §_-rR§() : Boolean
      {
         return (t > 0 ? a[0] & 1 : s) == 0;
      }
      
      bi_internal function exp(param1:int, param2:§_-i1s§) : BigInteger
      {
         var _loc4_:BigInteger = null;
         if(param1 > 4294967295 || param1 < 1)
         {
            return ONE;
         }
         var _loc5_:BigInteger = §_-iP§();
         var _loc6_:BigInteger = §_-iP§();
         var _loc3_:BigInteger = param2.§_-Qa§(this);
         var _loc7_:int = §_-XI§(param1) - 1;
         _loc3_.copyTo(_loc5_);
         while(--_loc7_ >= 0)
         {
            param2.§_-V22§(_loc5_,_loc6_);
            if((param1 & 1 << _loc7_) > 0)
            {
               param2.§_-N1w§(_loc6_,_loc3_,_loc5_);
            }
            else
            {
               _loc4_ = _loc5_;
               _loc5_ = _loc6_;
               _loc6_ = _loc4_;
            }
         }
         return param2.§_-w6§(_loc5_);
      }
      
      bi_internal function §_-b1Q§(param1:String, param2:int) : int
      {
         return parseInt(param1.charAt(param2),36);
      }
      
      protected function §_-iP§() : *
      {
         return new BigInteger();
      }
      
      public function clone() : BigInteger
      {
         var _loc1_:BigInteger = new BigInteger();
         this.copyTo(_loc1_);
         return _loc1_;
      }
      
      public function §_-u22§() : int
      {
         if(s < 0)
         {
            if(t == 1)
            {
               return a[0] - 1073741824;
            }
            if(t == 0)
            {
               return -1;
            }
         }
         else
         {
            if(t == 1)
            {
               return a[0];
            }
            if(t == 0)
            {
               return 0;
            }
         }
         return (a[1] & 3) << 30 | a[0];
      }
      
      public function §_-W6§() : int
      {
         return t == 0 ? s : a[0] << 24 >> 24;
      }
      
      public function §_-Z9§() : int
      {
         return t == 0 ? s : a[0] << 16 >> 16;
      }
      
      protected function §_-d2l§(param1:Number) : int
      {
         return Math.floor(0.6931471805599453 * 30 / Math.log(param1));
      }
      
      public function §_-jS§() : int
      {
         if(s < 0)
         {
            return -1;
         }
         if(t <= 0 || t == 1 && a[0] <= 0)
         {
            return 0;
         }
         return 1;
      }
      
      protected function §_-v1j§(param1:uint = 10) : String
      {
         if(§_-jS§() == 0 || param1 < 2 || param1 > 32)
         {
            return "0";
         }
         var _loc7_:int = §_-d2l§(param1);
         var _loc4_:Number = Number(Math.pow(param1,_loc7_));
         var _loc2_:BigInteger = §_-Z0§(_loc4_);
         var _loc6_:BigInteger = §_-iP§();
         var _loc5_:BigInteger = §_-iP§();
         var _loc3_:String = "";
         §_-03h§(_loc2_,_loc6_,_loc5_);
         while(_loc6_.§_-jS§() > 0)
         {
            _loc3_ = (_loc4_ + _loc5_.§_-u22§()).toString(param1).substr(1) + _loc3_;
            _loc6_.§_-03h§(_loc2_,_loc6_,_loc5_);
         }
         return _loc5_.§_-u22§().toString(param1) + _loc3_;
      }
      
      protected function §_-u2A§(param1:String, param2:int = 10) : void
      {
         var _loc8_:int = 0;
         var _loc7_:int = 0;
         §_-O2E§(0);
         var _loc9_:int = §_-d2l§(param2);
         var _loc4_:Number = Number(Math.pow(param2,_loc9_));
         var _loc6_:Boolean = false;
         var _loc5_:int = 0;
         var _loc3_:int = 0;
         _loc8_ = 0;
         while(_loc8_ < param1.length)
         {
            _loc7_ = §_-b1Q§(param1,_loc8_);
            if(_loc7_ < 0)
            {
               if(param1.charAt(_loc8_) == "-" && §_-jS§() == 0)
               {
                  _loc6_ = true;
               }
            }
            else
            {
               _loc3_ = param2 * _loc3_ + _loc7_;
               if(++_loc5_ >= _loc9_)
               {
                  §_-xg§(_loc4_);
                  §_-82q§(_loc3_,0);
                  _loc5_ = 0;
                  _loc3_ = 0;
               }
            }
            _loc8_++;
         }
         if(_loc5_ > 0)
         {
            §_-xg§(Math.pow(param2,_loc5_));
            §_-82q§(_loc3_,0);
         }
         if(_loc6_)
         {
            BigInteger.ZERO.§_-D7§(this,this);
         }
      }
      
      public function §_-l1U§() : ByteArray
      {
         var _loc1_:int = 0;
         var _loc5_:int = t;
         var _loc2_:ByteArray = new ByteArray();
         _loc2_[0] = s;
         var _loc3_:int = 30 - _loc5_ * 30 % 8;
         var _loc4_:int = 0;
         if(_loc5_-- > 0)
         {
            if(_loc3_ < 30 && (_loc1_ = a[_loc5_] >> _loc3_) != (s & 0x3FFFFFFF) >> _loc3_)
            {
               _loc2_[_loc4_++] = _loc1_ | s << 30 - _loc3_;
            }
            while(_loc5_ >= 0)
            {
               if(_loc3_ < 8)
               {
                  _loc1_ = (a[_loc5_] & (1 << _loc3_) - 1) << 8 - _loc3_;
                  _loc1_ |= a[--_loc5_] >> (_loc3_ += 30 - 8);
               }
               else
               {
                  _loc1_ = a[_loc5_] >> (_loc3_ -= 8) & 0xFF;
                  if(_loc3_ <= 0)
                  {
                     _loc3_ += 30;
                     _loc5_--;
                  }
               }
               if((_loc1_ & 0x80) != 0)
               {
                  _loc1_ |= -256;
               }
               if(_loc4_ == 0 && (s & 0x80) != (_loc1_ & 0x80))
               {
                  _loc4_++;
               }
               if(_loc4_ > 0 || _loc1_ != s)
               {
                  _loc2_[_loc4_++] = _loc1_;
               }
            }
         }
         return _loc2_;
      }
      
      public function equals(param1:BigInteger) : Boolean
      {
         return §_-v1n§(param1) == 0;
      }
      
      public function min(param1:BigInteger) : BigInteger
      {
         return §_-v1n§(param1) < 0 ? this : param1;
      }
      
      public function max(param1:BigInteger) : BigInteger
      {
         return §_-v1n§(param1) > 0 ? this : param1;
      }
      
      protected function §_-Ed§(param1:BigInteger, param2:Function, param3:BigInteger) : void
      {
         var _loc6_:int = 0;
         var _loc4_:int = 0;
         var _loc5_:int = int(Math.min(param1.t,t));
         _loc6_ = 0;
         while(_loc6_ < _loc5_)
         {
            param3.a[_loc6_] = param2(this.a[_loc6_],param1.a[_loc6_]);
            _loc6_++;
         }
         if(param1.t < t)
         {
            _loc4_ = param1.s & 0x3FFFFFFF;
            _loc6_ = _loc5_;
            while(_loc6_ < t)
            {
               param3.a[_loc6_] = param2(this.a[_loc6_],_loc4_);
               _loc6_++;
            }
            param3.t = t;
         }
         else
         {
            _loc4_ = s & 0x3FFFFFFF;
            _loc6_ = _loc5_;
            while(_loc6_ < param1.t)
            {
               param3.a[_loc6_] = param2(_loc4_,param1.a[_loc6_]);
               _loc6_++;
            }
            param3.t = param1.t;
         }
         param3.s = param2(s,param1.s);
         param3.clamp();
      }
      
      private function §_-t1c§(param1:int, param2:int) : int
      {
         return param1 & param2;
      }
      
      public function §_-D2D§(param1:BigInteger) : BigInteger
      {
         var _loc2_:BigInteger = new BigInteger();
         §_-Ed§(param1,§_-t1c§,_loc2_);
         return _loc2_;
      }
      
      private function §_-G2N§(param1:int, param2:int) : int
      {
         return param1 | param2;
      }
      
      public function §_-l2k§(param1:BigInteger) : BigInteger
      {
         var _loc2_:BigInteger = new BigInteger();
         §_-Ed§(param1,§_-G2N§,_loc2_);
         return _loc2_;
      }
      
      private function §_-N2o§(param1:int, param2:int) : int
      {
         return param1 ^ param2;
      }
      
      public function §_-zL§(param1:BigInteger) : BigInteger
      {
         var _loc2_:BigInteger = new BigInteger();
         §_-Ed§(param1,§_-N2o§,_loc2_);
         return _loc2_;
      }
      
      private function §_-x2R§(param1:int, param2:int) : int
      {
         return param1 & ~param2;
      }
      
      public function §_-3Y§(param1:BigInteger) : BigInteger
      {
         var _loc2_:BigInteger = new BigInteger();
         §_-Ed§(param1,§_-x2R§,_loc2_);
         return _loc2_;
      }
      
      public function §_-t1h§() : BigInteger
      {
         var _loc2_:int = 0;
         var _loc1_:BigInteger = new BigInteger();
         _loc2_ = 0;
         while(_loc2_ < t)
         {
            _loc1_[_loc2_] = 0x3FFFFFFF & ~a[_loc2_];
            _loc2_++;
         }
         _loc1_.t = t;
         _loc1_.s = ~s;
         return _loc1_;
      }
      
      public function §_-CL§(param1:int) : BigInteger
      {
         var _loc2_:BigInteger = new BigInteger();
         if(param1 < 0)
         {
            §_-Bf§(-param1,_loc2_);
         }
         else
         {
            §_-Y1B§(param1,_loc2_);
         }
         return _loc2_;
      }
      
      public function §_-23V§(param1:int) : BigInteger
      {
         var _loc2_:BigInteger = new BigInteger();
         if(param1 < 0)
         {
            §_-Y1B§(-param1,_loc2_);
         }
         else
         {
            §_-Bf§(param1,_loc2_);
         }
         return _loc2_;
      }
      
      private function §_-Y4§(param1:int) : int
      {
         if(param1 == 0)
         {
            return -1;
         }
         var _loc2_:int = 0;
         if((param1 & 0xFFFF) == 0)
         {
            param1 >>= 16;
            _loc2_ += 16;
         }
         if((param1 & 0xFF) == 0)
         {
            param1 >>= 8;
            _loc2_ += 8;
         }
         if((param1 & 0x0F) == 0)
         {
            param1 >>= 4;
            _loc2_ += 4;
         }
         if((param1 & 3) == 0)
         {
            param1 >>= 2;
            _loc2_ += 2;
         }
         if((param1 & 1) == 0)
         {
            _loc2_++;
         }
         return _loc2_;
      }
      
      public function §_-Ql§() : int
      {
         var _loc1_:int = 0;
         _loc1_ = 0;
         while(_loc1_ < t)
         {
            if(a[_loc1_] != 0)
            {
               return _loc1_ * 30 + §_-Y4§(a[_loc1_]);
            }
            _loc1_++;
         }
         if(s < 0)
         {
            return t * 30;
         }
         return -1;
      }
      
      private function §_-qK§(param1:int) : int
      {
         var _loc2_:uint = 0;
         while(param1 != 0)
         {
            param1 &= param1 - 1;
            _loc2_++;
         }
         return _loc2_;
      }
      
      public function §_-71I§() : int
      {
         var _loc2_:int = 0;
         var _loc1_:int = 0;
         var _loc3_:int = s & 0x3FFFFFFF;
         _loc2_ = 0;
         while(_loc2_ < t)
         {
            _loc1_ += §_-qK§(a[_loc2_] ^ _loc3_);
            _loc2_++;
         }
         return _loc1_;
      }
      
      public function §_-512§(param1:int) : Boolean
      {
         var _loc2_:int = int(Math.floor(param1 / 30));
         if(_loc2_ >= t)
         {
            return s != 0;
         }
         return (a[_loc2_] & 1 << param1 % 30) != 0;
      }
      
      protected function §_-p1Y§(param1:int, param2:Function) : BigInteger
      {
         var _loc3_:BigInteger = BigInteger.ONE.§_-CL§(param1);
         §_-Ed§(_loc3_,param2,_loc3_);
         return _loc3_;
      }
      
      public function §_-mL§(param1:int) : BigInteger
      {
         return §_-p1Y§(param1,§_-G2N§);
      }
      
      public function §_-01H§(param1:int) : BigInteger
      {
         return §_-p1Y§(param1,§_-x2R§);
      }
      
      public function §_-6w§(param1:int) : BigInteger
      {
         return §_-p1Y§(param1,§_-N2o§);
      }
      
      protected function §_-Xp§(param1:BigInteger, param2:BigInteger) : void
      {
         var _loc5_:int = 0;
         var _loc3_:int = 0;
         var _loc4_:int = int(Math.min(param1.t,t));
         while(_loc5_ < _loc4_)
         {
            _loc3_ += this.a[_loc5_] + param1.a[_loc5_];
            param2.a[_loc5_++] = _loc3_ & 0x3FFFFFFF;
            _loc3_ >>= 30;
         }
         if(param1.t < t)
         {
            _loc3_ += param1.s;
            while(_loc5_ < t)
            {
               _loc3_ += this.a[_loc5_];
               param2.a[_loc5_++] = _loc3_ & 0x3FFFFFFF;
               _loc3_ >>= 30;
            }
            _loc3_ += s;
         }
         else
         {
            _loc3_ += s;
            while(_loc5_ < param1.t)
            {
               _loc3_ += param1.a[_loc5_];
               param2.a[_loc5_++] = _loc3_ & 0x3FFFFFFF;
               _loc3_ >>= 30;
            }
            _loc3_ += param1.s;
         }
         param2.s = _loc3_ < 0 ? -1 : 0;
         if(_loc3_ > 0)
         {
            param2.a[_loc5_++] = _loc3_;
         }
         else if(_loc3_ < -1)
         {
            param2.a[_loc5_++] = 1073741824 + _loc3_;
         }
         param2.t = _loc5_;
         param2.clamp();
      }
      
      public function add(param1:BigInteger) : BigInteger
      {
         var _loc2_:BigInteger = new BigInteger();
         §_-Xp§(param1,_loc2_);
         return _loc2_;
      }
      
      public function subtract(param1:BigInteger) : BigInteger
      {
         var _loc2_:BigInteger = new BigInteger();
         §_-D7§(param1,_loc2_);
         return _loc2_;
      }
      
      public function multiply(param1:BigInteger) : BigInteger
      {
         var _loc2_:BigInteger = new BigInteger();
         §_-n29§(param1,_loc2_);
         return _loc2_;
      }
      
      public function §_-P1M§(param1:BigInteger) : BigInteger
      {
         var _loc2_:BigInteger = new BigInteger();
         §_-03h§(param1,_loc2_,null);
         return _loc2_;
      }
      
      public function §_-vI§(param1:BigInteger) : BigInteger
      {
         var _loc2_:BigInteger = new BigInteger();
         §_-03h§(param1,null,_loc2_);
         return _loc2_;
      }
      
      public function §_-hb§(param1:BigInteger) : Array
      {
         var _loc3_:BigInteger = new BigInteger();
         var _loc2_:BigInteger = new BigInteger();
         §_-03h§(param1,_loc3_,_loc2_);
         return [_loc3_,_loc2_];
      }
      
      bi_internal function §_-xg§(param1:int) : void
      {
         a[t] = am(0,param1 - 1,this,0,0,t);
         t = t + 1;
         clamp();
      }
      
      bi_internal function §_-82q§(param1:int, param2:int) : void
      {
         while(t <= param2)
         {
            a[t++] = 0;
         }
         var _loc3_:* = param2;
         var _loc4_:* = a[_loc3_] + param1;
         a[_loc3_] = _loc4_;
         while(a[param2] >= 1073741824)
         {
            _loc4_ = param2;
            _loc3_ = a[_loc4_] - 1073741824;
            a[_loc4_] = _loc3_;
            if(++param2 >= t)
            {
               a[t++] = 0;
            }
            ++a[param2];
         }
      }
      
      public function pow(param1:int) : BigInteger
      {
         return exp(param1,new §_-c27§());
      }
      
      bi_internal function §_-l2g§(param1:BigInteger, param2:int, param3:BigInteger) : void
      {
         var _loc4_:int = 0;
         var _loc5_:int = int(Math.min(t + param1.t,param2));
         param3.s = 0;
         param3.t = _loc5_;
         while(_loc5_ > 0)
         {
            param3.a[--_loc5_] = 0;
         }
         _loc4_ = param3.t - t;
         while(_loc5_ < _loc4_)
         {
            param3.a[_loc5_ + t] = am(0,param1.a[_loc5_],param3,_loc5_,0,t);
            _loc5_++;
         }
         _loc4_ = int(Math.min(param1.t,param2));
         while(_loc5_ < _loc4_)
         {
            am(0,param1.a[_loc5_],param3,_loc5_,0,param2 - _loc5_);
            _loc5_++;
         }
         param3.clamp();
      }
      
      bi_internal function §_-S1z§(param1:BigInteger, param2:int, param3:BigInteger) : void
      {
         param2--;
         var _loc4_:int = param3.t = t + param1.t - param2;
         param3.s = 0;
         while(--_loc4_ >= 0)
         {
            param3.a[_loc4_] = 0;
         }
         _loc4_ = int(Math.max(param2 - t,0));
         while(_loc4_ < param1.t)
         {
            param3.a[t + _loc4_ - param2] = am(param2 - _loc4_,param1.a[_loc4_],param3,0,0,t + _loc4_ - param2);
            _loc4_++;
         }
         param3.clamp();
         param3.§_-kL§(1,param3);
      }
      
      public function §_-WW§(param1:BigInteger, param2:BigInteger) : BigInteger
      {
         var _loc7_:int = 0;
         var _loc16_:§_-i1s§ = null;
         var _loc14_:BigInteger = null;
         var _loc11_:int = 0;
         var _loc12_:BigInteger = null;
         var _loc10_:int = param1.§_-L1J§();
         var _loc13_:BigInteger = §_-Z0§(1);
         if(_loc10_ <= 0)
         {
            return _loc13_;
         }
         if(_loc10_ < 18)
         {
            _loc7_ = 1;
         }
         else if(_loc10_ < 48)
         {
            _loc7_ = 3;
         }
         else if(_loc10_ < 144)
         {
            _loc7_ = 4;
         }
         else if(_loc10_ < 768)
         {
            _loc7_ = 5;
         }
         else
         {
            _loc7_ = 6;
         }
         if(_loc10_ < 8)
         {
            _loc16_ = new §_-f1c§(param2);
         }
         else if(param2.§_-rR§())
         {
            _loc16_ = new §_-9X§(param2);
         }
         else
         {
            _loc16_ = new §_-B2D§(param2);
         }
         var _loc3_:Array = [];
         var _loc4_:int = 3;
         var _loc8_:int = _loc7_ - 1;
         var _loc9_:int = (1 << _loc7_) - 1;
         _loc3_[1] = _loc16_.§_-Qa§(this);
         if(_loc7_ > 1)
         {
            _loc14_ = new BigInteger();
            _loc16_.§_-V22§(_loc3_[1],_loc14_);
            while(_loc4_ <= _loc9_)
            {
               _loc3_[_loc4_] = new BigInteger();
               _loc16_.§_-N1w§(_loc14_,_loc3_[_loc4_ - 2],_loc3_[_loc4_]);
               _loc4_ += 2;
            }
         }
         var _loc6_:int = param1.t - 1;
         var _loc5_:Boolean = true;
         var _loc15_:BigInteger = new BigInteger();
         _loc10_ = §_-XI§(param1.a[_loc6_]) - 1;
         while(_loc6_ >= 0)
         {
            if(_loc10_ >= _loc8_)
            {
               _loc11_ = param1.a[_loc6_] >> _loc10_ - _loc8_ & _loc9_;
            }
            else
            {
               _loc11_ = (param1.a[_loc6_] & (1 << _loc10_ + 1) - 1) << _loc8_ - _loc10_;
               if(_loc6_ > 0)
               {
                  _loc11_ |= param1.a[_loc6_ - 1] >> 30 + _loc10_ - _loc8_;
               }
            }
            _loc4_ = _loc7_;
            while((_loc11_ & 1) == 0)
            {
               _loc11_ >>= 1;
               _loc4_--;
            }
            _loc10_ -= _loc4_;
            if(_loc10_ < 0)
            {
               _loc10_ += 30;
               _loc6_--;
            }
            if(_loc5_)
            {
               _loc3_[_loc11_].copyTo(_loc13_);
               _loc5_ = false;
            }
            else
            {
               while(_loc4_ > 1)
               {
                  _loc16_.§_-V22§(_loc13_,_loc15_);
                  _loc16_.§_-V22§(_loc15_,_loc13_);
                  _loc4_ -= 2;
               }
               if(_loc4_ > 0)
               {
                  _loc16_.§_-V22§(_loc13_,_loc15_);
               }
               else
               {
                  _loc12_ = _loc13_;
                  _loc13_ = _loc15_;
                  _loc15_ = _loc12_;
               }
               _loc16_.§_-N1w§(_loc15_,_loc3_[_loc11_],_loc13_);
            }
            while(_loc6_ >= 0 && (param1.a[_loc6_] & 1 << _loc10_) == 0)
            {
               _loc16_.§_-V22§(_loc13_,_loc15_);
               _loc12_ = _loc13_;
               _loc13_ = _loc15_;
               _loc15_ = _loc12_;
               if(--_loc10_ < 0)
               {
                  _loc10_ = 30 - 1;
                  _loc6_--;
               }
            }
         }
         return _loc16_.§_-w6§(_loc13_);
      }
      
      public function §_-8o§(param1:BigInteger) : BigInteger
      {
         var _loc3_:BigInteger = null;
         var _loc6_:BigInteger = s < 0 ? §_-D3U§() : clone();
         var _loc4_:BigInteger = param1.s < 0 ? param1.§_-D3U§() : param1.clone();
         if(_loc6_.§_-v1n§(_loc4_) < 0)
         {
            _loc3_ = _loc6_;
            _loc6_ = _loc4_;
            _loc4_ = _loc3_;
         }
         var _loc5_:int = _loc6_.§_-Ql§();
         var _loc2_:int = _loc4_.§_-Ql§();
         if(_loc2_ < 0)
         {
            return _loc6_;
         }
         if(_loc5_ < _loc2_)
         {
            _loc2_ = _loc5_;
         }
         if(_loc2_ > 0)
         {
            _loc6_.§_-Bf§(_loc2_,_loc6_);
            _loc4_.§_-Bf§(_loc2_,_loc4_);
         }
         while(_loc6_.§_-jS§() > 0)
         {
            _loc5_ = _loc6_.§_-Ql§();
            if(_loc5_ > 0)
            {
               _loc6_.§_-Bf§(_loc5_,_loc6_);
            }
            _loc5_ = _loc4_.§_-Ql§();
            if(_loc5_ > 0)
            {
               _loc4_.§_-Bf§(_loc5_,_loc4_);
            }
            if(_loc6_.§_-v1n§(_loc4_) >= 0)
            {
               _loc6_.§_-D7§(_loc4_,_loc6_);
               _loc6_.§_-Bf§(1,_loc6_);
            }
            else
            {
               _loc4_.§_-D7§(_loc6_,_loc4_);
               _loc4_.§_-Bf§(1,_loc4_);
            }
         }
         if(_loc2_ > 0)
         {
            _loc4_.§_-Y1B§(_loc2_,_loc4_);
         }
         return _loc4_;
      }
      
      protected function §_-x1K§(param1:int) : int
      {
         var _loc4_:int = 0;
         if(param1 <= 0)
         {
            return 0;
         }
         var _loc2_:int = 1073741824 % param1;
         var _loc3_:int = s < 0 ? param1 - 1 : 0;
         if(t > 0)
         {
            if(_loc2_ == 0)
            {
               _loc3_ = a[0] % param1;
            }
            else
            {
               _loc4_ = t - 1;
               while(_loc4_ >= 0)
               {
                  _loc3_ = (_loc2_ * _loc3_ + a[_loc4_]) % param1;
                  _loc4_--;
               }
            }
         }
         return _loc3_;
      }
      
      public function §_-xj§(param1:BigInteger) : BigInteger
      {
         var _loc8_:Boolean = param1.§_-rR§();
         if(§_-rR§() && _loc8_ || param1.§_-jS§() == 0)
         {
            return BigInteger.ZERO;
         }
         var _loc4_:BigInteger = param1.clone();
         var _loc2_:BigInteger = clone();
         var _loc7_:BigInteger = §_-Z0§(1);
         var _loc5_:BigInteger = §_-Z0§(0);
         var _loc6_:BigInteger = §_-Z0§(0);
         var _loc3_:BigInteger = §_-Z0§(1);
         while(_loc4_.§_-jS§() != 0)
         {
            while(_loc4_.§_-rR§())
            {
               _loc4_.§_-Bf§(1,_loc4_);
               if(_loc8_)
               {
                  if(!_loc7_.§_-rR§() || !_loc5_.§_-rR§())
                  {
                     _loc7_.§_-Xp§(this,_loc7_);
                     _loc5_.§_-D7§(param1,_loc5_);
                  }
                  _loc7_.§_-Bf§(1,_loc7_);
               }
               else if(!_loc5_.§_-rR§())
               {
                  _loc5_.§_-D7§(param1,_loc5_);
               }
               _loc5_.§_-Bf§(1,_loc5_);
            }
            while(_loc2_.§_-rR§())
            {
               _loc2_.§_-Bf§(1,_loc2_);
               if(_loc8_)
               {
                  if(!_loc6_.§_-rR§() || !_loc3_.§_-rR§())
                  {
                     _loc6_.§_-Xp§(this,_loc6_);
                     _loc3_.§_-D7§(param1,_loc3_);
                  }
                  _loc6_.§_-Bf§(1,_loc6_);
               }
               else if(!_loc3_.§_-rR§())
               {
                  _loc3_.§_-D7§(param1,_loc3_);
               }
               _loc3_.§_-Bf§(1,_loc3_);
            }
            if(_loc4_.§_-v1n§(_loc2_) >= 0)
            {
               _loc4_.§_-D7§(_loc2_,_loc4_);
               if(_loc8_)
               {
                  _loc7_.§_-D7§(_loc6_,_loc7_);
               }
               _loc5_.§_-D7§(_loc3_,_loc5_);
            }
            else
            {
               _loc2_.§_-D7§(_loc4_,_loc2_);
               if(_loc8_)
               {
                  _loc6_.§_-D7§(_loc7_,_loc6_);
               }
               _loc3_.§_-D7§(_loc5_,_loc3_);
            }
         }
         if(_loc2_.§_-v1n§(BigInteger.ONE) != 0)
         {
            return BigInteger.ZERO;
         }
         if(_loc3_.§_-v1n§(param1) >= 0)
         {
            return _loc3_.subtract(param1);
         }
         if(_loc3_.§_-jS§() < 0)
         {
            _loc3_.§_-Xp§(param1,_loc3_);
            if(_loc3_.§_-jS§() < 0)
            {
               return _loc3_.add(param1);
            }
            return _loc3_;
         }
         return _loc3_;
      }
      
      public function §_-jo§(param1:int) : Boolean
      {
         var _loc5_:int = 0;
         var _loc2_:int = 0;
         var _loc3_:int = 0;
         var _loc4_:BigInteger = abs();
         if(_loc4_.t == 1 && _loc4_.a[0] <= §_-L1t§[§_-L1t§.length - 1])
         {
            _loc5_ = 0;
            while(_loc5_ < §_-L1t§.length)
            {
               if(_loc4_[0] == §_-L1t§[_loc5_])
               {
                  return true;
               }
               _loc5_++;
            }
            return false;
         }
         if(_loc4_.§_-rR§())
         {
            return false;
         }
         _loc5_ = 1;
         while(_loc5_ < §_-L1t§.length)
         {
            _loc2_ = int(§_-L1t§[_loc5_]);
            _loc3_ = _loc5_ + 1;
            while(_loc3_ < §_-L1t§.length && _loc2_ < §_-f1X§)
            {
               _loc2_ *= §_-L1t§[_loc3_++];
            }
            _loc2_ = _loc4_.§_-x1K§(_loc2_);
            while(_loc5_ < _loc3_)
            {
               if(_loc2_ % §_-L1t§[_loc5_++] == 0)
               {
                  return false;
               }
            }
         }
         return _loc4_.§_-xi§(param1);
      }
      
      protected function §_-xi§(param1:int) : Boolean
      {
         var _loc8_:int = 0;
         var _loc7_:BigInteger = null;
         var _loc5_:int = 0;
         var _loc2_:BigInteger = subtract(BigInteger.ONE);
         var _loc6_:int = _loc2_.§_-Ql§();
         if(_loc6_ <= 0)
         {
            return false;
         }
         var _loc3_:BigInteger = _loc2_.§_-23V§(_loc6_);
         param1 = param1 + 1 >> 1;
         if(param1 > §_-L1t§.length)
         {
            param1 = int(§_-L1t§.length);
         }
         var _loc4_:BigInteger = new BigInteger();
         _loc8_ = 0;
         while(_loc8_ < param1)
         {
            _loc4_.§_-O2E§(§_-L1t§[_loc8_]);
            _loc7_ = _loc4_.§_-WW§(_loc3_,this);
            if(_loc7_.§_-v1n§(BigInteger.ONE) != 0 && _loc7_.§_-v1n§(_loc2_) != 0)
            {
               _loc5_ = 1;
               while(_loc5_++ < _loc6_ && _loc7_.§_-v1n§(_loc2_) != 0)
               {
                  _loc7_ = _loc7_.§_-9L§(2,this);
                  if(_loc7_.§_-v1n§(BigInteger.ONE) == 0)
                  {
                     return false;
                  }
               }
               if(_loc7_.§_-v1n§(_loc2_) != 0)
               {
                  return false;
               }
            }
            _loc8_++;
         }
         return true;
      }
      
      public function §_-123§(param1:int, param2:int) : void
      {
         if(!§_-512§(param1 - 1))
         {
            §_-Ed§(BigInteger.ONE.§_-CL§(param1 - 1),§_-G2N§,this);
         }
         if(§_-rR§())
         {
            §_-82q§(1,0);
         }
         while(!§_-jo§(param2))
         {
            §_-82q§(2,0);
            while(§_-L1J§() > param1)
            {
               §_-D7§(BigInteger.ONE.§_-CL§(param1 - 1),this);
            }
         }
      }
   }
}

