package com.hurlant.math
{
   import §_-62§.*;
   import §_-A1K§.§_-TA§;
   import §_-H16§.*;
   import §_-Y1Q§.§_-61Z§;
   import §_-l2r§.§_-K1t§;
   import §_-w2i§.§_-Zd§;
   import flash.errors.IllegalOperationError;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import flash.utils.IDataOutput;
   import org.swiftsuspenders.Injector;
   import org.swiftsuspenders.§_-71M§;
   import org.swiftsuspenders.§_-T1p§;
   import ru.pragmatix.flox.social.utils.storage.StorageType;
   import ru.pragmatix.wormix.messages.clans.main.server.ClanMemberStructure;
   import ru.pragmatix.wormix.messages.structures.RentedItemsStructure;
   import ru.pragmatix.wormix.messages.structures.TemporalStuffStructure;
   import ru.pragmatix.wormix.messages.structures.UnitStructure;
   import ru.pragmatix.wormix.messages.structures.UserProfileStructure;
   import ru.pragmatix.wormix.messages.structures.WeaponStructure;
   import ru.pragmatix.wormix.pvp.messages.ex.RejectBattleOffer;
   import ru.pragmatix.wormix.serialization.SerializationUtils;
   import ru.pragmatix.wormix.serialization.structures.*;
   import starling.events.Event;
   
   use namespace bi_internal;
   
   internal class §_-B2D§ implements §_-i1s§
   {
      
      private var m:BigInteger;
      
      private var §_-M1G§:int;
      
      private var §_-Bp§:int;
      
      private var §_-to§:int;
      
      private var §_-R1r§:int;
      
      private var §_-F12§:int;
      
      public function §_-B2D§(param1:BigInteger)
      {
         super();
         this.m = param1;
         §_-M1G§ = param1.§_-1Z§();
         §_-Bp§ = §_-M1G§ & 0x7FFF;
         §_-to§ = §_-M1G§ >> 15;
         §_-R1r§ = 32767;
         §_-F12§ = 2 * param1.t;
      }
      
      public function §_-Qa§(param1:BigInteger) : BigInteger
      {
         var _loc2_:BigInteger = new BigInteger();
         param1.abs().§_-bD§(m.t,_loc2_);
         _loc2_.§_-03h§(m,null,_loc2_);
         if(param1.s < 0 && _loc2_.§_-v1n§(BigInteger.ZERO) > 0)
         {
            m.§_-D7§(_loc2_,_loc2_);
         }
         return _loc2_;
      }
      
      public function §_-w6§(param1:BigInteger) : BigInteger
      {
         var _loc2_:BigInteger = new BigInteger();
         param1.copyTo(_loc2_);
         §_-k22§(_loc2_);
         return _loc2_;
      }
      
      public function §_-k22§(param1:BigInteger) : void
      {
         var _loc4_:int = 0;
         var _loc3_:int = 0;
         var _loc2_:int = 0;
         while(param1.t <= §_-F12§)
         {
            param1.a[param1.t++] = 0;
         }
         _loc4_ = 0;
         while(_loc4_ < m.t)
         {
            _loc3_ = param1.a[_loc4_] & 0x7FFF;
            _loc2_ = _loc3_ * §_-Bp§ + ((_loc3_ * §_-to§ + (param1.a[_loc4_] >> 15) * §_-Bp§ & §_-R1r§) << 15) & 0x3FFFFFFF;
            _loc3_ = _loc4_ + m.t;
            var _loc5_:* = _loc3_;
            var _loc6_:* = param1.a[_loc5_] + m.am(0,_loc2_,param1,_loc4_,0,m.t);
            param1.a[_loc5_] = _loc6_;
            while(param1.a[_loc3_] >= 1073741824)
            {
               _loc6_ = _loc3_;
               _loc5_ = param1.a[_loc6_] - 1073741824;
               param1.a[_loc6_] = _loc5_;
               param1.a[++_loc3_]++;
            }
            _loc4_++;
         }
         param1.clamp();
         param1.§_-kL§(m.t,param1);
         if(param1.§_-v1n§(m) >= 0)
         {
            param1.§_-D7§(m,param1);
         }
      }
      
      public function §_-V22§(param1:BigInteger, param2:BigInteger) : void
      {
         param1.§_-I3k§(param2);
         §_-k22§(param2);
      }
      
      public function §_-N1w§(param1:BigInteger, param2:BigInteger, param3:BigInteger) : void
      {
         param1.§_-n29§(param2,param3);
         §_-k22§(param3);
      }
   }
}

