package §_-F2M§
{
   import §_-03T§.§_-2p§;
   import §_-5Y§.§_-h2c§;
   import §_-62§.§_-G1p§;
   import §_-9§.§_-52A§;
   import §_-91B§.§_-z2l§;
   import §_-931§.*;
   import §_-A1K§.§_-TA§;
   import §_-B1y§.*;
   import §_-B2z§.§_-63i§;
   import §_-CF§.§_-E19§;
   import §_-CF§.§_-x2t§;
   import §_-Cl§.*;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-73§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-V1Y§;
   import §_-DJ§.§_-fH§;
   import §_-GQ§.§_-31v§;
   import §_-H3§.*;
   import §_-K35§.§_-L1O§;
   import §_-K35§.§_-p1m§;
   import §_-K3q§.§_-L3A§;
   import §_-L1H§.§_-C3e§;
   import §_-Ly§.§_-81L§;
   import §_-RE§.§_-D3v§;
   import §_-RE§.§_-r2q§;
   import §_-TF§.§_-q1j§;
   import §_-Tm§.§_-RF§;
   import §_-U1i§.§_-J1§;
   import §_-U1i§.§_-U16§;
   import §_-Y1O§.§_-yA§;
   import §_-Y1Q§.§_-aG§;
   import §_-Y1Q§.§_-tc§;
   import §_-YF§.§_-q2v§;
   import §_-Z1K§.§_-q24§;
   import §_-b1F§.§_-G4§;
   import §_-f1G§.*;
   import §_-jF§.§_-E2y§;
   import §_-l1K§.*;
   import §_-l1g§.§_-L3Q§;
   import §_-q26§.§_-Z25§;
   import §_-r1C§.§_-h2B§;
   import §_-u1T§.§_-33B§;
   import §_-u2J§.§_-T1K§;
   import §_-w2W§.§_-21w§;
   import §_-w2i§.§_-Ia§;
   import §_-z1g§.*;
   import §_-zI§.§_-A1s§;
   import com.greensock.events.TweenEvent;
   import com.greensock.loading.core.LoaderItem;
   import config.§_-vR§;
   import dragonBones.animation.WorldClock;
   import feathers.controls.Button;
   import feathers.controls.ImageLoader;
   import feathers.controls.LayoutGroup;
   import feathers.controls.List;
   import feathers.controls.ScrollPolicy;
   import feathers.controls.ToggleButton;
   import feathers.controls.text.TextInstanceCreator;
   import feathers.core.ITextRenderer;
   import feathers.core.ToggleGroup;
   import feathers.data.ArrayCollection;
   import feathers.events.FeathersEventType;
   import feathers.layout.Direction;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.RelativePosition;
   import feathers.layout.TiledRowsLayout;
   import feathers.layout.VerticalAlign;
   import feathers.layout.VerticalLayoutData;
   import feathers.themes.FontColor;
   import feathers.themes.FontSize;
   import flash.display.BitmapData;
   import flash.geom.Point;
   import flash.net.Socket;
   import flash.system.Capabilities;
   import flash.system.System;
   import flash.text.Font;
   import flash.text.TextFormatAlign;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import flash.utils.getTimer;
   import org.gestouch.core.Touch;
   import org.gestouch.core.gestouch_internal;
   import ru.pragmatix.flox.serialization.§_-616§;
   import ru.pragmatix.flox.social.utils.id.MobilePlatformAccountController;
   import ru.pragmatix.wormix.Scene;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fonts.BitmapFonts;
   import ru.pragmatix.wormix.fx.EffectType;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.§_-3m§;
   import ru.pragmatix.wormix.gui.menu.§_-738§;
   import ru.pragmatix.wormix.gui.screenOverlay.view.*;
   import ru.pragmatix.wormix.messages.clans.main.server.ClanMemberStructure;
   import ru.pragmatix.wormix.messages.clans.structures.ClanChatMessageTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanNewsTO;
   import ru.pragmatix.wormix.messages.structures.ChatMessage;
   import ru.pragmatix.wormix.messages.structures.CostStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.bonus.§_-x2M§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.*;
   import ru.pragmatix.wormix.physics.Force;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.pvp.messages.ex.PvpBattleType;
   import ru.pragmatix.wormix.pvp.messages.server.PvpRetryCommandRequestServer;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.§_-6A§;
   import ru.pragmatix.wormix.utils.§_-MN§;
   import ru.pragmatix.wormix.utils.§_-R2g§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.Bullet;
   import ru.pragmatix.wormix.weapons.ammo.phase.HarmPhase;
   import ru.pragmatix.wormix.weapons.ammo.type.grenade.cluster.ShellBurst;
   import starling.display.DisplayObject;
   import starling.display.Image;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.textures.Texture;
   import starling.utils.MathUtil;
   import starling.utils.Pool;
   import starling.utils.SystemUtil;
   
   use namespace gestouch_internal;
   
   public class ChooseTeammateMenu extends §_-V1Y§
   {
      
      private static const §_-u7§:String = "teammate";
      
      private var binder:Binder;
      
      private var §_-H2J§:List;
      
      private var §_-53Y§:ArrayCollection;
      
      private var charIcon:§_-p1m§;
      
      private var §_-I2H§:UserProfile;
      
      private var §_-sB§:int;
      
      private var §_-LN§:int;
      
      private var §_-y1A§:int;
      
      private var §_-91q§:int;
      
      private var toggleGroup:ToggleGroup;
      
      public function ChooseTeammateMenu(param1:UserProfile = null)
      {
         super();
         this.§_-I2H§ = param1;
      }
      
      override protected function initialize() : void
      {
         var tiled:TiledRowsLayout;
         super.initialize();
         this.binder = new Binder();
         §_-Z1p§("choose_teammate_panel",this.binder);
         addChild(this.binder._container);
         this.binder._tabBar.tabInitializer = function(param1:ToggleButton, param2:Object):void
         {
            param1.label = §_-s2a§.§_-K3t§(param2.stringID);
            param1.isEnabled = param2.isEnabled;
         };
         this.binder._tabBar.distributeTabSizes = false;
         this.binder._tabBar.tabProperties.width = 150;
         this.binder._tabBar.paddingLeft = 20;
         this.binder._tabBar.paddingTop = 10;
         this.binder._tabBar.gap = 5;
         tiled = new TiledRowsLayout();
         tiled.gap = 15;
         tiled.horizontalAlign = HorizontalAlign.CENTER;
         tiled.verticalAlign = VerticalAlign.TOP;
         tiled.requestedColumnCount = 5;
         tiled.requestedRowCount = 3;
         tiled.typicalItemWidth = 100;
         tiled.typicalItemHeight = 100;
         tiled.paging = feathers.layout.Direction.HORIZONTAL;
         this.§_-sB§ = tiled.requestedColumnCount * tiled.requestedRowCount;
         this.§_-LN§ = 0;
         this.§_-y1A§ = 0;
         this.§_-91q§ = 0;
         this.§_-H2J§ = new List();
         this.§_-H2J§.addEventListener(FeathersEventType.INITIALIZE,this.§_-fQ§);
         this.§_-H2J§.layout = tiled;
         this.§_-H2J§.layoutData = new VerticalLayoutData(100,100);
         this.§_-H2J§.itemRendererType = §_-E2y§;
         this.§_-H2J§.snapToPages = true;
         this.§_-H2J§.horizontalScrollPolicy = ScrollPolicy.OFF;
         this.§_-H2J§.verticalScrollPolicy = ScrollPolicy.OFF;
         this.§_-H2J§.allowMultipleSelection = false;
         this.§_-53Y§ = new ArrayCollection();
         this.§_-H2J§.dataProvider = this.§_-53Y§;
         this.binder._charListContainer.addChild(this.§_-H2J§);
         this.charIcon = new §_-p1m§(this.binder._avatarView);
         §_-J2N§(this.binder._closeButton,Event.TRIGGERED,§_-R1t§);
         §_-J2N§(this.binder._tabBar,Event.CHANGE,this.§_-d11§);
         §_-J2N§(this.binder._tabBar,Event.TRIGGERED,this.§_-Zw§);
         §_-J2N§(this.binder._listPrevPageButton,Event.TRIGGERED,this.§_-fS§);
         §_-J2N§(this.binder._listNextPageButton,Event.TRIGGERED,this.§_-fS§);
         §_-J2N§(this.§_-H2J§,Event.CHANGE,this.§_-B1n§);
         §_-J2N§(this.§_-H2J§,Event.SCROLL,this.§_-K1D§);
         §_-J2N§(this.§_-H2J§,Event.TRIGGERED,this.§_-W1K§);
         §_-J2N§(this.binder._buyFuzyButton,Event.TRIGGERED,this.§_-90§);
         §_-J2N§(this.binder._buyRubyButton,Event.TRIGGERED,this.§_-90§);
      }
      
      protected function §_-fQ§(param1:Event) : void
      {
         this.§_-H2J§.removeEventListener(FeathersEventType.INITIALIZE,this.§_-fQ§);
      }
      
      override public function dispose() : void
      {
         super.dispose();
         §_-jg§(this.binder._closeButton,Event.TRIGGERED);
         §_-jg§(this.binder._tabBar,Event.CHANGE);
         §_-jg§(this.binder._tabBar,Event.TRIGGERED);
         §_-jg§(this.binder._listPrevPageButton,Event.TRIGGERED);
         §_-jg§(this.binder._listNextPageButton,Event.TRIGGERED);
         §_-jg§(this.§_-H2J§,Event.CHANGE);
         §_-jg§(this.§_-H2J§,Event.SCROLL);
         §_-jg§(this.§_-H2J§,Event.TRIGGERED);
         §_-jg§(this.binder._buyFuzyButton,Event.TRIGGERED);
         §_-jg§(this.binder._buyRubyButton,Event.TRIGGERED);
      }
      
      public function §_-7c§(param1:Array) : void
      {
         var _loc2_:int = this.binder._tabBar.selectedIndex;
         this.binder._tabBar.dataProvider = new ArrayCollection(param1);
         if(_loc2_ > -1)
         {
            if(param1.length > _loc2_ && Boolean(param1[_loc2_].isEnabled))
            {
               _loc2_ = this.binder._tabBar.selectedIndex;
            }
            else
            {
               _loc2_ = 0;
            }
            this.binder._tabBar.selectedIndex = _loc2_;
         }
      }
      
      private function §_-Zw§(param1:Event) : void
      {
         §_-h2B§.play(§_-81L§.§_-o1Z§);
      }
      
      private function §_-d11§(param1:Event) : void
      {
         var _loc2_:int = int(this.binder._tabBar.selectedItem.type);
         this.binder._description.text = §_-s2a§.§_-K3t§(§_-s2a§.LOADING);
         dispatchEventWith(§_-T1K§.TEAM_MEMBER_TYPE_CHANGED,false,_loc2_);
      }
      
      public function setData(param1:Array, param2:String = null) : void
      {
         var _loc6_:int = 0;
         var _loc7_:int = 0;
         var _loc8_:UserProfile = null;
         var _loc9_:int = 0;
         var _loc3_:int = this.§_-H2J§.selectedIndex;
         var _loc4_:int = this.§_-e2Z§(this.§_-H2J§.selectedItem);
         var _loc5_:Boolean = Boolean(param1) && param1.length > 0;
         if(this.§_-53Y§.length > 0)
         {
            this.§_-53Y§.removeAll();
         }
         if(param1)
         {
            _loc6_ = int(param1.length);
            _loc7_ = 0;
            while(_loc7_ < _loc6_)
            {
               _loc8_ = param1[_loc7_];
               this.§_-53Y§.setItemAt(_loc8_,_loc7_);
               _loc7_++;
            }
         }
         this.§_-H2J§.validate();
         this.§_-y1A§ = 0;
         this.§_-91q§ = this.§_-H2J§.horizontalPageCount;
         this.§_-LN§ = this.§_-53Y§.length;
         this.§_-bx§(this.§_-y1A§,this.§_-91q§);
         if(Boolean(param1) && param1.length > 0)
         {
            this.§_-H2J§.scrollToPageIndex(this.§_-y1A§,0,0);
            _loc9_ = this.§_-y1A§ * this.§_-sB§;
            if(_loc3_ < _loc9_ || _loc3_ > _loc9_ + this.§_-sB§ - 1)
            {
               this.§_-H2J§.selectedIndex = _loc9_;
            }
            else
            {
               this.§_-H2J§.selectedIndex = _loc3_;
            }
         }
         if(!param1 || param1.length == 0)
         {
            if(param2 == null)
            {
               param2 = §_-s2a§.NO_PROFILES_FOR_ADD_TO_TEAM;
            }
            this.binder._description.text = §_-s2a§.§_-K3t§(param2);
         }
         else
         {
            this.binder._description.text = this.§_-21r§();
         }
         this.binder._navigationControls.visible = Boolean(param1) && param1.length > 0;
         this.§_-B3A§(this.§_-91q§);
      }
      
      private function §_-B3A§(param1:int) : void
      {
         var _loc3_:ToggleButton = null;
         var _loc4_:Sprite = null;
         var _loc5_:ITextRenderer = null;
         var _loc6_:int = 0;
         if(this.binder._pagingBarContainer.numChildren == param1)
         {
            return;
         }
         var _loc2_:int = 0;
         while(_loc2_ < this.binder._pagingBarContainer.numChildren)
         {
            _loc3_ = this.binder._pagingBarContainer.getChildAt(_loc2_) as ToggleButton;
            _loc3_.removeEventListener(Event.TRIGGERED,this.§_-D2q§);
            _loc2_++;
         }
         this.binder._pagingBarContainer.removeChildren(0,-1,true);
         this.toggleGroup = new ToggleGroup();
         _loc2_ = 0;
         while(_loc2_ < param1)
         {
            _loc4_ = §_-YQ§.§_-qM§(§_-q2v§.§_-s2r§,§_-q2v§.§_-A2T§);
            _loc3_ = _loc4_.getChildAt(0) as ToggleButton;
            _loc5_ = §_-R2g§.createTextRenderer(BitmapFonts.AD_LIB,18,8284506);
            _loc6_ = _loc2_ + 1;
            _loc5_.text = _loc6_.toString();
            _loc3_.addChild(_loc5_ as DisplayObject);
            _loc5_.y = 2;
            _loc5_.width = _loc3_.width;
            this.binder._pagingBarContainer.addChild(_loc3_);
            _loc3_.touchable = true;
            _loc3_.addEventListener(Event.TRIGGERED,this.§_-D2q§);
            _loc3_.toggleGroup = this.toggleGroup;
            _loc4_.dispose();
            _loc2_++;
         }
      }
      
      private function §_-D2q§(param1:Event) : void
      {
         var _loc2_:§_-738§ = §_-738§(param1.target);
         var _loc3_:int = _loc2_.parent.getChildIndex(_loc2_);
         this.§_-N§(_loc3_);
      }
      
      private function §_-N§(param1:int) : void
      {
         this.§_-y1A§ = param1;
         var _loc2_:int = int(this.binder._tabBar.selectedItem.type);
         this.§_-H2J§.scrollToPageIndex(param1,0,0);
         dispatchEventWith(§_-T1K§.PAGE_CHANGED,false,{
            "type":_loc2_,
            "page":param1
         });
         this.§_-H2J§.selectedIndex = param1 * this.§_-sB§;
      }
      
      private function §_-3u§(param1:int) : void
      {
         if(this.toggleGroup)
         {
            this.toggleGroup.selectedIndex = param1;
         }
      }
      
      public function §_-p2g§(param1:UserProfile, param2:§_-x2t§, param3:Boolean) : void
      {
         if(param1)
         {
            §_-L1O§.§_-z1Z§(this.binder._nameData,param1);
            §_-L1O§.§_-z1Z§(this.binder._hpData,param1);
            §_-L1O§.§_-z1Z§(this.binder._armorData,param1);
            §_-L1O§.§_-z1Z§(this.binder._attackData,param1);
            this.charIcon.setIcon(param1);
         }
         this.binder._selectedProfileInfo.visible = param1 != null;
         this.binder._buyFuzyButton.label = !isNaN(param2.§_-R1T§) ? param2.§_-R1T§.toString() : "...";
         this.binder._buyRubyButton.label = !isNaN(param2.§_-R1T§) ? param2.realPrice.toString() : "...";
         this.binder._buyFuzyButton.isEnabled = this.binder._buyRubyButton.isEnabled = param3;
      }
      
      private function §_-fS§(param1:Event) : void
      {
         var _loc3_:UserProfile = null;
         var _loc2_:int = 0;
         switch(param1.currentTarget)
         {
            case this.binder._listPrevPageButton:
               _loc2_ = -1;
               break;
            case this.binder._listNextPageButton:
               _loc2_ = 1;
         }
         var _loc4_:int = 0;
         while(_loc4_ < this.§_-sB§)
         {
            _loc4_++;
         }
         §_-h2B§.play(§_-81L§.§_-o1Z§);
         var _loc5_:int = MathUtil.clamp(this.§_-y1A§ + _loc2_,0,this.§_-91q§);
         if(this.§_-y1A§ != _loc5_)
         {
            this.§_-N§(_loc5_);
            this.§_-3u§(this.§_-y1A§);
         }
      }
      
      public function §_-H29§(param1:Array, param2:int) : void
      {
         var _loc6_:int = 0;
         if(!this.§_-53Y§)
         {
            return;
         }
         var _loc3_:int = 0;
         var _loc4_:int = 0;
         var _loc5_:int = 0;
         while(_loc5_ < param1.length)
         {
            _loc6_ = param2 + _loc5_;
            if(_loc6_ < this.§_-LN§)
            {
               if(this.§_-t26§(param1[_loc5_]) && !this.§_-t26§(this.§_-53Y§.getItemAt(_loc6_)))
               {
                  _loc3_++;
               }
               this.§_-53Y§.setItemAt(param1[_loc5_],_loc6_);
               _loc4_++;
            }
            _loc5_++;
         }
         this.§_-H2J§.validate();
         this.§_-H2J§.scrollToPageIndex(this.§_-y1A§,0,0);
         this.§_-H2J§.selectedIndex = param2;
      }
      
      protected function §_-B1n§(param1:Event) : void
      {
         var _loc2_:UserProfile = this.§_-H2J§.selectedItem as UserProfile;
         var _loc3_:int = int(this.binder._tabBar.selectedItem.type);
         if(_loc2_)
         {
            _loc2_ = _loc2_.§_-517§(_loc3_);
         }
         dispatchEventWith(§_-T1K§.ITEM_SELECTED,false,{
            "type":_loc3_,
            "profile":_loc2_
         });
      }
      
      protected function §_-K1D§(param1:Event) : void
      {
         this.binder._listPrevPageButton.isEnabled = this.§_-y1A§ > 0;
         this.binder._listNextPageButton.isEnabled = this.§_-y1A§ < this.§_-91q§ - 1;
      }
      
      public function §_-bx§(param1:int = -1, param2:Number = NaN) : void
      {
         param1 = param1 == -1 ? this.§_-y1A§ : param1;
         param2 = isNaN(param2) ? this.§_-91q§ : param2;
         this.binder._listNextPageButton.isEnabled = param1 != param2 - 1 && param2 > 0;
         this.binder._listPrevPageButton.isEnabled = param1 != 0 && param2 > 0;
      }
      
      private function §_-W1K§(param1:Event) : void
      {
         §_-h2B§.play(§_-d27§.§_-S29§);
      }
      
      private function §_-90§(param1:Event) : void
      {
         var _loc2_:§_-E19§ = null;
         if(param1.currentTarget == this.binder._buyFuzyButton)
         {
            _loc2_ = §_-E19§.§_-i2d§;
         }
         else if(param1.currentTarget == this.binder._buyRubyButton)
         {
            _loc2_ = §_-E19§.§_-51D§;
         }
         dispatchEventWith(§_-T1K§.BUY_TRIGGERED,false,{
            "moneyType":_loc2_,
            "replacedProfile":this.§_-I2H§
         });
      }
      
      public function §_-13o§(param1:Boolean) : void
      {
         param1;
      }
      
      private function §_-21r§() : String
      {
         var _loc1_:String = "";
         var _loc2_:Object = this.binder._tabBar.selectedItem;
         if(_loc2_)
         {
            switch(_loc2_.type)
            {
               case §_-yA§.§_-uF§:
                  _loc1_ = §_-s2a§.CLAN_TEAM_MEMBER_DESC;
                  break;
               case §_-yA§.§_-v2X§:
                  _loc1_ = §_-s2a§.FRIEND_TEAM_MEMBER_DESC;
                  break;
               case §_-yA§.§_-e2e§:
                  _loc1_ = §_-s2a§.MERCENARY_TEAM_MEMBER_DESC;
            }
         }
         return _loc1_ ? §_-s2a§.§_-K3t§(_loc1_).replace("<br>","\n") : _loc1_;
      }
      
      private function §_-e2Z§(param1:Object) : int
      {
         return this.§_-t26§(param1) ? (param1 as UserProfile).getId() : -1;
      }
      
      private function §_-t26§(param1:Object) : Boolean
      {
         return Boolean(param1) && param1 is UserProfile;
      }
      
      public function get §_-R1e§() : UserProfile
      {
         return this.§_-I2H§;
      }
      
      public function get §_-A32§() : LayoutGroup
      {
         return this.binder._socialControllerPanel;
      }
      
      public function get pageSize() : int
      {
         return this.§_-sB§;
      }
      
      public function set §_-O2e§(param1:int) : void
      {
         this.§_-LN§ = param1;
      }
      
      public function get §_-n1R§() : int
      {
         return this.§_-y1A§;
      }
      
      public function set §_-n1R§(param1:int) : void
      {
         this.§_-y1A§ = param1;
      }
      
      public function get §_-2d§() : int
      {
         return this.§_-91q§;
      }
      
      public function set §_-2d§(param1:int) : void
      {
         this.§_-91q§ = param1;
      }
   }
}

import feathers.controls.Button;
import feathers.controls.Label;
import feathers.controls.LayoutGroup;
import feathers.controls.TabBar;
import starling.display.Sprite;

class Binder
{
   
   public var _container:LayoutGroup;
   
   public var _selectedProfileInfo:LayoutGroup;
   
   public var _nameData:LayoutGroup;
   
   public var _hpData:LayoutGroup;
   
   public var _armorData:LayoutGroup;
   
   public var _attackData:LayoutGroup;
   
   public var _navigationControls:LayoutGroup;
   
   public var _pagingBarContainer:LayoutGroup;
   
   public var _charListContainer:LayoutGroup;
   
   public var _socialControllerPanel:LayoutGroup;
   
   public var _avatarView:Sprite;
   
   public var _description:Label;
   
   public var _tabBar:TabBar;
   
   public var _closeButton:Button;
   
   public var _buyFuzyButton:Button;
   
   public var _buyRubyButton:Button;
   
   public var _listPrevPageButton:Button;
   
   public var _listNextPageButton:Button;
   
   public function Binder()
   {
      super();
   }
}
