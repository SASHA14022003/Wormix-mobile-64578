package §_-2U§
{
   import §_-52L§.§_-u2x§;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-W1r§;
   import §_-62§.§_-zF§;
   import §_-A1K§.§_-6L§;
   import §_-A1K§.§_-U11§;
   import §_-A2U§.§_-A23§;
   import §_-Af§.§_-d1B§;
   import §_-B1y§.§_-bs§;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-J31§.§_-R1h§;
   import §_-J31§.§_-e2J§;
   import §_-L1H§.§_-C3e§;
   import §_-RE§.§_-D3v§;
   import §_-RE§.§_-r2q§;
   import §_-Ta§.*;
   import §_-Z1L§.§_-A2V§;
   import §_-Z1L§.§_-H1K§;
   import §_-Z1w§.§_-s1x§;
   import §_-aM§.AncientGhostScript;
   import §_-aM§.§_-P1N§;
   import §_-b1F§.§_-v2Q§;
   import §_-b1R§.§_-C3P§;
   import §_-fo§.§_-r5§;
   import §_-j1w§.§_-B2i§;
   import §_-l1g§.§_-L3Q§;
   import §_-l2r§.§_-K1t§;
   import §_-r1C§.§_-h2B§;
   import §_-r1C§.§_-t1R§;
   import §_-rM§.§_-61j§;
   import §_-s20§.§_-J2g§;
   import §_-z1g§.§_-522§;
   import com.distriqt.extension.inappbilling.InAppBilling;
   import com.distriqt.extension.inappbilling.Purchase;
   import com.greensock.*;
   import com.greensock.core.*;
   import com.greensock.events.LoaderEvent;
   import com.greensock.loading.LoaderMax;
   import com.greensock.loading.LoaderStatus;
   import com.greensock.loading.core.*;
   import com.greensock.plugins.AutoAlphaPlugin;
   import com.greensock.plugins.BevelFilterPlugin;
   import com.greensock.plugins.BezierPlugin;
   import com.greensock.plugins.BezierThroughPlugin;
   import com.greensock.plugins.BlurFilterPlugin;
   import com.greensock.plugins.ColorMatrixFilterPlugin;
   import com.greensock.plugins.ColorTransformPlugin;
   import com.greensock.plugins.DropShadowFilterPlugin;
   import com.greensock.plugins.EndArrayPlugin;
   import com.greensock.plugins.FrameLabelPlugin;
   import com.greensock.plugins.FramePlugin;
   import com.greensock.plugins.GlowFilterPlugin;
   import com.greensock.plugins.HexColorsPlugin;
   import com.greensock.plugins.RemoveTintPlugin;
   import com.greensock.plugins.RoundPropsPlugin;
   import com.greensock.plugins.ShortRotationPlugin;
   import com.greensock.plugins.TintPlugin;
   import com.greensock.plugins.TweenPlugin;
   import com.greensock.plugins.VisiblePlugin;
   import com.greensock.plugins.VolumePlugin;
   import com.hurlant.util.der.§_-UO§;
   import dragonBones.animation.WorldClock;
   import flash.display.DisplayObject;
   import flash.display.MovieClip;
   import flash.display.Shape;
   import flash.events.*;
   import flash.utils.ByteArray;
   import flash.utils.Dictionary;
   import flash.utils.IDataInput;
   import flash.utils.Timer;
   import flash.utils.getTimer;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.request.AuditActionsRequest;
   import ru.pragmatix.wormix.messages.clans.response.AuditActionsResponse;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.client.AppleVerifyReceipt;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.items.craft.*;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.pvp.messages.client.PvpRetryCommandRequestClient;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.*;
   import ru.pragmatix.wormix.weapons.ammo.LightningBullet;
   import starling.display.DisplayObject;
   import starling.display.Image;
   import starling.events.Event;
   import starling.textures.Texture;
   import starling.utils.Align;
   
   public class AncientGhost extends §_-d1B§
   {
      
      private var boss:§_-01J§;
      
      public function AncientGhost()
      {
         super(67);
      }
      
      override protected function §_-IB§() : void
      {
         §_-6D§ = new <§_-P1N§>[new AncientGhostScript()];
      }
      
      override protected function §_-C2E§() : void
      {
         super.§_-C2E§();
         §_-32L§ = [[§_-H28§(1343,1182),§_-H28§(2353,1225),§_-H28§(923,735),§_-H28§(285,605)],[§_-H28§(2001,585)],[§_-H28§(1182,387),§_-H28§(1820,910)]];
      }
      
      override protected function §_-p13§() : void
      {
         script.addEventListener(§_-L3Q§.§_-Qw§,this.§_-Jc§);
         §_-o2x§();
      }
      
      override public function §_-e2d§() : void
      {
         super.§_-e2d§();
         this.boss = §_-336§[0].getUnits()[0];
      }
      
      private function §_-Jc§(param1:Event, param2:§_-v2Q§) : void
      {
         var _loc3_:§_-01J§ = §_-01J§(param2.victim);
         var _loc4_:§_-e2J§ = §_-A6§(§_-s1x§.ANCIENT_GHOST_AVOID_CLOUDS);
         if(_loc4_.available && param2.source is LightningBullet && param2.source.owner.squad.isAi())
         {
            _loc4_.§_-j2F§();
            §_-wJ§(_loc4_);
         }
         if(_loc3_.disposed && _loc3_ == this.boss)
         {
            _loc4_ = §_-A6§(§_-s1x§.ANCIENT_GHOST_KILL_WITH_CLOUD);
            if(_loc4_.available && param2.source is LightningBullet && param2.source.owner.squad.isAi())
            {
               _loc4_.§_-h2j§ = true;
               §_-o2e§(_loc4_);
            }
         }
      }
      
      override protected function §_-Te§(param1:Event) : void
      {
         var _loc2_:§_-e2J§ = §_-A6§(§_-s1x§.ANCIENT_GHOST_AVOID_CLOUDS);
         if(_loc2_.available && param1.data.source is LightningBullet && Boolean(param1.data.source.owner.squad.isAi()))
         {
            _loc2_.§_-j2F§();
            §_-wJ§(_loc2_);
         }
      }
      
      override protected function §_-d1Y§(param1:§_-R1h§) : void
      {
         var _loc2_:§_-e2J§ = null;
         if(param1.code == §_-s1x§.ANCIENT_GHOST_DONT_MOVE)
         {
            _loc2_ = §_-A6§(§_-s1x§.ANCIENT_GHOST_DONT_MOVE);
            if(_loc2_.available)
            {
               _loc2_.§_-j2F§();
               §_-wJ§(_loc2_);
            }
         }
      }
      
      override protected function §_-e1m§() : void
      {
         §_-A6§(§_-s1x§.ANCIENT_GHOST_AVOID_CLOUDS).§_-Z2M§();
         §_-A6§(§_-s1x§.ANCIENT_GHOST_DONT_MOVE).§_-Z2M§();
      }
   }
}

