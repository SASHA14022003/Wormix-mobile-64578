package §_-2U§
{
   import §_-12W§.*;
   import §_-21p§.§_-4w§;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-O2H§;
   import §_-73I§.*;
   import §_-Af§.§_-d1B§;
   import §_-CF§.§_-E19§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-J31§.§_-R1h§;
   import §_-J31§.§_-e2J§;
   import §_-L2F§.§_-D2p§;
   import §_-RE§.§_-D3v§;
   import §_-RE§.§_-r2q§;
   import §_-T2h§.*;
   import §_-TF§.§_-q1j§;
   import §_-YF§.§_-q2v§;
   import §_-Z1w§.§_-s1x§;
   import §_-aM§.§_-E3R§;
   import §_-aM§.§_-P1N§;
   import §_-d26§.§_-d1H§;
   import §_-j22§.§_-5g§;
   import §_-k1u§.§_-Oi§;
   import §_-x2Q§.§_-dU§;
   import §_-y1s§.§_-P9§;
   import com.distriqt.extension.inappbilling.events.ApplicationReceiptEvent;
   import com.greensock.events.TweenEvent;
   import com.hurlant.util.der.§_-p1B§;
   import feathers.controls.Button;
   import feathers.utils.touch.TapToTrigger;
   import flash.events.MouseEvent;
   import flash.text.TextFormat;
   import flash.utils.ByteArray;
   import flash.utils.IDataOutput;
   import org.swiftsuspenders.Injector;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.flox.social.model.SocialUserData;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.client.StartBattle;
   import ru.pragmatix.wormix.model.user.*;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.weapons.ammo.LaserLineAmmoController;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.utils.Pool;
   
   public class Engineer extends §_-d1B§
   {
      
      public function Engineer()
      {
         super(70);
      }
      
      override protected function §_-IB§() : void
      {
         §_-6D§ = new <§_-P1N§>[new §_-E3R§()];
      }
      
      override protected function §_-C2E§() : void
      {
         super.§_-C2E§();
         §_-32L§ = [[Pool.getPoint(1421,1190),Pool.getPoint(779,1033),Pool.getPoint(2551,968),Pool.getPoint(2230,303)],[Pool.getPoint(683,419)]];
      }
      
      override protected function §_-p13§() : void
      {
         §_-o2x§();
      }
      
      override protected function §_-d1Y§(param1:§_-R1h§) : void
      {
         var _loc2_:§_-e2J§ = null;
         if(param1.code == §_-s1x§.ENGINEER_DONT_LET_SPAWN_2_DRONES)
         {
            _loc2_ = §_-A6§(§_-s1x§.ENGINEER_DONT_LET_SPAWN_2_DRONES);
            if(_loc2_.available)
            {
               _loc2_.§_-j2F§();
               §_-wJ§(_loc2_);
            }
         }
         else if(param1.code == §_-s1x§.ENGINEER_KILL_WITH_ROCKETS)
         {
            _loc2_ = §_-A6§(§_-s1x§.ENGINEER_KILL_WITH_ROCKETS);
            if(_loc2_.available)
            {
               _loc2_.§_-h2j§ = true;
               §_-o2e§(_loc2_);
            }
         }
      }
      
      override protected function §_-Te§(param1:Event) : void
      {
         var _loc2_:§_-e2J§ = null;
         if(LaserLineAmmoController.isLaserAmmo(param1.data.source) && Boolean(param1.data.source.owner.squad.isAi()))
         {
            _loc2_ = §_-A6§(§_-s1x§.ENGINEER_AVOID_LASERS);
            if(param1.data.power > 0 && _loc2_.available)
            {
               _loc2_.§_-j2F§();
               §_-wJ§(_loc2_);
            }
         }
      }
      
      override public function clear() : void
      {
         super.clear();
      }
      
      override protected function §_-e1m§() : void
      {
         §_-A6§(§_-s1x§.ENGINEER_AVOID_LASERS).§_-Z2M§();
         §_-A6§(§_-s1x§.ENGINEER_DONT_LET_SPAWN_2_DRONES).§_-Z2M§();
      }
   }
}

