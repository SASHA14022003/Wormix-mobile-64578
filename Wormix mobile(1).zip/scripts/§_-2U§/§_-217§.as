package §_-2U§
{
   import §_-02q§.§_-4s§;
   import §_-12W§.§_-221§;
   import §_-31W§.AchievRoomPanel;
   import §_-31W§.AwardCell;
   import §_-62§.*;
   import §_-63U§.ProgressBarBoss;
   import §_-63U§.SafetyArea;
   import §_-931§.§_-02O§;
   import §_-A1K§.§_-6L§;
   import §_-A1K§.§_-TA§;
   import §_-A1K§.§_-U11§;
   import §_-Af§.§_-d1B§;
   import §_-B1y§.Cookie;
   import §_-C2t§.§_-92W§;
   import §_-C3f§.§_-yG§;
   import §_-CF§.§_-x2t§;
   import §_-D3A§.§_-TZ§;
   import §_-Tm§.§_-RF§;
   import §_-U1i§.§_-J1§;
   import §_-U1i§.§_-U16§;
   import §_-Y1O§.*;
   import §_-Y1b§.§_-81l§;
   import §_-Z1K§.§_-q24§;
   import §_-aM§.§_-P1N§;
   import §_-aM§.§_-mm§;
   import §_-b1F§.§_-G4§;
   import §_-d26§.§_-c2E§;
   import §_-j1w§.§_-B2i§;
   import §_-j1w§.§_-L1x§;
   import §_-j22§.§_-5g§;
   import §_-k1u§.§_-2m§;
   import §_-k1u§.§_-Oi§;
   import §_-l1g§.§_-L3Q§;
   import §_-q26§.*;
   import §_-qH§.§_-S25§;
   import §_-r1C§.§_-t1R§;
   import §_-w2i§.§_-Ia§;
   import com.greensock.*;
   import com.greensock.plugins.*;
   import com.hurlant.crypto.tls.§_-Tx§;
   import com.hurlant.crypto.tls.§_-a2D§;
   import dragonBones.animation.WorldClock;
   import feathers.controls.Button;
   import feathers.controls.ScrollContainer;
   import feathers.core.FeathersControl;
   import feathers.core.ITextRenderer;
   import feathers.events.FeathersEventType;
   import feathers.layout.AnchorLayoutData;
   import flash.display.StageDisplayState;
   import flash.geom.Point;
   import flash.net.URLRequest;
   import flash.net.navigateToURL;
   import flash.text.TextField;
   import flash.text.TextFormat;
   import flash.utils.ByteArray;
   import flash.utils.IDataOutput;
   import flash.utils.getTimer;
   import org.gestouch.core.*;
   import ru.pragmatix.flox.gui.controls.§_-zi§;
   import ru.pragmatix.flox.serialization.§_-616§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.ScreenShake;
   import ru.pragmatix.wormix.game.ai.§_-A1l§;
   import ru.pragmatix.wormix.game.ai.§_-de§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.request.login.LoginClanBase;
   import ru.pragmatix.wormix.messages.clans.response.LoginClanEnterAccount;
   import ru.pragmatix.wormix.messages.clans.response.LoginClanErrorResponse;
   import ru.pragmatix.wormix.messages.server.GetFriendListPageResult;
   import ru.pragmatix.wormix.messages.server.ShopResult;
   import ru.pragmatix.wormix.messages.structures.ShopItemStructure;
   import ru.pragmatix.wormix.messages.structures.UserProfileStructure;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.objects.§_-Qi§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.pvp.messages.ex.*;
   import ru.pragmatix.wormix.serialization.server.*;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.utils.§_-MN§;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Image;
   import starling.events.Event;
   import starling.textures.Texture;
   
   public class §_-217§ extends §_-d1B§
   {
      
      private var §_-F2H§:§_-TA§;
      
      private const §_-G3M§:§_-TA§ = new §_-TA§(4);
      
      private const §_-N2H§:§_-TA§ = new §_-TA§(80);
      
      private const §_-k16§:§_-TA§ = new §_-TA§(4);
      
      private var §_-ly§:ProgressBarBoss;
      
      private var §_-E3h§:§_-TA§ = new §_-TA§(2000);
      
      private const §_-91T§:§_-TA§ = new §_-TA§(225);
      
      private var §_-t2b§:Vector.<Point>;
      
      private var §_-L21§:Vector.<SafetyArea> = new Vector.<SafetyArea>();
      
      private var dummy:§_-F3o§;
      
      public function §_-217§()
      {
         super(75);
      }
      
      override protected function §_-IB§() : void
      {
         §_-6D§ = new <§_-P1N§>[new §_-mm§()];
      }
      
      override protected function §_-C2E§() : void
      {
         super.§_-C2E§();
         var _loc1_:uint = 5 + (Application.userProfile.§_-hz§() + Application.userProfile.getLevel()) / 4;
         var _loc2_:Number = §_-N1V§.§_-I39§.§_-X1P§().§_-z1N§();
         §_-J1q§ = [new §_-81l§(§_-s2a§.§_-K3t§("TEAM_GUARDIANS_DEPTHS_NAME"),[UserProfile.§_-bR§(_loc2_,§_-s2a§.§_-K3t§("BOT_GUARDIANS_DEPTHS"),4 + _loc1_,§_-L1x§.§_-r2y§,250 + _loc1_ * 17,8 + _loc1_ * 0.9,8 + _loc1_ * 0.8,§_-S25§.§_-cG§),UserProfile.§_-bR§(_loc2_,§_-s2a§.§_-K3t§("BOT_GUARDIANS_DEPTHS"),4 + _loc1_,§_-L1x§.§_-r2y§,250 + _loc1_ * 17,8 + _loc1_ * 0.9,8 + _loc1_ * 0.8,§_-S25§.§_-cG§)]),new §_-81l§(§_-s2a§.§_-K3t§("TEAM_GUARDIANS_DEPTHS_NAME"),[UserProfile.§_-bR§(_loc2_,§_-s2a§.§_-K3t§("BOT_GUARDIANS_DEPTHS"),6 + _loc1_ * 0.8,§_-L1x§.§_-l2G§,200 + _loc1_ * 17,8 + _loc1_ * 0.5,10 + _loc1_ * 1.2,§_-S25§.§_-I23§),UserProfile.§_-bR§(_loc2_,§_-s2a§.§_-K3t§("BOT_GUARDIANS_DEPTHS"),6 + _loc1_ * 0.8,§_-L1x§.§_-l2G§,200 + _loc1_ * 17,8 + _loc1_ * 0.5,10 + _loc1_ * 1.2,§_-S25§.§_-I23§)]),new §_-81l§(§_-s2a§.§_-K3t§("TEAM_GUARDIANS_DEPTHS_NAME"),[UserProfile.§_-bR§(_loc2_,§_-s2a§.§_-K3t§("BOT_GUARDIANS_DEPTHS"),6 + _loc1_ * 0.7,§_-L1x§.§_-I1h§,100 + _loc1_ * 14,7 + _loc1_ * 0.6,7 + _loc1_ * 0.5
         ,§_-S25§.NEO),UserProfile.§_-bR§(_loc2_,§_-s2a§.§_-K3t§("BOT_GUARDIANS_DEPTHS"),6 + _loc1_ * 0.7,§_-L1x§.§_-I1h§,100 + _loc1_ * 14,7 + _loc1_ * 0.6,7 + _loc1_ * 0.5,§_-S25§.NEO)])];
         §_-32L§ = [[§_-H28§(2426,845),§_-H28§(987,1017),§_-H28§(273,325),§_-H28§(1337,290)],[§_-H28§(1979,942),§_-H28§(974,639)],[§_-H28§(478,634),§_-H28§(1411,942)],[§_-H28§(1646,776),§_-H28§(1781,316)]];
         this.§_-F2H§ = new §_-TA§(Physics.UNIT_HEIGHT + 10);
         §§push(this);
         var _temp_6:* = new <Point>[§_-H28§(401,1030),§_-H28§(579,566),§_-H28§(810,853),§_-H28§(1128,1020),§_-H28§(1691,381),§_-H28§(1758,797),§_-H28§(2070,1011),§_-H28§(2314,681)];
         §§pop().§_-t2b§ = new <Point>[§_-H28§(401,1030),§_-H28§(579,566),§_-H28§(810,853),§_-H28§(1128,1020),§_-H28§(1691,381),§_-H28§(1758,797),§_-H28§(2070,1011),§_-H28§(2314,681)];
      }
      
      override public function §_-e2d§() : void
      {
         var _loc1_:int = 0;
         var _loc2_:§_-01J§ = null;
         _loc1_ = 0;
         while(_loc1_ < 2)
         {
            _loc2_ = §_-01J§(§_-336§[0].getUnits()[_loc1_]);
            _loc2_.aiMissFactor = 1;
            _loc2_.aiShotPower = 5;
            _loc2_.aiArsenal = new §_-A1l§(new <§_-de§>[new §_-de§(§_-q24§.§_-ZW§,0.9),new §_-de§(§_-q24§.§_-m1P§,0.9),new §_-de§(§_-q24§.§_-w1k§,0.6)]);
            _loc2_.buffs.place(new §_-92W§());
            _loc1_++;
         }
         _loc1_ = 0;
         while(_loc1_ < 2)
         {
            _loc2_ = §_-01J§(§_-336§[1].getUnits()[_loc1_]);
            _loc2_.aiMissFactor = 1;
            _loc2_.aiShotPower = 5;
            §§push(_loc2_);
            §§push(§§findproperty(§_-A1l§));
            var _temp_5:* = new <§_-de§>[new §_-de§(§_-q24§.AK_47,0.5),new §_-de§(§_-q24§.§_-s1b§),new §_-de§(§_-q24§.§_-J2R§,0.6),new §_-de§(§_-q24§.§_-w1k§,0.6)];
            §§pop().aiArsenal = new §§pop().§_-A1l§(new <§_-de§>[new §_-de§(§_-q24§.AK_47,0.5),new §_-de§(§_-q24§.§_-s1b§),new §_-de§(§_-q24§.§_-J2R§,0.6),new §_-de§(§_-q24§.§_-w1k§,0.6)]);
            _loc2_.buffs.place(new §_-92W§());
            _loc1_++;
         }
         _loc1_ = 0;
         while(_loc1_ < 2)
         {
            _loc2_ = §_-01J§(§_-336§[2].getUnits()[_loc1_]);
            _loc2_.aiMissFactor = 1;
            _loc2_.aiShotPower = 5;
            _loc2_.aiArsenal = new §_-A1l§(new <§_-de§>[new §_-de§(§_-q24§.§_-F31§,0.5),new §_-de§(§_-q24§.§_-Qf§,0.6),new §_-de§(§_-q24§.§_-w1k§,0.6),new §_-de§(§_-q24§.§_-w1s§,0.6)]);
            _loc2_.buffs.place(new §_-92W§());
            _loc1_++;
         }
         this.dummy = §_-X1j§.§_-12n§.scene.makeUnstabilizer();
         this.dummy.stable = true;
         this.§_-v1p§();
      }
      
      private function §_-v1p§() : void
      {
         this.§_-ly§ = §_-X1j§.§_-12n§.scene.gameInterface.§_-a11§(this.§_-k16§.value,"PROGRESS_BAR_GUARDIANS_DEPTHS");
      }
      
      override protected function §_-03f§(param1:uint) : void
      {
         var length:uint = 0;
         var i:int = 0;
         var area:SafetyArea = null;
         var turnNumber:uint = param1;
         if(turnNumber == 1)
         {
            length = uint(§_-X1j§.§_-12n§.gameMaster.§_-vJ§(Application.userProfile).getUnits().length);
            if(length > 1)
            {
               this.§_-E3h§.value = 400 + 400 * (4 - length);
            }
            i = 0;
            while(i < this.§_-t2b§.length)
            {
               this.§_-L21§[this.§_-L21§.length] = new SafetyArea(this.§_-t2b§[i].x,this.§_-t2b§[i].y,this.§_-F2H§,this.§_-N2H§);
               i++;
            }
            this.§_-s3§();
         }
         if(§_-X1j§.§_-12n§.gameMaster.§_-E3b§())
         {
            if(this.§_-ly§.§_-9G§() >= this.§_-ly§.§_-i1u§())
            {
               this.§_-IA§();
               this.§_-ly§.update(0);
               this.dummy.stable = false;
               for each(area in this.§_-L21§)
               {
                  if(area.getState() != SafetyArea.§_-D3q§)
                  {
                     area.setState(SafetyArea.STATE_FADING);
                  }
               }
               §_-Ia§.§_-33o§(15,function():void
               {
                  dummy.stable = true;
                  §_-s3§();
               });
            }
            this.§_-ly§.update(this.§_-ly§.§_-9G§() + 1);
         }
      }
      
      override protected function §_-K2o§(param1:uint) : void
      {
         var _loc2_:SafetyArea = null;
         if(Boolean(!§_-X1j§.§_-12n§.gameMaster.§_-E3b§()) && Boolean(currentUnit) && !currentUnit.disposed)
         {
            for each(_loc2_ in §_-X1j§.§_-12n§.scene.gameObjectProcessor.cache.§_-MM§([SafetyArea]))
            {
               if(Boolean(_loc2_.getTarget() && !_loc2_.getTarget().disposed) && Boolean(_loc2_.getTarget().squad.getTeamId() != currentUnit.squad.getTeamId()) && (this.§_-E3h§.value == -1 ? Boolean(true) : Boolean(MathUtil.distance(currentUnit.x,currentUnit.y,_loc2_.getTarget().x,_loc2_.getTarget().y) <= this.§_-E3h§.value)))
               {
                  Physics.teleportUnit(currentUnit as §_-F3o§,_loc2_.getTarget().x,_loc2_.getTarget().y);
                  break;
               }
            }
         }
      }
      
      private function §_-s3§() : void
      {
         var newArea:Vector.<SafetyArea>;
         var i:int;
         var index:int = 0;
         this.dummy.stable = false;
         newArea = new Vector.<SafetyArea>().concat(this.§_-L21§);
         i = 0;
         while(i < this.§_-G3M§.value)
         {
            index = MathUtil.random(0,newArea.length - 1);
            newArea[index].setState(SafetyArea.§_-B2o§);
            newArea.splice(index,1);
            i++;
         }
         §_-Ia§.§_-33o§(15,function():void
         {
            dummy.stable = true;
         });
      }
      
      private function §_-IA§() : void
      {
         var _loc2_:SafetyArea = null;
         var _loc3_:§_-01J§ = null;
         var _loc4_:int = 0;
         var _loc1_:Vector.<§_-01J§> = §_-X1j§.§_-12n§.gameMaster.§_-vJ§(Application.userProfile).getUnits();
         for each(_loc2_ in §_-X1j§.§_-12n§.scene.gameObjectProcessor.cache.§_-MM§([SafetyArea]))
         {
            _loc4_ = int(_loc1_.indexOf(_loc2_.getTarget()));
            if(_loc4_ != -1)
            {
               _loc1_.splice(_loc4_,1);
            }
         }
         for each(_loc3_ in _loc1_)
         {
            §_-G4§.inflictDamage(new §_-Qi§(null,_loc3_.x,_loc3_.y,false,1),_loc3_ as §_-F3o§,this.§_-91T§.value,10,10);
         }
         ScreenShake.go(12,false,0.7);
         for each(_loc3_ in _loc1_)
         {
            _loc3_.rotateUntilStable();
            _loc3_.addSpeedXY(§_-X1j§.randomSeed.§_-Fh§(-5,5),§_-X1j§.randomSeed.§_-Fh§(-8,-3));
         }
      }
      
      override public function clear() : void
      {
         this.§_-ly§.destroy();
         this.§_-ly§ = null;
         super.clear();
      }
   }
}

