package §_-2U§
{
   import §_-62§.*;
   import §_-91B§.§_-z2l§;
   import §_-A1K§.§_-TA§;
   import §_-Af§.§_-d1B§;
   import §_-B2z§.§_-63i§;
   import §_-SP§.§_-j1f§;
   import §_-Y1O§.§_-y1o§;
   import §_-ZB§.§_-A10§;
   import §_-aM§.*;
   import §_-bI§.§_-d2V§;
   import §_-q26§.§_-Z25§;
   import §_-z20§.§_-Tn§;
   import com.hurlant.math.*;
   import feathers.controls.ScrollPolicy;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import feathers.layout.AnchorLayout;
   import flash.events.Event;
   import flash.geom.Rectangle;
   import flash.media.SoundMixer;
   import flash.media.SoundTransform;
   import flash.utils.Dictionary;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-Q2v§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.pvp.messages.server.PvpEndBattle;
   import ru.pragmatix.wormix.pvp.messages.server.PvpRetryCommandRequestServer;
   import ru.pragmatix.wormix.pvp.messages.server.PvpStartTurn;
   import ru.pragmatix.wormix.pvp.messages.server.PvpSystemMessage;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.§_-2t§;
   import ru.pragmatix.wormix.utils.§_-F2L§;
   import ru.pragmatix.wormix.utils.§_-J2h§;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.MolotovProjectile;
   import ru.pragmatix.wormix.weapons.ammo.boss.emperor.EmperorTerracottaWarrior;
   import starling.core.Starling;
   import starling.events.Event;
   import starling.utils.Pool;
   import starling.utils.RectangleUtil;
   import starling.utils.ScaleMode;
   import starling.utils.SystemUtil;
   
   use namespace bi_internal;
   
   public class Archbot extends §_-d1B§
   {
      
      public function Archbot()
      {
         super(99);
      }
      
      override protected function §_-IB§() : void
      {
         §_-6D§ = new <§_-P1N§>[new §_-7L§()];
      }
      
      override protected function §_-C2E§() : void
      {
         super.§_-C2E§();
         §_-32L§ = [§_-F2L§.§_-CT§([map.§_-FV§[7],map.§_-FV§[5],map.§_-FV§[3],map.§_-FV§[1]]),[map.§_-FV§[8]],[map.§_-FV§[4],map.§_-FV§[6],map.§_-FV§[0],map.§_-42I§[2]]];
      }
   }
}

