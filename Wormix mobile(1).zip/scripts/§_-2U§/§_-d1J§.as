package §_-2U§
{
   import §_-12W§.§_-221§;
   import §_-533§.§_-c2b§;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-zF§;
   import §_-931§.§_-sz§;
   import §_-A1K§.§_-TA§;
   import §_-Af§.§_-d1B§;
   import §_-CF§.§_-gE§;
   import §_-J31§.§_-R1h§;
   import §_-J31§.§_-e2J§;
   import §_-U1i§.§_-O2i§;
   import §_-Y1O§.§_-42h§;
   import §_-YF§.§_-L29§;
   import §_-Z1w§.§_-s1x§;
   import §_-aM§.§_-P1N§;
   import §_-aM§.§_-w9§;
   import §_-b1F§.§_-v2Q§;
   import §_-g2r§.§_-03A§;
   import §_-n1w§.*;
   import §_-r1C§.§_-h2B§;
   import §_-s20§.§_-J2g§;
   import §_-u2J§.§_-A0§;
   import §_-u2J§.§_-T1K§;
   import §_-w2W§.§_-21w§;
   import com.distriqt.extension.application.Application;
   import com.distriqt.extension.application.display.Display;
   import com.hurlant.crypto.tls.§_-F16§;
   import com.hurlant.crypto.tls.§_-Tx§;
   import com.hurlant.crypto.tls.§_-a2D§;
   import com.worlize.websocket.§_-x2j§;
   import flash.utils.ByteArray;
   import ru.pragmatix.flox.logger.*;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.messages.clans.request.PromoteRankInClanRequest;
   import ru.pragmatix.wormix.messages.structures.HeroicMissionStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.pvp.messages.ex.CallToBattle;
   import starling.core.Starling;
   import starling.events.Event;
   import starling.utils.AssetManager;
   import starling.utils.SystemUtil;
   
   public class §_-d1J§ extends §_-d1B§
   {
      
      public function §_-d1J§()
      {
         super(66);
      }
      
      override protected function §_-IB§() : void
      {
         §_-6D§ = new <§_-P1N§>[new §_-w9§()];
      }
      
      override protected function §_-C2E§() : void
      {
         super.§_-C2E§();
         §_-32L§ = [[§_-H28§(1633,397),§_-H28§(385,729),§_-H28§(1882,749),§_-H28§(2206,417)],[§_-H28§(799,797)],[§_-H28§(2265,938)]];
      }
      
      override public function §_-e2d§() : void
      {
         super.§_-e2d§();
      }
      
      override protected function §_-d1Y§(param1:§_-R1h§) : void
      {
         var _loc2_:§_-e2J§ = null;
         if(param1.code == §_-s1x§.ROMEO_KILL_WITH_ONE_SHOT)
         {
            _loc2_ = §_-A6§(§_-s1x§.ROMEO_KILL_WITH_ONE_SHOT);
            if(Boolean(_loc2_) && _loc2_.available)
            {
               _loc2_.§_-h2j§ = true;
               §_-o2e§(_loc2_);
            }
         }
         else if(param1.code == §_-s1x§.ROMEO_KILL_AS_ZOMBIES)
         {
            _loc2_ = §_-A6§(§_-s1x§.ROMEO_KILL_AS_ZOMBIES);
            if(Boolean(_loc2_) && _loc2_.available)
            {
               _loc2_.§_-h2j§ = true;
               §_-o2e§(_loc2_);
            }
         }
         else if(param1.code == §_-s1x§.ROMEO_DONT_LET_DODGE)
         {
            _loc2_ = §_-A6§(§_-s1x§.ROMEO_DONT_LET_DODGE);
            if(Boolean(_loc2_) && _loc2_.available)
            {
               _loc2_.§_-j2F§();
               §_-wJ§(_loc2_);
            }
         }
      }
      
      override protected function §_-e1m§() : void
      {
         §_-A6§(§_-s1x§.ROMEO_DONT_LET_DODGE).§_-Z2M§();
      }
   }
}

