package §_-2U§
{
   import §_-63U§.§_-21K§;
   import §_-Af§.§_-d1B§;
   import §_-Y1b§.§_-OP§;
   import §_-YF§.§_-q2v§;
   import §_-aM§.§_-4u§;
   import §_-aM§.§_-P1N§;
   import §_-j1w§.§_-L1x§;
   import §_-sQ§.§_-H3D§;
   import §_-z1g§.§_-y1S§;
   import com.hurlant.math.*;
   import feathers.core.ITextRenderer;
   import flash.utils.ByteArray;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.EffectType;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.gui.§_-Q2v§;
   import ru.pragmatix.wormix.messages.clans.request.edit.ChangeClanJoinRatingRequest;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.weapons.ammo.GuardingBot;
   import starling.display.DisplayObjectContainer;
   
   use namespace bi_internal;
   
   public class Scientist extends §_-d1B§
   {
      
      public function Scientist()
      {
         super(101);
      }
      
      override protected function §_-IB§() : void
      {
         §_-6D§ = new <§_-P1N§>[new §_-4u§()];
      }
      
      override protected function §_-C2E§() : void
      {
         super.§_-C2E§();
         §_-32L§ = [[map.§_-FV§[7],map.§_-FV§[5],map.§_-FV§[3],map.§_-FV§[1]],[map.§_-FV§[4]],[map.§_-FV§[6],map.§_-FV§[0],map.§_-FV§[2]]];
      }
   }
}

