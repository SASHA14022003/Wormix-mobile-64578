package §_-2U§
{
   import §_-5Y§.*;
   import §_-62§.§_-F1D§;
   import §_-62§.§_-a3§;
   import §_-91B§.§_-z2l§;
   import §_-A1K§.§_-TA§;
   import §_-Af§.§_-d1B§;
   import §_-B1y§.§_-bs§;
   import §_-B2z§.Server;
   import §_-B2z§.§_-c1G§;
   import §_-CF§.§_-E19§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-H3§.*;
   import §_-J31§.§_-R1h§;
   import §_-J31§.§_-e2J§;
   import §_-J3L§.§_-K2i§;
   import §_-L1H§.§_-C3e§;
   import §_-L1H§.§_-b2K§;
   import §_-Ly§.§_-81L§;
   import §_-N8§.§_-2C§;
   import §_-N8§.§_-o2w§;
   import §_-T1t§.§_-u19§;
   import §_-T2h§.§_-43C§;
   import §_-T2h§.§_-C1R§;
   import §_-Tm§.§_-RF§;
   import §_-U1i§.§_-81M§;
   import §_-U1i§.§_-O2i§;
   import §_-Z1w§.§_-s1x§;
   import §_-aM§.§_-P1N§;
   import §_-aM§.§_-y10§;
   import §_-b1F§.§_-v2Q§;
   import §_-d26§.§_-d1H§;
   import §_-hv§.*;
   import §_-j1w§.§_-B2i§;
   import §_-l1g§.§_-L3Q§;
   import §_-m1g§.§_-K2W§;
   import §_-qH§.§_-S25§;
   import §_-r1C§.§_-h2B§;
   import §_-s1Q§.Artifacts;
   import §_-u13§.MD5;
   import §_-u13§.SHA1;
   import §_-w2W§.§_-21w§;
   import §_-w2W§.§_-v27§;
   import §_-z1g§.§_-82X§;
   import §_-z20§.*;
   import com.greensock.plugins.*;
   import config.§_-B1K§;
   import dragonBones.animation.WorldClock;
   import feathers.data.ListCollection;
   import flash.events.Event;
   import flash.utils.ByteArray;
   import flash.utils.Dictionary;
   import flash.utils.IDataInput;
   import flash.utils.IDataOutput;
   import ru.pragmatix.flox.social.controller.SocialApiSettings;
   import ru.pragmatix.flox.social.model.PaymentOption;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.game.§_-eX§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.structures.EndBattleStructure;
   import ru.pragmatix.wormix.messages.structures.PumpReactionRateStructure;
   import ru.pragmatix.wormix.messages.structures.WeaponStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   import ru.pragmatix.wormix.model.user.§_-r1d§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.serialization.SerializationUtils;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.weapons.*;
   import starling.display.DisplayObject;
   import starling.events.Event;
   
   public class §_-t2u§ extends §_-d1B§
   {
      
      private static const §_-X2r§:int = 2;
      
      public function §_-t2u§()
      {
         super(65);
      }
      
      override protected function §_-IB§() : void
      {
         §_-6D§ = new <§_-P1N§>[new §_-y10§()];
      }
      
      override protected function §_-C2E§() : void
      {
         super.§_-C2E§();
         §_-32L§ = [[§_-H28§(1991,1153),§_-H28§(1300,1097),§_-H28§(666,823),§_-H28§(2337,728)],[§_-H28§(1389,621)],[§_-H28§(1991,609)]];
      }
      
      override protected function §_-p13§() : void
      {
         script.addEventListener(§_-L3Q§.§_-Qw§,this.onDamaged);
      }
      
      override protected function §_-K2o§(param1:uint) : void
      {
         super.§_-K2o§(param1);
         var _loc2_:§_-e2J§ = §_-A6§(§_-s1x§.KING_DEAD_KILL_IN_ONE_TURN);
         if(_loc2_.available && _loc2_.count == 1)
         {
            _loc2_.§_-j2F§();
            §_-wJ§(_loc2_);
         }
      }
      
      private function onDamaged(param1:starling.events.Event, param2:§_-v2Q§) : void
      {
         var _loc3_:§_-e2J§ = null;
         if(param2.victim.disposed)
         {
            _loc3_ = §_-A6§(§_-s1x§.KING_DEAD_KILL_IN_ONE_TURN);
            if(_loc3_.available)
            {
               §_-T27§(_loc3_,§_-X2r§);
            }
         }
      }
      
      override protected function §_-d1Y§(param1:§_-R1h§) : void
      {
         var _loc2_:§_-e2J§ = null;
         if(param1.code == §_-s1x§.KING_DEAD_DONT_LET_RES_FIVE_TIMES)
         {
            _loc2_ = §_-A6§(§_-s1x§.KING_DEAD_DONT_LET_RES_FIVE_TIMES);
            if(_loc2_.available)
            {
               _loc2_.§_-j2F§();
               §_-wJ§(_loc2_);
            }
         }
         else if(param1.code == §_-s1x§.KING_DEAD_LET_SPAWN_10_ZOMBIES)
         {
            _loc2_ = §_-A6§(§_-s1x§.KING_DEAD_LET_SPAWN_10_ZOMBIES);
            if(_loc2_.available)
            {
               _loc2_.§_-h2j§ = true;
               §_-o2e§(_loc2_);
            }
         }
      }
      
      override protected function §_-e1m§() : void
      {
         §_-A6§(§_-s1x§.KING_DEAD_DONT_LET_RES_FIVE_TIMES).§_-Z2M§();
      }
   }
}

