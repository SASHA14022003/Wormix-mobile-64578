package §_-2U§
{
   import §_-Af§.§_-d1B§;
   import §_-Af§.§_-k1I§;
   import §_-F2Q§.GestureEvent;
   import §_-F39§.*;
   import §_-HD§.*;
   import §_-S1N§.§_-R1U§;
   import §_-aM§.§_-P1N§;
   import §_-aM§.§_-q1p§;
   import §_-j1w§.§_-L1x§;
   import §_-l1K§.*;
   import §_-qH§.§_-S25§;
   import §_-r1C§.§_-h2B§;
   import §_-s1Q§.Artifacts;
   import feathers.controls.Callout;
   import feathers.controls.NumericStepper;
   import feathers.layout.RelativePosition;
   import flash.geom.Point;
   import org.gestouch.core.GestureState;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.shop.§_-s1V§;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.pvp.messages.ex.PvpBattleType;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.§_-F2L§;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   import starling.utils.Pool;
   import starlingbuilder.extensions.uicomponents.ContainerButtonWithStates;
   
   public class Alchemist extends §_-d1B§
   {
      
      public function Alchemist()
      {
         super(94);
      }
      
      override protected function §_-IB§() : void
      {
         §_-6D§ = new <§_-P1N§>[new §_-q1p§()];
      }
      
      override protected function §_-C2E§() : void
      {
         super.§_-C2E§();
         §_-32L§ = [§_-F2L§.§_-CT§([map.§_-FV§[0],map.§_-FV§[7],map.§_-FV§[5],map.§_-FV§[3],map.§_-FV§[1]]),[map.§_-FV§[2]],[map.§_-FV§[4],map.§_-FV§[6],map.§_-FV§[8]]];
      }
   }
}

