package §_-2U§
{
   import §_-31N§.§_-42G§;
   import §_-5P§.*;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-O2H§;
   import §_-62§.§_-W1r§;
   import §_-9e§.§_-73e§;
   import §_-9e§.§_-8O§;
   import §_-9e§.§_-A18§;
   import §_-A1K§.§_-TA§;
   import §_-Af§.§_-d1B§;
   import §_-B1y§.*;
   import §_-Cl§.*;
   import §_-D3A§.§_-TZ§;
   import §_-J31§.§_-R1h§;
   import §_-J31§.§_-e2J§;
   import §_-L1H§.§_-C3e§;
   import §_-Ly§.§_-I2K§;
   import §_-R2I§.§_-u2V§;
   import §_-RE§.§_-qW§;
   import §_-Tm§.§_-RF§;
   import §_-U1i§.§_-J1§;
   import §_-U1i§.§_-O2i§;
   import §_-Vu§.MD5;
   import §_-Z1K§.§_-q24§;
   import §_-Z1w§.§_-s1x§;
   import §_-aM§.*;
   import §_-b1F§.§_-v2Q§;
   import §_-jF§.*;
   import §_-k1u§.§_-Vr§;
   import §_-l1g§.§_-L3Q§;
   import §_-lh§.§_-z2A§;
   import §_-q2b§.§_-S2L§;
   import §_-r1C§.§_-h2B§;
   import §_-s20§.§_-J2g§;
   import §_-t10§.§_-B29§;
   import §_-v2t§.§_-43O§;
   import §_-w2i§.§_-Zd§;
   import §_-z1g§.§_-82X§;
   import config.§_-vR§;
   import feathers.controls.ImageLoader;
   import flash.events.Event;
   import flash.geom.Point;
   import ru.pragmatix.flox.logger.§_-93v§;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.flox.social.utils.id.GetAuthKeyEvent;
   import ru.pragmatix.flox.social.utils.id.IPlatformAccountController;
   import ru.pragmatix.flox.social.utils.id.UserIdType;
   import ru.pragmatix.flox.social.utils.storage.StorageType;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.sets.ControlSets;
   import ru.pragmatix.wormix.game.§_-eX§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.arena.boss.BossTypesTab;
   import ru.pragmatix.wormix.messages.clans.main.server.GetJoinClansMainRequest;
   import ru.pragmatix.wormix.messages.clans.response.GetJoinClansMainResponse;
   import ru.pragmatix.wormix.messages.clans.structures.ClanMemberTO;
   import ru.pragmatix.wormix.messages.client.MobileLogin;
   import ru.pragmatix.wormix.model.§_-4V§;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.items.craft.*;
   import ru.pragmatix.wormix.model.user.*;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.pvp.messages.ex.BattleCreationFailure;
   import ru.pragmatix.wormix.pvp.messages.ex.StartPvpBattle;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.utils.§_-J2h§;
   import ru.pragmatix.wormix.utils.§_-v2b§;
   import ru.pragmatix.wormix.weapons.Weapon;
   import ru.pragmatix.wormix.weapons.ammo.ChargingBullet;
   import ru.pragmatix.wormix.weapons.ammo.Meteor;
   import ru.pragmatix.wormix.weapons.ammo.MeteorShard;
   import ru.pragmatix.wormix.weapons.ammo.Mine;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.utils.Pool;
   
   public class §_-cH§ extends §_-d1B§
   {
      
      private static const §_-Fv§:int = 4;
      
      private static const §_-bj§:int = 3;
      
      public function §_-cH§()
      {
         super(64);
      }
      
      override protected function §_-IB§() : void
      {
         §_-6D§ = new <§_-P1N§>[new §_-53k§()];
      }
      
      override public function §_-H1J§() : §_-73e§
      {
         var _loc1_:§_-73e§ = null;
         _loc1_ = new §_-73e§();
         _loc1_.online = false;
         _loc1_.backpackEnabled = true;
         _loc1_.§_-v17§ = false;
         _loc1_.§_-f2m§ = false;
         _loc1_.§_-724§ = false;
         _loc1_.§_-z2U§ = false;
         _loc1_.§_-nA§ = false;
         _loc1_.achievements = §_-N1V§.settings.§_-l9§();
         _loc1_.water = §_-A18§.§_-J24§;
         _loc1_.timer = §_-8O§.DEFAULT;
         _loc1_.§_-b2i§ = §_-43O§.§_-i1N§;
         return _loc1_;
      }
      
      override protected function §_-C2E§() : void
      {
         super.§_-C2E§();
         §_-32L§ = [[map.§_-FV§[0],map.§_-FV§[1],map.§_-FV§[2],map.§_-42I§[1]],[map.§_-FV§[4],map.§_-FV§[5],map.§_-FV§[7],map.§_-FV§[3]]];
      }
      
      override protected function §_-p13§() : void
      {
         §_-TZ§.addListener(script,§_-L3Q§.§_-Qw§,this.§_-61a§,§_-4V§.§_-CO§);
         var _loc1_:§_-e2J§ = §_-A6§(§_-s1x§.PIRATE_REVENGE_AVOID_METEORS);
         if(Boolean(_loc1_) && _loc1_.available)
         {
            §_-o2x§();
         }
      }
      
      override protected function §_-d1Y§(param1:§_-R1h§) : void
      {
         var _loc2_:§_-e2J§ = null;
         if(param1.code == §_-s1x§.PIRATE_REVENGE_DROWN_SUPPORTS)
         {
            _loc2_ = §_-A6§(§_-s1x§.PIRATE_REVENGE_DROWN_SUPPORTS);
            if(Boolean(_loc2_) && _loc2_.available)
            {
               §_-T27§(_loc2_,§_-Fv§);
            }
         }
         else if(param1.code == §_-s1x§.PIRATE_REVENGE_DROWN_THREE_TIMES)
         {
            _loc2_ = §_-A6§(§_-s1x§.PIRATE_REVENGE_DROWN_THREE_TIMES);
            if(Boolean(_loc2_) && _loc2_.available)
            {
               §_-T27§(_loc2_,§_-bj§);
            }
         }
      }
      
      private function §_-61a§(param1:starling.events.Event) : void
      {
         var _loc2_:§_-e2J§ = null;
         if(param1.data.victim.disposed)
         {
            _loc2_ = §_-A6§(§_-s1x§.PIRATE_REVENGE_DROWN_SUPPORTS);
            if(Boolean(_loc2_) && _loc2_.available)
            {
               _loc2_.§_-j2F§();
               §_-wJ§(_loc2_);
            }
         }
      }
      
      override protected function §_-Te§(param1:starling.events.Event) : void
      {
         var _loc2_:§_-e2J§ = null;
         if(param1.data.source is Meteor || param1.data.source is MeteorShard)
         {
            _loc2_ = §_-A6§(§_-s1x§.PIRATE_REVENGE_AVOID_METEORS);
            if(Boolean(_loc2_) && _loc2_.available)
            {
               _loc2_.§_-j2F§();
               §_-wJ§(_loc2_);
               §_-43n§();
            }
         }
      }
      
      override protected function §_-e1m§() : void
      {
         var _loc1_:§_-e2J§ = §_-A6§(§_-s1x§.PIRATE_REVENGE_AVOID_METEORS);
         if(_loc1_)
         {
            §_-A6§(§_-s1x§.PIRATE_REVENGE_AVOID_METEORS).§_-Z2M§();
         }
      }
   }
}

