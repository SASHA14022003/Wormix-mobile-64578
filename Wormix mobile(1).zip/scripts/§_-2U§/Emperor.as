package §_-2U§
{
   import §_-31W§.§_-E1E§;
   import §_-Af§.§_-d1B§;
   import §_-C3f§.§_-4I§;
   import §_-CF§.§_-E19§;
   import §_-DJ§.§_-73§;
   import §_-DJ§.§_-73y§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-F39§.*;
   import §_-Ly§.§_-81L§;
   import §_-Tm§.§_-RF§;
   import §_-Y1O§.§_-V23§;
   import §_-YF§.§_-q2v§;
   import §_-aM§.§_-51L§;
   import §_-aM§.§_-P1N§;
   import §_-r1C§.*;
   import com.distriqt.extension.application.Application;
   import feathers.core.ITextRenderer;
   import flash.display.SimpleButton;
   import flash.utils.ByteArray;
   import flash.utils.IDataOutput;
   import ru.pragmatix.flox.social.response.LoadFriendsResponse;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.game.§_-eX§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.shop.desktop.§_-11V§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.utils.§_-F2L§;
   import ru.pragmatix.wormix.utils.§_-R2g§;
   import ru.pragmatix.wormix.weapons.*;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   import starlingbuilder.extensions.uicomponents.ContainerButtonWithStates;
   
   public class Emperor extends §_-d1B§
   {
      
      public function Emperor()
      {
         super(103);
      }
      
      override protected function §_-IB§() : void
      {
         §_-6D§ = new <§_-P1N§>[new §_-51L§()];
      }
      
      override protected function §_-C2E§() : void
      {
         super.§_-C2E§();
         §_-32L§ = [§_-F2L§.§_-CT§([map.§_-FV§[0],map.§_-FV§[1],map.§_-FV§[2],map.§_-FV§[3],map.§_-FV§[4],map.§_-FV§[5]]),[map.§_-42I§[1]],[map.§_-42I§[3]]];
      }
   }
}

