package §_-2U§
{
   import §_-82a§.*;
   import §_-Af§.§_-d1B§;
   import §_-TF§.§_-q1j§;
   import §_-aM§.§_-32U§;
   import §_-aM§.§_-P1N§;
   import §_-fo§.§_-21L§;
   import §_-j1w§.§_-B2i§;
   import §_-l1g§.§_-L3Q§;
   import com.hurlant.crypto.tls.§_-21v§;
   import com.hurlant.util.§_-F2L§;
   import flash.utils.ByteArray;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.messages.clans.response.PromoteRankInClanResponse;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.pvp.messages.ex.*;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.§_-6A§;
   import ru.pragmatix.wormix.utils.§_-F2L§;
   import ru.pragmatix.wormix.weapons.DoctorBag;
   import starling.events.Event;
   
   public class Assassin extends §_-d1B§
   {
      
      public function Assassin()
      {
         super(96);
      }
      
      override protected function §_-IB§() : void
      {
         §_-6D§ = new <§_-P1N§>[new §_-32U§()];
      }
      
      override protected function §_-C2E§() : void
      {
         super.§_-C2E§();
         §_-32L§ = [ru.pragmatix.wormix.utils.§_-F2L§.§_-CT§([map.§_-FV§[0],map.§_-FV§[1],map.§_-FV§[2],map.§_-FV§[4],map.§_-FV§[5],map.§_-FV§[6],map.§_-FV§[7]]),[map.§_-FV§[3]]];
      }
   }
}

