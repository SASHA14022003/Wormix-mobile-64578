package §_-2U§
{
   import §_-A1K§.§_-TA§;
   import §_-Af§.§_-d1B§;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-J2l§;
   import §_-E1I§.§_-b2n§;
   import §_-aM§.§_-P1N§;
   import §_-aM§.§_-mg§;
   import §_-gG§.§_-8u§;
   import §_-l1g§.§_-L3Q§;
   import §_-s20§.§_-J2g§;
   import com.greensock.loading.*;
   import com.greensock.loading.core.LoaderCore;
   import com.greensock.loading.core.LoaderItem;
   import flash.display.Shape;
   import flash.geom.Point;
   import flash.utils.Dictionary;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.wormix.Scene;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.messages.clans.response.*;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.client.Disconnect;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.physics.HitTest;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.social.*;
   import ru.pragmatix.wormix.utils.§_-F2L§;
   import starling.display.DisplayObject;
   import starling.events.Event;
   import starling.filters.ColorMatrixFilter;
   import starling.utils.ScaleMode;
   
   public class Symbiote extends §_-d1B§
   {
      
      public function Symbiote()
      {
         super(85);
      }
      
      override protected function §_-IB§() : void
      {
         §_-6D§ = new <§_-P1N§>[new §_-mg§()];
      }
      
      override protected function §_-C2E§() : void
      {
         super.§_-C2E§();
         §_-32L§ = [§_-F2L§.§_-CT§([map.§_-FV§[0],map.§_-FV§[1],map.§_-FV§[2],map.§_-FV§[3],map.§_-FV§[4],map.§_-FV§[5],map.§_-FV§[6],map.§_-FV§[7]]),[map.§_-42I§[3]],[map.§_-42I§[1]]];
      }
   }
}

