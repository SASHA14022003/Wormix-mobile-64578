package §_-2U§
{
   import §_-12W§.*;
   import §_-31W§.*;
   import §_-91A§.*;
   import §_-A1K§.§_-TA§;
   import §_-Af§.§_-d1B§;
   import §_-B1y§.§_-bs§;
   import §_-Cl§.*;
   import §_-G16§.*;
   import §_-G2H§.*;
   import §_-J31§.§_-R1h§;
   import §_-P1B§.§_-b21§;
   import §_-P2i§.*;
   import §_-U1i§.§_-I3t§;
   import §_-W§.§_-mK§;
   import §_-W§.§_-y1q§;
   import §_-Y1O§.§_-V23§;
   import §_-Y1b§.§_-81l§;
   import §_-Y1b§.§_-OP§;
   import §_-Z1K§.§_-q24§;
   import §_-Z1w§.§_-s1x§;
   import §_-aM§.§_-P1N§;
   import §_-aM§.§_-y1L§;
   import §_-j1w§.§_-L1x§;
   import §_-j22§.§_-5g§;
   import §_-l1g§.§_-L3Q§;
   import §_-lh§.§_-z2A§;
   import §_-nE§.SelectCraftWeaponScreen;
   import §_-nE§.§_-p16§;
   import §_-qH§.§_-S25§;
   import §_-s1Q§.Artifacts;
   import §_-x22§.§_-xY§;
   import com.distriqt.extension.inappbilling.Purchase;
   import com.greensock.events.LoaderEvent;
   import com.greensock.loading.*;
   import com.greensock.loading.core.LoaderCore;
   import feathers.controls.LayoutGroup;
   import feathers.data.ListCollection;
   import feathers.events.FeathersEventType;
   import feathers.layout.AnchorLayout;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.HorizontalLayout;
   import feathers.layout.ILayout;
   import feathers.layout.RelativePosition;
   import feathers.layout.TiledColumnsLayout;
   import feathers.layout.VerticalAlign;
   import feathers.layout.VerticalLayout;
   import flash.desktop.NativeApplication;
   import flash.display.Bitmap;
   import flash.display.DisplayObject;
   import flash.display.MovieClip;
   import flash.display.SimpleButton;
   import flash.events.Event;
   import flash.events.IEventDispatcher;
   import flash.geom.Point;
   import flash.geom.Rectangle;
   import flash.media.SoundTransform;
   import flash.net.SharedObject;
   import flash.utils.ByteArray;
   import flash.utils.IDataOutput;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fonts.BitmapFonts;
   import ru.pragmatix.wormix.fx.AbstractAuraEffect;
   import ru.pragmatix.wormix.fx.ArmatureAuraEffect;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.game.ai.§_-A1l§;
   import ru.pragmatix.wormix.game.ai.§_-de§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.§_-3m§;
   import ru.pragmatix.wormix.messages.server.Pong;
   import ru.pragmatix.wormix.messages.structures.ProfileDoubleKeyStructure;
   import ru.pragmatix.wormix.messages.structures.UserProfileStructure;
   import ru.pragmatix.wormix.model.items.craft.§_-6S§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.physics.model.UnitPhysicModel;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.utils.§_-R2g§;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.phase.HealBolt;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.events.Event;
   import starling.utils.Pool;
   import starling.utils.RectangleUtil;
   import starling.utils.ScaleMode;
   
   public class DarkKnight extends §_-d1B§
   {
      
      private static const §_-822§:§_-TA§ = new §_-TA§(30);
      
      private static const §_-a2X§:§_-TA§ = new §_-TA§(30);
      
      private static const §_-YX§:§_-TA§ = new §_-TA§(20);
      
      private static const §_-a2c§:§_-TA§ = new §_-TA§(4);
      
      private static const §_-31F§:§_-TA§ = new §_-TA§(§_-a2c§.value + 1);
      
      private static const §_-D1k§:§_-TA§ = new §_-TA§(3);
      
      private static const §_-iH§:§_-TA§ = new §_-TA§(3);
      
      private static const §_-1T§:§_-TA§ = new §_-TA§(10);
      
      private static const §_-220§:§_-TA§ = new §_-TA§(4);
      
      private var mainBoss:§_-01J§;
      
      private var §_-E2u§:§_-TA§ = new §_-TA§(§_-31F§.value);
      
      private var §_-R2W§:§_-TA§ = new §_-TA§(§_-iH§.value);
      
      private var §_-D1S§:§_-V23§;
      
      private var §_-tD§:UserProfile;
      
      public function DarkKnight()
      {
         super(87);
      }
      
      private static function §_-01U§(param1:§_-01J§) : AbstractAuraEffect
      {
         return new ArmatureAuraEffect(param1,"DarkKnight_ProtectiveShield");
      }
      
      override protected function §_-IB§() : void
      {
         §_-6D§ = new <§_-P1N§>[new §_-y1L§()];
      }
      
      override protected function §_-C2E§() : void
      {
         super.§_-C2E§();
         var _loc1_:uint = 5 + (Application.userProfile.§_-hz§() + Application.userProfile.getLevel()) / 4;
         var _loc2_:Number = §_-N1V§.§_-I39§.§_-X1P§().§_-z1N§();
         this.§_-tD§ = UserProfile.§_-bR§(_loc2_,§_-s2a§.§_-K3t§(§_-s2a§.BOSS_DARK_KNIGHT_ACOLYTE),2 + _loc1_ * 1.7,§_-L1x§.§_-I1h§,100 + _loc1_ * 23,6 + _loc1_ * 0.8,6 + _loc1_ * 1.2,§_-S25§.§_-H3Q§,Artifacts.TRAINING_SHIELD);
         §_-J1q§ = [new §_-81l§(§_-s2a§.§_-K3t§(§_-s2a§.BOSS_DARK_KNIGHT_NAME),[UserProfile.§_-bR§(_loc2_,§_-s2a§.§_-K3t§(§_-s2a§.BOSS_DARK_KNIGHT_NAME),2 + _loc1_ * 2.2,§_-L1x§.§_-AU§,500 + _loc1_ * 30,10 + _loc1_ * 2.5,10 + _loc1_ * 1.5,§_-S25§.BOSS_DARK_KNIGHT,Artifacts.BROKEN_SWORD)]),new §_-81l§(§_-s2a§.§_-K3t§(§_-s2a§.BOSS_DARK_KNIGHT_TEAM_ACOLYTES),[this.§_-H3s§(),this.§_-H3s§()])];
         §_-32L§ = [[§_-H28§(673,575),§_-H28§(1966,438),§_-H28§(1521,887),§_-H28§(2511,458)],[§_-H28§(1078,228)],[§_-H28§(2103,248),§_-H28§(515,57)]];
      }
      
      override public function §_-e2d§() : void
      {
         this.mainBoss = §_-01J§(§_-336§[0].getUnits()[0]);
         this.mainBoss.aiMissFactor = 1;
         this.mainBoss.aiShotPower = 5;
         §§push(this.mainBoss);
         §§push(§§findproperty(§_-A1l§));
         var _temp_6:* = new <§_-de§>[new §_-de§(§_-q24§.§_-w1k§,1),new §_-de§(§_-q24§.CANNON_UPG_2,0.2),new §_-de§(§_-q24§.§_-g1q§,0.7),new §_-de§(§_-q24§.§_-s1b§,0.7),new §_-de§(§_-q24§.WATERMELON,0.1),new §_-de§(§_-q24§.BLIZZARD,0.2),new §_-de§(§_-q24§.ANTITOXIN,0.4),new §_-de§(§_-q24§.BANDAGE,0.3,1),new §_-de§(§_-q24§.§_-R2h§,0.8,2)];
         §§pop().aiArsenal = new §§pop().§_-A1l§(new <§_-de§>[new §_-de§(§_-q24§.§_-w1k§,1),new §_-de§(§_-q24§.CANNON_UPG_2,0.2),new §_-de§(§_-q24§.§_-g1q§,0.7),new §_-de§(§_-q24§.§_-s1b§,0.7),new §_-de§(§_-q24§.WATERMELON,0.1),new §_-de§(§_-q24§.BLIZZARD,0.2),new §_-de§(§_-q24§.ANTITOXIN,0.4),new §_-de§(§_-q24§.BANDAGE,0.3,1),new §_-de§(§_-q24§.§_-R2h§,0.8,2)]);
         this.§_-Y2C§(this.mainBoss);
         this.mainBoss.buffs.place(new §_-y1q§(§_-01U§(this.mainBoss),§_-822§.value + Application.userProfile.getMaxLevel() * 2,this.§_-Y2C§));
         this.§_-D1S§ = §_-336§[1];
         var _loc1_:uint = 0;
         while(_loc1_ < this.§_-D1S§.getUnits().length)
         {
            this.§_-P1u§(this.§_-D1S§.getUnits()[_loc1_]);
            _loc1_++;
         }
      }
      
      private function §_-P1u§(param1:§_-01J§) : void
      {
         param1.aiMissFactor = 1;
         param1.aiShotPower = 5;
         §§push(param1);
         §§push(§§findproperty(§_-A1l§));
         var _temp_2:* = new <§_-de§>[new §_-de§(§_-q24§.§_-Qf§,0.4),new §_-de§(§_-q24§.§_-w1k§,0.8),new §_-de§(§_-q24§.MOLOTOV,0.1),new §_-de§(§_-q24§.§_-Z2L§,0.3),new §_-de§(§_-q24§.SNIPER_RIFLE_UPG_1,0.7)];
         var _temp_4:* = new <§_-de§>[new §_-de§(§_-q24§.§_-Qf§,0.4),new §_-de§(§_-q24§.§_-w1k§,0.8),new §_-de§(§_-q24§.MOLOTOV,0.1),new §_-de§(§_-q24§.§_-Z2L§,0.3),new §_-de§(§_-q24§.SNIPER_RIFLE_UPG_1,0.7)];
         §§pop().aiArsenal = new §§pop().§_-A1l§(new <§_-de§>[new §_-de§(§_-q24§.§_-Qf§,0.4),new §_-de§(§_-q24§.§_-w1k§,0.8),new §_-de§(§_-q24§.MOLOTOV,0.1),new §_-de§(§_-q24§.§_-Z2L§,0.3),new §_-de§(§_-q24§.SNIPER_RIFLE_UPG_1,0.7)]);
         this.§_-Y2C§(param1);
      }
      
      private function §_-Y2C§(param1:§_-01J§) : void
      {
         §_-OP§.§_-g1j§(param1);
         param1.§_-q2T§();
      }
      
      private function §_-H3s§() : UserProfile
      {
         var _loc1_:UserProfile = this.§_-tD§.§_-F1b§();
         _loc1_.§_-s1I§(§_-L1x§.§_-R2b§(new <§_-L1x§>[§_-L1x§.§_-p21§,§_-L1x§.§_-t1I§,§_-L1x§.§_-AU§]).§_-wz§());
         return _loc1_;
      }
      
      override protected function §_-03f§(param1:uint) : void
      {
         var _loc2_:§_-01J§ = null;
         var _loc3_:Vector.<§_-01J§> = null;
         var _loc4_:int = 0;
         var _loc5_:Point = null;
         var _loc6_:§_-01J§ = null;
         if(!§_-X1j§.§_-12n§.gameMaster.§_-E3b§())
         {
            if(currentUnit != this.mainBoss)
            {
               _loc3_ = new Vector.<§_-01J§>();
               for each(_loc2_ in §_-X1j§.§_-12n§.gameMaster.§_-b2W§(this.mainBoss))
               {
                  if(_loc2_ != this.mainBoss && !_loc2_.disposed && !_loc2_.buffs.hasBuff(§_-y1q§.NAME))
                  {
                     _loc3_.push(_loc2_);
                  }
               }
               if(_loc3_.length > 0)
               {
                  _loc2_ = _loc3_[MathUtil.random(0,_loc3_.length - 1)];
                  _loc2_.buffs.place(new §_-y1q§(§_-01U§(_loc2_),§_-822§.value,this.§_-Y2C§));
               }
            }
            else if(!this.mainBoss.disposed)
            {
               _loc4_ = §_-X1j§.§_-12n§.gameMaster.§_-b2W§(this.mainBoss).length - 1;
               if(!(param1 % §_-220§.value) && _loc4_ < §_-1T§.value)
               {
                  var _temp_4:* = §_-OP§.§_-pa§();
                  _loc5_ = §_-OP§.§_-pa§();
                  if(_loc5_)
                  {
                     _loc6_ = §_-OP§.§_-R19§(_loc5_,this.§_-H3s§(),null,this.§_-D1S§);
                     this.§_-P1u§(_loc6_);
                     Pool.putPoint(_loc5_);
                  }
               }
               if(MathUtil.§_-oL§(this.mainBoss.attributes.hp.value,this.mainBoss.attributes.hp.§_-33H§()) <= §_-YX§.value)
               {
                  if(!this.mainBoss.buffs.hasBuff(§_-mK§.NAME) && this.§_-E2u§.value++ >= §_-31F§.value && _loc4_ > §_-D1k§.value)
                  {
                     this.mainBoss.buffs.§_-e1z§(§_-y1q§.NAME);
                     this.mainBoss.buffs.place(new §_-mK§(new ArmatureAuraEffect(this.mainBoss,"DarkKnight_AbsorbShield"),§_-a2c§.value));
                     this.§_-E2u§.value = 0;
                  }
               }
               else if(!this.mainBoss.buffs.hasBuff(§_-y1q§.NAME) && this.§_-R2W§.value++ >= §_-iH§.value)
               {
                  this.mainBoss.buffs.place(new §_-y1q§(§_-01U§(this.mainBoss),§_-822§.value + Application.userProfile.getMaxLevel() * 2,this.§_-Y2C§));
                  this.§_-R2W§.value = 0;
               }
            }
         }
      }
      
      override protected function §_-K2o§(param1:uint) : void
      {
         var unit:§_-01J§ = null;
         var mainBossHp:§_-b21§ = null;
         var dummy:§_-F3o§ = null;
         var turnNumber:uint = param1;
         if(!§_-X1j§.§_-12n§.gameMaster.§_-E3b§() && §_-X1j§.§_-12n§.gameMaster.activeUnit != this.mainBoss)
         {
            unit = §_-X1j§.§_-12n§.gameMaster.activeUnit;
            mainBossHp = this.mainBoss.attributes.hp;
            if(!this.mainBoss.disposed && !unit.disposed && MathUtil.§_-oL§(mainBossHp.value,mainBossHp.§_-33H§()) <= §_-a2X§.value)
            {
               dummy = §_-X1j§.§_-12n§.scene.makeUnstabilizer();
               Effects.aura(unit,"DarkKnight_SacrificeMinion",54,function():void
               {
                  new HealBolt(unit,unit.x,unit.y,mainBoss,mainBossHp.§_-33H§());
                  if(Boolean(dummy) && !dummy.disposed)
                  {
                     dummy.disposed = true;
                  }
                  unit.disposed = true;
               });
            }
         }
      }
   }
}

