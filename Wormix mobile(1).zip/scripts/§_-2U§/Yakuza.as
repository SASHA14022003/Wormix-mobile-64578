package §_-2U§
{
   import §_-21p§.§_-4w§;
   import §_-31W§.AwardCell;
   import §_-43V§.*;
   import §_-A1K§.§_-6L§;
   import §_-A1K§.§_-TA§;
   import §_-A1K§.§_-U11§;
   import §_-Af§.§_-d1B§;
   import §_-CF§.§_-E19§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-J31§.§_-R1h§;
   import §_-J31§.§_-e2J§;
   import §_-Y1O§.*;
   import §_-YF§.§_-q2v§;
   import §_-Z1K§.§_-q24§;
   import §_-Z1w§.§_-s1x§;
   import §_-aM§.§_-P1N§;
   import §_-aM§.§_-x2d§;
   import §_-bI§.§_-d2V§;
   import §_-eO§.§_-yH§;
   import §_-fo§.*;
   import §_-j22§.§_-5g§;
   import §_-k2s§.§_-Go§;
   import §_-k2s§.§_-iI§;
   import §_-l1g§.§_-L3Q§;
   import §_-l1g§.§_-T2N§;
   import §_-l2r§.§_-K1t§;
   import §_-r1C§.§_-h2B§;
   import §_-s20§.§_-J2g§;
   import §_-s20§.§_-R1P§;
   import §_-sQ§.§_-V1n§;
   import §_-z1g§.§_-y1S§;
   import com.greensock.*;
   import com.greensock.core.*;
   import com.greensock.events.LoaderEvent;
   import com.greensock.plugins.*;
   import dragonBones.animation.WorldClock;
   import feathers.controls.Button;
   import feathers.controls.ScrollPolicy;
   import feathers.layout.AnchorLayout;
   import flash.display.*;
   import flash.events.Event;
   import flash.geom.ColorTransform;
   import flash.text.TextFormat;
   import flash.utils.ByteArray;
   import flash.utils.IDataOutput;
   import flash.utils.getTimer;
   import ru.pragmatix.wormix.Scene;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.§_-3m§;
   import ru.pragmatix.wormix.messages.client.EndBattle;
   import ru.pragmatix.wormix.messages.server.ShopResult;
   import ru.pragmatix.wormix.messages.structures.WeaponStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   import ru.pragmatix.wormix.model.user.§_-r1d§;
   import ru.pragmatix.wormix.objects.Direction;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-A16§;
   import ru.pragmatix.wormix.physics.Force;
   import ru.pragmatix.wormix.serialization.SerializationUtils;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.*;
   import starling.display.DisplayObject;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.utils.ScaleMode;
   
   public class Yakuza extends §_-d1B§
   {
      
      public static const §_-X2r§:§_-TA§ = new §_-TA§(3);
      
      public static const §_-31I§:§_-TA§ = new §_-TA§(3);
      
      public function Yakuza()
      {
         super(68);
      }
      
      override protected function §_-IB§() : void
      {
         §_-6D§ = new <§_-P1N§>[new §_-x2d§()];
      }
      
      override protected function §_-C2E§() : void
      {
         super.§_-C2E§();
         §_-32L§ = [[§_-H28§(1389,744),§_-H28§(828,744),§_-H28§(2218,842),§_-H28§(1409,1068)],[§_-H28§(1697,309)],[§_-H28§(1174,391)],[§_-H28§(1772,790)]];
      }
      
      override protected function §_-p13§() : void
      {
         §_-X1j§.§_-12n§.scene.addEventListener(§_-L3Q§.MASSIVE_DAMAGE,this.§_-A2M§);
      }
      
      override protected function §_-K2o§(param1:uint) : void
      {
         super.§_-K2o§(param1);
         var _loc2_:§_-e2J§ = §_-A6§(§_-s1x§.YAKUZA_KILL_TWO_IN_TURN);
         if(Boolean(_loc2_) && _loc2_.available)
         {
            if(this.§_-03P§ <= 1)
            {
               _loc2_.§_-j2F§();
               §_-wJ§(_loc2_);
            }
            else
            {
               _loc2_.count = 0;
            }
         }
      }
      
      override protected function §_-d1Y§(param1:§_-R1h§) : void
      {
         var _loc2_:§_-e2J§ = §_-A6§(§_-s1x§.YAKUZA_KILL_STEEL_LAST);
         if(Boolean(_loc2_ && _loc2_.available) && Boolean(param1.code == §_-s1x§.YAKUZA_KILL_STEEL_LAST) && this.§_-03P§ > 0)
         {
            _loc2_.§_-j2F§();
            §_-wJ§(_loc2_);
         }
         _loc2_ = §_-A6§(§_-s1x§.YAKUZA_KILL_TWO_IN_TURN);
         if(Boolean(_loc2_) && Boolean(_loc2_.available) && param1.code == §_-s1x§.YAKUZA_KILL_TWO_IN_TURN)
         {
            §_-T27§(_loc2_,§_-X2r§.value - 1);
         }
      }
      
      override protected function §_-e1m§() : void
      {
         var _loc1_:§_-e2J§ = §_-A6§(§_-s1x§.YAKUZA_KILL_STEEL_LAST);
         if(_loc1_)
         {
            §_-A6§(§_-s1x§.YAKUZA_KILL_STEEL_LAST).§_-Z2M§();
         }
      }
      
      private function §_-A2M§(param1:starling.events.Event) : void
      {
         var _loc2_:§_-e2J§ = §_-A6§(§_-s1x§.YAKUZA_DO_MONSTER_THREE_TIMES);
         if(Boolean(_loc2_) && _loc2_.available)
         {
            §_-T27§(_loc2_,§_-31I§.value);
         }
      }
      
      private function get §_-03P§() : int
      {
         var _loc2_:§_-V23§ = null;
         var _loc1_:int = 0;
         for each(_loc2_ in §_-336§)
         {
            _loc1_ += _loc2_.§_-Z2G§();
         }
         return _loc1_;
      }
      
      override public function clear() : void
      {
         super.clear();
         §_-X1j§.§_-12n§.scene.removeEventListener(§_-L3Q§.MASSIVE_DAMAGE,this.§_-A2M§);
      }
   }
}

