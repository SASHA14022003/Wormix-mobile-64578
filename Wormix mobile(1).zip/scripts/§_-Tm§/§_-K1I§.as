package §_-Tm§
{
   import §_-21p§.§_-4w§;
   import §_-51W§.§_-92y§;
   import §_-51W§.§_-G2h§;
   import §_-92a§.*;
   import §_-A1K§.§_-6L§;
   import §_-A1K§.§_-TA§;
   import §_-A1K§.§_-U11§;
   import §_-CF§.§_-p2U§;
   import §_-CF§.§_-x2t§;
   import §_-DJ§.§_-fH§;
   import §_-YF§.§_-q2v§;
   import §_-rM§.§_-61j§;
   import §_-s20§.§_-J2g§;
   import feathers.controls.Button;
   import feathers.core.FeathersControl;
   import feathers.layout.Direction;
   import flash.errors.IllegalOperationError;
   import flash.geom.Point;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import ru.pragmatix.flox.logger.§_-93v§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.server.VerifyPaymentResult;
   import ru.pragmatix.wormix.messages.structures.GenericAwardStructure;
   import ru.pragmatix.wormix.serialization.SerializationUtils;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import starling.display.DisplayObjectContainer;
   import starling.display.Image;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.events.Touch;
   import starling.events.TouchEvent;
   import starling.events.TouchPhase;
   import starling.utils.Pool;
   
   public class §_-K1I§ extends Event
   {
      
      public static const ACTION:String = "ACTION";
      
      public var actions:Array;
      
      public var frame:uint;
      
      public function §_-K1I§(param1:Array, param2:uint = 0, param3:Boolean = false, param4:Boolean = false)
      {
         super(ACTION,param3);
         this.actions = param1;
         this.frame = param2 == 0 ? uint(§_-X1j§.§_-12n§.scene.gameObjectProcessor.§_-O1C§() + 1) : param2;
      }
      
      public static function empty(param1:uint = 0) : §_-K1I§
      {
         return new §_-K1I§([],param1);
      }
      
      override public function toString() : String
      {
         return "ActionEvent: type=" + type + ", bubbles=" + bubbles + ", actions=" + this.actions + ", frame=" + this.frame;
      }
   }
}

