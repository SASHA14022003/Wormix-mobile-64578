package §_-Tm§
{
   import §_-rM§.§_-61j§;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import flash.utils.IDataOutput;
   import ru.pragmatix.wormix.messages.server.RepeatBossBattleAwardResult;
   import ru.pragmatix.wormix.messages.structures.AdvertisingPurchaseStructure;
   import ru.pragmatix.wormix.messages.structures.GenericAwardStructure;
   import ru.pragmatix.wormix.messages.structures.ShopItemStructure;
   import ru.pragmatix.wormix.serialization.SerializationUtils;
   
   public class Action
   {
      
      public var commandId:int;
      
      public var params:Array;
      
      public function Action(param1:int, ... rest)
      {
         var _loc3_:* = undefined;
         this.params = [];
         super();
         this.commandId = param1;
         for each(_loc3_ in rest)
         {
            if(_loc3_ is Array)
            {
               this.params = this.params.concat(_loc3_);
            }
            else
            {
               this.params.push(_loc3_);
            }
         }
      }
   }
}

