package §_-Tm§
{
   import §_-02q§.§_-4s§;
   import §_-03T§.§_-2p§;
   import §_-11L§.Archdemon;
   import §_-11L§.Hacker;
   import §_-11L§.Paladin;
   import §_-11L§.Phantoms;
   import §_-11L§.Thieves;
   import §_-11L§.§_-P25§;
   import §_-12W§.*;
   import §_-12a§.KamikazeBuff;
   import §_-21p§.§_-4w§;
   import §_-2U§.*;
   import §_-51M§.Dragon;
   import §_-5Y§.§_-h2c§;
   import §_-62§.*;
   import §_-63M§.§_-F3f§;
   import §_-73d§.§_-g1J§;
   import §_-82a§.SwitchedRenderTextures;
   import §_-82a§.§_-yb§;
   import §_-91B§.§_-z2l§;
   import §_-931§.§_-02O§;
   import §_-937§.§_-n1b§;
   import §_-A1K§.§_-6L§;
   import §_-A1K§.§_-7u§;
   import §_-A1K§.§_-TA§;
   import §_-A1K§.§_-U11§;
   import §_-B1y§.§_-83E§;
   import §_-B2z§.§_-63i§;
   import §_-C2t§.§_-92W§;
   import §_-CF§.§_-E19§;
   import §_-CF§.§_-p2U§;
   import §_-CF§.§_-x2t§;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-E1I§.§_-b2n§;
   import §_-F2M§.*;
   import §_-F39§.*;
   import §_-G2H§.*;
   import §_-GQ§.§_-31v§;
   import §_-H3§.*;
   import §_-HD§.*;
   import §_-L1H§.§_-C3e§;
   import §_-L1H§.§_-b2K§;
   import §_-L2F§.§_-D2p§;
   import §_-O2L§.§_-X1T§;
   import §_-OJ§.§_-sY§;
   import §_-P2i§.§_-b7§;
   import §_-RE§.*;
   import §_-T1t§.§_-u19§;
   import §_-T2h§.*;
   import §_-TF§.§_-q1j§;
   import §_-Ty§.§_-SC§;
   import §_-U1i§.§_-J1§;
   import §_-Vg§.*;
   import §_-Y1O§.§_-42h§;
   import §_-Y1O§.§_-V23§;
   import §_-Y1b§.§_-81l§;
   import §_-Y1b§.§_-OP§;
   import §_-Y23§.*;
   import §_-YF§.§_-q2v§;
   import §_-Yk§.*;
   import §_-Z1K§.§_-q24§;
   import §_-aM§.*;
   import §_-b1F§.§_-G4§;
   import §_-d26§.§_-c2E§;
   import §_-d26§.§_-d1H§;
   import §_-f1G§.§_-kf§;
   import §_-fo§.§_-A29§;
   import §_-fo§.§_-r5§;
   import §_-hO§.§_-v24§;
   import §_-hv§.*;
   import §_-j1w§.§_-B2i§;
   import §_-j1w§.§_-L1x§;
   import §_-j1w§.§_-lD§;
   import §_-j22§.§_-5g§;
   import §_-k1u§.§_-Oi§;
   import §_-k1u§.§_-Vr§;
   import §_-k2s§.§_-b0§;
   import §_-k2s§.§_-e1U§;
   import §_-k2s§.§_-iI§;
   import §_-k2s§.§_-uU§;
   import §_-l1K§.*;
   import §_-l1g§.§_-L3Q§;
   import §_-m0§.§_-X1F§;
   import §_-m2s§.*;
   import §_-p18§.§_-vd§;
   import §_-qH§.§_-S25§;
   import §_-r1C§.§_-h2B§;
   import §_-rM§.§_-61j§;
   import §_-s1Q§.Artifacts;
   import §_-s1s§.§_-62d§;
   import §_-s20§.§_-J2g§;
   import §_-sQ§.§_-H3D§;
   import §_-u13§.MAC;
   import §_-w2i§.§_-Ia§;
   import §_-w2i§.§_-Zd§;
   import §_-x2Q§.§_-dU§;
   import §_-y1s§.§_-P9§;
   import §_-z1g§.§_-522§;
   import §_-z1g§.§_-y1S§;
   import §_-zI§.§_-X1q§;
   import §_-zI§.§_-sI§;
   import com.distriqt.extension.application.Application;
   import com.distriqt.extension.application.events.DeviceOrientationEvent;
   import com.distriqt.extension.inappbilling.Product;
   import com.distriqt.extension.inappbilling.SubscriptionOffer;
   import com.distriqt.extension.inappbilling.SubscriptionPhase;
   import com.distriqt.extension.inappbilling.events.ApplicationReceiptEvent;
   import com.distriqt.extension.inappbilling.events.ProductEvent;
   import com.greensock.*;
   import com.greensock.core.*;
   import com.greensock.events.LoaderEvent;
   import com.greensock.loading.LoaderMax;
   import com.greensock.loading.LoaderStatus;
   import com.greensock.loading.core.*;
   import com.greensock.plugins.AutoAlphaPlugin;
   import com.greensock.plugins.BevelFilterPlugin;
   import com.greensock.plugins.BezierPlugin;
   import com.greensock.plugins.BezierThroughPlugin;
   import com.greensock.plugins.BlurFilterPlugin;
   import com.greensock.plugins.ColorMatrixFilterPlugin;
   import com.greensock.plugins.ColorTransformPlugin;
   import com.greensock.plugins.DropShadowFilterPlugin;
   import com.greensock.plugins.EndArrayPlugin;
   import com.greensock.plugins.FrameLabelPlugin;
   import com.greensock.plugins.FramePlugin;
   import com.greensock.plugins.GlowFilterPlugin;
   import com.greensock.plugins.HexColorsPlugin;
   import com.greensock.plugins.RemoveTintPlugin;
   import com.greensock.plugins.RoundPropsPlugin;
   import com.greensock.plugins.ShortRotationPlugin;
   import com.greensock.plugins.TintPlugin;
   import com.greensock.plugins.TweenPlugin;
   import com.greensock.plugins.VisiblePlugin;
   import com.greensock.plugins.VolumePlugin;
   import com.hurlant.crypto.*;
   import com.hurlant.crypto.tls.*;
   import com.hurlant.math.*;
   import dragonBones.animation.WorldClock;
   import dragonBones.starling.StarlingFactory;
   import dragonBones.starling.StarlingTextureAtlasData;
   import dragonBones.textures.TextureAtlasData;
   import feathers.controls.Button;
   import feathers.controls.LayoutGroup;
   import feathers.controls.NumericStepper;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import feathers.controls.text.TextInstanceCreator;
   import feathers.core.ITextRenderer;
   import feathers.core.PopUpManager;
   import feathers.data.ArrayCollection;
   import feathers.data.ListCollection;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.RelativePosition;
   import feathers.layout.VerticalAlign;
   import feathers.themes.FontColor;
   import feathers.themes.FontSize;
   import flash.display.BitmapData;
   import flash.display.Stage;
   import flash.errors.IllegalOperationError;
   import flash.events.Event;
   import flash.events.IEventDispatcher;
   import flash.events.StatusEvent;
   import flash.geom.Point;
   import flash.net.LocalConnection;
   import flash.net.Socket;
   import flash.text.TextField;
   import flash.text.TextFormat;
   import flash.text.TextFormatAlign;
   import flash.utils.ByteArray;
   import flash.utils.Dictionary;
   import flash.utils.IDataInput;
   import flash.utils.IDataOutput;
   import flash.utils.getDefinitionByName;
   import flash.utils.getTimer;
   import org.gestouch.core.*;
   import ru.pragmatix.flox.gui.controls.§_-zi§;
   import ru.pragmatix.flox.serialization.§_-616§;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.flox.social.response.SocialResponse;
   import ru.pragmatix.wormix.Scene;
   import ru.pragmatix.wormix.controller.§_-S2Y§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.sets.ControlSets;
   import ru.pragmatix.wormix.fx.EffectType;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.game.§_-eX§;
   import ru.pragmatix.wormix.game.ai.§_-A1l§;
   import ru.pragmatix.wormix.game.ai.§_-de§;
   import ru.pragmatix.wormix.gui.§_-Q2v§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.shop.§_-7D§;
   import ru.pragmatix.wormix.gui.menu.shop.§_-s1V§;
   import ru.pragmatix.wormix.messages.clans.request.edit.IncreaseLevelClanRequest;
   import ru.pragmatix.wormix.messages.clans.request.edit.RenameClanRequest;
   import ru.pragmatix.wormix.messages.clans.response.*;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.client.Disconnect;
   import ru.pragmatix.wormix.messages.server.GetFriendListPageResult;
   import ru.pragmatix.wormix.messages.structures.PumpReactionRateStructure;
   import ru.pragmatix.wormix.messages.structures.TemporalStuffStructure;
   import ru.pragmatix.wormix.messages.structures.UserProfileStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.bonus.§_-x2M§;
   import ru.pragmatix.wormix.model.items.craft.CraftedEquipFamily;
   import ru.pragmatix.wormix.model.rewards.§_-P2q§;
   import ru.pragmatix.wormix.model.user.*;
   import ru.pragmatix.wormix.objects.*;
   import ru.pragmatix.wormix.physics.CollideType;
   import ru.pragmatix.wormix.physics.HitTest;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.pvp.messages.ex.RejectBattleOffer;
   import ru.pragmatix.wormix.pvp.messages.server.PvpRetryCommandRequestServer;
   import ru.pragmatix.wormix.serialization.SerializationUtils;
   import ru.pragmatix.wormix.serialization.server.*;
   import ru.pragmatix.wormix.social.*;
   import ru.pragmatix.wormix.utils.§_-71v§;
   import ru.pragmatix.wormix.utils.§_-72u§;
   import ru.pragmatix.wormix.utils.§_-F2L§;
   import ru.pragmatix.wormix.utils.§_-J2h§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.ammoFactory.AmmosFactory;
   import ru.pragmatix.wormix.weapons.ammo.ammoFactory.IPooledAmmo;
   import ru.pragmatix.wormix.weapons.ammo.type.blocker.HealBlocker;
   import ru.pragmatix.wormix.weapons.interfaces.§_-J3w§;
   import ru.pragmatix.wormix.weapons.interfaces.§_-b29§;
   import ru.pragmatix.wormix.weapons.interfaces.§_-jm§;
   import ru.pragmatix.wormix.weapons.interfaces.§_-o2d§;
   import ru.pragmatix.wormix.weapons.interfaces.§_-y2Q§;
   import starling.animation.Transitions;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Image;
   import starling.display.Quad;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.textures.Texture;
   import starling.textures.TextureAtlas;
   import starling.utils.Align;
   import starling.utils.AssetManager;
   import starling.utils.Color;
   import starling.utils.MathUtil;
   import starling.utils.Pool;
   import starling.utils.ScaleMode;
   import starling.utils.SystemUtil;
   import starlingbuilder.extensions.uicomponents.ContainerButtonWithStates;
   
   use namespace gestouch_internal;
   use namespace bi_internal;
   
   public class §_-W1Y§
   {
      
      public function §_-W1Y§()
      {
         super();
      }
      
      public static function run(param1:Action) : void
      {
         §_-X1j§.§_-12n§.§_-Y0§.§_-N1p§("Run action",param1.commandId.toString(16),param1.params.toString());
         var _loc2_:int = param1.commandId;
         switch(_loc2_)
         {
            case §_-RF§.§_-h2w§:
               §§push(0);
               break;
            case §_-RF§.§_-m2J§:
               §§push(1);
               break;
            case §_-RF§.§_-Ja§:
               §§push(2);
               break;
            case §_-RF§.§_-u21§:
               §§push(3);
               break;
            case §_-RF§.§_-K1K§:
               §§push(4);
               break;
            case §_-RF§.§_-Z24§:
               §§push(5);
               break;
            case §_-RF§.§_-oT§:
               §§push(6);
               break;
            case §_-RF§.§_-XX§:
               §§push(7);
               break;
            case §_-RF§.§_-537§:
               §§push(8);
               break;
            case §_-RF§.§_-hX§:
               §§push(9);
               break;
            case §_-RF§.§_-W3§:
               §§push(10);
               break;
            case §_-RF§.§_-St§:
               §§push(11);
               break;
            case §_-RF§.§_-e2p§:
               §§push(12);
               break;
            case §_-RF§.§_-G1H§:
               §§push(13);
               break;
            case §_-RF§.§_-s17§:
               §§push(14);
               break;
            case §_-RF§.§_-T2D§:
               §§push(15);
               break;
            case §_-RF§.§_-v1k§:
               §§push(16);
               break;
            case §_-RF§.§_-o3§:
               §§push(17);
               break;
            case §_-RF§.§_-o1G§:
               §§push(18);
               break;
            case §_-RF§.§_-gI§:
               §§push(19);
               break;
            case §_-RF§.§_-E3N§:
               §§push(20);
               break;
            case §_-RF§.§_-N2h§:
               §§push(21);
               break;
            case §_-RF§.§_-Ad§:
               §§push(22);
               break;
            case §_-RF§.§_-839§:
               §§push(23);
               break;
            case §_-RF§.§_-xU§:
               §§push(24);
               break;
            case §_-RF§.§_-sw§:
               §§push(25);
               break;
            case §_-RF§.§_-h1F§:
               §§push(26);
               break;
            case §_-RF§.§_-Hl§:
               §§push(27);
               break;
            case §_-RF§.§_-C3J§:
               §§push(28);
               break;
            case §_-RF§.§_-WT§:
               §§push(29);
               break;
            case §_-RF§.§_-m1C§:
               §§push(30);
               break;
            case §_-RF§.§_-l1A§:
               §§push(31);
               break;
            case §_-RF§.§_-y1J§:
               §§push(32);
               break;
            case §_-RF§.§_-f12§:
               §§push(33);
               break;
            case §_-RF§.§_-P20§:
               §§push(34);
               break;
            case §_-RF§.§_-p1Q§:
               §§push(35);
               break;
            case §_-RF§.§_-lG§:
               §§push(36);
               break;
            case §_-RF§.§_-L1Q§:
               §§push(37);
               break;
            case §_-RF§.§_-p2B§:
               §§push(38);
               break;
            default:
               switch(_loc2_)
               {
                  case §_-RF§.§_-U23§:
                     §§push(39);
                     break;
                  case §_-RF§.§_-Y2b§:
                     §§push(40);
                     break;
                  default:
                     §§push(41);
               }
         }
         switch(§§pop())
         {
            case 0:
               unitLeft(param1.params[0]);
               break;
            case 1:
               unitRight(param1.params[0]);
               break;
            case 2:
               unitStop();
               break;
            case 3:
               unitJumpForward(param1.params[0]);
               break;
            case 4:
               unitJumpBack(param1.params[0]);
               break;
            case 5:
               unitJumpShoot(param1.params[0]);
               break;
            case 6:
               §_-P1Q§(param1.params[0],param1.params[1]);
               break;
            case 7:
               chUp(param1.params[0]);
               break;
            case 8:
               chDown(param1.params[0]);
               break;
            case 9:
               chLeft();
               break;
            case 10:
               chRight();
               break;
            case 11:
               chCharge(param1.params[0]);
               break;
            case 12:
               break;
            case 13:
               chRelease();
               break;
            case 14:
               chPoint(param1.params[0],param1.params[1]);
               break;
            case 15:
               chCounter(param1.params[0]);
               break;
            case 16:
               setAngle(param1.params[0]);
               break;
            case 17:
               §_-gt§(param1.params[0],param1.params[1],param1.params[2],param1.params[3]);
               break;
            case 18:
               wpnUpPressed();
               break;
            case 19:
               wpnUpReleased();
               break;
            case 20:
               wpnDownPressed();
               break;
            case 21:
               wpnDownReleased();
               break;
            case 22:
               wpnLeftPressed();
               break;
            case 23:
               wpnLeftReleased();
               break;
            case 24:
               wpnRightPressed();
               break;
            case 25:
               wpnRightReleased();
               break;
            case 26:
               wpnCharge();
               break;
            case 27:
               §_-43L§(param1.params[0],param1.params[1]);
               break;
            case 28:
               uiWeaponSelectCancel();
               break;
            case 29:
               §_-e0§(param1.params[0]);
               break;
            case 30:
               §_-92N§(param1.params[0],param1.params[1]);
               break;
            case 31:
               break;
            case 32:
               §_-X1j§.§_-12n§.gameMaster.§_-f13§();
               break;
            case 33:
               flightLeftPressed();
               break;
            case 34:
               flightLeftRelease();
               break;
            case 35:
               flightRightPressed();
               break;
            case 36:
               flightRightRelease();
               break;
            case 37:
               flightDownRelease();
               break;
            case 38:
               flightDownPressed();
               break;
            case 39:
               flightUpPressed();
               break;
            case 40:
               flightStop();
         }
      }
      
      private static function unitLeft(param1:Boolean = false) : void
      {
         var _loc2_:§_-01J§ = activeUnit();
         if(_loc2_)
         {
            §_-X1j§.§_-12n§.§_-Y0§.§_-N1p§("Execute action","unitLeft");
            if(param1 && _loc2_.direction == §_-8K§.RIGHT)
            {
               _loc2_.§_-u2K§(param1);
               _loc2_.§_-01D§();
            }
            else
            {
               _loc2_.§_-01D§();
               _loc2_.§_-u2K§(param1);
               if(!_loc2_.attributes.jump.§_-C9§())
               {
                  §_-X1j§.§_-12n§.scene.gameInterface.§_-WM§(true);
               }
            }
         }
      }
      
      private static function unitRight(param1:Boolean = false) : void
      {
         var _loc2_:§_-01J§ = activeUnit();
         if(_loc2_)
         {
            §_-X1j§.§_-12n§.§_-Y0§.§_-N1p§("Execute action","unitRight");
            if(param1 && _loc2_.direction == §_-8K§.LEFT)
            {
               _loc2_.§_-o1k§(param1);
               _loc2_.§_-01D§();
            }
            else
            {
               _loc2_.§_-01D§();
               _loc2_.§_-o1k§(param1);
               if(!_loc2_.attributes.jump.§_-C9§())
               {
                  §_-X1j§.§_-12n§.scene.gameInterface.§_-WM§(false);
               }
            }
         }
      }
      
      private static function unitStop() : void
      {
         var _loc1_:§_-01J§ = activeUnit();
         if(Boolean(_loc1_) && _loc1_.crawling != 0)
         {
            §_-X1j§.§_-12n§.§_-Y0§.§_-N1p§("Execute action","unitStop");
            _loc1_.§_-01D§();
         }
      }
      
      private static function unitJumpForward(param1:int) : void
      {
         var _loc5_:Boolean = false;
         var _loc2_:§_-01J§ = activeUnit();
         var _loc3_:Weapon = §_-U2Q§();
         var _loc4_:Boolean = _loc3_ ? _loc3_.§_-U2Y§() : true;
         if(Boolean(_loc2_) && _loc4_)
         {
            §_-X1j§.§_-12n§.§_-Y0§.§_-N1p§("Execute action","unitJumpForward");
            _loc5_ = param1 != 0;
            _loc2_.attributes.jump.§_-T1k§(_loc5_);
         }
      }
      
      private static function unitJumpBack(param1:int) : void
      {
         var _loc5_:Boolean = false;
         var _loc2_:§_-01J§ = activeUnit();
         var _loc3_:Weapon = §_-U2Q§();
         var _loc4_:Boolean = _loc3_ ? _loc3_.§_-U2Y§() : true;
         if(Boolean(_loc2_) && _loc4_)
         {
            §_-X1j§.§_-12n§.§_-Y0§.§_-N1p§("Execute action","unitJumpBack");
            _loc5_ = param1 != 0;
            _loc2_.attributes.jump.§_-iU§(_loc5_);
         }
      }
      
      private static function unitJumpShoot(param1:int) : void
      {
         var _loc3_:Boolean = false;
         var _loc2_:Weapon = §_-U2Q§();
         if(Boolean(_loc2_) && _loc2_ is §_-b29§)
         {
            §_-X1j§.§_-12n§.§_-Y0§.§_-N1p§("Execute action","unitJumpShoot");
            _loc3_ = param1 > 0;
            §_-b29§(_loc2_).jumpShoot(_loc3_);
         }
      }
      
      private static function §_-P1Q§(param1:int, param2:§_-01J§) : void
      {
         var _loc3_:§_-F3o§ = null;
         if(!param2)
         {
            param2 = activeUnit();
         }
         if(!§_-X1j§.§_-12n§ || !§_-X1j§.§_-12n§.gameMaster)
         {
            return;
         }
         if(Boolean(param2 && !param2.disposed) && Boolean(param2.stable) && !§_-X1j§.§_-12n§.gameMaster.§_-U2O§())
         {
            _loc3_ = §_-X1j§.§_-12n§.scene.gameObjectProcessor.cache.§_-L1c§(param1);
            if(_loc3_ != null && _loc3_ is §_-i14§)
            {
               param2.§_-K1A§(§_-i14§(_loc3_));
            }
         }
      }
      
      private static function chUp(param1:Boolean) : void
      {
         var _loc2_:Weapon = §_-U2Q§();
         var _loc3_:§_-m2§ = §_-i2m§();
         if(Boolean(_loc3_) && _loc2_.isActive())
         {
            §_-X1j§.§_-12n§.§_-Y0§.§_-N1p§("Execute action","chUp");
            _loc3_.§_-Ka§(param1);
         }
      }
      
      private static function chDown(param1:Boolean) : void
      {
         var _loc2_:Weapon = §_-U2Q§();
         var _loc3_:§_-m2§ = §_-i2m§();
         if(Boolean(_loc3_) && _loc2_.isActive())
         {
            §_-X1j§.§_-12n§.§_-Y0§.§_-N1p§("Execute action","chDown");
            _loc3_.§_-519§(param1);
         }
      }
      
      private static function chLeft() : void
      {
         var _loc1_:Weapon = §_-U2Q§();
         var _loc2_:§_-m2§ = §_-i2m§();
         if(Boolean(_loc2_) && _loc1_.isActive())
         {
            §_-X1j§.§_-12n§.§_-Y0§.§_-N1p§("Execute action","chLeft");
            _loc2_.§_-az§();
         }
      }
      
      private static function chRight() : void
      {
         var _loc1_:Weapon = §_-U2Q§();
         var _loc2_:§_-m2§ = §_-i2m§();
         if(Boolean(_loc2_) && _loc1_.isActive())
         {
            §_-X1j§.§_-12n§.§_-Y0§.§_-N1p§("Execute action","chRight");
            _loc2_.§_-51a§();
         }
      }
      
      private static function chCharge(param1:int) : void
      {
         var _loc4_:Boolean = false;
         unitStop();
         var _loc2_:Weapon = §_-U2Q§();
         var _loc3_:§_-m2§ = §_-i2m§();
         if(Boolean(_loc3_) && _loc2_.isActive())
         {
            §_-X1j§.§_-12n§.§_-Y0§.§_-N1p§("Execute action","chCharge");
            _loc4_ = param1 > 0;
            _loc3_.charge(_loc4_);
         }
      }
      
      private static function chRelease() : void
      {
         var _loc1_:Weapon = §_-U2Q§();
         var _loc2_:§_-m2§ = §_-i2m§();
         if(Boolean(_loc2_) && _loc1_.isActive())
         {
            §_-X1j§.§_-12n§.§_-Y0§.§_-N1p§("Execute action","chRelease");
            _loc2_.§_-53x§();
         }
      }
      
      private static function chPoint(param1:int, param2:int) : void
      {
         var _loc3_:Weapon = §_-U2Q§();
         var _loc4_:§_-m2§ = §_-i2m§();
         if((Boolean(_loc4_)) && _loc3_.isActive())
         {
            §_-X1j§.§_-12n§.§_-Y0§.§_-N1p§("Execute action","chPoint");
            _loc4_.point(param1,param2);
         }
      }
      
      private static function §_-gt§(param1:int, param2:int, param3:int, param4:int) : void
      {
         var _loc5_:Weapon = §_-U2Q§();
         var _loc6_:§_-m2§ = §_-i2m§();
         if((Boolean(_loc6_)) && _loc5_.isActive())
         {
            §_-X1j§.§_-12n§.§_-Y0§.§_-N1p§("Execute action","chPointAndAngle");
            _loc6_.§_-B19§(param1,param2,param3,param4);
         }
      }
      
      private static function chCounter(param1:int) : void
      {
         var _loc2_:Weapon = §_-U2Q§();
         var _loc3_:§_-m2§ = §_-i2m§();
         if(Boolean(_loc3_) && _loc2_.isActive())
         {
            §_-X1j§.§_-12n§.§_-Y0§.§_-N1p§("Execute action","chCounter");
            _loc3_.counter(param1);
         }
      }
      
      private static function chSet(param1:int) : void
      {
         var _loc2_:Weapon = §_-U2Q§();
         var _loc3_:§_-m2§ = §_-i2m§();
         if(Boolean(_loc3_) && _loc2_.isActive())
         {
            §_-X1j§.§_-12n§.§_-Y0§.§_-N1p§("Execute action","chSet");
            _loc3_.set(param1);
         }
      }
      
      private static function setAngle(param1:Number) : void
      {
         var _loc4_:§_-W2f§ = null;
         var _loc5_:§_-J3w§ = null;
         var _loc2_:Weapon = §_-U2Q§();
         var _loc3_:§_-m2§ = §_-i2m§();
         if(Boolean(_loc3_) && _loc2_.isActive())
         {
            §_-X1j§.§_-12n§.§_-Y0§.§_-N1p§("Execute action","setAngle");
            _loc4_ = _loc3_ as §_-W2f§;
            if(_loc4_)
            {
               _loc4_.setAngle(param1);
            }
            _loc5_ = _loc2_ as §_-J3w§;
            if(_loc5_)
            {
               _loc5_.setAngle(param1);
            }
         }
      }
      
      private static function wpnUpPressed() : void
      {
         var _loc1_:Weapon = §_-U2Q§();
         if(Boolean(_loc1_) && _loc1_ is §_-o2d§)
         {
            §_-X1j§.§_-12n§.§_-Y0§.§_-N1p§("Execute action","wpnUpPressed");
            §_-o2d§(_loc1_).weaponUpPressed();
         }
      }
      
      private static function wpnUpReleased() : void
      {
         var _loc1_:Weapon = §_-U2Q§();
         if(Boolean(_loc1_) && _loc1_ is §_-o2d§)
         {
            §_-X1j§.§_-12n§.§_-Y0§.§_-N1p§("Execute action","wpnUpReleased");
            §_-o2d§(_loc1_).weaponUpReleased();
         }
      }
      
      private static function wpnDownPressed() : void
      {
         var _loc1_:Weapon = §_-U2Q§();
         if(Boolean(_loc1_) && _loc1_ is §_-o2d§)
         {
            §_-X1j§.§_-12n§.§_-Y0§.§_-N1p§("Execute action","wpnDownPressed");
            §_-o2d§(_loc1_).weaponDownPressed();
         }
      }
      
      private static function wpnDownReleased() : void
      {
         var _loc1_:Weapon = §_-U2Q§();
         if(Boolean(_loc1_) && _loc1_ is §_-o2d§)
         {
            §_-X1j§.§_-12n§.§_-Y0§.§_-N1p§("Execute action","wpnDownReleased");
            §_-o2d§(_loc1_).weaponDownReleased();
         }
      }
      
      private static function wpnLeftPressed() : void
      {
         var _loc1_:Weapon = §_-U2Q§();
         if(Boolean(_loc1_) && _loc1_ is §_-jm§)
         {
            §_-X1j§.§_-12n§.§_-Y0§.§_-N1p§("Execute action","wpnLeftPressed");
            §_-jm§(_loc1_).weaponLeftPressed();
         }
      }
      
      private static function wpnLeftReleased() : void
      {
         var _loc1_:Weapon = §_-U2Q§();
         if(Boolean(_loc1_) && _loc1_ is §_-jm§)
         {
            §_-X1j§.§_-12n§.§_-Y0§.§_-N1p§("Execute action","wpnLeftReleased");
            §_-jm§(_loc1_).weaponLeftReleased();
         }
         §_-X1j§.§_-12n§.scene.gameInterface.§_-WM§(true);
      }
      
      private static function wpnRightPressed() : void
      {
         var _loc1_:Weapon = §_-U2Q§();
         if(Boolean(_loc1_) && _loc1_ is §_-jm§)
         {
            §_-X1j§.§_-12n§.§_-Y0§.§_-N1p§("Execute action","wpnRightPressed");
            §_-jm§(_loc1_).weaponRightPressed();
         }
      }
      
      private static function wpnRightReleased() : void
      {
         var _loc1_:Weapon = §_-U2Q§();
         if(Boolean(_loc1_) && _loc1_ is §_-jm§)
         {
            §_-X1j§.§_-12n§.§_-Y0§.§_-N1p§("Execute action","wpnRightReleased");
            §_-jm§(_loc1_).weaponRightReleased();
         }
         §_-X1j§.§_-12n§.scene.gameInterface.§_-WM§(false);
      }
      
      private static function wpnCharge() : void
      {
         var _loc1_:Weapon = §_-U2Q§();
         if(Boolean(_loc1_) && _loc1_ is §_-y2Q§)
         {
            §_-X1j§.§_-12n§.§_-Y0§.§_-N1p§("Execute action","wpnCharge");
            §_-y2Q§(_loc1_).weaponCharge();
         }
      }
      
      private static function §_-e0§(param1:uint) : void
      {
         var _loc2_:§_-01J§ = activeUnit();
         _loc2_.§_-c1F§();
      }
      
      private static function flightLeftPressed() : void
      {
         var _loc1_:§_-01J§ = activeUnit();
         if(Boolean(_loc1_) && _loc1_ is Dragon)
         {
            §_-X1j§.§_-12n§.§_-Y0§.§_-N1p§("Execute action","flightLeftPressed");
            Dragon(_loc1_).flyLeftPressed();
         }
      }
      
      private static function flightLeftRelease() : void
      {
         var _loc1_:§_-01J§ = activeUnit();
         if(Boolean(_loc1_) && _loc1_ is Dragon)
         {
            §_-X1j§.§_-12n§.§_-Y0§.§_-N1p§("Execute action","flightLeftRelease");
            Dragon(_loc1_).flyLeftReleased();
         }
      }
      
      private static function flightRightPressed() : void
      {
         var _loc1_:§_-01J§ = activeUnit();
         if(Boolean(_loc1_) && _loc1_ is Dragon)
         {
            §_-X1j§.§_-12n§.§_-Y0§.§_-N1p§("Execute action","flightRightPressed");
            Dragon(_loc1_).flyRightPressed();
         }
      }
      
      private static function flightRightRelease() : void
      {
         var _loc1_:§_-01J§ = activeUnit();
         if(Boolean(_loc1_) && _loc1_ is Dragon)
         {
            §_-X1j§.§_-12n§.§_-Y0§.§_-N1p§("Execute action","flightRightRelease");
            Dragon(_loc1_).flyRightReleased();
         }
      }
      
      private static function flightStop() : void
      {
         var _loc1_:§_-01J§ = activeUnit();
         if(Boolean(_loc1_) && _loc1_ is Dragon)
         {
            §_-X1j§.§_-12n§.§_-Y0§.§_-N1p§("Execute action","flightStop");
            Dragon(_loc1_).jumpPressed();
         }
      }
      
      private static function flightDownRelease() : void
      {
         var _loc1_:§_-01J§ = activeUnit();
         if(Boolean(_loc1_) && _loc1_ is Dragon)
         {
            §_-X1j§.§_-12n§.§_-Y0§.§_-N1p§("Execute action","flightDownRelease");
            Dragon(_loc1_).flyDownReleased();
         }
      }
      
      private static function flightDownPressed() : void
      {
         var _loc1_:§_-01J§ = activeUnit();
         if(Boolean(_loc1_) && _loc1_ is Dragon)
         {
            §_-X1j§.§_-12n§.§_-Y0§.§_-N1p§("Execute action","flightDownPressed");
            Dragon(_loc1_).flyDownPressed();
         }
      }
      
      private static function flightUpPressed() : void
      {
         var _loc1_:§_-01J§ = activeUnit();
         if(Boolean(_loc1_) && _loc1_ is Dragon)
         {
            §_-X1j§.§_-12n§.§_-Y0§.§_-N1p§("Execute action","flightUpPressed");
            Dragon(_loc1_).flyUpPressed();
         }
      }
      
      private static function §_-43L§(param1:uint, param2:uint) : void
      {
         var _loc3_:§_-eX§ = §_-X1j§.§_-12n§.gameMaster;
         var _loc4_:§_-01J§ = activeUnit();
         if((Boolean(_loc4_)) && !_loc3_.§_-v1V§())
         {
            §_-X1j§.§_-12n§.gameMaster.§_-J3U§();
            §_-X1j§.§_-12n§.gameMaster.§_-hx§(param1);
            _loc4_.§_-W1u§(param1);
         }
      }
      
      private static function uiWeaponSelectCancel() : void
      {
         var _loc1_:§_-01J§ = activeUnit();
         if(_loc1_)
         {
            §_-X1j§.§_-12n§.§_-Y0§.§_-N1p§("Execute action","uiWeaponSelectCancel");
            §_-X1j§.§_-12n§.gameMaster.§_-J3U§();
            _loc1_.§_-U1S§();
         }
      }
      
      private static function §_-92N§(param1:int, param2:uint) : void
      {
         var _loc4_:§_-V23§ = null;
         var _loc5_:§_-Oi§ = null;
         var _loc3_:§_-eX§ = §_-X1j§.§_-12n§.gameMaster;
         for each(_loc4_ in _loc3_.§_-12G§())
         {
            if(_loc4_.getNumber() == param1)
            {
               _loc5_ = _loc4_.§_-B2M§().§_-V2J§().§_-d0§(param2);
               if((Boolean(_loc5_)) && _loc5_.getId() == param2)
               {
                  if(!_loc3_.§_-Rk§())
                  {
                     if(Boolean(_loc3_.activeUnit) && Boolean(_loc3_.activeUnit.weapon))
                     {
                        _loc3_.activeUnit.weapon.shootWithParams(new §_-b2K§());
                        _loc3_.activeUnit.weapon.detach();
                     }
                     ControlSets.UNIT_CONTROL_SET.activate();
                     if(§_-X1j§.§_-12n§.gameMaster.§_-E3b§())
                     {
                        §_-X1j§.§_-12n§.gameMaster.§_-h2Z§(true);
                     }
                  }
                  return;
               }
            }
         }
      }
      
      private static function activeUnit() : §_-01J§
      {
         return Boolean(§_-X1j§.§_-12n§) && Boolean(§_-X1j§.§_-12n§.gameMaster) ? §_-X1j§.§_-12n§.gameMaster.activeUnit : null;
      }
      
      private static function §_-U2Q§() : Weapon
      {
         var _loc1_:§_-01J§ = activeUnit();
         return _loc1_ ? Weapon(_loc1_.weapon) : null;
      }
      
      private static function §_-i2m§() : §_-m2§
      {
         var _loc1_:Weapon = §_-U2Q§();
         return _loc1_ ? _loc1_.§_-G3H§() : null;
      }
   }
}

