package §_-lh§
{
   import §_-02q§.§_-4s§;
   import §_-31N§.§_-42G§;
   import §_-51W§.§_-SN§;
   import §_-5P§.*;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-L1r§;
   import §_-62§.§_-O2H§;
   import §_-62§.§_-W1r§;
   import §_-62§.§_-gr§;
   import §_-63U§.§_-21K§;
   import §_-82l§.§_-1I§;
   import §_-B2z§.§_-63i§;
   import §_-C3f§.§_-1Y§;
   import §_-C3f§.§_-Z1Y§;
   import §_-CF§.§_-E19§;
   import §_-DJ§.§_-Es§;
   import §_-DJ§.§_-fH§;
   import §_-F2Q§.GestureEvent;
   import §_-H3§.*;
   import §_-J3b§.*;
   import §_-Ly§.§_-81L§;
   import §_-Nq§.§_-G1J§;
   import §_-Nq§.§_-Ow§;
   import §_-Nq§.§_-s1O§;
   import §_-Nq§.§_-uh§;
   import §_-Tm§.§_-K1I§;
   import §_-YF§.§_-q2v§;
   import §_-jF§.§_-PY§;
   import §_-k2s§.§_-8c§;
   import §_-k2s§.§_-C3A§;
   import §_-k2s§.§_-fG§;
   import §_-m2s§.§_-R11§;
   import §_-p18§.§_-h1b§;
   import §_-r1C§.§_-h2B§;
   import §_-u2J§.§_-T1K§;
   import §_-y1s§.§_-P9§;
   import §_-z1g§.§_-4l§;
   import §_-zI§.§_-F3q§;
   import com.greensock.events.LoaderEvent;
   import com.greensock.loading.*;
   import feathers.controls.ScrollPolicy;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import feathers.data.ArrayCollection;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.HorizontalLayout;
   import feathers.layout.TiledRowsLayout;
   import feathers.layout.VerticalAlign;
   import feathers.layout.VerticalLayout;
   import flash.display.DisplayObject;
   import flash.display.DisplayObjectContainer;
   import flash.events.Event;
   import flash.events.NativeWindowDisplayStateEvent;
   import flash.text.TextField;
   import ru.pragmatix.flox.gui.controls.§_-zi§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.gui.§_-F2n§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.server.EnterAccount;
   import ru.pragmatix.wormix.messages.structures.LoginAwardStructure;
   import ru.pragmatix.wormix.model.items.craft.§_-13q§;
   import ru.pragmatix.wormix.model.items.craft.§_-6S§;
   import ru.pragmatix.wormix.model.items.craft.§_-IE§;
   import ru.pragmatix.wormix.model.items.craft.§_-Y2u§;
   import ru.pragmatix.wormix.model.rewards.§_-qU§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.platform.§_-WK§;
   import ru.pragmatix.wormix.pvp.messages.client.PvpActionEx;
   import ru.pragmatix.wormix.scene.SortingLayer;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.StringUtil;
   import ru.pragmatix.wormix.utils.§_-2t§;
   import ru.pragmatix.wormix.utils.§_-Cq§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.utils.§_-c1S§;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   import starling.utils.SystemUtil;
   
   public class §_-72s§ extends §_-PY§
   {
      
      private static const §_-F1F§:String = "select";
      
      protected var display:starling.display.DisplayObjectContainer;
      
      protected var itemIcon:§_-P9§;
      
      protected var selection:starling.display.DisplayObject;
      
      protected var _state:§_-z2A§;
      
      public function §_-72s§()
      {
         super();
         this.display = §_-YQ§.§_-qM§(§_-q2v§.§_-C4§,§_-q2v§.§_-A2T§);
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         _isToggle = false;
         useHandCursor = true;
         this.itemIcon = new §_-P9§(this.display);
         this.selection = this.display.getChildByName(§_-F1F§);
         this.selection.visible = isSelected;
         addChild(this.display);
         width = this.display.width;
         height = this.display.height;
      }
      
      override protected function commitData() : void
      {
         if(data is §_-13q§)
         {
            this.itemIcon.§_-o1w§(this.§_-n19§((data as §_-13q§).root));
         }
         else if(data is §_-1Y§)
         {
            this.itemIcon.§_-o1w§((data as §_-1Y§).getState() == §_-Z1Y§.§_-Vi§);
         }
      }
      
      private function §_-n19§(param1:§_-6S§) : Boolean
      {
         var _loc2_:Boolean = param1.weapon.getState() == §_-Z1Y§.§_-Vi§;
         var _loc3_:Vector.<§_-6S§> = param1.next;
         var _loc4_:* = int(_loc3_.length);
         while(_loc4_--)
         {
            _loc2_ ||= this.§_-n19§(_loc3_[_loc4_]);
         }
         return _loc2_;
      }
      
      override public function set isSelected(param1:Boolean) : void
      {
         if(Boolean(this.itemIcon) && _isSelected != param1)
         {
            if(this.selection)
            {
               this.selection.visible = param1;
            }
            if(param1 && this._state == §_-z2A§.AVAILABLE)
            {
               this._state = §_-z2A§.§_-t2N§;
            }
            else if(!param1 && this._state == §_-z2A§.§_-t2N§)
            {
               this._state = §_-z2A§.AVAILABLE;
            }
            this.itemIcon.setState(this._state);
            if(param1)
            {
               §_-h2B§.play(§_-81L§.§_-jn§);
            }
         }
         super.isSelected = param1;
      }
      
      override public function dispose() : void
      {
         if(this.itemIcon)
         {
            this.itemIcon.dispose();
            this.itemIcon = null;
         }
         this.selection = §_-c1S§.dispose(this.selection);
         this.display = §_-c1S§.dispose(this.display);
         super.dispose();
      }
   }
}

