package §_-lh§
{
   import §_-RE§.§_-D3v§;
   import flash.utils.ByteArray;
   import org.swiftsuspenders.*;
   import ru.pragmatix.wormix.controller.§_-S2Y§;
   import ru.pragmatix.wormix.messages.clans.ClanMessages;
   
   public class §_-z2A§
   {
      
      public static const §_-v1N§:§_-z2A§ = new §_-z2A§("locked");
      
      public static const §_-t2N§:§_-z2A§ = new §_-z2A§("taken");
      
      public static const NOT_AVAILABLE:§_-z2A§ = new §_-z2A§("unavailable");
      
      public static const AVAILABLE:§_-z2A§ = new §_-z2A§("available");
      
      public var name:String;
      
      public function §_-z2A§(param1:String)
      {
         super();
         this.name = param1;
      }
   }
}

