package §_-79§
{
   import §_-62§.§_-G1p§;
   import §_-J31§.§_-R1h§;
   import §_-Y1O§.*;
   import §_-Y23§.*;
   import §_-Z1w§.§_-s1x§;
   import §_-b1F§.§_-v2Q§;
   import §_-j1w§.§_-L1x§;
   import §_-l1g§.§_-L3Q§;
   import com.hurlant.math.BigInteger;
   import com.hurlant.math.bi_internal;
   import feathers.core.ITextRenderer;
   import flash.text.TextFormat;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.utils.§_-R2g§;
   import starling.events.Event;
   
   use namespace bi_internal;
   
   public class §_-9k§ extends §_-11E§
   {
      
      public function §_-9k§()
      {
         super();
         attackSounds = [§_-d27§.§_-w2a§["worm"].speak_v_ataku,§_-d27§.§_-w2a§["worm"].speak_lojis,§_-d27§.§_-w2a§["worm"].speak_ogon,§_-d27§.§_-w2a§["worm"].speak_vboy,§_-d27§.§_-w2a§["worm"].speak_vottebe,§_-d27§.§_-w2a§["worm"].speak_smeh2];
         §_-Sb§ = [§_-d27§.§_-w2a§["worm"].damage1,§_-d27§.§_-w2a§["worm"].damage2,§_-d27§.§_-w2a§["worm"].damage3,§_-d27§.§_-w2a§["worm"].damage4];
         §_-72k§ = [§_-d27§.§_-w2a§["worm"].speak_prijok1,§_-d27§.§_-w2a§["worm"].speak_prijok2];
         §_-D1d§ = [§_-d27§.§_-w2a§["worm"].speak_promazal,§_-d27§.§_-w2a§["worm"].speak_nepopal];
         §_-F2a§ = [§_-d27§.§_-w2a§["worm"].speak_smeh1,§_-d27§.§_-w2a§["worm"].speak_smeh2];
         §_-z2K§ = [§_-d27§.§_-w2a§["worm"].speak_nukanuka,§_-d27§.§_-w2a§["worm"].speak_pogodi,§_-d27§.§_-w2a§["worm"].speak_cel_obnarujena,§_-d27§.§_-w2a§["worm"].speak_vpered,§_-d27§.§_-w2a§["worm"].speak_yessir,§_-d27§.§_-w2a§["worm"].speak_komandir,§_-d27§.§_-w2a§["worm"].speak_jdu_prikaza];
         §_-12w§ = [§_-d27§.§_-w2a§["worm"].speak_cheknutiy,§_-d27§.§_-w2a§["worm"].speak_hoho];
         §_-G1d§ = [§_-d27§.§_-w2a§["worm"].speak_nashol];
         §_-Ng§ = [§_-d27§.§_-w2a§["worm"].speak_smotri,§_-d27§.§_-w2a§["worm"].speak_predatel];
         §_-51c§ = [§_-d27§.§_-w2a§["worm"].speak_vottebe,§_-d27§.§_-w2a§["worm"].speak_mest];
         §_-11F§ = [§_-d27§.§_-w2a§["worm"].speak_granata];
         §_-Z1q§ = [§_-d27§.§_-w2a§["worm"].speak_pervayakrov];
         §_-726§ = §_-d27§.§_-w2a§["worm"].win;
      }
   }
}

