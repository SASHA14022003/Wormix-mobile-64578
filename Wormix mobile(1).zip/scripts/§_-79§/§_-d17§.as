package §_-79§
{
   import §_-D3A§.§_-TZ§;
   import §_-E1I§.§_-b2n§;
   import §_-H2g§.§_-di§;
   import §_-j1y§.§_-i1b§;
   import §_-l1g§.§_-L3Q§;
   import dragonBones.animation.WorldClock;
   import ru.pragmatix.flox.social.response.photo.PhotoSaveResponse;
   import ru.pragmatix.wormix.Scene;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.messages.clans.response.*;
   import ru.pragmatix.wormix.messages.clans.structures.ClanMemberTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.utils.*;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.utils.ScaleMode;
   
   public class §_-d17§ extends §_-11E§
   {
      
      public function §_-d17§()
      {
         super();
         attackSounds = [§_-d27§.§_-Fy§["worm"].speak_v_ataku,§_-d27§.§_-Fy§["worm"].speak_lojis,§_-d27§.§_-Fy§["worm"].speak_ogon,§_-d27§.§_-Fy§["worm"].speak_vboy,§_-d27§.§_-Fy§["worm"].speak_vottebe,§_-d27§.§_-Fy§["worm"].speak_smeh2];
         §_-Sb§ = [§_-d27§.§_-Fy§["worm"].damage1,§_-d27§.§_-Fy§["worm"].damage2,§_-d27§.§_-Fy§["worm"].damage3,§_-d27§.§_-Fy§["worm"].damage4];
         §_-72k§ = [§_-d27§.§_-Fy§["worm"].speak_prijok1,§_-d27§.§_-Fy§["worm"].speak_prijok2];
         §_-D1d§ = [§_-d27§.§_-Fy§["worm"].speak_promazal,§_-d27§.§_-Fy§["worm"].speak_nepopal];
         §_-F2a§ = [§_-d27§.§_-Fy§["worm"].speak_smeh1,§_-d27§.§_-Fy§["worm"].speak_smeh2];
         §_-z2K§ = [§_-d27§.§_-Fy§["worm"].speak_nukanuka,§_-d27§.§_-Fy§["worm"].speak_pogodi,§_-d27§.§_-Fy§["worm"].speak_cel_obnarujena,§_-d27§.§_-Fy§["worm"].speak_vpered,§_-d27§.§_-Fy§["worm"].speak_yessir,§_-d27§.§_-Fy§["worm"].speak_komandir,§_-d27§.§_-Fy§["worm"].speak_jdu_prikaza];
         §_-12w§ = [§_-d27§.§_-Fy§["worm"].speak_cheknutiy,§_-d27§.§_-Fy§["worm"].speak_hoho];
         §_-G1d§ = [§_-d27§.§_-Fy§["worm"].speak_nashol];
         §_-Ng§ = [§_-d27§.§_-Fy§["worm"].speak_smotri,§_-d27§.§_-Fy§["worm"].speak_predatel];
         §_-51c§ = [§_-d27§.§_-Fy§["worm"].speak_vottebe,§_-d27§.§_-Fy§["worm"].speak_mest];
         §_-11F§ = [§_-d27§.§_-Fy§["worm"].speak_granata];
         §_-Z1q§ = [§_-d27§.§_-Fy§["worm"].speak_pervayakrov];
         §_-726§ = §_-d27§.§_-Fy§["worm"].win;
      }
   }
}

