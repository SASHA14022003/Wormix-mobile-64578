package §_-79§
{
   import §_-12W§.§_-X2w§;
   import §_-12W§.§_-l23§;
   import §_-12a§.§_-6p§;
   import §_-21p§.§_-4w§;
   import §_-43V§.*;
   import §_-52L§.*;
   import §_-62§.§_-O2H§;
   import §_-62§.§_-o6§;
   import §_-9§.§_-52A§;
   import §_-91B§.§_-z2l§;
   import §_-A1K§.§_-6L§;
   import §_-A1K§.§_-TA§;
   import §_-A1K§.§_-U11§;
   import §_-Af§.§_-k1I§;
   import §_-B1y§.§_-F1P§;
   import §_-B1y§.§_-bs§;
   import §_-B1y§.§_-ts§;
   import §_-DJ§.§_-fH§;
   import §_-H16§.*;
   import §_-J31§.§_-R1h§;
   import §_-P1z§.*;
   import §_-Ta§.BuyVipDialog;
   import §_-U1i§.§_-J1§;
   import §_-U1i§.§_-O2i§;
   import §_-U1i§.§_-hK§;
   import §_-Y1O§.§_-V23§;
   import §_-Y1O§.§_-y1o§;
   import §_-Y1b§.§_-81l§;
   import §_-Z1K§.§_-q24§;
   import §_-aM§.*;
   import §_-b1F§.§_-v2Q§;
   import §_-e2r§.*;
   import §_-f1G§.§_-kf§;
   import §_-g2r§.§_-03A§;
   import §_-j1w§.§_-B2i§;
   import §_-j1w§.§_-L1x§;
   import §_-qH§.§_-S25§;
   import §_-r1C§.§_-h2B§;
   import §_-r1C§.§_-t1R§;
   import §_-rM§.§_-61j§;
   import §_-s20§.§_-J2g§;
   import com.greensock.*;
   import com.greensock.core.*;
   import com.greensock.events.TweenEvent;
   import com.hurlant.math.BigInteger;
   import com.hurlant.math.bi_internal;
   import dragonBones.Slot;
   import feathers.controls.NumericStepper;
   import feathers.controls.ProgressBar;
   import feathers.core.ITextRenderer;
   import flash.errors.IllegalOperationError;
   import flash.events.*;
   import flash.geom.Point;
   import flash.utils.ByteArray;
   import flash.utils.Dictionary;
   import flash.utils.IDataInput;
   import flash.utils.IDataOutput;
   import org.gestouch.core.*;
   import org.swiftsuspenders.Injector;
   import org.swiftsuspenders.§_-71M§;
   import org.swiftsuspenders.§_-T1p§;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.request.DeleteClanRequest;
   import ru.pragmatix.wormix.messages.clans.response.DeleteClanResponse;
   import ru.pragmatix.wormix.messages.clans.structures.ClanChatMessageTO;
   import ru.pragmatix.wormix.messages.client.PvpChatMessage;
   import ru.pragmatix.wormix.messages.server.EndTurnResponse;
   import ru.pragmatix.wormix.messages.server.EnterAccount;
   import ru.pragmatix.wormix.messages.structures.BossWormStructure;
   import ru.pragmatix.wormix.messages.structures.EndBattleStructure;
   import ru.pragmatix.wormix.messages.structures.WeaponStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.items.craft.CraftedEquipFamily;
   import ru.pragmatix.wormix.model.items.craft.§_-6S§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   import ru.pragmatix.wormix.model.user.§_-WU§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.serialization.SerializationUtils;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.social.common.post.*;
   import ru.pragmatix.wormix.utils.*;
   import ru.pragmatix.wormix.weapons.*;
   import starling.display.DisplayObject;
   import starling.display.Image;
   import starling.events.Event;
   import starling.textures.Texture;
   
   use namespace bi_internal;
   use namespace gestouch_internal;
   
   public class §_-11E§
   {
      
      protected var attackSounds:Array = [];
      
      protected var §_-72k§:Array = [];
      
      protected var §_-Sb§:Array = [];
      
      protected var §_-D1d§:Array = [];
      
      protected var §_-F2a§:Array = [];
      
      protected var §_-z2K§:Array = [];
      
      protected var §_-12w§:Array = [];
      
      protected var §_-G1d§:Array = [];
      
      protected var §_-Ng§:Array = [];
      
      protected var §_-51c§:Array = [];
      
      protected var §_-11F§:Array = [];
      
      protected var §_-Z1q§:Array = [];
      
      protected var §_-726§:§_-t1R§;
      
      public function §_-11E§()
      {
         super();
      }
      
      public function §_-h2Y§() : void
      {
         §_-h2B§.play(§_-d27§.§_-k4§(this.§_-72k§));
      }
      
      public function §_-93I§() : void
      {
         §_-h2B§.play(§_-d27§.§_-k4§(this.attackSounds));
      }
      
      public function §_-13Q§() : void
      {
         §_-h2B§.play(§_-d27§.§_-k4§(this.§_-Sb§));
      }
      
      public function §_-l1v§() : void
      {
         §_-h2B§.play(§_-d27§.§_-k4§(this.§_-D1d§));
      }
      
      public function §_-j2i§() : void
      {
         §_-h2B§.play(§_-d27§.§_-k4§(this.§_-F2a§));
      }
      
      public function §_-76§() : void
      {
         §_-h2B§.play(§_-d27§.§_-k4§(this.§_-z2K§));
      }
      
      public function §_-Y16§() : void
      {
         §_-h2B§.play(§_-d27§.§_-k4§(this.§_-G1d§));
      }
      
      public function §_-of§() : void
      {
         §_-h2B§.play(§_-d27§.§_-k4§(this.§_-12w§));
      }
      
      public function §_-L3L§() : void
      {
         §_-h2B§.play(§_-d27§.§_-k4§(this.§_-Ng§));
      }
      
      public function §_-A1c§() : void
      {
         §_-h2B§.play(§_-d27§.§_-k4§(this.§_-51c§));
      }
      
      public function §_-13N§() : void
      {
         §_-h2B§.play(§_-d27§.§_-k4§(this.§_-11F§));
      }
      
      public function §_-Y2d§() : void
      {
         §_-h2B§.play(§_-d27§.§_-k4§(this.§_-Z1q§));
      }
      
      public function §_-O2U§() : §_-t1R§
      {
         return this.§_-726§;
      }
   }
}

