package §_-79§
{
   import §_-533§.§_-c2b§;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-zF§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-F39§.§_-D14§;
   import §_-Z1K§.§_-q24§;
   import §_-p18§.§_-V14§;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.wormix.controls.Command;
   import ru.pragmatix.wormix.controls.system.ControlSystems;
   import ru.pragmatix.wormix.gui.*;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.weapons.ammo.DynamiteStick;
   import starling.display.DisplayObjectContainer;
   import starling.display.Image;
   import starling.events.Event;
   import starling.utils.AssetManager;
   import starling.utils.Pool;
   
   public class §_-v1W§ extends §_-11E§
   {
      
      public function §_-v1W§()
      {
         super();
         attackSounds = [§_-d27§.§_-Fy§["boxer"].speak_v_ataku,§_-d27§.§_-Fy§["boxer"].speak_lojis,§_-d27§.§_-Fy§["boxer"].speak_ogon,§_-d27§.§_-Fy§["boxer"].speak_vboy,§_-d27§.§_-Fy§["boxer"].speak_vottebe,§_-d27§.§_-Fy§["boxer"].speak_smeh2,§_-d27§.§_-Fy§["boxer"].speak_pobeda];
         §_-Sb§ = [§_-d27§.§_-Fy§["boxer"].damage1,§_-d27§.§_-Fy§["boxer"].damage2,§_-d27§.§_-Fy§["boxer"].damage3,§_-d27§.§_-Fy§["boxer"].damage4];
         §_-72k§ = [§_-d27§.§_-Fy§["boxer"].speak_prijok1,§_-d27§.§_-Fy§["boxer"].speak_prijok2];
         §_-D1d§ = [§_-d27§.§_-Fy§["boxer"].speak_promazal,§_-d27§.§_-Fy§["boxer"].speak_nepopal];
         §_-F2a§ = [§_-d27§.§_-Fy§["boxer"].speak_smeh1,§_-d27§.§_-Fy§["boxer"].speak_smeh2];
         §_-z2K§ = [§_-d27§.§_-Fy§["boxer"].speak_nukanuka,§_-d27§.§_-Fy§["boxer"].speak_pogodi,§_-d27§.§_-Fy§["boxer"].speak_cel_obnarujena,§_-d27§.§_-Fy§["boxer"].speak_jdu_prikaza,§_-d27§.§_-Fy§["boxer"].speak_vpered,§_-d27§.§_-Fy§["boxer"].speak_komandir];
         §_-12w§ = [§_-d27§.§_-Fy§["boxer"].speak_cheknutiy,§_-d27§.§_-Fy§["boxer"].speak_hoho];
         §_-G1d§ = [§_-d27§.§_-Fy§["boxer"].speak_nashol];
         §_-Ng§ = [§_-d27§.§_-Fy§["boxer"].speak_smotri,§_-d27§.§_-Fy§["boxer"].speak_predatel];
         §_-51c§ = [§_-d27§.§_-Fy§["boxer"].speak_vottebe,§_-d27§.§_-Fy§["boxer"].speak_mest];
         §_-11F§ = [§_-d27§.§_-Fy§["boxer"].speak_granata];
         §_-Z1q§ = [§_-d27§.§_-Fy§["boxer"].speak_pervayakrov];
         §_-726§ = §_-d27§.§_-Fy§["boxer"].win;
      }
   }
}

