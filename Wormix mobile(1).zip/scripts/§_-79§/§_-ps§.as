package §_-79§
{
   import §_-21p§.§_-4w§;
   import §_-31W§.*;
   import §_-43V§.Random;
   import §_-62§.§_-L1r§;
   import §_-82l§.§_-1I§;
   import §_-91A§.*;
   import §_-931§.§_-i2r§;
   import §_-B1y§.*;
   import §_-B2z§.§_-63i§;
   import §_-Cl§.*;
   import §_-DJ§.§_-J2l§;
   import §_-F2Q§.GestureEvent;
   import §_-F39§.§_-i1i§;
   import §_-G2H§.*;
   import §_-H3§.*;
   import §_-J31§.§_-R1h§;
   import §_-L1H§.§_-b2K§;
   import §_-L2F§.*;
   import §_-Ly§.§_-81L§;
   import §_-S1N§.*;
   import §_-Ta§.*;
   import §_-Y1O§.*;
   import §_-ZP§.§_-H1H§;
   import §_-ZP§.§_-w1J§;
   import §_-a19§.§_-g1S§;
   import §_-a29§.*;
   import §_-d2p§.*;
   import §_-j1w§.§_-L1x§;
   import §_-l1K§.*;
   import §_-l1g§.§_-L3Q§;
   import §_-r1C§.§_-h2B§;
   import §_-rM§.§_-61j§;
   import §_-u1T§.*;
   import com.greensock.*;
   import com.greensock.core.*;
   import com.greensock.plugins.*;
   import com.hurlant.math.*;
   import com.hurlant.util.§_-a2P§;
   import dragonBones.animation.WorldClock;
   import feathers.data.ListCollection;
   import flash.display.*;
   import flash.events.*;
   import flash.geom.*;
   import flash.text.TextFormat;
   import flash.utils.*;
   import org.gestouch.core.GestureState;
   import ru.pragmatix.flox.social.model.PaymentOption;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.EffectType;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.game.§_-eX§;
   import ru.pragmatix.wormix.game.ai.§_-de§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.shop.*;
   import ru.pragmatix.wormix.messages.clans.request.login.LoginClanBase;
   import ru.pragmatix.wormix.model.bonus.§_-x2M§;
   import ru.pragmatix.wormix.model.items.craft.CraftedEquipFamily;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.ZombieGrave;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.model.CatPhysicModel;
   import ru.pragmatix.wormix.pvp.messages.client.PvpEndTurn;
   import ru.pragmatix.wormix.pvp.messages.client.PvpEndTurnResponse;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.utils.§_-MN§;
   import ru.pragmatix.wormix.weapons.AntifreezePotion;
   import ru.pragmatix.wormix.weapons.Antitoxin;
   import ru.pragmatix.wormix.weapons.Auger;
   import ru.pragmatix.wormix.weapons.Bandage;
   import ru.pragmatix.wormix.weapons.Bat;
   import ru.pragmatix.wormix.weapons.Drill;
   import ru.pragmatix.wormix.weapons.Dynamite;
   import ru.pragmatix.wormix.weapons.ElectricHarpoon;
   import ru.pragmatix.wormix.weapons.EmergencyTeleport;
   import ru.pragmatix.wormix.weapons.FireThrower;
   import ru.pragmatix.wormix.weapons.Firework;
   import ru.pragmatix.wormix.weapons.Girder;
   import ru.pragmatix.wormix.weapons.GravityGun;
   import ru.pragmatix.wormix.weapons.Helipad;
   import ru.pragmatix.wormix.weapons.Jetpack;
   import ru.pragmatix.wormix.weapons.LaserBarrier;
   import ru.pragmatix.wormix.weapons.Minigun;
   import ru.pragmatix.wormix.weapons.Rifle;
   import ru.pragmatix.wormix.weapons.RopeGun;
   import ru.pragmatix.wormix.weapons.Shocker;
   import ru.pragmatix.wormix.weapons.Shotgun;
   import ru.pragmatix.wormix.weapons.SniperRifle;
   import ru.pragmatix.wormix.weapons.SuperBoarWeapon;
   import ru.pragmatix.wormix.weapons.SwineWeapon;
   import ru.pragmatix.wormix.weapons.SwitchTurn;
   import ru.pragmatix.wormix.weapons.Teleport;
   import ru.pragmatix.wormix.weapons.UfoPad;
   import ru.pragmatix.wormix.weapons.Uzi;
   import ru.pragmatix.wormix.weapons.ammo.BouncingTeleport;
   import ru.pragmatix.wormix.weapons.ammo.Mine;
   import ru.pragmatix.wormix.weapons.ammo.type.grenade.simple.BouncingGrenade;
   import ru.pragmatix.wormix.weapons.interfaces.§_-P2v§;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.events.Event;
   import starling.filters.ColorMatrixFilter;
   import starling.utils.Pool;
   
   use namespace bi_internal;
   
   public class §_-ps§
   {
      
      private static var §_-C2V§:Array = [Shocker,Rifle,Shotgun,BouncingTeleport,Teleport,SwineWeapon,SuperBoarWeapon,SwitchTurn,SniperRifle,Jetpack,Uzi,Minigun,Auger,Drill,FireThrower,Girder,RopeGun,ElectricHarpoon,Bat,AntifreezePotion,Helipad,UfoPad,GravityGun,Bandage,EmergencyTeleport,LaserBarrier];
      
      public function §_-ps§()
      {
         super();
      }
      
      public static function §_-93I§(param1:§_-01J§) : void
      {
         var _loc3_:§_-P2v§ = null;
         var _loc4_:Boolean = false;
         var _loc5_:Class = null;
         var _loc2_:§_-eX§ = §_-X1j§.§_-12n§.gameMaster;
         if(Boolean(_loc2_) && Boolean(_loc2_.activeUnit))
         {
            _loc3_ = _loc2_.activeUnit.weapon;
            if(_loc3_)
            {
               _loc4_ = false;
               for each(_loc5_ in §_-C2V§)
               {
                  if(_loc3_ is _loc5_)
                  {
                     _loc4_ = true;
                     break;
                  }
               }
               if(!_loc4_)
               {
                  if(!(_loc3_ is Antitoxin))
                  {
                     if(_loc3_ is Dynamite || _loc3_ is Mine || _loc3_ is Firework)
                     {
                        §_-zC§(param1).§_-j2i§();
                     }
                     else if(_loc3_ is BouncingGrenade)
                     {
                        §_-zC§(param1).§_-13N§();
                     }
                     else
                     {
                        §_-zC§(param1).§_-93I§();
                     }
                  }
               }
            }
         }
      }
      
      public static function §_-wC§(param1:§_-01J§) : void
      {
         §_-zC§(param1).§_-13Q§();
      }
      
      public static function §_-21F§(param1:§_-01J§) : void
      {
         §_-zC§(param1).§_-Y16§();
      }
      
      public static function §_-76§(param1:§_-01J§) : void
      {
         §_-zC§(param1).§_-76§();
      }
      
      public static function §_-Y2d§(param1:§_-01J§) : void
      {
         §_-zC§(param1).§_-Y2d§();
      }
      
      public static function §_-L3L§(param1:§_-01J§) : void
      {
         §_-zC§(param1).§_-L3L§();
      }
      
      public static function §_-A1c§(param1:§_-01J§) : void
      {
         §_-zC§(param1).§_-A1c§();
      }
      
      public static function §_-of§(param1:§_-01J§) : void
      {
         §_-zC§(param1).§_-of§();
      }
      
      public static function §_-l1v§(param1:§_-01J§) : void
      {
         §_-zC§(param1).§_-l1v§();
      }
      
      public static function §_-h2Y§(param1:§_-01J§) : void
      {
         §_-zC§(param1).§_-h2Y§();
      }
      
      private static function §_-zC§(param1:§_-01J§) : §_-11E§
      {
         return param1.record.§_-zC§() != null ? param1.record.§_-zC§() : §_-sd§.§_-zC§(param1.record.§_-P2e§().configName);
      }
   }
}

