package §_-oq§
{
   import §_-51p§.§_-P1R§;
   import §_-52V§.§_-031§;
   import §_-52V§.§_-b2z§;
   import §_-63U§.§_-21K§;
   import §_-A1K§.§_-TA§;
   import §_-Cl§.*;
   import §_-DJ§.§_-J2l§;
   import §_-Ly§.§_-81L§;
   import §_-Ly§.§_-I2K§;
   import §_-YF§.§_-q2v§;
   import §_-aM§.*;
   import §_-l1K§.§_-vO§;
   import §_-s20§.§_-J2g§;
   import feathers.controls.Button;
   import feathers.controls.TextInput;
   import feathers.core.FeathersControl;
   import feathers.core.ITextRenderer;
   import flash.errors.IllegalOperationError;
   import flash.geom.Point;
   import flash.media.SoundMixer;
   import flash.utils.Dictionary;
   import ru.pragmatix.flox.social.controller.ISocialController;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controller.§_-m1o§;
   import ru.pragmatix.wormix.messages.structures.ReconnectToSimpleBattleResultStructure;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.pvp.messages.ex.RejectBattleOffer;
   import ru.pragmatix.wormix.utils.§_-R2g§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.events.TouchEvent;
   import starling.text.TextField;
   import starling.text.TextFormat;
   import starling.utils.Align;
   import starling.utils.Pool;
   
   public class §_-43g§ extends §_-X2j§
   {
      
      private var collectedReagents:Vector.<int> = new Vector.<int>();
      
      public function §_-43g§()
      {
         super(0.06);
      }
      
      public function §_-91P§(param1:int, param2:int, param3:uint) : §_-P1R§
      {
         var _loc5_:Point = null;
         var _loc6_:§_-P1R§ = null;
         var _loc4_:Vector.<int> = §_-X1j§.§_-12n§.§_-WN§().reagentsForBattle;
         if(_loc4_.length > 0 && §_-42u§(param1,param2,param3))
         {
            _loc5_ = Pool.getPoint(param1,param2);
            _loc6_ = new §_-P1R§(_loc5_,_loc4_.shift());
            Pool.putPoint(_loc5_);
            return _loc6_;
         }
         return null;
      }
      
      public function §_-11§(param1:int) : void
      {
         this.collectedReagents.push(param1);
      }
      
      public function §_-5C§() : Vector.<int>
      {
         return this.collectedReagents.concat();
      }
   }
}

