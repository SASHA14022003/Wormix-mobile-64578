package §_-oq§
{
   import §_-23P§.§_-V2T§;
   import §_-23P§.§_-u1z§;
   import §_-62§.§_-W1r§;
   import §_-73I§.§_-q15§;
   import §_-CR§.§_-S2o§;
   import §_-G16§.*;
   import §_-H2g§.§_-di§;
   import §_-R2S§.*;
   import §_-TF§.§_-q1j§;
   import §_-Z1L§.§_-A2V§;
   import §_-Z1L§.§_-H1K§;
   import feathers.events.FeathersEventType;
   import feathers.layout.VerticalLayout;
   import flash.utils.IDataInput;
   import flash.utils.IDataOutput;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.menu.§_-3m§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import starling.display.DisplayObject;
   import starling.display.Image;
   import starling.events.Event;
   import starling.textures.Texture;
   import starling.utils.ScaleMode;
   
   public class §_-X2j§
   {
      
      private var §_-K1W§:Number;
      
      public function §_-X2j§(param1:Number)
      {
         super();
         this.§_-K1W§ = param1 > 0.15 ? 0.15 : param1;
      }
      
      final protected function §_-42u§(param1:int, param2:int, param3:uint) : Boolean
      {
         if(param3 > 400)
         {
            §_-X1j§.§_-12n§.scene.dispatchEvent(new §_-H1K§(§_-A2V§.§_-A2e§,"damage radius " + param3));
         }
         if(this.§_-K1W§ > 0.15)
         {
            §_-X1j§.§_-12n§.scene.dispatchEvent(new §_-H1K§(§_-A2V§.§_-A2e§,"AbstractSpawnerController hacked"));
         }
         return !§_-X1j§.§_-12n§.scene.hitTestPermanent(param1,param2) && Math.random() < this.§_-K1W§ * param3 * param3 / 10000;
      }
   }
}

