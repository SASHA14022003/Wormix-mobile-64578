package §_-oq§
{
   import §_-12W§.*;
   import §_-A1K§.§_-TA§;
   import §_-B1y§.§_-bs§;
   import §_-C2t§.§_-92W§;
   import §_-DJ§.§_-J2l§;
   import §_-W§.§_-Ap§;
   import §_-Y1O§.*;
   import §_-g1P§.§_-L38§;
   import §_-g1P§.§_-o1l§;
   import §_-s20§.§_-J2g§;
   import §_-s20§.§_-d21§;
   import §_-w2W§.§_-21w§;
   import feathers.core.ITextRenderer;
   import flash.geom.Point;
   import flash.text.TextFormat;
   import ru.pragmatix.flox.gui.controls.§_-NY§;
   import ru.pragmatix.wormix.messages.client.ToggleTeamMember;
   import ru.pragmatix.wormix.messages.server.ToggleTeamMemberResult;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.utils.§_-R2g§;
   import starling.display.DisplayObject;
   import starling.events.Event;
   import starling.utils.Pool;
   
   public class §_-c1o§ extends §_-X2j§
   {
      
      public static const §_-z1B§:uint = 4;
      
      public static const §_-U1r§:uint = 1;
      
      public static const §_-r2d§:uint = 5;
      
      private var §_-n1q§:§_-TA§ = new §_-TA§(0);
      
      public function §_-c1o§()
      {
         super(0.1);
      }
      
      public function §_-O2G§(param1:int, param2:int, param3:uint) : §_-L38§
      {
         var _loc4_:Point = null;
         var _loc5_:§_-o1l§ = null;
         if(this.§_-n1q§.value < §_-r2d§ && §_-42u§(param1,param2,param3))
         {
            ++this.§_-n1q§.value;
            _loc4_ = Pool.getPoint(param1,param2);
            _loc5_ = new §_-o1l§(_loc4_,§_-U1r§,§_-z1B§);
            Pool.putPoint(_loc4_);
            return _loc5_;
         }
         return null;
      }
   }
}

