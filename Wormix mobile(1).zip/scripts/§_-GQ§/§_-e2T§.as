package §_-GQ§
{
   import §_-62§.§_-G1p§;
   import §_-B1y§.*;
   import §_-DJ§.§_-fH§;
   import §_-H16§.*;
   import §_-m2s§.§_-R11§;
   import org.swiftsuspenders.Injector;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import starling.events.Event;
   
   public class §_-e2T§ extends §_-P1G§
   {
      
      public function §_-e2T§()
      {
         super();
      }
      
      override protected function §_-EX§() : void
      {
         var _loc1_:int = §_-d1L§(§_-G1p§.§_-62S§(owner.record.§_-P2e§()));
         owner.§_-r1V§(_loc1_);
      }
   }
}

