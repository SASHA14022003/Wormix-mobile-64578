package §_-GQ§
{
   import §_-21p§.§_-4w§;
   import §_-63U§.*;
   import §_-73d§.§_-g1J§;
   import §_-A1K§.§_-TA§;
   import §_-CF§.§_-E19§;
   import §_-Cl§.*;
   import §_-D3A§.§_-TZ§;
   import §_-Jd§.BonusTrait;
   import §_-a19§.*;
   import §_-fo§.§_-hH§;
   import §_-l1K§.§_-d2j§;
   import §_-l1g§.§_-L3Q§;
   import §_-l2r§.§_-K1t§;
   import com.distriqt.extension.inappbilling.InAppBillingAvailability;
   import com.distriqt.extension.inappbilling.Product;
   import com.distriqt.extension.inappbilling.Purchase;
   import com.distriqt.extension.inappbilling.events.AvailabilityEvent;
   import com.distriqt.extension.inappbilling.events.PurchaseEvent;
   import dragonBones.animation.WorldClock;
   import flash.utils.IDataInput;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.messages.structures.SelectStuffResultStructure;
   import ru.pragmatix.wormix.model.rewards.§_-P2q§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.utils.MathUtil;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.events.Event;
   
   public class §_-V12§ extends BonusTrait
   {
      
      protected var §_-D2j§:§_-TA§ = new §_-TA§(9);
      
      public function §_-V12§()
      {
         super();
      }
      
      override protected function activate(param1:§_-4w§) : void
      {
         owner.§_-E17§(this.§_-D2j§);
      }
      
      override protected function deactivate(param1:§_-4w§) : void
      {
         owner.§_-E17§(§_-F3o§.§_-A3X§);
      }
   }
}

