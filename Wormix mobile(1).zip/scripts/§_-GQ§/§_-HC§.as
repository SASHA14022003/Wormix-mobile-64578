package §_-GQ§
{
   import §_-21p§.§_-4w§;
   import §_-2U§.Alchemist;
   import §_-2U§.AncientGhost;
   import §_-2U§.Archbot;
   import §_-2U§.Assassin;
   import §_-2U§.DarkKnight;
   import §_-2U§.Emperor;
   import §_-2U§.Engineer;
   import §_-2U§.Scientist;
   import §_-2U§.Symbiote;
   import §_-2U§.Yakuza;
   import §_-2U§.§_-217§;
   import §_-2U§.§_-cH§;
   import §_-2U§.§_-d1J§;
   import §_-2U§.§_-t2u§;
   import §_-51M§.Cat;
   import §_-A1K§.§_-7u§;
   import §_-A1K§.§_-TA§;
   import §_-CF§.§_-E19§;
   import §_-E29§.*;
   import §_-J31§.§_-R1h§;
   import §_-Jd§.BonusTrait;
   import §_-L2F§.§_-D2p§;
   import §_-P1z§.§_-Cc§;
   import §_-P1z§.§_-E2z§;
   import §_-P1z§.§_-L1s§;
   import §_-P1z§.§_-j2E§;
   import §_-P1z§.§_-k2X§;
   import §_-R2S§.Farmer;
   import §_-R2S§.Hunter;
   import §_-R2S§.Maniacs;
   import §_-R2S§.Miner;
   import §_-R2S§.Sergeant;
   import §_-R2S§.§_-M2x§;
   import §_-R2S§.§_-P1U§;
   import §_-R2S§.§_-z2x§;
   import §_-RE§.*;
   import §_-Ub§.Vikings;
   import §_-Ub§.VoodooShaman;
   import §_-Ub§.WindMaster;
   import §_-Ub§.§_-W1E§;
   import §_-Ub§.§_-v1t§;
   import §_-Z1K§.§_-q24§;
   import §_-Z1w§.§_-s1x§;
   import §_-f1G§.§_-kf§;
   import §_-g2e§.§_-q2Z§;
   import §_-hO§.AttackDodgedEvent;
   import §_-k1u§.§_-Oi§;
   import §_-k2s§.§_-b0§;
   import §_-k2s§.§_-e1U§;
   import §_-k2s§.§_-iI§;
   import §_-k2s§.§_-uU§;
   import §_-l1g§.§_-L3Q§;
   import §_-qH§.§_-S25§;
   import §_-s1Q§.Artifacts;
   import §_-w2i§.§_-Zd§;
   import §_-z1g§.§_-y1S§;
   import feathers.layout.HorizontalLayout;
   import flash.display.SimpleButton;
   import flash.utils.getQualifiedClassName;
   import org.gestouch.core.gestouch_internal;
   import ru.pragmatix.wormix.controller.§_-C2c§;
   import ru.pragmatix.wormix.game.ai.§_-12u§;
   import ru.pragmatix.wormix.game.ai.§_-H3h§;
   import ru.pragmatix.wormix.game.ai.§_-dG§;
   import ru.pragmatix.wormix.game.ai.§_-n2q§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.structures.WeaponStructure;
   import ru.pragmatix.wormix.model.rewards.§_-P2q§;
   import ru.pragmatix.wormix.objects.Direction;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import starling.core.Starling;
   import starling.events.Event;
   
   use namespace gestouch_internal;
   
   public class §_-HC§ extends BonusTrait
   {
      
      public function §_-HC§()
      {
         super();
      }
      
      override protected function activate(param1:§_-4w§) : void
      {
         owner.physParams.sinkable = false;
      }
      
      override protected function deactivate(param1:§_-4w§) : void
      {
         owner.physParams.sinkable = true;
      }
   }
}

