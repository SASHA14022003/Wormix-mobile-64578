package §_-GQ§
{
   import §_-12W§.*;
   import §_-21p§.§_-4w§;
   import §_-5P§.§_-H1u§;
   import §_-62§.§_-L1r§;
   import §_-B1y§.§_-bs§;
   import §_-CR§.§_-72p§;
   import §_-Jd§.BonusTrait;
   import §_-K35§.§_-99§;
   import §_-TF§.§_-q1j§;
   import §_-Vg§.*;
   import §_-YF§.§_-Zi§;
   import §_-j22§.§_-5g§;
   import §_-jF§.ClanMemberItemRenderer;
   import §_-jF§.§_-U17§;
   import §_-l1g§.§_-L3Q§;
   import §_-l1g§.§_-f2L§;
   import §_-rM§.§_-61j§;
   import §_-s20§.§_-J2g§;
   import §_-s20§.§_-d21§;
   import com.greensock.loading.LoaderMax;
   import com.hurlant.crypto.tls.*;
   import com.hurlant.util.§_-a2P§;
   import feathers.controls.ScrollPolicy;
   import feathers.data.ArrayCollection;
   import feathers.layout.AnchorLayout;
   import feathers.layout.Direction;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.RelativePosition;
   import feathers.layout.TiledColumnsLayout;
   import feathers.layout.VerticalAlign;
   import feathers.layout.VerticalLayout;
   import feathers.themes.styles.AlternateButtonsStyles;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import flash.utils.IDataOutput;
   import ru.pragmatix.flox.gui.controls.§_-NY§;
   import ru.pragmatix.flox.social.controller.ISocialController;
   import ru.pragmatix.flox.social.controller.mobile.VkMobileSocialController;
   import ru.pragmatix.flox.social.response.LoadFriendsResponse;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.EffectType;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.gui.§_-eP§;
   import ru.pragmatix.wormix.messages.client.BuyUnlockMission;
   import ru.pragmatix.wormix.messages.client.Connect;
   import ru.pragmatix.wormix.messages.server.ConnectResult;
   import ru.pragmatix.wormix.messages.server.SteamProductsInfoResponse;
   import ru.pragmatix.wormix.messages.structures.SteamProductInfoStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-V1L§;
   import ru.pragmatix.wormix.pvp.messages.ex.PvpBattleType;
   import ru.pragmatix.wormix.pvp.messages.server.PvpEndBattle;
   import ru.pragmatix.wormix.pvp.messages.server.PvpRetryCommandRequestServer;
   import ru.pragmatix.wormix.pvp.messages.server.PvpStartTurn;
   import ru.pragmatix.wormix.pvp.messages.server.PvpSystemMessage;
   import ru.pragmatix.wormix.serialization.SerializationUtils;
   import ru.pragmatix.wormix.social.*;
   import starling.display.DisplayObject;
   import starling.events.Event;
   import starling.utils.SystemUtil;
   
   public class §_-P1G§ extends BonusTrait
   {
      
      private var §_-w2r§:Boolean;
      
      public function §_-P1G§()
      {
         super();
      }
      
      override protected function activate(param1:§_-4w§) : void
      {
         /*
          * Decompilation error
          * Code may be obfuscated
          * Error type: IndexOutOfBoundsException (Index -1 out of bounds for length 0)
          */
         throw new flash.errors.IllegalOperationError("Not decompiled due to error");
      }
      
      override protected function deactivate(param1:§_-4w§) : void
      {
         §_-X1j§.§_-12n§.scene.removeEventListener(§_-L3Q§.UNIT_ACTIVATION,this.trigger);
      }
      
      protected function trigger(param1:Event) : void
      {
         if(Boolean(param1) && param1.data != owner)
         {
            return;
         }
         §_-X1j§.§_-12n§.scene.removeEventListener(§_-L3Q§.UNIT_ACTIVATION,this.trigger);
         var _loc2_:Boolean = owner.graphics.§_-kh§();
         if(_loc2_)
         {
            owner.graphics.unlock();
         }
         this.§_-EX§();
         if(_loc2_)
         {
            owner.graphics.lock();
         }
         Effects.createDragonbonesAnimationEffect(EffectType.EXPLOSION_SMOKE,owner.x,owner.y,30,§_-d27§.§_-j1o§);
      }
      
      [Abstract]
      protected function §_-EX§() : void
      {
      }
      
      protected function §_-d1L§(param1:Array) : int
      {
         var _loc2_:§_-L1r§ = param1[§_-X1j§.randomSeed.§_-Fh§(0,param1.length - 1)];
         return _loc2_.getId();
      }
   }
}

