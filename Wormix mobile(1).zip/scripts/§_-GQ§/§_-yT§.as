package §_-GQ§
{
   import §_-62§.§_-G1p§;
   import §_-A1K§.§_-TA§;
   import §_-B1y§.§_-F1P§;
   import §_-B1y§.§_-bs§;
   import §_-H2g§.§_-di§;
   import §_-L1H§.§_-C3e§;
   import §_-Y1O§.§_-yA§;
   import §_-aM§.*;
   import §_-fo§.*;
   import §_-j1w§.§_-B2i§;
   import §_-j1y§.§_-i1b§;
   import §_-k1u§.§_-2m§;
   import §_-k1u§.§_-52D§;
   import §_-k1u§.§_-F3H§;
   import §_-k1u§.§_-H2M§;
   import §_-k1u§.§_-Vr§;
   import §_-k1u§.§_-by§;
   import §_-l1K§.*;
   import §_-l1g§.§_-L3Q§;
   import §_-l2r§.§_-K1t§;
   import com.greensock.loading.ImageLoader;
   import com.greensock.loading.LoaderMax;
   import dragonBones.animation.WorldClock;
   import feathers.data.IListCollection;
   import flash.events.*;
   import flash.utils.*;
   import org.as3commons.zip.*;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.messages.structures.RentedItemsStructure;
   import ru.pragmatix.wormix.messages.structures.UserProfileStructure;
   import ru.pragmatix.wormix.model.user.*;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.weapons.Girder;
   import starling.core.Starling;
   import starling.events.Event;
   import starling.utils.MathUtil;
   
   public class §_-yT§ extends §_-P1G§
   {
      
      public function §_-yT§()
      {
         super();
      }
      
      override protected function §_-EX§() : void
      {
         var _loc1_:int = §_-d1L§(§_-G1p§.§_-Hm§());
         owner.§_-P1t§(_loc1_);
      }
   }
}

