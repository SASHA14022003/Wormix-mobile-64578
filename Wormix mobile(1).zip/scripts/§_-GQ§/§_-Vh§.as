package §_-GQ§
{
   import §_-21p§.§_-4w§;
   import §_-62§.§_-T1y§;
   import §_-62§.§_-gr§;
   import §_-62§.§_-zF§;
   import §_-63U§.§_-21K§;
   import §_-73I§.§_-q15§;
   import §_-C2t§.§_-92W§;
   import §_-DJ§.§_-fH§;
   import §_-Jd§.BonusTrait;
   import §_-Nq§.*;
   import §_-TF§.§_-q1j§;
   import §_-Y1O§.§_-yA§;
   import §_-Z2S§.*;
   import §_-b1F§.§_-G4§;
   import §_-l1K§.§_-W2f§;
   import §_-l1g§.§_-L3Q§;
   import §_-rM§.§_-61j§;
   import §_-wD§.*;
   import feathers.core.ITextRenderer;
   import feathers.layout.RelativePosition;
   import feathers.skins.ImageSkin;
   import flash.geom.Rectangle;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.flox.social.response.SocialResponse;
   import ru.pragmatix.wormix.fonts.BitmapFonts;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.*;
   import ru.pragmatix.wormix.messages.server.ArenaResult;
   import ru.pragmatix.wormix.messages.structures.AdvertisingPurchaseStructure;
   import ru.pragmatix.wormix.messages.structures.HeroicMissionDailyProgressStructure;
   import ru.pragmatix.wormix.messages.structures.HeroicMissionStructure;
   import ru.pragmatix.wormix.model.bonus.§_-x2M§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.serialization.SerializationUtils;
   import ru.pragmatix.wormix.serialization.server.*;
   import ru.pragmatix.wormix.utils.§_-R2g§;
   import starling.display.DisplayObject;
   import starling.display.Quad;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.textures.Texture;
   import starling.utils.Pool;
   import starling.utils.RectangleUtil;
   import starling.utils.ScaleMode;
   
   public class §_-Vh§ extends BonusTrait
   {
      
      private static const §_-W2P§:Number = 0.3;
      
      public function §_-Vh§()
      {
         super();
      }
      
      override protected function activate(param1:§_-4w§) : void
      {
         owner.buffs.place(new §_-92W§());
         owner.addEventListener(§_-L3Q§.§_-kl§,this.§_-p1h§);
      }
      
      override protected function deactivate(param1:§_-4w§) : void
      {
         this.clear();
      }
      
      private function §_-p1h§(param1:Event) : void
      {
         this.clear();
         var _loc2_:§_-T1y§ = owner.§_-32q§();
         var _loc3_:§_-zF§ = owner.getHat();
         if(Boolean(_loc2_) && _loc2_.§_-V1v§().§_-yQ§(§_-x2M§.WATER_PROTECTION))
         {
            owner.§_-aV§(null);
            if(_loc3_)
            {
               owner.§_-r1V§(_loc3_.getId());
            }
         }
         else if(Boolean(_loc3_) && _loc3_.§_-V1v§().§_-yQ§(§_-x2M§.WATER_PROTECTION))
         {
            owner.§_-r1V§(0);
         }
         var _loc4_:int = int(Math.floor(owner.hp * §_-W2P§)) > 100 ? int(int(Math.floor(owner.hp * §_-W2P§))) : 100;
         §_-G4§.§_-Ee§(owner,owner.x,owner.y,owner as §_-F3o§,_loc4_,0,0,true,true);
      }
      
      private function clear() : void
      {
         owner.buffs.§_-e1z§(§_-92W§.NAME);
         owner.removeEventListener(§_-L3Q§.§_-kl§,this.§_-p1h§);
      }
   }
}

