package §_-GQ§
{
   import §_-62§.§_-G1p§;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-fH§;
   import §_-E1I§.§_-b2n§;
   import §_-j22§.§_-5g§;
   import §_-l1g§.§_-L3Q§;
   import feathers.controls.Panel;
   import flash.utils.ByteArray;
   import flash.utils.IDataOutput;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.flox.social.response.photo.PhotoSaveResponse;
   import ru.pragmatix.wormix.Scene;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.request.PostClanNewsRequest;
   import ru.pragmatix.wormix.messages.clans.response.*;
   import ru.pragmatix.wormix.messages.clans.structures.ClanMemberTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.pvp.messages.client.BattleReconnect;
   import ru.pragmatix.wormix.utils.*;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.utils.ScaleMode;
   
   public class §_-I2C§ extends §_-P1G§
   {
      
      public function §_-I2C§()
      {
         super();
      }
      
      override protected function §_-EX§() : void
      {
         var _loc1_:int = §_-d1L§(§_-G1p§.§_-P1k§());
         owner.§_-P1t§(_loc1_);
      }
   }
}

