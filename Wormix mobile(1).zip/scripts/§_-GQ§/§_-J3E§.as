package §_-GQ§
{
   import §_-12W§.*;
   import §_-5P§.§_-50§;
   import §_-5Y§.§_-h2c§;
   import §_-62§.*;
   import §_-A1K§.§_-7u§;
   import §_-A2F§.§_-4B§;
   import §_-C3f§.§_-yG§;
   import §_-G2H§.*;
   import §_-Z1K§.§_-M6§;
   import §_-Z1L§.§_-A2V§;
   import §_-Z1L§.§_-H1K§;
   import §_-gG§.§_-M2S§;
   import §_-k1u§.§_-F3H§;
   import §_-k1u§.§_-Oi§;
   import §_-l1K§.§_-W2f§;
   import §_-q26§.*;
   import §_-r1C§.§_-h2B§;
   import §_-rM§.§_-61j§;
   import §_-sQ§.§_-H3D§;
   import §_-w2i§.§_-Ia§;
   import com.distriqt.extension.inappbilling.Product;
   import com.distriqt.extension.inappbilling.SubscriptionOffer;
   import com.distriqt.extension.inappbilling.SubscriptionPhase;
   import com.distriqt.extension.inappbilling.events.ProductEvent;
   import config.§_-vR§;
   import feathers.events.FeathersEventType;
   import flash.system.Capabilities;
   import flash.system.System;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import flash.utils.getTimer;
   import ru.pragmatix.wormix.Scene;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.sets.ControlSets;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.messages.clans.request.login.LoginClanBase;
   import ru.pragmatix.wormix.messages.clans.response.LoginClanEnterAccount;
   import ru.pragmatix.wormix.messages.clans.response.LoginClanErrorResponse;
   import ru.pragmatix.wormix.messages.server.ShowSystemMessage;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.HitTest;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.utils.§_-F2L§;
   import ru.pragmatix.wormix.weapons.§_-N1C§;
   import ru.pragmatix.wormix.weapons.ammo.StaticCharge;
   import starling.display.DisplayObject;
   import starling.events.Event;
   import starling.utils.SystemUtil;
   
   public class §_-J3E§ extends §_-P1G§
   {
      
      public function §_-J3E§()
      {
         super();
      }
      
      override protected function §_-EX§() : void
      {
         var _loc1_:int = §_-d1L§(§_-G1p§.§_-n2w§(owner.record.§_-P2e§()));
         owner.§_-r1V§(_loc1_);
      }
   }
}

