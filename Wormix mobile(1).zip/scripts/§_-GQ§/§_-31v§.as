package §_-GQ§
{
   import §_-21p§.§_-4w§;
   import §_-52L§.§_-u2x§;
   import §_-62§.*;
   import §_-A1K§.§_-TA§;
   import §_-C2t§.§_-92W§;
   import §_-C3f§.§_-Z1Y§;
   import §_-G1h§.MobileMainOverlayScreen;
   import §_-Jd§.BonusTrait;
   import §_-Y1O§.§_-V23§;
   import §_-Z1K§.§_-q24§;
   import §_-aM§.*;
   import §_-l1K§.§_-vO§;
   import §_-l1g§.§_-L3Q§;
   import §_-w2i§.§_-Zd§;
   import com.worlize.websocket.§_-x2j§;
   import feathers.controls.Button;
   import feathers.controls.LayoutGroup;
   import feathers.controls.Screen;
   import feathers.controls.ScreenNavigatorItem;
   import feathers.events.FeathersEventType;
   import flash.utils.ByteArray;
   import ru.pragmatix.wormix.game.ai.§_-A1l§;
   import ru.pragmatix.wormix.game.ai.§_-de§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import starling.display.DisplayObject;
   import starling.display.Sprite;
   import starling.events.Event;
   
   public class §_-31v§ extends BonusTrait
   {
      
      public static const §_-U2i§:§_-TA§ = new §_-TA§(18);
      
      public static const DURATION:§_-TA§ = new §_-TA§(20);
      
      private static const §_-32p§:§_-TA§ = new §_-TA§(2);
      
      public function §_-31v§()
      {
         super();
      }
      
      override protected function activate(param1:§_-4w§) : void
      {
         owner.attributes.jump.§_-qX§(§_-32p§.value);
      }
      
      override protected function deactivate(param1:§_-4w§) : void
      {
         owner.attributes.jump.§_-qX§(-§_-32p§.value);
      }
   }
}

