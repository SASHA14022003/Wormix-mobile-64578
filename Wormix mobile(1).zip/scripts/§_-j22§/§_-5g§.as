package §_-j22§
{
   import §_-DJ§.§_-J2l§;
   import §_-rM§.§_-61j§;
   import flash.utils.IDataInput;
   import flash.utils.IDataOutput;
   import ru.pragmatix.flox.social.utils.storage.StorageType;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   
   public class §_-5g§ implements §_-61j§
   {
      
      private static const §_-g§:int = 87;
      
      private static const §_-G35§:uint = 128;
      
      private static const §_-B5§:uint = 32768;
      
      private static const §_-V2Q§:uint = 32;
      
      private static const §_-y5§:uint = 1073741824;
      
      private static const §_-j2k§:uint = 8;
      
      private static const §_-q1S§:uint = 2147483648;
      
      private static const §_-33C§:uint = 32767;
      
      private static const §_-KZ§:uint = 1073741823;
      
      private static const §_-A3M§:uint = 32767;
      
      private static const §_-13Y§:uint = 1073741823;
      
      private static const §_-N2B§:String = "Недопустимый заголовок команды";
      
      private static const §_-mW§:String = "Недопустимые значения переменных";
      
      private static var §_-I2d§:uint = 0;
      
      private var isValid:Boolean;
      
      private var commandId:uint;
      
      private var length:uint;
      
      private var flags:uint;
      
      private var §_-FQ§:uint;
      
      private var §_-83f§:uint;
      
      public function §_-5g§()
      {
         super();
         this.isValid = false;
      }
      
      public function read(param1:IDataInput) : §_-61j§
      {
         this.§_-W2B§(param1);
         if(this.validate())
         {
            this.parse();
            return this;
         }
         throw new ArgumentError(§_-N2B§);
      }
      
      private function §_-W2B§(param1:IDataInput) : void
      {
         this.flags = param1.readUnsignedByte();
         this.§_-FQ§ = param1.readUnsignedShort();
         this.§_-83f§ = param1.readUnsignedInt();
      }
      
      private function validate() : Boolean
      {
         this.isValid = this.§_-S2x§() && this.§_-s2O§() && this.§_-33p§() && this.§_-H2A§();
         return this.isValid;
      }
      
      private function §_-S2x§() : Boolean
      {
         return (this.flags & §_-g§) == §_-g§;
      }
      
      private function §_-s2O§() : Boolean
      {
         return Boolean(this.flags & §_-j2k§) != Boolean(this.§_-83f§ & §_-q1S§);
      }
      
      private function §_-33p§() : Boolean
      {
         return Boolean(this.flags & §_-V2Q§) != Boolean(this.§_-83f§ & §_-y5§);
      }
      
      private function §_-H2A§() : Boolean
      {
         return Boolean(this.flags & §_-G35§) != Boolean(this.§_-FQ§ & §_-B5§);
      }
      
      private function parse() : void
      {
         this.commandId = this.§_-FQ§ & §_-33C§;
         this.length = this.§_-83f§ & §_-KZ§;
      }
      
      public function write(param1:IDataOutput) : void
      {
         if(this.§_-a20§())
         {
            this.§_-qG§();
            this.§_-o20§(param1);
            return;
         }
         throw new ArgumentError(§_-mW§);
      }
      
      private function §_-a20§() : Boolean
      {
         return this.commandId <= §_-A3M§ && this.commandId >= 0 && this.length <= §_-13Y§ && this.length >= 0;
      }
      
      private function §_-qG§() : void
      {
         this.§_-FQ§ = this.commandId;
         this.§_-83f§ = this.length;
         this.flags = §_-g§;
         if(Math.random() > 0.5)
         {
            this.flags |= 128;
         }
         else
         {
            this.§_-FQ§ |= 32768;
         }
         if(Math.random() > 0.5)
         {
            this.flags |= 32;
         }
         else
         {
            this.§_-83f§ |= 1073741824;
         }
         if(Math.random() > 0.5)
         {
            this.flags |= 8;
         }
         else
         {
            this.§_-83f§ |= 2147483648;
         }
      }
      
      private function §_-o20§(param1:IDataOutput) : void
      {
         param1.writeByte(this.flags);
         param1.writeShort(this.§_-FQ§);
         param1.writeInt(this.§_-83f§);
      }
      
      public function getCommandId() : uint
      {
         return this.commandId;
      }
      
      public function §_-c2D§(param1:uint) : void
      {
         this.commandId = param1;
      }
      
      public function getLength() : uint
      {
         return this.length;
      }
      
      public function setLength(param1:uint) : void
      {
         this.length = param1;
      }
      
      public function §_-E1W§() : Boolean
      {
         return this.isValid;
      }
   }
}

