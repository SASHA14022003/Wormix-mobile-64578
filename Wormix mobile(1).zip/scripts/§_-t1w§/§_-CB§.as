package §_-t1w§
{
   import §_-5Y§.§_-91F§;
   import §_-C2M§.*;
   import §_-DJ§.§_-J2l§;
   import §_-rM§.§_-61j§;
   import feathers.controls.text.TextFieldTextRenderer;
   import feathers.controls.text.TextInstanceCreator;
   import feathers.core.ITextRenderer;
   import feathers.themes.FontSize;
   import flash.display.Shape;
   import flash.events.Event;
   import flash.text.TextFormatAlign;
   import flash.utils.Dictionary;
   import flash.utils.IDataInput;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.wormix.fx.EffectType;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.server.EndTurnResponse;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.utils.§_-YD§;
   import ru.pragmatix.wormix.weapons.ammo.type.grenade.Parasite;
   import starling.events.Event;
   import starling.utils.SystemUtil;
   
   public class §_-CB§
   {
      
      public function §_-CB§()
      {
         super();
      }
      
      public static function §_-r2§(param1:String) : §_-uf§
      {
         var _loc2_:Boolean = §_-YD§.§_-t1O§;
         var _loc3_:§_-uf§ = null;
         var _loc4_:String = param1;
         switch(_loc4_)
         {
            case "steam":
               §§push(0);
               break;
            case "web":
               §§push(1);
               break;
            default:
               switch(_loc4_)
               {
                  case SocialType.MOBILE_ANDROID.name:
                     §§push(2);
                     break;
                  case SocialType.MOBILE_IOS.name:
                     §§push(3);
                     break;
                  default:
                     §§push(4);
               }
         }
         switch(§§pop())
         {
            case 0:
            case 1:
               _loc3_ = new §_-r1k§();
               break;
            case 2:
               if(_loc2_)
               {
                  _loc3_ = new §_-E6§();
                  break;
               }
               _loc3_ = new §_-G2O§();
               break;
            case 3:
               if(_loc2_)
               {
                  _loc3_ = new §_-E6§();
                  break;
               }
               _loc3_ = new §_-HW§();
         }
         return _loc3_;
      }
   }
}

