package §_-t1w§
{
   import §_-23P§.*;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-j1w§.§_-L1x§;
   import §_-p18§.§_-V14§;
   import flash.display.DisplayObject;
   import flash.display.DisplayObjectContainer;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.flox.social.model.IUserProfile;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.objects.Direction;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-i14§;
   import ru.pragmatix.wormix.utils.§_-6A§;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Image;
   import starling.events.Event;
   import starling.filters.ColorMatrixFilter;
   import starling.utils.Pool;
   
   public class §_-HW§ extends §_-qF§
   {
      
      private static const §_-P1o§:String = "sprites/ios/";
      
      public function §_-HW§()
      {
         super();
      }
      
      override public function §_-I2q§(param1:String = "") : String
      {
         return §_-P1o§ + param1;
      }
      
      override public function §_-y1u§(param1:int) : int
      {
         if(param1 == §_-V14§.§_-m1s§)
         {
            return §_-V14§.§_-M2K§;
         }
         return param1;
      }
   }
}

