package §_-t1w§
{
   public interface §_-uf§
   {
      
      function §_-61l§(param1:String) : Array;
      
      function §_-I2q§(param1:String = "") : String;
      
      function §_-y1u§(param1:int) : int;
   }
}

