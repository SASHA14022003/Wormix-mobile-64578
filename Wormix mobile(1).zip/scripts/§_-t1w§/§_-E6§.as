package §_-t1w§
{
   import §_-12W§.*;
   import §_-21p§.§_-4w§;
   import §_-5Y§.§_-91F§;
   import §_-62§.§_-L1r§;
   import §_-Vg§.ClanEditView;
   import §_-Y1Q§.§_-aG§;
   import §_-Y1Q§.§_-tc§;
   import §_-k13§.§_-j23§;
   import §_-l1K§.§_-W2f§;
   import §_-p18§.§_-V14§;
   import §_-zI§.§_-F3q§;
   import com.greensock.*;
   import com.greensock.core.*;
   import feathers.controls.List;
   import feathers.core.FeathersControl;
   import feathers.data.ListCollection;
   import flash.events.*;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import starling.events.Event;
   
   public class §_-E6§ extends §_-qF§
   {
      
      private static const §_-P1o§:String = "sprites/mobile-emulator/";
      
      public function §_-E6§()
      {
         super();
      }
      
      override public function §_-I2q§(param1:String = "") : String
      {
         return §_-P1o§ + param1;
      }
      
      override public function §_-y1u§(param1:int) : int
      {
         if(param1 == §_-V14§.§_-m1s§)
         {
            return §_-V14§.§_-M2K§;
         }
         return param1;
      }
   }
}

