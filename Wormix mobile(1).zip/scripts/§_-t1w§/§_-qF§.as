package §_-t1w§
{
   import §_-51p§.§_-W2e§;
   import §_-62§.§_-G1p§;
   import §_-A1K§.§_-TA§;
   import §_-DJ§.§_-J2l§;
   import §_-L1H§.§_-C3e§;
   import §_-P1z§.*;
   import §_-Tm§.§_-RF§;
   import §_-Y1O§.*;
   import §_-YF§.§_-q2v§;
   import §_-Z1K§.§_-q24§;
   import §_-hO§.§_-v24§;
   import §_-j22§.§_-5g§;
   import §_-l1g§.§_-L3Q§;
   import §_-p18§.§_-V14§;
   import §_-w2W§.§_-21w§;
   import feathers.core.ITextRenderer;
   import flash.geom.Point;
   import flash.text.TextFormat;
   import flash.utils.ByteArray;
   import flash.utils.IDataOutput;
   import org.swiftsuspenders.Injector;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.flox.social.model.SocialUserData;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.messages.client.StartBattle;
   import ru.pragmatix.wormix.model.user.*;
   import ru.pragmatix.wormix.objects.Waypoint;
   import ru.pragmatix.wormix.utils.*;
   import ru.pragmatix.wormix.weapons.Weapon;
   import ru.pragmatix.wormix.weapons.§_-73v§;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   import starling.utils.Pool;
   
   public class §_-qF§ extends §_-b§
   {
      
      private var configs:Array = [{
         "id":"base",
         "assets":[{
            "path":§_-I2q§(),
            "type":§_-y1u§(§_-V14§.§_-M2K§),
            "names":["spriteSheet_base_0","spriteSheet_base_1","spriteSheet_menu"]
         },{
            "path":"data/particles/",
            "type":§_-V14§.§_-EI§,
            "names":["FlyingObjectTrail","antitoxine","heal","WindAura","RageAura","SoulAura","RevengeParticle","ammoTrailParticle","AmmoPoisonTrailParticle","ArchbotParticle","PaladinHealTop","PaladinHealBottom","poison","laserEnd","cloudParticle","ArmorReduction"]
         },{
            "path":"data/particles/stardust/",
            "type":§_-V14§.§_-I2A§,
            "names":["particle_explosion_normal","particle_explosion_small","particle_explosion_large","particle_explosion_bullet","particle_fire","particle_explosion_fire_end","particle_explosion_poison_large","particle_explosion_electric_small","particle_explosion_supply","particle_explosion_demonic","particle_explosion_electric_large","smoke_small_white_par","particle_explosion_shard","particle_explosion_smoke"]
         },{
            "path":"data/dragonbones/",
            "type":§_-V14§.§_-ri§,
            "names":["DragonbonedCharActionsSkeleton","DragonbonedEffectsSkeleton","DragonbonedWeaponsSkeleton","DragonbonedArtifactsSkeleton","DragonbonedHatsSkeleton","DragonbonedLoadingMessageAnimation","DragonbonedClanBannerSkeleton"]
         },{
            "path":"data/ui/",
            "type":§_-V14§.XML,
            "names":[§_-q2v§.§_-22s§,§_-q2v§.§_-A2T§,§_-q2v§.§_-h2y§,§_-q2v§.§_-iW§]
         },{
            "path":"data/ui/",
            "type":§_-V14§.§_-W2x§,
            "names":["GROBOLD_WITH_SHADOWS","GROBOLD_NORMAL"]
         },{
            "path":"data/layouts/common/",
            "type":§_-V14§.§_-Wm§,
            "names":["battle_chat_double_tab","battle_chat_tab","emoji_bottom","emoji_top","friend_list_item_renderer","invite_friend_list_item_renderer","deposit_income_window","achieve_awards","info_panel","buy_vip_dialog","learning_tips","language_option","craft_tree11","craft_tree12","craft_tree111","craft_tree112","craft_tree1111","craft_tree1211","fuzy_button","ruby_button","pvp-card-info","shop_cell_renderer","bonus_panel","level_up_dialog","not_in_clan_view","clan_create_panel","clan_emblem_edit_panel","clan_info_view","clan_info_panel","clan_search_panel","clan_item_renderer","clan_activity_view","clan_activity_item_renderer","clan_treasury_view","clan_edit_panel","clan_member_item_renderer","choose_teammate_panel","clan_fire_dialog","clan_buy_dialog","clan_create_news_panel","clan_change_medal_price_dialog","base-message-box","clan_invite_renderer","not_in_clan_view","ratings-window","rating_screen_daily","rating_screen_yesterday","rating_screen_global","rating_screen_top_clan","player_rating_item_renderer"
            ,"top_award_item_renderer","clan_rating_item_renderer","avatar-hint-params-screen","avatar-hint-params-screen","avatar-hint-actions-screen","rating_list_devider","left_panel","chat_sticker_panel","buy_reaction_dialog","buy_weapon_instant_dialog","user_params_menu","simple_buy_dialog","buy_equip_craft_dialog","settings_dialog","change_name_dialog","new_params_window","chat_input_field"]
         },{
            "path":"data/layouts/desktop/",
            "type":§_-V14§.§_-Wm§,
            "names":["craft_box_anim","help_control","shop_equip_info","shop_weapon_info","shop_info_requirements_renderer","bank_buy_info","bank_deposit_info","bank_deposit_day","bank_vip_info","bank_vip_info_feature","bank_bundle_info","bank_vip_cell","bank_bundle_cell","buy_craft_box_result_window","global_chat_message_renderer","battle_chat_message_renderer"]
         },{
            "path":"data/layouts/mobile/",
            "type":§_-V14§.§_-Wm§,
            "names":["main_screen_overlay","base_overlay_nav_btn","buy_weapon_dialog","buy_equip_dialog","shop_menu_param_cell","clan_main_window"]
         }]
      },{
         "id":§_-21w§.§_-lv§,
         "assets":[{
            "path":§_-I2q§("/preloader/"),
            "type":§_-V14§.§_-8q§,
            "names":["preloader_back"]
         }]
      },{
         "id":§_-21w§.§_-G31§,
         "assets":[{
            "path":"data/layouts/mobile/",
            "type":§_-V14§.§_-Wm§,
            "names":["main_menu_screen","main_menu_teammate_renderer"]
         },{
            "path":§_-I2q§(),
            "type":§_-y1u§(§_-V14§.§_-M2K§),
            "names":["spriteSheet_main_menu"]
         }]
      },{
         "id":§_-21w§.§_-81H§,
         "assets":[{
            "path":§_-I2q§(),
            "type":§_-y1u§(§_-V14§.§_-M2K§),
            "names":["shopMenu"]
         },{
            "path":"data/layouts/mobile/",
            "type":§_-V14§.§_-Wm§,
            "names":["shop_menu","shop_menu_cell","bank_menu","mobile_bank_category_cell","bank_buy_bundle_info_panel","bank_buy_clan_donation_panel","bank_bundle_info_feature"]
         }]
      },{
         "id":§_-21w§.§_-F3d§,
         "assets":[{
            "path":§_-I2q§("house/"),
            "type":§_-y1u§(§_-V14§.§_-m1s§),
            "names":["armory_room_sprite_sheet"]
         },{
            "path":"data/layouts/mobile/",
            "type":§_-V14§.§_-Wm§,
            "names":["armory_room_back"]
         }]
      },{
         "id":§_-21w§.§_-H2E§,
         "assets":[{
            "path":§_-I2q§("house/"),
            "type":§_-y1u§(§_-V14§.§_-m1s§),
            "names":["team_room_sprite_sheet"]
         },{
            "path":"data/layouts/mobile/",
            "type":§_-V14§.§_-Wm§,
            "names":["team_room_screen","team_room_member_renderer"]
         },{
            "path":"data/particles/",
            "type":§_-V14§.§_-EI§,
            "names":["team_room_bubbles"]
         }]
      },{
         "id":§_-21w§.§_-G2M§,
         "assets":[{
            "path":§_-I2q§("house/"),
            "type":§_-y1u§(§_-V14§.§_-m1s§),
            "names":["wardrobe_room_sprite_sheet"]
         },{
            "path":"data/layouts/mobile/",
            "type":§_-V14§.§_-Wm§,
            "names":["wardrobe_room_screen"]
         }]
      },{
         "id":§_-21w§.§_-jc§,
         "assets":[{
            "path":§_-I2q§("house/"),
            "type":§_-y1u§(§_-V14§.§_-m1s§),
            "names":["race_room_sprite_sheet"]
         },{
            "path":"data/layouts/mobile/",
            "type":§_-V14§.§_-Wm§,
            "names":["race_room_screen","race_room_race_description","race_room_race_abilities","race_room_race_ability_renderer","race_room_race_description_renderer"]
         },{
            "path":"data/particles/",
            "type":§_-V14§.§_-EI§,
            "names":["race_room_bubbles"]
         }]
      },{
         "id":§_-21w§.§_-43d§,
         "assets":[{
            "path":§_-I2q§("house/"),
            "type":§_-y1u§(§_-V14§.§_-M2K§),
            "names":["craft_room_sprite_sheet"]
         },{
            "path":"data/layouts/common/",
            "type":§_-V14§.§_-Wm§,
            "names":["craft_weapon_upgrade_screen","craft_weapon_downgrade_screen","craft_weapon_info_screen","reagents_panel","craft_equip_info_panel"]
         },{
            "path":"data/layouts/mobile/",
            "type":§_-V14§.§_-Wm§,
            "names":["craft_room_screen"]
         }]
      },{
         "id":§_-21w§.§_-l1e§,
         "assets":[{
            "path":§_-I2q§("house/"),
            "type":§_-y1u§(§_-V14§.§_-M2K§),
            "names":["achieve_room_sprite_sheet"]
         },{
            "path":"data/layouts/mobile/",
            "type":§_-V14§.§_-Wm§,
            "names":["achieve_room_screen"]
         }]
      }];
      
      public function §_-qF§()
      {
         super();
      }
      
      override protected function §_-r2§() : Array
      {
         return this.configs;
      }
   }
}

