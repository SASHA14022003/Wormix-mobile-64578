package §_-t1w§
{
   import §_-62§.§_-G1p§;
   import §_-931§.§_-02O§;
   import §_-DJ§.§_-73§;
   import §_-DJ§.§_-73y§;
   import §_-DJ§.§_-fH§;
   import §_-F39§.*;
   import §_-HD§.*;
   import §_-Ly§.§_-81L§;
   import §_-RE§.§_-D3v§;
   import §_-SP§.§_-M4§;
   import §_-SP§.§_-j1f§;
   import §_-T2h§.*;
   import §_-Y1b§.§_-OP§;
   import §_-YF§.§_-q2v§;
   import §_-Z1K§.§_-q24§;
   import §_-Z1L§.§_-A2V§;
   import §_-Z1L§.§_-H1K§;
   import §_-aM§.*;
   import §_-j1w§.§_-B2i§;
   import §_-k1u§.§_-Oi§;
   import §_-l1K§.§_-d2j§;
   import §_-r1C§.§_-h2B§;
   import §_-w2i§.§_-52k§;
   import com.distriqt.extension.inappbilling.Purchase;
   import com.hurlant.math.*;
   import config.§_-V2w§;
   import feathers.controls.NumericStepper;
   import feathers.events.FeathersEventType;
   import feathers.layout.RelativePosition;
   import flash.display.MovieClip;
   import flash.filesystem.File;
   import flash.net.Socket;
   import flash.text.TextFormat;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import org.swiftsuspenders.*;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.game.ai.§_-A1l§;
   import ru.pragmatix.wormix.game.ai.§_-de§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.shop.§_-s1V§;
   import ru.pragmatix.wormix.messages.clans.ClanMessages;
   import ru.pragmatix.wormix.messages.clans.request.edit.RenameClanRequest;
   import ru.pragmatix.wormix.messages.client.GoogleValidateInappPurchase;
   import ru.pragmatix.wormix.messages.structures.ShopItemStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.weapons.Weapon;
   import ru.pragmatix.wormix.weapons.ammo.ammoFactory.AmmosFactory;
   import ru.pragmatix.wormix.weapons.ammo.ammoFactory.IPooledAmmo;
   import starling.core.Starling;
   import starling.display.DisplayObjectContainer;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.utils.AssetManager;
   import starlingbuilder.extensions.uicomponents.ContainerButtonWithStates;
   
   use namespace bi_internal;
   
   public class §_-b§ implements §_-uf§
   {
      
      public function §_-b§()
      {
         super();
      }
      
      public function §_-61l§(param1:String) : Array
      {
         var _loc3_:Object = null;
         var _loc2_:Array = [];
         for each(_loc3_ in this.§_-r2§())
         {
            if(_loc3_.id == param1)
            {
               _loc2_ = _loc3_.assets as Array;
               break;
            }
         }
         return _loc2_;
      }
      
      protected function §_-r2§() : Array
      {
         return [];
      }
      
      public function §_-y1u§(param1:int) : int
      {
         return param1;
      }
      
      public function §_-I2q§(param1:String = "") : String
      {
         return param1;
      }
   }
}

