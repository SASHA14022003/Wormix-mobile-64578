package §_-t1w§
{
   import §_-G16§.*;
   import §_-TF§.§_-q1j§;
   import §_-Y1b§.§_-81l§;
   import §_-YF§.§_-q2v§;
   import §_-j1w§.§_-L1x§;
   import §_-qH§.§_-S25§;
   import §_-s1Q§.Artifacts;
   import §_-y1s§.§_-P9§;
   import com.greensock.*;
   import com.greensock.core.*;
   import com.greensock.loading.LoaderMax;
   import com.greensock.loading.core.LoaderCore;
   import com.greensock.plugins.*;
   import feathers.events.FeathersEventType;
   import feathers.layout.VerticalLayout;
   import flash.display.DisplayObject;
   import ru.pragmatix.flox.social.post.*;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import starling.display.DisplayObject;
   import starling.events.Event;
   
   public class §_-G2O§ extends §_-qF§
   {
      
      private static const §_-P1o§:String = "sprites/android/";
      
      public function §_-G2O§()
      {
         super();
      }
      
      override public function §_-I2q§(param1:String = "") : String
      {
         return §_-P1o§ + param1;
      }
   }
}

