package config
{
   import §_-43V§.Random;
   import §_-51M§.Boxer;
   import §_-51M§.Cat;
   import §_-51M§.Dragon;
   import §_-51M§.Rabbit;
   import §_-51M§.Robot;
   import §_-51M§.Zombie;
   import §_-L1H§.§_-C3e§;
   import §_-j1w§.§_-T0§;
   import §_-rM§.§_-61j§;
   import §_-z20§.§_-pl§;
   import com.hurlant.crypto.tls.*;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.sets.ControlSets;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-8K§;
   import ru.pragmatix.wormix.utils.*;
   import ru.pragmatix.wormix.weapons.§_-7o§;
   import ru.pragmatix.wormix.weapons.ammo.boss.emperor.EmperorSpearman;
   import ru.pragmatix.wormix.weapons.ammo.boss.emperor.EmperorTerracottaWarrior;
   import starling.display.DisplayObject;
   
   public class §_-J1r§
   {
      
      public var chars:Array;
      
      public function §_-J1r§()
      {
         §§push(this);
         §§push({
            "id":2,
            "abilities":new <§_-T0§>[new §_-T0§("ABILITY_HP_NAME","ABILITY_HP_DESCR","hp"),new §_-T0§("ABILITY_ARMOR_NAME","ABILITY_ARMOR_DESCR","armor")],
            "bonus":{
               "armorEachLevels":Boxer.§_-11n§.value,
               "hpPct":8
            },
            "className":Boxer,
            "configName":"boxer",
            "fraction":1,
            "name":"RACE_BOXER_NAME",
            "descr":"RACE_BOXER_DESCR",
            "price":1000,
            "realprice":10,
            "requiredLevel":1,
            "stayClip":"BoxerStay",
            "goClip":"BoxerGo",
            "prepareToJumpClip":"BoxerPrepareToJump",
            "endJumpClip":"BoxerEndJump",
            "jumpClip":"BoxerJump",
            "jumpBackClip":"BoxerJumpBack",
            "breathClip":"BoxerBreath",
            "clapClip":"BoxerClap",
            "jetpack":"BoxerJetpack",
            "jetpackStay":"BoxerJetpackStay",
            "shocker":"ShockerUnit",
            "defrost":"HotShield",
            "antifrost":"AntiFrostShield",
            "defrostAttack":"AttackShield",
            "defrostArmory":"ArmoryShield",
            "hammer":"BoxerHammerHit",
            "bat":"BoxerBat",
            "rope":"BoxerRope",
            "sadClip":"BoxerSad",
            "hatClip":"hat",
            "eyesClip":"eyes",
            "leftHand":"leftHand",
            "rightHand":"rightHand",
            "graveType":"BoxerGrave",
            "soulType":"BigSoul",
            "stateActions":["BoxerWink","BoxerWave","BoxerHappy","BoxerThinkDeath","BoxerThinkPizza","BoxerThinkGrenade","BoxerThinkCoffee"],
            "stateActionsInHat":["BoxerWink","BoxerWave","BoxerThinkDeath","BoxerThinkPizza","BoxerThinkGrenade","BoxerThinkCoffee"],
            "happy":"BoxerHappy",
            "damaged":"BoxerBoom"
         });
         §§push({
            "id":3,
            "abilities":new <§_-T0§>[new §_-T0§("ABILITY_POISON_NAME","ABILITY_POISON_DESCR","poison"),new §_-T0§("ABILITY_UNDERWATER_NAME","ABILITY_UNDERWATER_DESCR","water")],
            "bonus":{
               "value":60,
               "poisonDamage":60,
               "waterBreath":1
            },
            "className":§_-8K§,
            "configName":"demon",
            "fraction":2,
            "name":"RACE_DEMON_NAME",
            "descr":"RACE_DEMON_DESCR",
            "price":2000,
            "realprice":20,
            "requiredLevel":10,
            "stayClip":"DemonStay",
            "goClip":"DemonGo",
            "prepareToJumpClip":"DemonPrepareToJump",
            "endJumpClip":"DemonEndJump",
            "jumpClip":"DemonJump",
            "jumpBackClip":"DemonJumpBack",
            "breathClip":"DemonBreath",
            "clapClip":"DemonClap",
            "jetpack":"DemonJetpack",
            "jetpackStay":"DemonJetpackStay",
            "shocker":"ShockerUnit",
            "defrost":"HotShield",
            "antifrost":"AntiFrostShield",
            "defrostAttack":"AttackShield",
            "defrostArmory":"ArmoryShield",
            "hammer":"DemonHammerHit",
            "bat":"DemonBat",
            "rope":"DemonRope",
            "sadClip":"DemonSad",
            "hatClip":"hat",
            "earsClip":"ears",
            "eyesClip":"eyes",
            "leftHand":"leftHand",
            "rightHand":"rightHand",
            "graveType":"DemonGrave",
            "soulType":"BigSoul",
            "stateActions":["DemonWink","DemonWave","DemonHappy","DemonThinkDeath","DemonThinkPizza","DemonThinkGrenade","DemonThinkCoffee"],
            "stateActionsInHat":["DemonWink","DemonWave","DemonThinkDeath","DemonThinkPizza","DemonThinkGrenade","DemonThinkCoffee"],
            "happy":"DemonHappy",
            "damaged":"DemonBoom"
         });
         §§push({
            "id":4,
            "abilities":new <§_-T0§>[new §_-T0§("ABILITY_SPEED_NAME","ABILITY_SPEED_DESCR","rabbit_run"),new §_-T0§("ABILITY_REGEN_NAME","ABILITY_REGEN_DESCR","rabbit_regen")],
            "bonus":{"speed":6},
            "className":Rabbit,
            "configName":"rabbit",
            "fraction":1,
            "name":"RACE_RABBIT_NAME",
            "descr":"RACE_RABBIT_DESCR",
            "price":1600,
            "realprice":16,
            "requiredLevel":8,
            "stayClip":"RabbitStay",
            "goClip":"RabbitGo",
            "prepareToJumpClip":"RabbitPrepareToJump",
            "endJumpClip":"RabbitEndJump",
            "jumpClip":"RabbitJump",
            "jumpBackClip":"RabbitJumpBack",
            "breathClip":"RabbitBreath",
            "clapClip":"RabbitClap",
            "jetpack":"RabbitJetpack",
            "jetpackStay":"RabbitJetpackStay",
            "shocker":"ShockerUnit",
            "defrost":"HotShield",
            "antifrost":"AntiFrostShield",
            "defrostAttack":"AttackShield",
            "defrostArmory":"ArmoryShield",
            "hammer":"RabbitHammerHit",
            "bat":"RabbitBat",
            "rope":"RabbitRope",
            "sadClip":"RabbitSad",
            "hatClip":"hat",
            "earsClip":"ears",
            "eyesClip":"eyes",
            "leftHand":"leftHand",
            "rightHand":"rightHand",
            "graveType":"RabbitGrave",
            "soulType":"BigSoul",
            "stateActions":["RabbitWink","RabbitWave","RabbitHappy","RabbitThinkDeath","RabbitThinkPizza","RabbitThinkGrenade","RabbitThinkCoffee"],
            "stateActionsInHat":["RabbitWink","RabbitWave","RabbitThinkDeath","RabbitThinkPizza","RabbitThinkGrenade","RabbitThinkCoffee"],
            "happy":"RabbitHappy",
            "damaged":"RabbitBoom"
         });
         §§push("id");
         §§push(5);
         §§push("abilities");
         §§push(null);
         §§push({
            "id":6,
            "abilities":new <§_-T0§>[new §_-T0§("ABILITY_CLIMBING_NAME","ABILITY_CLIMBING_DESCR","cat_climbing"),new §_-T0§("ABILITY_PHASING_NAME","ABILITY_PHASING_DESCR","cat_phasing")],
            "className":Cat,
            "configName":"cat",
            "fraction":2,
            "name":"RACE_CAT_NAME",
            "descr":"RACE_CAT_DESCR",
            "price":2500,
            "realprice":25,
            "requiredLevel":12,
            "stayClip":"CatStay",
            "goClip":"CatGo",
            "prepareToJumpClip":"CatPrepareToJump",
            "endJumpClip":"CatEndJump",
            "jumpClip":"CatJump",
            "jumpBackClip":"CatJumpBack",
            "breathClip":"CatBreath",
            "clapClip":"CatClap",
            "jetpack":"CatJetpack",
            "jetpackStay":"CatJetpackStay",
            "shocker":"ShockerUnit",
            "defrost":"HotShield",
            "antifrost":"AntiFrostShield",
            "defrostAttack":"AttackShield",
            "defrostArmory":"ArmoryShield",
            "hammer":"CatHammerHit",
            "bat":"CatBat",
            "rope":"CatRope",
            "sadClip":"CatSad",
            "hatClip":"hat",
            "earsClip":"ears",
            "eyesClip":"eyes",
            "leftHand":"leftHand",
            "rightHand":"rightHand",
            "graveType":"CatGrave",
            "soulType":"BigSoul",
            "stateActions":["CatWink","CatWave","CatHappy","CatThinkDeath","CatThinkPizza","CatThinkGrenade","CatThinkCoffee"],
            "stateActionsInHat":["CatWink","CatWave","CatThinkDeath","CatThinkPizza","CatThinkGrenade","CatThinkCoffee"],
            "happy":"CatHappy",
            "damaged":"CatBoom",
            "climbs":"CatClimbs",
            "flying":"CatFlying"
         });
         §§push({
            "id":7,
            "abilities":new <§_-T0§>[new §_-T0§("ABILITY_FLYING_NAME","ABILITY_FLYING_DESCR","dragon_fly"),new §_-T0§("ABILITY_FIERY_PACE_NAME","ABILITY_FIERY_PACE_DESCR","dragon_fiery_pace")],
            "className":Dragon,
            "configName":"dragon",
            "fraction":2,
            "name":"RACE_DRAGON_NAME",
            "descr":"RACE_DRAGON_DESCR",
            "price":2600,
            "realprice":26,
            "requiredLevel":14,
            "staticClip":"DragonStatic",
            "stayClip":"DragonStay",
            "goClip":"DragonGo",
            "prepareToJumpClip":"DragonPrepareToJump",
            "endJumpClip":"DragonEndJump",
            "jumpClip":"DragonJump",
            "jumpBackClip":"DragonJumpBack",
            "breathClip":"DragonBreath",
            "clapClip":"DragonClap",
            "jetpack":"DragonJetpack",
            "jetpackStay":"DragonJetpackStay",
            "shocker":"ShockerUnit",
            "defrost":"HotShield",
            "antifrost":"AntiFrostShield",
            "defrostAttack":"AttackShield",
            "defrostArmory":"ArmoryShield",
            "bannerAura":"FlagAura",
            "darkAura":"DarkAura",
            "hammer":"DragonHammerHit",
            "bat":"DragonBat",
            "rope":"DragonRope",
            "sadClip":"DragonSad",
            "sadDownClip":"DragonSad",
            "sadUpClip":"DragonSad",
            "hatClip":"hat",
            "earsClip":"ears",
            "eyesClip":"eyes",
            "leftHand":"leftHand",
            "rightHand":"rightHand",
            "graveType":"DragonGrave",
            "soulType":"BigSoul",
            "stateActions":["DragonWink","DragonWave","DragonHappy","DragonThinkDeath","DragonThinkPizza","DragonThinkGrenade","DragonThinkCoffee"],
            "stateActionsInHat":["DragonWink","DragonWave","DragonThinkDeath","DragonThinkPizza","DragonThinkGrenade","DragonThinkCoffee"],
            "happy":"DragonHappy",
            "damaged":"DragonBoom"
         });
         §§push("id");
         §§push(8);
         §§push("abilities");
         §§pop().chars = null;
         super();
      }
   }
}

