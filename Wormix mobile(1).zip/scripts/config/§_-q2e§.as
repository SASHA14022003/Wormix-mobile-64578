package config
{
   import §_-31W§.§_-g16§;
   import §_-62§.§_-zF§;
   import §_-D3A§.*;
   import §_-H2g§.§_-di§;
   import §_-Y1O§.§_-V23§;
   import §_-YF§.§_-q2v§;
   import §_-l1g§.§_-L3Q§;
   import §_-w2i§.§_-Zd§;
   import com.greensock.*;
   import com.greensock.core.*;
   import feathers.controls.List;
   import flash.events.*;
   import flash.geom.Point;
   import flash.utils.Timer;
   import ru.pragmatix.flox.social.SocialAppContext;
   import ru.pragmatix.flox.social.controller.mobile.*;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.game.ai.§_-A1l§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Quad;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   
   public class §_-q2e§
   {
      
      public static const §_-v2A§:int = 0;
      
      public static const §_-7a§:Array = [{
         "id":§_-g16§.PVP_PLAYED,
         "name":§_-s2a§.§_-E27§
      },{
         "id":§_-g16§.PVP_WON,
         "name":§_-s2a§.§_-p1Z§
      },{
         "id":§_-g16§.PVP_DRAWS,
         "name":§_-s2a§.§_-429§
      },{
         "id":§_-g16§.MISSIONS_PLAYED,
         "name":§_-s2a§.§_-z1q§,
         "newGroup":true
      },{
         "id":§_-g16§.MISSIONS_WON,
         "name":§_-s2a§.§_-j2z§
      },{
         "id":§_-g16§.MISSIONS_EARNED,
         "name":§_-s2a§.§_-qC§,
         "newGroup":true
      },{
         "id":§_-g16§.SNIPER_SHOTS,
         "name":§_-s2a§.§_-42F§,
         "newGroup":true
      },{
         "id":§_-g16§.WIND_SHOTS,
         "name":§_-s2a§.§_-B2k§
      },{
         "id":§_-g16§.KILLED_BOXERS,
         "name":§_-s2a§.§_-H2z§,
         "newGroup":true
      },{
         "id":§_-g16§.KILLED_DEMONS,
         "name":§_-s2a§.§_-D1Q§
      },{
         "id":§_-g16§.KILLED_RABBITS,
         "name":§_-s2a§.§_-j2L§
      },{
         "id":§_-g16§.KILLED_CATS,
         "name":§_-s2a§.§_-422§
      },{
         "id":§_-g16§.KILLED_ZOMBIES,
         "name":§_-s2a§.§_-d1X§
      },{
         "id":§_-g16§.KILLED_REVIVED,
         "name":§_-s2a§.§_-022§
      },{
         "id":§_-g16§.KILLED_DRAGONS,
         "name":§_-s2a§.§_-Si§
      },{
         "id":§_-g16§.KILLED_BOTS,
         "name":§_-s2a§.§_-Jo§
      },{
         "id":§_-g16§.§_-71X§,
         "name":§_-s2a§.KILLED_TOTAL
      },{
         "id":§_-g16§.UNITS_LOST,
         "name":§_-s2a§.§_-s2b§
      },{
         "id":§_-g16§.COLLECTED_MEDKITS,
         "name":§_-s2a§.§_-935§,
         "newGroup":true
      },{
         "id":§_-g16§.COLLECTED_CRATES,
         "name":§_-s2a§.§_-91R§
      },{
         "id":§_-g16§.COLLECTED_STARS,
         "name":§_-s2a§.§_-W1e§
      },{
         "id":§_-g16§.DESTROYED_SUPPLIES,
         "name":§_-s2a§.§_-Zz§
      },{
         "id":§_-g16§.GRAVES_SANK,
         "name":§_-s2a§.§_-N1U§
      }];
      
      public function §_-q2e§()
      {
         super();
      }
   }
}

