package config
{
   import §_-82a§.*;
   import §_-YF§.§_-G2U§;
   import §_-Z1K§.§_-A2n§;
   import §_-Z1K§.§_-q24§;
   import §_-k2s§.§_-b0§;
   import §_-l1K§.§_-d2j§;
   import §_-p18§.§_-83X§;
   import §_-p18§.§_-V14§;
   import §_-r1C§.§_-U2p§;
   import §_-z1g§.§_-13d§;
   import feathers.core.ToggleGroup;
   import feathers.events.FeathersEventType;
   import flash.utils.IDataOutput;
   import ru.pragmatix.wormix.fx.UfoTargetPointer;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.scene.tile.AtlasTileData;
   import ru.pragmatix.wormix.weapons.ammo.Ufo;
   import starling.core.Starling;
   import starling.events.Event;
   import starling.textures.Texture;
   import starling.textures.TextureAtlas;
   import starling.utils.AssetManager;
   
   public class §_-x1p§
   {
      
      private static var §_-93H§:Array = [new §_-13d§(1,[]),new §_-13d§(2,[new §_-b0§(§_-q24§.UZI,1),new §_-b0§(§_-q24§.MINE,-1),new §_-b0§(§_-q24§.ROPE,-1)]),new §_-13d§(3,[new §_-b0§(§_-q24§.§_-f2f§,1),new §_-b0§(§_-q24§.DYNAMITE,1),new §_-b0§(§_-q24§.SHURIKEN,1)]),new §_-13d§(4,[new §_-b0§(§_-q24§.§_-K3z§,-1),new §_-b0§(§_-q24§.§_-82U§,1),new §_-b0§(§_-q24§.SHOTGUN,1)]),new §_-13d§(5,[new §_-b0§(§_-q24§.MINIGUN,1),new §_-b0§(§_-q24§.§_-B1§,2),new §_-b0§(§_-q24§.MORTAR,-1)]),new §_-13d§(6,[new §_-b0§(§_-q24§.HOMING_BAZOOKA,1),new §_-b0§(§_-q24§.GIRDER,1),new §_-b0§(§_-q24§.SHOCKER,1)]),new §_-13d§(7,[new §_-b0§(§_-q24§.PNEUMATIC_DRILL,1),new §_-b0§(§_-q24§.SWITCH_TURN,1),new §_-b0§(§_-q24§.CAT_BAZOOKA,1)]),new §_-13d§(8,[new §_-b0§(§_-q24§.SNIPER_RIFLE,1),new §_-b0§(§_-q24§.AIR_STRIKE,2)]),new §_-13d§(9,[new §_-b0§(§_-q24§.CROSSBOW,1),new §_-b0§(§_-q24§.ANTIFREEZE,2)]),new §_-13d§(10,[new §_-b0§(§_-q24§.JETPACK,1),new §_-b0§(§_-q24§.NAPALM,2)]),new §_-13d§(11,[new §_-b0§(§_-q24§.AK_47,1),new §_-b0§(§_-q24§
      .METEOR,2)]),new §_-13d§(12,[new §_-b0§(§_-q24§.§_-p2f§,1),new §_-b0§(§_-q24§.HOPPING_BAZOOKA,3)]),new §_-13d§(13,[new §_-b0§(§_-q24§.DISC_LAUNCHER,2)]),new §_-13d§(14,[new §_-b0§(§_-q24§.BAT,2)]),new §_-13d§(15,[new §_-b0§(§_-q24§.AIR_STRIKE,2)]),new §_-13d§(16,[new §_-b0§(§_-q24§.FIREWORK,2)]),new §_-13d§(17,[new §_-b0§(§_-q24§.BUNKER_BUSTER,2)]),new §_-13d§(18,[new §_-b0§(§_-q24§.§_-B1§,3)]),new §_-13d§(19,[new §_-b0§(§_-q24§.ANTIFREEZE,2)]),new §_-13d§(20,[new §_-b0§(§_-q24§.CAT_STRIKE,2)]),new §_-13d§(21,[new §_-b0§(§_-q24§.FORCE_FIELD,2)]),new §_-13d§(22,[new §_-b0§(§_-q24§.WATERMELON,2)]),new §_-13d§(23,[new §_-b0§(§_-q24§.HELICOPTER,3)]),new §_-13d§(24,[new §_-b0§(§_-q24§.FIREWORK,3)]),new §_-13d§(25,[new §_-b0§(§_-q24§.CAT_STRIKE,2)]),new §_-13d§(26,[new §_-b0§(§_-q24§.HELICOPTER,3)]),new §_-13d§(27,[new §_-b0§(§_-q24§.FORCE_FIELD,3)]),new §_-13d§(28,[new §_-b0§(§_-q24§.HOPPING_BAZOOKA,3)]),new §_-13d§(29,[new §_-b0§(§_-q24§.HELICOPTER,2)]),new §_-13d§(30,[new §_-b0§(§_-q24§.METEOR
      ,2)])];
      
      public function §_-x1p§()
      {
         super();
      }
      
      public static function §_-32k§(param1:uint) : §_-13d§
      {
         var _loc2_:§_-13d§ = null;
         for each(_loc2_ in §_-93H§)
         {
            if(param1 == _loc2_.getLevel())
            {
               return _loc2_;
            }
         }
         return new §_-13d§(param1,[]);
      }
      
      public static function §_-u2z§() : void
      {
         var _loc3_:§_-13d§ = null;
         var _loc4_:Vector.<§_-b0§> = null;
         var _loc5_:String = null;
         var _loc6_:§_-b0§ = null;
         var _loc1_:Vector.<int> = §_-A2n§.§_-83§();
         var _loc2_:String = "";
         for each(_loc3_ in §_-93H§)
         {
            _loc4_ = _loc3_.§_-53R§();
            _loc5_ = "";
            for each(_loc6_ in _loc4_)
            {
               if(_loc1_.indexOf(_loc6_.getId()) > -1)
               {
                  _loc5_ += (_loc5_ ? "," : "") + _loc6_.getId();
               }
            }
            if(_loc5_)
            {
               _loc2_ += _loc3_.getLevel() + ":" + _loc5_ + ";";
            }
         }
      }
   }
}

