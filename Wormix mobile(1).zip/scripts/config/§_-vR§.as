package config
{
   import §_-23U§.*;
   import §_-5Y§.*;
   import §_-62§.§_-a3§;
   import §_-91B§.§_-QK§;
   import §_-91B§.§_-z2l§;
   import §_-A1K§.§_-TA§;
   import §_-B2z§.Server;
   import §_-B2z§.§_-63i§;
   import §_-B2z§.§_-c1G§;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-73y§;
   import §_-DJ§.§_-fH§;
   import §_-J31§.§_-e2J§;
   import §_-L1H§.§_-b2K§;
   import §_-N8§.§_-2C§;
   import §_-N8§.§_-o2w§;
   import §_-TF§.§_-q1j§;
   import §_-Y1Q§.§_-aG§;
   import §_-Y1b§.§_-22N§;
   import §_-aM§.*;
   import §_-b1R§.§_-Bx§;
   import §_-gG§.§_-M2S§;
   import §_-gG§.§_-Z2z§;
   import §_-l1g§.§_-L3Q§;
   import §_-w2i§.§_-Ia§;
   import com.distriqt.extension.inappbilling.Purchase;
   import com.distriqt.extension.inappbilling.events.PurchaseEvent;
   import com.hurlant.crypto.tls.*;
   import com.mesmotronic.ane.AndroidFullScreen;
   import feathers.controls.LayoutGroup;
   import feathers.events.FeathersEventType;
   import flash.desktop.NativeApplication;
   import flash.system.Capabilities;
   import flash.text.TextField;
   import flash.text.TextFormat;
   import flash.utils.ByteArray;
   import flash.utils.Dictionary;
   import ru.pragmatix.flox.logger.§_-93v§;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.flox.social.utils.id.MobilePlatformAccountController;
   import ru.pragmatix.flox.social.utils.storage.EncryptedLocalStorageCookie;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.sets.ControlSets;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.§_-3m§;
   import ru.pragmatix.wormix.gui.menu.shop.§_-7D§;
   import ru.pragmatix.wormix.messages.clans.main.server.ClanInviteStructure;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.model.user.§_-r1d§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.pvp.messages.ex.BattleCreationFailure;
   import ru.pragmatix.wormix.pvp.messages.ex.CallToBattleResultType;
   import ru.pragmatix.wormix.pvp.messages.ex.CancelBattle;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.FreezingMissile;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Image;
   import starling.events.Event;
   import starling.extensions.ParticleAura;
   import starling.textures.Texture;
   import starling.utils.ScaleMode;
   
   public class §_-vR§
   {
      
      public static var §_-C36§:String;
      
      public static const WIDTH:int = 1920;
      
      public static const HEIGHT:int = 1080;
      
      public static const §_-Ik§:String = "pvp_url";
      
      public static const MOBILE_SOCIAL_USER_ID:String = MobilePlatformAccountController.MOBILE_SOCIAL_USER_ID;
      
      public static const USER_ID:String = "UserID";
      
      public static const §_-C1O§:String = "GameVersion";
      
      public function §_-vR§()
      {
         super();
      }
      
      public static function get protocolVersion() : String
      {
         return String("2.77.0.0");
      }
      
      public static function get §_-U0§() : String
      {
         return String("2.77.03");
      }
      
      public static function get §_-w2u§() : String
      {
         return §_-U0§ + (§_-P1l§ ? "-" + (§_-t1L§ ? §_-V24§ : "") : "");
      }
      
      public static function get §_-h1L§() : String
      {
         var _loc1_:String = "";
         return _loc1_ + (isSecure ? "" : ".unsc");
      }
      
      public static function get §_-q18§() : String
      {
         var _loc1_:String = §_-w2u§ + §_-h1L§;
         if(§_-I1D§)
         {
            _loc1_ = "test-" + _loc1_;
         }
         if(Capabilities.isDebugger)
         {
            _loc1_ = "debug-" + _loc1_;
         }
         return _loc1_;
      }
      
      public static function §_-g1L§() : String
      {
         return " (" + §_-s2a§.§_-K3t§(§_-s2a§.TITLE_VERSION) + " " + §_-w2u§ + ")";
      }
      
      public static function get facebookAppId() : String
      {
         return String(233852296749686);
      }
      
      public static function get facebookAppLinkURL() : String
      {
         return String("https://fb.me/732775443524033");
      }
      
      public static function get vkAppId() : String
      {
         return String(5611163);
      }
      
      public static function get §_-j2§() : String
      {
         return String("https://vk.com/app5611163");
      }
      
      public static function get appDownloadLink() : String
      {
         return String("https://play.google.com/store/apps/details?id=air.ru.pragmatix.wormix.mobile");
      }
      
      public static function get clubLink() : String
      {
         return String("market://details?id=air.ru.pragmatix.wormix.mobile");
      }
      
      public static function get §_-rc§() : String
      {
         return String("mobile");
      }
      
      public static function get §_-I1d§() : String
      {
         return String("android");
      }
      
      public static function get §_-P1l§() : Boolean
      {
         return §_-I1d§ == SocialType.MOBILE_ANDROID.name;
      }
      
      public static function get §_-13J§() : Boolean
      {
         return §_-I1d§ == SocialType.MOBILE_IOS.name;
      }
      
      public static function get §_-L1W§() : Server
      {
         return new Server(String("tesla.rmart.ru"),String("80").split(","),String("wormix_android_2.77.0"),String("wss"));
      }
      
      public static function get §_-wA§() : Server
      {
         return new Server(String("185.55.58.228"),String("60702").split(","),"","");
      }
      
      public static function get §_-92n§() : Server
      {
         return new Server(§_-fO§(),[§_-l1s§()],"","");
      }
      
      public static function get §_-73S§() : Boolean
      {
         return true;
      }
      
      public static function get §_-42H§() : Boolean
      {
         return true;
      }
      
      public static function get §_-HH§() : Boolean
      {
         return false;
      }
      
      public static function get §_-y1k§() : Boolean
      {
         return false;
      }
      
      public static function get §_-J3l§() : Boolean
      {
         return true;
      }
      
      public static function get §_-w2x§() : Boolean
      {
         return false;
      }
      
      public static function get §_-Sp§() : String
      {
         return String("");
      }
      
      public static function get §_-Ep§() : String
      {
         return String("market://details?id=air.ru.pragmatix.wormix.mobile");
      }
      
      public static function get §_-w2N§() : String
      {
         return String("https://ssl.rmart.ru/wormix_mobile/icons_production/");
      }
      
      public static function get §_-s5§() : String
      {
         return String("MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAi+gKYmWgVoT53VF5o2RHD6Gh2IET2R7AuFkFBzbIzGuwnRFIreCWGrS0tQ3H7uWxp91p7RB5dzuEsX7LisPmc09oIu3jlhTWseoyvrlOCs46+ymYoYINmY+eDmkQ6Y8NCXjGiVYCCE4+MAtU5qRvnZ4eIzJYZadTeISxS0j64OnI/jRKnSVpqYO3TkuXDimf8f7hCYs13ZKFJiLkRG1i6t58Mmc0MrkKimo7QpkCKBQcFmRchjky5xMezXAYR4+PX86JyTqymqJZEgnKKBK8B8ynkdGHSxCXc5rlhkGsXQdkMK5J+e+Myp6g8mYzZY/V7axCA9DEXdfT+p/HRXTZAQIDAQAB");
      }
      
      public static function get §_-61E§() : String
      {
         return String("821670409723");
      }
      
      public static function get §_-v2g§() : String
      {
         return String("http://markus.rmart.ru/wormix_facebook/achievements/");
      }
      
      public static function get §_-o7§() : String
      {
         return String("http://markus.rmart.ru/wormix_mobile/");
      }
      
      public static function get §_-pD§() : Boolean
      {
         return Boolean(false);
      }
      
      public static function get §_-I1D§() : Boolean
      {
         return false;
      }
      
      public static function get §_-s2R§() : String
      {
         return String("Wormix");
      }
      
      public static function get §_-t1L§() : String
      {
         return String("armv8");
      }
      
      public static function get §_-V24§() : String
      {
         return "x" + String("64");
      }
      
      public static function get isSecure() : Boolean
      {
         return Boolean(true);
      }
      
      public static function get fps() : int
      {
         return 60;
      }
      
      public static function get §_-52v§() : int
      {
         return Application.scene.sceneH / 75;
      }
      
      public static function §_-C1W§(param1:Object) : void
      {
      }
      
      public static function §_-m1J§() : void
      {
      }
      
      public static function §_-uA§(param1:String) : void
      {
      }
      
      public static function §_-C1w§(param1:String) : void
      {
      }
      
      public static function setUserId(param1:String) : void
      {
         var _loc2_:String = null;
         if(§_-vR§.§_-I1d§ == SocialType.MOBILE_IOS.name)
         {
            _loc2_ = EncryptedLocalStorageCookie.getStringValue(USER_ID);
            if(!_loc2_)
            {
               EncryptedLocalStorageCookie.setStringValue(USER_ID,param1);
            }
         }
      }
      
      public static function §_-fO§() : String
      {
         return §_-C36§ ? §_-C36§.split(":")[0] : "";
      }
      
      public static function §_-l1s§() : String
      {
         return §_-C36§ ? §_-C36§.split(":")[1] : "";
      }
      
      public static function §_-I2T§(param1:Dictionary) : void
      {
         var _loc2_:Array = null;
         var _loc3_:Server = null;
         §_-C36§ = param1[§_-Ik§];
         if(§_-C36§)
         {
            _loc2_ = §_-C36§.split(":");
            if(_loc2_.length == 2)
            {
               Server.§_-f1y§(§_-vR§.§_-92n§,§_-c1G§.PVP);
               _loc3_ = Server.§_-O2A§(§_-c1G§.PVP);
            }
         }
      }
   }
}

