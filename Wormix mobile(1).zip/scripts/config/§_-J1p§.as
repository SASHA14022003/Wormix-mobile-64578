package config
{
   import §_-D3A§.§_-TZ§;
   import §_-O2L§.§_-C3d§;
   import §_-O2L§.§_-X1T§;
   import §_-RE§.§_-52p§;
   import §_-ZP§.§_-w1J§;
   import §_-l1g§.§_-L3Q§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.game.§_-eX§;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   
   public class §_-J1p§
   {
      
      private static var §_-72Q§:Array = [{
         "id":4001,
         "quantity":20,
         "name":"cat_0",
         "folderName":"cat_0",
         "productId":§_-w1J§.STICKER_PACK_1
      },{
         "id":4002,
         "quantity":17,
         "name":"cat_1",
         "folderName":"cat_1",
         "productId":§_-w1J§.STICKER_PACK_2
      }];
      
      public function §_-J1p§()
      {
         super();
      }
      
      public static function get §_-q1O§() : Array
      {
         return §_-72Q§;
      }
   }
}

