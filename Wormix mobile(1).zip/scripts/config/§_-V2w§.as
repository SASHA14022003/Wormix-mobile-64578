package config
{
   import §_-5Y§.§_-Ma§;
   import §_-62§.§_-F1D§;
   import §_-73j§.§_-E3z§;
   import §_-91A§.*;
   import §_-A1K§.§_-TA§;
   import §_-A2U§.*;
   import §_-B1y§.§_-bs§;
   import §_-C2t§.§_-92W§;
   import §_-CR§.§_-02k§;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-F39§.§_-i1i§;
   import §_-G16§.*;
   import §_-K35§.§_-S18§;
   import §_-L1H§.§_-C3e§;
   import §_-T1t§.§_-u19§;
   import §_-Y1O§.§_-V23§;
   import §_-Y1b§.*;
   import §_-YF§.§_-q2v§;
   import §_-Z1K§.§_-q24§;
   import §_-aM§.*;
   import §_-d2p§.BuyEquipCraftDialog;
   import §_-hO§.AttackDodgedEvent;
   import §_-l1K§.§_-d2j§;
   import §_-l1g§.§_-L3Q§;
   import §_-qH§.§_-S25§;
   import §_-r1C§.§_-V1R§;
   import §_-r1C§.§_-t1R§;
   import §_-rM§.§_-61j§;
   import §_-s1Q§.Artifacts;
   import §_-u13§.MD5;
   import §_-u13§.SHA1;
   import §_-w2i§.§_-52k§;
   import §_-z20§.*;
   import com.greensock.TweenLite;
   import feathers.controls.LayoutGroup;
   import feathers.controls.Scroller;
   import feathers.core.ITextRenderer;
   import feathers.events.FeathersEventType;
   import feathers.layout.Direction;
   import flash.events.TimerEvent;
   import flash.geom.Point;
   import flash.geom.Rectangle;
   import flash.media.SoundTransform;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import ru.pragmatix.flox.social.SocialAppContext;
   import ru.pragmatix.flox.social.controller.SocialApiSettings;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.game.ai.§_-A1l§;
   import ru.pragmatix.wormix.game.ai.§_-de§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.screenOverlay.view.*;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.model.§_-4V§;
   import ru.pragmatix.wormix.model.items.craft.CraftedEquipFamily;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-r1d§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F1r§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.social.§_-L23§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.weapons.ammo.Ufo;
   import starling.animation.Transitions;
   import starling.animation.Tween;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.textures.Texture;
   import starling.utils.Pool;
   
   public class §_-V2w§
   {
      
      public static const §_-h2§:int = 0;
      
      public static const §_-h2F§:int = 0;
      
      public static const §_-331§:int = 1000;
      
      public static const §_-M2J§:int = 2000;
      
      public static const §_-529§:int = 4000;
      
      public static const §_-T2v§:int = 5000;
      
      public static const §_-tu§:int = 10000;
      
      public function §_-V2w§()
      {
         super();
      }
      
      public static function §_-q1F§(param1:int) : Boolean
      {
         return §_-k2o§(param1,§_-331§);
      }
      
      public static function §_-Q2a§(param1:int) : Boolean
      {
         return §_-k2o§(param1,§_-M2J§);
      }
      
      public static function §_-13I§(param1:int) : Boolean
      {
         return §_-k2o§(param1,§_-h2§);
      }
      
      public static function §_-613§(param1:int) : Boolean
      {
         return §_-k2o§(param1,§_-529§);
      }
      
      public static function §_-y2r§(param1:int) : Boolean
      {
         return §_-k2o§(param1,§_-h2F§);
      }
      
      public static function §_-L2o§(param1:int) : Boolean
      {
         return §_-k2o§(param1,§_-T2v§);
      }
      
      public static function §_-em§(param1:int) : Boolean
      {
         return §_-k2o§(param1,§_-tu§);
      }
      
      public static function §_-5H§(param1:int) : int
      {
         return param1 - §_-tu§;
      }
      
      private static function §_-k2o§(param1:int, param2:int) : Boolean
      {
         return param2 <= param1 && param1 < param2 + 1000;
      }
   }
}

