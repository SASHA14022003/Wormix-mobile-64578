package config
{
   import §_-31W§.§_-Kb§;
   import §_-31W§.§_-Y1v§;
   import §_-31W§.§_-aO§;
   import §_-31W§.§_-r26§;
   import §_-5P§.*;
   import §_-62§.§_-F1D§;
   import §_-62§.§_-G1p§;
   import §_-A1m§.*;
   import §_-A2U§.§_-A23§;
   import §_-CF§.§_-x2t§;
   import §_-DJ§.MessageBox;
   import §_-DJ§.§_-fH§;
   import §_-Ly§.§_-81L§;
   import §_-P2i§.§_-b7§;
   import §_-T1t§.§_-u19§;
   import §_-Y1O§.*;
   import §_-YF§.§_-q2v§;
   import §_-j1w§.§_-B2i§;
   import §_-l1g§.§_-L3Q§;
   import §_-qH§.§_-S25§;
   import §_-r1C§.§_-h2B§;
   import §_-s1Q§.Artifacts;
   import §_-u13§.MD5;
   import §_-u13§.SHA1;
   import §_-z1g§.§_-4l§;
   import §_-z20§.*;
   import §_-zI§.§_-92Q§;
   import §_-zI§.§_-F3q§;
   import §_-zI§.§_-X1q§;
   import §_-zI§.§_-sI§;
   import com.greensock.loading.*;
   import feathers.events.FeathersEventType;
   import flash.display.Bitmap;
   import flash.display.BitmapData;
   import flash.events.Event;
   import flash.utils.ByteArray;
   import ru.pragmatix.flox.social.controller.ISocialController;
   import ru.pragmatix.flox.social.controller.SocialApiSettings;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.game.§_-eX§;
   import ru.pragmatix.wormix.gui.§_-F2n§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.structures.ClanMemberTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.server.EnterAccount;
   import ru.pragmatix.wormix.messages.structures.LoginAwardStructure;
   import ru.pragmatix.wormix.messages.structures.WeaponStructure;
   import ru.pragmatix.wormix.model.items.craft.§_-IE§;
   import ru.pragmatix.wormix.model.rewards.§_-qU§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.objects.§_-V1L§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.pvp.messages.server.PvpEndBattle;
   import ru.pragmatix.wormix.pvp.messages.server.PvpRetryCommandRequestServer;
   import ru.pragmatix.wormix.pvp.messages.server.PvpStartTurn;
   import ru.pragmatix.wormix.pvp.messages.server.PvpSystemMessage;
   import ru.pragmatix.wormix.utils.StringUtil;
   import ru.pragmatix.wormix.utils.§_-6A§;
   import ru.pragmatix.wormix.utils.§_-Cq§;
   import starling.core.Starling;
   import starling.display.Image;
   import starling.events.Event;
   import starling.textures.Texture;
   
   public class §_-xD§
   {
      
      public static const §_-Cr§:Object = {
         "battle":[new §_-Y1v§(§_-r26§.§_-GB§,§_-s2a§.ACHIEV_WAGER_WINNER_DESCR,[new §_-Kb§(§_-s2a§.ACHIEV_WAGER_WINNER_1LEVEL_TITLE,{
            "type":§_-aO§.REACTION.value,
            "count":5
         },50,§_-q2v§.WINNER,80),new §_-Kb§(§_-s2a§.ACHIEV_WAGER_WINNER_2LEVEL_TITLE,{
            "type":§_-aO§.REACTION.value,
            "count":10
         },400,§_-q2v§.§_-e2t§,90),new §_-Kb§(§_-s2a§.ACHIEV_WAGER_WINNER_3LEVEL_TITLE,{
            "type":§_-aO§.REACTION.value,
            "count":20
         },1000,§_-q2v§.§_-x11§,100)]),new §_-Y1v§(§_-r26§.§_-M29§,§_-s2a§.ACHIEV_DESTROYED_SQUARE_DESCR,[new §_-Kb§(§_-s2a§.ACHIEV_DESTROYED_SQUARE_1LEVEL_TITLE,{
            "type":§_-aO§.REACTION.value,
            "count":10
         },1000,§_-q2v§.§_-CM§,60),new §_-Kb§(§_-s2a§.ACHIEV_DESTROYED_SQUARE_2LEVEL_TITLE,{
            "type":§_-aO§.REACTION.value,
            "count":15
         },10000,§_-q2v§.§_-612§,70),new §_-Kb§(§_-s2a§.ACHIEV_DESTROYED_SQUARE_3LEVEL_TITLE,{
            "type":§_-aO§.§_-Mu§.value,
            "count":5
         },30000,§_-q2v§.§_-L1n§,80)]),new §_-Y1v§(§_-r26§.§_-h1B§,§_-s2a§.ACHIEV_GATHERED_SUPPLIES_DESCR,[new §_-Kb§(§_-s2a§.ACHIEV_GATHERED_SUPPLIES_1LEVEL_TITLE,{
            "type":§_-aO§.REACTION.value,
            "count":10
         },100,§_-q2v§.§_-f5§,45),new §_-Kb§(§_-s2a§.ACHIEV_GATHERED_SUPPLIES_2LEVEL_TITLE,{
            "type":§_-aO§.§_-Mu§.value,
            "count":3
         },350,§_-q2v§.§_-A3y§,55),new §_-Kb§(§_-s2a§.ACHIEV_GATHERED_SUPPLIES_3LEVEL_TITLE,{
            "type":§_-aO§.REACTION.value,
            "count":20
         },800,§_-q2v§.§_-93N§,65)]),new §_-Y1v§(§_-r26§.§_-L2w§,§_-s2a§.ACHIEV_DROWNED_OPPONENTS_DESCR,[new §_-Kb§(§_-s2a§.ACHIEV_DROWNED_OPPONENTS_1LEVEL_TITLE,{
            "type":§_-aO§.REACTION.value,
            "count":3
         },50,§_-q2v§.§_-63a§,45),new §_-Kb§(§_-s2a§.ACHIEV_DROWNED_OPPONENTS_2LEVEL_TITLE,{
            "type":§_-aO§.REACTION.value,
            "count":5
         },250,§_-q2v§.§_-720§,60),new §_-Kb§(§_-s2a§.ACHIEV_DROWNED_OPPONENTS_3LEVEL_TITLE,{
            "type":§_-aO§.REACTION.value,
            "count":10
         },600,§_-q2v§.§_-X1v§,75)]),new §_-Y1v§(§_-r26§.GRAVES_SANK,§_-s2a§.ACHIEV_GRAVES_SANK_DESCR,[new §_-Kb§(§_-s2a§.ACHIEV_GRAVES_SANK_1LEVEL_TITLE,{
            "type":§_-aO§.§_-J2y§.value,
            "count":50
         },25,§_-q2v§.§_-Y2e§,50),new §_-Kb§(§_-s2a§.ACHIEV_GRAVES_SANK_2LEVEL_TITLE,{
            "type":§_-aO§.§_-J2y§.value,
            "count":100
         },80,§_-q2v§.§_-f1B§,60),new §_-Kb§(§_-s2a§.ACHIEV_GRAVES_SANK_3LEVEL_TITLE,{
            "type":§_-aO§.REACTION.value,
            "count":10
         },200,§_-q2v§.§_-6c§,70)]),new §_-Y1v§(§_-r26§.§_-B2b§,§_-s2a§.ACHIEV_DOUBLE_KILLLS_DESCR,[new §_-Kb§(§_-s2a§.ACHIEV_DOUBLE_KILLLS_1LEVEL_TITLE,{
            "type":§_-aO§.REACTION.value,
            "count":3
         },20,§_-q2v§.§_-i1x§,50),new §_-Kb§(§_-s2a§.ACHIEV_DOUBLE_KILLLS_2LEVEL_TITLE,{
            "type":§_-aO§.§_-J2y§.value,
            "count":150
         },100,§_-q2v§.§_-b2Q§,60),new §_-Kb§(§_-s2a§.ACHIEV_DOUBLE_KILLLS_3LEVEL_TITLE,{
            "type":§_-aO§.REACTION.value,
            "count":10
         },250,§_-q2v§.§_-31A§,70)]),new §_-Y1v§(§_-r26§.KAMIKAZE,§_-s2a§.ACHIEV_KAMIKAZE_DESCR,[new §_-Kb§(§_-s2a§.ACHIEV_KAMIKAZE_1LEVEL_TITLE,{
            "type":§_-aO§.REACTION.value,
            "count":3
         },25,§_-q2v§.KAMIKADZE,45),new §_-Kb§(§_-s2a§.ACHIEV_KAMIKAZE_2LEVEL_TITLE,{
            "type":§_-aO§.§_-J2y§.value,
            "count":150
         },100,§_-q2v§.§_-e20§,55),new §_-Kb§(§_-s2a§.ACHIEV_KAMIKAZE_3LEVEL_TITLE,{
            "type":§_-aO§.REACTION.value,
            "count":10
         },250,§_-q2v§.§_-Vf§,65)]),new §_-Y1v§(§_-r26§.§_-r1W§,§_-s2a§.ACHIEV_FLAWLESS_VICTORIES,[new §_-Kb§(§_-s2a§.ACHIEV_FLAWLESS_VICTORIES_1LEVEL_TITLE,{
            "type":§_-aO§.§_-J2y§.value,
            "count":150
         },50,§_-q2v§.§_-42w§,60),new §_-Kb§(§_-s2a§.ACHIEV_FLAWLESS_VICTORIES_2LEVEL_TITLE,{
            "type":§_-aO§.REACTION.value,
            "count":10
         },250,§_-q2v§.§_-43D§,70),new §_-Kb§(§_-s2a§.ACHIEV_FLAWLESS_VICTORIES_3LEVEL_TITLE,{
            "type":§_-aO§.REACTION.value,
            "count":20
         },1000,§_-q2v§.§_-021§,80)]),new §_-Y1v§(§_-r26§.§_-cV§,§_-s2a§.ACHIEV_BURNED_ENEMIES_DESCR,[new §_-Kb§(§_-s2a§.ACHIEV_BURNED_ENEMIES_1LEVEL_TITLE,{
            "type":§_-aO§.REACTION.value,
            "count":3
         },50,§_-q2v§.§_-T1U§,50),new §_-Kb§(§_-s2a§.ACHIEV_BURNED_ENEMIES_2LEVEL_TITLE,{
            "type":§_-aO§.REACTION.value,
            "count":5
         },200,§_-q2v§.§_-Z26§,60),new §_-Kb§(§_-s2a§.ACHIEV_BURNED_ENEMIES_3LEVEL_TITLE,{
            "type":§_-aO§.REACTION.value,
            "count":10
         },500,§_-q2v§.§_-g1I§,70)]),new §_-Y1v§(§_-r26§.MASSIVE_DAMAGE,§_-s2a§.ACHIEV_MASSIVE_DAMAGE_DESCR,[new §_-Kb§(§_-s2a§.ACHIEV_MASSIVE_DAMAGE_1LEVEL_TITLE,{
            "type":§_-aO§.REACTION.value,
            "count":3
         },20,§_-q2v§.§_-D2m§,60),new §_-Kb§(§_-s2a§.ACHIEV_MASSIVE_DAMAGE_2LEVEL_TITLE,{
            "type":§_-aO§.§_-J2y§.value,
            "count":150
         },100,§_-q2v§.§_-BL§,65),new §_-Kb§(§_-s2a§.ACHIEV_MASSIVE_DAMAGE_3LEVEL_TITLE,{
            "type":§_-aO§.REACTION.value,
            "count":10
         },250,§_-q2v§.§_-BT§,70)]),new §_-Y1v§(§_-r26§.§_-21t§,§_-s2a§.ACHIEV_MEDKIT_KILLS_DESCR,[new §_-Kb§(§_-s2a§.ACHIEV_MEDKIT_KILLS_1LEVEL_TITLE,{
            "type":§_-aO§.§_-J2y§.value,
            "count":75
         },15,§_-q2v§.§_-q1W§,60),new §_-Kb§(§_-s2a§.ACHIEV_MEDKIT_KILLS_2LEVEL_TITLE,{
            "type":§_-aO§.§_-J2y§.value,
            "count":150
         },40,§_-q2v§.§_-rj§,70),new §_-Kb§(§_-s2a§.ACHIEV_MEDKIT_KILLS_3LEVEL_TITLE,{
            "type":§_-aO§.§_-Mu§.value,
            "count":3
         },75,§_-q2v§.§_-cG§,80)]),new §_-Y1v§(§_-r26§.§_-2x§,§_-s2a§.ACHIEV_WIND_KILLS_DESCR,[new §_-Kb§(§_-s2a§.ACHIEV_WIND_KILLS_1LEVEL_TITLE,{
            "type":§_-aO§.§_-J2y§.value,
            "count":100
         },20,§_-q2v§.§_-X2C§,60),new §_-Kb§(§_-s2a§.ACHIEV_WIND_KILLS_2LEVEL_TITLE,{
            "type":§_-aO§.REACTION.value,
            "count":5
         },75,§_-q2v§.§_-ME§,65),new §_-Kb§(§_-s2a§.ACHIEV_WIND_KILLS_3LEVEL_TITLE,{
            "type":§_-aO§.REACTION.value,
            "count":10
         },200,§_-q2v§.§_-11B§,70)]),new §_-Y1v§(§_-r26§.§_-RR§,§_-s2a§.ACHIEV_IMMOBILE_KILLS_DESCR,[new §_-Kb§(§_-s2a§.ACHIEV_IMMOBILE_KILLS_1LEVEL_TITLE,{
            "type":§_-aO§.§_-J2y§.value,
            "count":120
         },20,§_-q2v§.§_-K2J§,60),new §_-Kb§(§_-s2a§.ACHIEV_IMMOBILE_KILLS_2LEVEL_TITLE,{
            "type":§_-aO§.REACTION.value,
            "count":7
         },50,§_-q2v§.§_-b1v§,65),new §_-Kb§(§_-s2a§.ACHIEV_IMMOBILE_KILLS_3LEVEL_TITLE,{
            "type":§_-aO§.REACTION.value,
            "count":15
         },150,§_-q2v§.§_-Xz§,70)]),new §_-Y1v§(§_-r26§.§_-R1y§,§_-s2a§.ACHIEV_ONE_HP_WIN_DESCR,[new §_-Kb§(§_-s2a§.ACHIEV_ONE_HP_WIN_1LEVEL_TITLE,{
            "type":§_-aO§.§_-Mu§.value,
            "count":1
         },2,§_-q2v§.§_-K0§,70),new §_-Kb§(§_-s2a§.ACHIEV_ONE_HP_WIN_2LEVEL_TITLE,{
            "type":§_-aO§.§_-Mu§.value,
            "count":2
         },4,§_-q2v§.LUCKY2,80),new §_-Kb§(§_-s2a§.ACHIEV_ONE_HP_WIN_3LEVEL_TITLE,{
            "type":§_-aO§.§_-Mu§.value,
            "count":3
         },6,§_-q2v§.§_-r1r§,90)]),new §_-Y1v§(§_-r26§.§_-n2M§,§_-s2a§.ACHIEV_DIPLOMAT_DESCR,[new §_-Kb§(§_-s2a§.ACHIEV_DIPLOMAT_1LEVEL_TITLE,{
            "type":§_-aO§.§_-J2y§.value,
            "count":100
         },5,§_-q2v§.§_-120§,60),new §_-Kb§(§_-s2a§.ACHIEV_DIPLOMAT_2LEVEL_TITLE,{
            "type":§_-aO§.§_-J2y§.value,
            "count":150
         },10,§_-q2v§.§_-n2M§,70),new §_-Kb§(§_-s2a§.ACHIEV_DIPLOMAT_3LEVEL_TITLE,{
            "type":§_-aO§.§_-J2y§.value,
            "count":200
         },15,§_-q2v§.§_-V20§,80)]),new §_-Y1v§(§_-r26§.§_-K33§,§_-s2a§.ACHIEV_ROPED_MILES_DESCR,[new §_-Kb§(§_-s2a§.ACHIEV_ROPED_MILES_1LEVEL_TITLE,{
            "type":§_-aO§.§_-J2y§.value,
            "count":40
         },200,§_-q2v§.§_-i2R§,50),new §_-Kb§(§_-s2a§.ACHIEV_ROPED_MILES_2LEVEL_TITLE,{
            "type":§_-aO§.§_-J2y§.value,
            "count":80
         },800,§_-q2v§.§_-X2p§,55),new §_-Kb§(§_-s2a§.ACHIEV_ROPED_MILES_3LEVEL_TITLE,{
            "type":§_-aO§.§_-J2y§.value,
            "count":120
         },2000,§_-q2v§.§_-s2l§,60)]),new §_-Y1v§(§_-r26§.§_-AH§,§_-s2a§.ACHIEV_FLEW_MILES_DESCR,[new §_-Kb§(§_-s2a§.ACHIEV_FLEW_MILES_1LEVEL_TITLE,{
            "type":§_-aO§.§_-J2y§.value,
            "count":40
         },1500,§_-q2v§.§_-k2D§,50),new §_-Kb§(§_-s2a§.ACHIEV_FLEW_MILES_2LEVEL_TITLE,{
            "type":§_-aO§.§_-J2y§.value,
            "count":80
         },3500,§_-q2v§.§_-c0§,60),new §_-Kb§(§_-s2a§.ACHIEV_FLEW_MILES_3LEVEL_TITLE,{
            "type":§_-aO§.§_-J2y§.value,
            "count":120
         },8000,§_-q2v§.ACE,70)]),new §_-Y1v§(§_-r26§.§_-R1k§,§_-s2a§.ACHIEV_DROP_WATER_DESCR,[new §_-Kb§(§_-s2a§.ACHIEV_DROP_WATER_1LEVEL_TITLE,{
            "type":§_-aO§.§_-J2y§.value,
            "count":50
         },30,§_-q2v§.§_-n1I§,45),new §_-Kb§(§_-s2a§.ACHIEV_DROP_WATER_2LEVEL_TITLE,{
            "type":§_-aO§.§_-J2y§.value,
            "count":100
         },80,§_-q2v§.§_-x28§,55),new §_-Kb§(§_-s2a§.ACHIEV_DROP_WATER_3LEVEL_TITLE,{
            "type":§_-aO§.REACTION.value,
            "count":10
         },200,§_-q2v§.§_-kI§,65)]),new §_-Y1v§(§_-r26§.§_-91c§,§_-s2a§.ACHIEV_KILL_WALKING_ZOMBIES_DESCR,[new §_-Kb§(§_-s2a§.ACHIEV_KILL_WALKING_ZOMBIES_1LEVEL_TITLE,{
            "type":§_-aO§.REACTION.value,
            "count":5
         },15,§_-q2v§.§_-a1P§,50),new §_-Kb§(§_-s2a§.ACHIEV_KILL_WALKING_ZOMBIES_2LEVEL_TITLE,{
            "type":§_-aO§.§_-J2y§.value,
            "count":80
         },50,§_-q2v§.§_-l1d§,60),new §_-Kb§(§_-s2a§.ACHIEV_KILL_WALKING_ZOMBIES_3LEVEL_TITLE,{
            "type":§_-aO§.§_-J2y§.value,
            "count":150
         },100,§_-q2v§.§_-W1d§,70)]),new §_-Y1v§(§_-r26§.§_-l2C§,§_-s2a§.ACHIEV_WEAR_HATS_DESCR,[new §_-Kb§(§_-s2a§.ACHIEV_KILL_WEAR_HATS_1LEVEL_TITLE,{
            "type":§_-aO§.§_-J2y§.value,
            "count":70
         },50,§_-q2v§.§_-13g§,60),new §_-Kb§(§_-s2a§.ACHIEV_KILL_WEAR_HATS_2LEVEL_TITLE,{
            "type":§_-aO§.§_-J2y§.value,
            "count":120
         },300,§_-q2v§.§_-72§,70),new §_-Kb§(§_-s2a§.ACHIEV_KILL_WEAR_HATS_3LEVEL_TITLE,{
            "type":§_-aO§.§_-Mu§.value,
            "count":3
         },800,§_-q2v§.§_-BW§,80)]),new §_-Y1v§(§_-r26§.§_-Uo§,§_-s2a§.ACHIEV_PARTISAN_DESCR,[new §_-Kb§(§_-s2a§.ACHIEV_PARTISAN_1LEVEL_TITLE,{
            "type":§_-aO§.§_-J2y§.value,
            "count":80
         },5,§_-q2v§.PARTISAN_LVL_1,60),new §_-Kb§(§_-s2a§.ACHIEV_PARTISAN_2LEVEL_TITLE,{
            "type":§_-aO§.REACTION.value,
            "count":10
         },20,§_-q2v§.PARTISAN_LVL_2,70),new §_-Kb§(§_-s2a§.ACHIEV_PARTISAN_3LEVEL_TITLE,{
            "type":§_-aO§.§_-Mu§.value,
            "count":3
         },50,§_-q2v§.PARTISAN_LVL_3,80)]),new §_-Y1v§(§_-r26§.§_-61y§,§_-s2a§.ACHIEV_COLLECTOR_DESCR,[new §_-Kb§(§_-s2a§.ACHIEV_COLLECTOR_1LEVEL_TITLE,{
            "type":§_-aO§.§_-J2y§.value,
            "count":70
         },25,§_-q2v§.COLLECTOR_LVL_1,60),new §_-Kb§(§_-s2a§.ACHIEV_COLLECTOR_2LEVEL_TITLE,{
            "type":§_-aO§.§_-J2y§.value,
            "count":120
         },70,§_-q2v§.COLLECTOR_LVL_2,65),new §_-Kb§(§_-s2a§.ACHIEV_COLLECTOR_3LEVEL_TITLE,{
            "type":§_-aO§.§_-Mu§.value,
            "count":3
         },150,§_-q2v§.COLLECTOR_LVL_3,70)]),new §_-Y1v§(§_-r26§.§_-K1B§,§_-s2a§.ACHIEV_DROP_WATER_FIRST_TURN_DESCR,[new §_-Kb§(§_-s2a§.ACHIEV_DROP_WATER_FIRST_TURN_1LEVEL_TITLE,{
            "type":§_-aO§.§_-J2y§.value,
            "count":50
         },5,§_-q2v§.DROP_WATER_FIRST_TURN_LVL_1,50),new §_-Kb§(§_-s2a§.ACHIEV_DROP_WATER_FIRST_TURN_2LEVEL_TITLE,{
            "type":§_-aO§.§_-J2y§.value,
            "count":150
         },30,§_-q2v§.DROP_WATER_FIRST_TURN_LVL_2,60),new §_-Kb§(§_-s2a§.ACHIEV_DROP_WATER_FIRST_TURN_3LEVEL_TITLE,{
            "type":§_-aO§.REACTION.value,
            "count":30
         },100,§_-q2v§.DROP_WATER_FIRST_TURN_LVL_3,70)]),new §_-Y1v§(§_-r26§.§_-l2m§,§_-s2a§.ACHIEV_COOP_FRIEND_WINNER_DESCR,[new §_-Kb§(§_-s2a§.ACHIEV_COOP_FRIEND_WINNER_1LEVEL_TITLE,{
            "type":§_-aO§.§_-J2y§.value,
            "count":80
         },20,§_-q2v§.COOP_FRIEND_WINNER_LVL_1,70),new §_-Kb§(§_-s2a§.ACHIEV_COOP_FRIEND_WINNER_2LEVEL_TITLE,{
            "type":§_-aO§.REACTION.value,
            "count":20
         },100,§_-q2v§.COOP_FRIEND_WINNER_LVL_2,80),new §_-Kb§(§_-s2a§.ACHIEV_COOP_FRIEND_WINNER_3LEVEL_TITLE,{
            "type":§_-aO§.REACTION.value,
            "count":40
         },400,§_-q2v§.COOP_FRIEND_WINNER_LVL_3,90)])],
         "game":[new §_-Y1v§(§_-r26§.§_-wy§,§_-s2a§.ACHIEV_GAME_VISITS_DESCR,[new §_-Kb§(§_-s2a§.ACHIEV_GAME_VISITS_1LEVEL_TITLE,{
            "type":§_-aO§.§_-J2y§.value,
            "count":200
         },5,§_-q2v§.§_-812§,100),new §_-Kb§(§_-s2a§.ACHIEV_GAME_VISITS_2LEVEL_TITLE,{
            "type":§_-aO§.REACTION.value,
            "count":20
         },10,§_-q2v§.§_-rk§,150),new §_-Kb§(§_-s2a§.ACHIEV_GAME_VISITS_3LEVEL_TITLE,{
            "type":§_-aO§.§_-Mu§.value,
            "count":5
         },20,§_-q2v§.§_-z1i§,300)]),new §_-Y1v§(§_-r26§.§_-T20§,§_-s2a§.ACHIEV_FUZZES_SPENT_DESCR,[new §_-Kb§(§_-s2a§.ACHIEV_FUZZES_SPENT_1LEVEL_TITLE,{
            "type":§_-aO§.REACTION.value,
            "count":10
         },10000,§_-q2v§.§_-y2f§,50),new §_-Kb§(§_-s2a§.ACHIEV_FUZZES_SPENT_2LEVEL_TITLE,{
            "type":§_-aO§.REACTION.value,
            "count":25
         },25000,§_-q2v§.§_-02u§,70),new §_-Kb§(§_-s2a§.ACHIEV_FUZZES_SPENT_3LEVEL_TITLE,{
            "type":§_-aO§.REACTION.value,
            "count":50
         },60000,§_-q2v§.§_-91p§,90)]),new §_-Y1v§(§_-r26§.§_-b22§,§_-s2a§.ACHIEV_RUBIES_SPENT_DESCR,[new §_-Kb§(§_-s2a§.ACHIEV_RUBIES_SPENT_1LEVEL_TITLE,{
            "type":§_-aO§.§_-Mu§.value,
            "count":5
         },100,§_-q2v§.§_-C1v§,80),new §_-Kb§(§_-s2a§.ACHIEV_RUBIES_SPENT_2LEVEL_TITLE,{
            "type":§_-aO§.REACTION.value,
            "count":40
         },300,§_-q2v§.§_-Rp§,100),new §_-Kb§(§_-s2a§.ACHIEV_RUBIES_SPENT_3LEVEL_TITLE,{
            "type":§_-aO§.REACTION.value,
            "count":80
         },800,§_-q2v§.§_-43G§,150)]),new §_-Y1v§(§_-r26§.§_-S2§,§_-s2a§.ACHIEV_PUMPED_REACTION_DESCR,[new §_-Kb§(§_-s2a§.ACHIEV_PUMPED_REACTION_1LEVEL_TITLE,{
            "type":§_-aO§.§_-J2y§.value,
            "count":50
         },100,§_-q2v§.§_-v2X§,50),new §_-Kb§(§_-s2a§.ACHIEV_PUMPED_REACTION_2LEVEL_TITLE,{
            "type":§_-aO§.§_-J2y§.value,
            "count":100
         },250,§_-q2v§.§_-s8§,55),new §_-Kb§(§_-s2a§.ACHIEV_PUMPED_REACTION_3LEVEL_TITLE,{
            "type":§_-aO§.§_-J2y§.value,
            "count":200
         },1000,§_-q2v§.§_-eF§,60)]),new §_-Y1v§(§_-r26§.RUBIES_FOUND,§_-s2a§.ACHIEV_RUBIES_FOUND_DESCR,[new §_-Kb§(§_-s2a§.ACHIEV_RUBIES_FOUND_1LEVEL_TITLE,{
            "type":§_-aO§.REACTION.value,
            "count":3
         },10,§_-q2v§.§_-nm§,50),new §_-Kb§(§_-s2a§.ACHIEV_RUBIES_FOUND_2LEVEL_TITLE,{
            "type":§_-aO§.REACTION.value,
            "count":6
         },25,§_-q2v§.§_-01V§,60),new §_-Kb§(§_-s2a§.ACHIEV_RUBIES_FOUND_3LEVEL_TITLE,{
            "type":§_-aO§.REACTION.value,
            "count":12
         },50,§_-q2v§.§_-31L§,70)]),new §_-Y1v§(§_-r26§.§_-HX§,§_-s2a§.ACHIEV_MADE_PHOTO_DESCR,[new §_-Kb§(§_-s2a§.ACHIEV_MADE_PHOTO_1LEVEL_TITLE,{
            "type":§_-aO§.§_-J2y§.value,
            "count":40
         },10,§_-q2v§.§_-32K§,40),new §_-Kb§(§_-s2a§.ACHIEV_MADE_PHOTO_2LEVEL_TITLE,{
            "type":§_-aO§.§_-J2y§.value,
            "count":80
         },25,§_-q2v§.§_-q1d§,50),new §_-Kb§(§_-s2a§.ACHIEV_MADE_PHOTO_3LEVEL_TITLE,{
            "type":§_-aO§.§_-J2y§.value,
            "count":120
         },100,§_-q2v§.§_-81j§,60)]),new §_-Y1v§(§_-r26§.§_-93q§,§_-s2a§.ACHIEV_MADE_VIDEO_DESCR,[new §_-Kb§(§_-s2a§.ACHIEV_MADE_VIDEO_1LEVEL_TITLE,{
            "type":§_-aO§.§_-J2y§.value,
            "count":40
         },5,§_-q2v§.§_-O1p§,40),new §_-Kb§(§_-s2a§.ACHIEV_MADE_VIDEO_2LEVEL_TITLE,{
            "type":§_-aO§.§_-J2y§.value,
            "count":80
         },10,§_-q2v§.§_-K2k§,50),new §_-Kb§(§_-s2a§.ACHIEV_MADE_VIDEO_3LEVEL_TITLE,{
            "type":§_-aO§.§_-J2y§.value,
            "count":120
         },30,§_-q2v§.§_-B1A§,60)]),new §_-Y1v§(§_-r26§.§_-41k§,§_-s2a§.ACHIEV_WEAPONS_UPGRADE_DESCR,[new §_-Kb§(§_-s2a§.ACHIEV_WEAPONS_UPGRADE_1LEVEL_TITLE,{
            "type":§_-aO§.§_-Mu§.value,
            "count":1
         },5,§_-q2v§.WEAPONS_UPGRADE_LVL_1,60),new §_-Kb§(§_-s2a§.ACHIEV_WEAPONS_UPGRADE_2LEVEL_TITLE,{
            "type":§_-aO§.§_-J2y§.value,
            "count":150
         },15,§_-q2v§.WEAPONS_UPGRADE_LVL_2,70),new §_-Kb§(§_-s2a§.ACHIEV_WEAPONS_UPGRADE_3LEVEL_TITLE,{
            "type":§_-aO§.§_-Mu§.value,
            "count":3
         },50,§_-q2v§.WEAPONS_UPGRADE_LVL_3,80)]),new §_-Y1v§(§_-r26§.§_-92j§,§_-s2a§.ACHIEV_CRAFT_LEGENDARY_DESCR,[new §_-Kb§(§_-s2a§.ACHIEV_CRAFT_LEGENDARY_1LEVEL_TITLE,{
            "type":§_-aO§.§_-Mu§.value,
            "count":5
         },1,§_-q2v§.CRAFT_LEGENDARY_LVL_1,100,§_-s2a§.ACHIEV_CRAFT_LEGENDARY_1LEVEL_DESCR),new §_-Kb§(§_-s2a§.ACHIEV_CRAFT_LEGENDARY_2LEVEL_TITLE,{
            "type":§_-aO§.REACTION.value,
            "count":50
         },2,§_-q2v§.CRAFT_LEGENDARY_LVL_2,120),new §_-Kb§(§_-s2a§.ACHIEV_CRAFT_LEGENDARY_3LEVEL_TITLE,{
            "type":§_-aO§.§_-Mu§.value,
            "count":15
         },3,§_-q2v§.CRAFT_LEGENDARY_LVL_3,150)]),new §_-Y1v§(§_-r26§.§_-U10§,§_-s2a§.ACHIEV_SUPERBOSS_DEFEATED_DESCR,[new §_-Kb§(§_-s2a§.ACHIEV_SUPERBOSS_DEFEATED_1LEVEL_TITLE,{
            "type":§_-aO§.§_-J2y§.value,
            "count":200
         },3,§_-q2v§.SUPERBOSS_DEFEATED_LVL_1,80),new §_-Kb§(§_-s2a§.ACHIEV_SUPERBOSS_DEFEATED_2LEVEL_TITLE,{
            "type":§_-aO§.§_-Mu§.value,
            "count":3
         },15,§_-q2v§.SUPERBOSS_DEFEATED_LVL_2,90),new §_-Kb§(§_-s2a§.ACHIEV_SUPERBOSS_DEFEATED_3LEVEL_TITLE,{
            "type":§_-aO§.§_-Mu§.value,
            "count":7
         },40,§_-q2v§.SUPERBOSS_DEFEATED_LVL_3,100)])]
      };
      
      public function §_-xD§()
      {
         super();
      }
      
      public static function init(param1:ISocialController) : void
      {
         var _loc2_:SocialType = §_-X1j§.§_-It§.getPlatformType();
         if(!param1.isVideoAvailable())
         {
            §_-p11§(§_-r26§.§_-93q§);
         }
         if(_loc2_.equals(SocialType.STEAM) || _loc2_.equals(SocialType.NONE))
         {
            §_-p11§(§_-r26§.§_-HX§);
         }
         §_-p11§(§_-r26§.RUBIES_FOUND);
      }
      
      private static function §_-p11§(param1:int) : void
      {
         var _loc2_:Array = null;
         var _loc3_:uint = 0;
         var _loc4_:uint = 0;
         for each(_loc2_ in §_-Cr§)
         {
            _loc3_ = uint(_loc2_.length);
            _loc4_ = 0;
            while(_loc4_ < _loc3_)
            {
               if(_loc2_[_loc4_].id == param1)
               {
                  _loc2_.splice(_loc4_,1);
                  return;
               }
               _loc4_++;
            }
         }
      }
      
      public static function getRecord(param1:int) : §_-Y1v§
      {
         var _loc2_:Array = null;
         var _loc3_:§_-Y1v§ = null;
         for each(_loc2_ in §_-Cr§)
         {
            for each(_loc3_ in _loc2_)
            {
               if(_loc3_.id == param1)
               {
                  return _loc3_;
               }
            }
         }
         return null;
      }
   }
}

