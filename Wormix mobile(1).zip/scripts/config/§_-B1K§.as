package config
{
   import §_-A1K§.§_-6L§;
   import §_-A1K§.§_-U11§;
   import §_-P2i§.§_-b7§;
   import §_-j22§.§_-5g§;
   import §_-lh§.§_-z2A§;
   import §_-nE§.SelectCraftWeaponScreen;
   import §_-nE§.§_-p16§;
   import feathers.data.ListCollection;
   import feathers.events.FeathersEventType;
   import flash.display.DisplayObject;
   import flash.utils.ByteArray;
   import flash.utils.IDataOutput;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.sets.ControlSets;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.client.PumpReactionRates;
   import ru.pragmatix.wormix.model.items.craft.§_-6S§;
   import ru.pragmatix.wormix.serialization.client.*;
   import ru.pragmatix.wormix.weapons.SwitchTurn;
   import ru.pragmatix.wormix.weapons.Weapon;
   import ru.pragmatix.wormix.weapons.§_-73v§;
   import starling.events.Event;
   
   public class §_-B1K§
   {
      
      public static const §_-c1c§:int = 1;
      
      public static const §_-C23§:int = 2;
      
      public static const §_-A2L§:int = 3;
      
      public static const §_-x1w§:int = 4;
      
      public static const HAT:int = 5;
      
      public static const ARTIFACT:int = 6;
      
      public function §_-B1K§()
      {
         super();
      }
   }
}

