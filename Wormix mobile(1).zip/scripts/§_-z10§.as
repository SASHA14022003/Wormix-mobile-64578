package
{
   import §_-B1y§.*;
   import §_-H16§.*;
   import §_-b1F§.§_-v2Q§;
   import §_-rM§.§_-61j§;
   import flash.events.Event;
   import flash.utils.IDataInput;
   import org.swiftsuspenders.Injector;
   import starling.events.Event;
   
   public class §_-z10§ extends flash.events.Event
   {
      
      public static const §_-S2Z§:String = "installConversionDataLoaded";
      
      public static const §_-C1F§:String = "installConversionFailure";
      
      public static const §_-V2I§:String = "appOpenAttribution";
      
      public static const §_-3x§:String = "attributionFailure";
      
      public static const §_-x1o§:String = "validateInApp";
      
      public static const §_-e2x§:String = "validateInAppFailure";
      
      public var data:String;
      
      public function §_-z10§(param1:String, param2:String, param3:Boolean = false, param4:Boolean = false)
      {
         super(param1,param3,param4);
         this.data = param2;
      }
   }
}

