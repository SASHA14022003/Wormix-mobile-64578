package §_-T1o§
{
   import §_-51p§.§_-W2e§;
   import §_-62§.§_-G1p§;
   import §_-9§.§_-52A§;
   import §_-931§.*;
   import §_-A1K§.§_-TA§;
   import §_-B1y§.§_-F1P§;
   import §_-L1H§.§_-C3e§;
   import §_-P1z§.*;
   import §_-Tm§.§_-RF§;
   import §_-Y1O§.§_-yA§;
   import §_-Z1K§.§_-q24§;
   import §_-fo§.§_-A29§;
   import §_-hO§.§_-v24§;
   import §_-l1g§.§_-L3Q§;
   import §_-p14§.§_-A3Y§;
   import dragonBones.Slot;
   import flash.errors.IllegalOperationError;
   import flash.events.Event;
   import flash.geom.Point;
   import flash.utils.Dictionary;
   import ru.pragmatix.flox.logger.§_-93v§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controller.§_-b1g§;
   import ru.pragmatix.wormix.objects.Waypoint;
   import ru.pragmatix.wormix.weapons.Weapon;
   import ru.pragmatix.wormix.weapons.§_-73v§;
   import starling.display.Image;
   import starling.events.Event;
   import starling.textures.Texture;
   import starling.utils.Pool;
   
   public class §_-L3M§ extends flash.events.Event
   {
      
      public static const SUPPORT_STATE_CHANGED:String = "SUPPORT_STATE_CHANGED";
      
      public static const §_-i2p§:String = "SERVICE";
      
      public static const §_-F2§:String = "PAYMENTS";
      
      public static const §_-Sg§:String = "PURCHASES";
      
      public static const §_-61W§:String = "RECEIPT";
      
      private var data:Object;
      
      public function §_-L3M§(param1:String, param2:Boolean = false, param3:Boolean = false, param4:Object = null)
      {
         super(param1,param2,param3);
         this.data = param4;
      }
      
      public static function create(param1:Object) : §_-L3M§
      {
         return new §_-L3M§(SUPPORT_STATE_CHANGED,false,false,param1);
      }
      
      public function getValue(param1:String) : Boolean
      {
         return this.data[param1];
      }
      
      public function §_-ax§(param1:String) : Boolean
      {
         return this.data.hasOwnProperty(param1);
      }
   }
}

