package §_-T1o§
{
   import §_-23P§.§_-V2T§;
   import §_-23P§.§_-u1z§;
   import §_-CF§.§_-x2t§;
   import §_-Y1O§.§_-yA§;
   import §_-l1g§.§_-T2N§;
   import §_-s20§.§_-J2g§;
   import §_-s20§.§_-d21§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.messages.client.BuyResetBonusItems;
   import ru.pragmatix.wormix.messages.server.BuyResetBonusItemsResult;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.utils.§_-J2h§;
   import starling.events.Event;
   
   public class §_-n1S§ extends Event
   {
      
      public static const RECREATED:String = "RECREATED";
      
      public function §_-n1S§(param1:String, param2:Boolean = false, param3:Object = null)
      {
         super(param1,param2,param3);
      }
   }
}

