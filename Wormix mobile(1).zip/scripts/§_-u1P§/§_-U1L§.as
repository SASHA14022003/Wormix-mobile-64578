package §_-u1P§
{
   import §_-9e§.§_-73e§;
   import §_-9e§.§_-8O§;
   import §_-9e§.§_-A18§;
   import §_-CF§.§_-E19§;
   import §_-YF§.§_-g2W§;
   import starling.events.Event;
   
   public class §_-U1L§ extends Event
   {
      
      public static const BUY_ITEM:String = "BUY_ITEM";
      
      public var moneyType:§_-E19§;
      
      public var item:§_-g2W§;
      
      public var count:uint;
      
      public function §_-U1L§(param1:String, param2:§_-g2W§, param3:§_-E19§, param4:uint = 0)
      {
         super(param1);
         this.item = param2;
         this.count = param4;
         this.moneyType = param3;
      }
   }
}

