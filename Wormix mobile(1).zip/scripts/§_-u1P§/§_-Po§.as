package §_-u1P§
{
   import §_-62§.§_-W1r§;
   import starling.events.Event;
   
   public class §_-Po§ extends Event
   {
      
      public static const TRY_BUY:String = "TRY_BUY";
      
      public var item:§_-W1r§;
      
      public var §_-j1U§:Array;
      
      public var §_-51w§:int;
      
      public function §_-Po§(param1:§_-W1r§, param2:Array = null, param3:int = 0)
      {
         super(TRY_BUY,true);
         this.item = param1;
         this.§_-j1U§ = param2;
         this.§_-51w§ = param3;
      }
   }
}

