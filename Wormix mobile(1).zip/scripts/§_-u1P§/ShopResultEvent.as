package §_-u1P§
{
   import §_-51p§.§_-W2e§;
   import §_-62§.§_-G1p§;
   import §_-A1K§.§_-TA§;
   import §_-L1H§.§_-C3e§;
   import §_-P1z§.*;
   import §_-Tm§.§_-RF§;
   import §_-Z1K§.§_-q24§;
   import §_-hO§.§_-v24§;
   import §_-l1g§.§_-L3Q§;
   import flash.geom.Point;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.objects.Waypoint;
   import ru.pragmatix.wormix.weapons.Weapon;
   import ru.pragmatix.wormix.weapons.§_-73v§;
   import starling.events.Event;
   import starling.utils.Pool;
   
   public class ShopResultEvent
   {
      
      public static const BUY_SUCCESS:String = "ShopResultEvent.BUY_SUCCESS";
      
      public static const BUY_FAILED:String = "ShopResultEvent.BUY_FAILED";
      
      public static const ITEM_ADDED:String = "ShopResultEvent.ITEM_ADDED";
      
      public function ShopResultEvent()
      {
         super();
      }
   }
}

