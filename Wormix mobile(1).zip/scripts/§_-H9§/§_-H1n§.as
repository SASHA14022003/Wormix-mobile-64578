package §_-H9§
{
   import §_-31W§.§_-Kb§;
   import §_-62§.§_-O2H§;
   import §_-62§.§_-T1y§;
   import §_-62§.§_-W1r§;
   import §_-62§.§_-zF§;
   import §_-CF§.§_-E19§;
   import §_-CF§.§_-x2t§;
   import §_-j1w§.§_-B2i§;
   
   public class §_-H1n§ implements §_-NX§
   {
      
      public function §_-H1n§()
      {
         super();
      }
      
      public function get §_-d2f§() : String
      {
         return "";
      }
      
      public function get winInPvp() : String
      {
         return "";
      }
      
      public function get rubyFoundInHouse() : String
      {
         return "";
      }
      
      public function get kickTeamMate() : String
      {
         return "";
      }
      
      public function get missionComplete() : String
      {
         return "";
      }
      
      public function get enter4DaySequence() : String
      {
         return "";
      }
      
      public function get enter5DaySequence_2mission() : String
      {
         return "";
      }
      
      public function get enter5DaySequence_reaction() : String
      {
         return "";
      }
      
      public function get enter5DaySequence_fuzzes() : String
      {
         return "";
      }
      
      public function get enter5DaySequence_rubies() : String
      {
         return "";
      }
      
      public function get §_-n2J§() : String
      {
         return "";
      }
      
      public function get newItems() : String
      {
         return "";
      }
      
      public function get newTeamMate() : String
      {
         return "";
      }
      
      public function get callToPvp() : Array
      {
         return [];
      }
      
      public function get activityPumpFriendsReaction() : String
      {
         return "";
      }
      
      public function get postStatus() : String
      {
         return "";
      }
      
      public function get remindAboutLose() : String
      {
         return "";
      }
      
      public function get requestPumpReaction() : String
      {
         return "";
      }
      
      public function get boxerIcon() : String
      {
         return null;
      }
      
      public function get zombieIcon() : String
      {
         return null;
      }
      
      public function get demonIcon() : String
      {
         return null;
      }
      
      public function get rabbitIcon() : String
      {
         return null;
      }
      
      public function get dragonIcon() : String
      {
         return null;
      }
      
      public function get robotIcon() : String
      {
         return null;
      }
      
      public function get catIcon() : String
      {
         return null;
      }
      
      public function §_-G1f§(param1:§_-B2i§) : String
      {
         return "";
      }
      
      public function §_-b1i§(param1:§_-zF§) : String
      {
         return "";
      }
      
      public function §_-l1F§(param1:§_-O2H§) : String
      {
         return "";
      }
      
      public function §_-K14§(param1:§_-T1y§) : String
      {
         return "";
      }
      
      public function §_-5b§(param1:§_-W1r§) : String
      {
         return "";
      }
      
      public function get bossIcon() : String
      {
         return "";
      }
      
      public function get tutorialIcon() : String
      {
         return "";
      }
      
      public function §_-o2z§(param1:Boolean, param2:Boolean) : String
      {
         return "";
      }
      
      public function §_-RX§(param1:int) : String
      {
         return "";
      }
      
      public function §_-g18§(param1:§_-Kb§) : String
      {
         return "";
      }
   }
}

