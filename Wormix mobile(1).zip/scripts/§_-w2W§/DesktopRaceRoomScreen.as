package §_-w2W§
{
   import §_-82l§.§_-A2Y§;
   import §_-B1y§.§_-83E§;
   import §_-B1y§.§_-bs§;
   import §_-C3f§.§_-yG§;
   import §_-bI§.*;
   import §_-f1G§.§_-kf§;
   import §_-q11§.RaceRoomAbilitiesPanel;
   import §_-q11§.RaceRoomDescriptionPanel;
   import §_-q11§.§_-V1F§;
   import §_-q11§.§_-i2T§;
   import §_-q26§.*;
   import §_-w2i§.§_-52k§;
   import config.§_-K32§;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import flash.errors.IllegalOperationError;
   import flash.events.Event;
   import flash.events.IEventDispatcher;
   import flash.geom.Point;
   import flash.geom.Rectangle;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import org.gestouch.core.*;
   import ru.pragmatix.wormix.messages.clans.request.edit.ChangeClanDescriptionRequest;
   import ru.pragmatix.wormix.messages.clans.request.login.LoginCreateClanRequest;
   import ru.pragmatix.wormix.messages.clans.request.login.LoginJoinClanRequest;
   import ru.pragmatix.wormix.messages.clans.response.edit.ChangeClanDescriptionResponse;
   import ru.pragmatix.wormix.messages.structures.ChatMessage;
   import ru.pragmatix.wormix.messages.structures.RatingProfileStructure;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.utils.§_-c1S§;
   import ru.pragmatix.wormix.weapons.ammo.Ufo;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.events.Event;
   import starling.events.Touch;
   import starling.events.TouchEvent;
   import starling.utils.Pool;
   import starling.utils.RectangleUtil;
   import starling.utils.ScaleMode;
   
   use namespace gestouch_internal;
   
   public class DesktopRaceRoomScreen extends §_-o28§ implements §_-z25§
   {
      
      private var binder:Binder;
      
      private var §_-v1D§:§_-i2T§;
      
      private var §_-C3Q§:§_-V1F§;
      
      private var §_-02N§:RaceRoomDescriptionPanel;
      
      private var §_-q1Y§:RaceRoomAbilitiesPanel;
      
      public function DesktopRaceRoomScreen()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         this.binder = new Binder();
         Application.uiBuilder.create(Application.assetManager.getObject("race_room_screen"),true,this.binder);
         addChild(this.binder._container);
         this.§_-v1D§ = new §_-i2T§(this.binder._charPlace,this.binder._leftArrow,this.binder._rightArrow);
         this.§_-C3Q§ = new §_-V1F§(this.binder._raceName,this.binder._selectedIndicator,this.§_-v1D§);
         this.§_-02N§ = new RaceRoomDescriptionPanel(this.binder._displayLeft,this.§_-v1D§);
         this.§_-q1Y§ = new RaceRoomAbilitiesPanel(this.binder._displayRight,this.§_-v1D§);
         Starling.juggler.add(this.binder._godRayPlane);
         Starling.juggler.add(this.binder._bubbles.particleSystem);
      }
      
      override public function dispose() : void
      {
         super.dispose();
         Starling.juggler.remove(this.binder._godRayPlane);
         Starling.juggler.remove(this.binder._bubbles.particleSystem);
         this.§_-v1D§.dispose();
         this.§_-C3Q§.dispose();
         this.§_-02N§.dispose();
         this.§_-q1Y§.dispose();
      }
      
      override protected function draw() : void
      {
         var stageWidth:Number;
         var stageHeight:Number;
         var scaledRect:Rectangle;
         var stageRect:Rectangle;
         var newScale:Number;
         super.draw();
         stageWidth = stage.stageWidth;
         stageHeight = stage.stageHeight;
         scaledRect = Pool.getRectangle(0,0,1920,1080);
         stageRect = Pool.getRectangle(0,0,stageWidth,stageHeight);
         scaledRect = RectangleUtil.fit(scaledRect,stageRect,ScaleMode.NO_BORDER);
         newScale = Number(Math.max(scaledRect.width / 1920,scaledRect.height / 1080));
         with(this.binder._container)
         {
            scale = newScale;
            x = scaledRect.x;
            y = scaledRect.y;
            width = scaledRect.width;
            height = scaledRect.height;
         }
         Pool.putRectangle(scaledRect);
         Pool.putRectangle(stageRect);
      }
      
      public function §_-82v§(param1:UserProfile) : void
      {
         this.§_-v1D§.§_-82v§(param1);
      }
   }
}

import feathers.controls.LayoutGroup;
import starling.display.Button;
import starling.display.Image;
import starling.display.Sprite;
import starling.extensions.GodRayPlane;
import starlingbuilder.extensions.particle.PDParticleSprite;
import starlingbuilder.extensions.uicomponents.CustomLabel;

class Binder
{
   
   public var _container:LayoutGroup;
   
   public var _charPlace:Sprite;
   
   public var _displayLeft:LayoutGroup;
   
   public var _displayRight:LayoutGroup;
   
   public var _raceName:CustomLabel;
   
   public var _leftArrow:Button;
   
   public var _rightArrow:Button;
   
   public var _godRayPlane:GodRayPlane;
   
   public var _bubbles:PDParticleSprite;
   
   public var _selectedIndicator:Image;
   
   public function Binder()
   {
      super();
   }
}
