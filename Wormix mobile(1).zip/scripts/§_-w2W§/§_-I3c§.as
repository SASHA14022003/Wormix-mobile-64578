package §_-w2W§
{
   import §_-62§.*;
   import §_-91A§.§_-Wy§;
   import §_-S1N§.§_-D2B§;
   import §_-YF§.§_-L29§;
   import §_-b1§.*;
   import §_-hO§.§_-03k§;
   import §_-hO§.§_-h2f§;
   import §_-j1w§.§_-lD§;
   import §_-j22§.§_-5g§;
   import §_-l1g§.§_-L3Q§;
   import §_-r1C§.§_-t1R§;
   import §_-u2J§.§_-A0§;
   import §_-z2S§.SafeAreaUtils;
   import com.distriqt.extension.inappbilling.events.ApplicationReceiptEvent;
   import config.§_-vR§;
   import feathers.controls.LayoutGroup;
   import feathers.controls.ProgressBar;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.VerticalAlign;
   import feathers.layout.VerticalLayout;
   import flash.display.DisplayObject;
   import flash.display.DisplayObjectContainer;
   import flash.display.InteractiveObject;
   import flash.display.SimpleButton;
   import flash.display.Stage;
   import flash.events.Event;
   import flash.geom.Point;
   import flash.geom.Rectangle;
   import flash.text.TextFormat;
   import flash.utils.ByteArray;
   import flash.utils.IDataOutput;
   import flash.utils.setTimeout;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fonts.BitmapFonts;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.gui.menu.§_-3m§;
   import ru.pragmatix.wormix.messages.server.Pong;
   import ru.pragmatix.wormix.objects.*;
   import ru.pragmatix.wormix.utils.§_-R2g§;
   import ru.pragmatix.wormix.utils.§_-c1S§;
   import ru.pragmatix.wormix.weapons.Girder;
   import ru.pragmatix.wormix.weapons.Weapon;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Image;
   import starling.display.Sprite;
   import starling.events.EnterFrameEvent;
   import starling.events.Event;
   import starling.events.KeyboardEvent;
   import starling.textures.Texture;
   import starling.utils.AssetManager;
   import starling.utils.Color;
   import starling.utils.Pool;
   import starling.utils.RectangleUtil;
   import starling.utils.ScaleMode;
   import starling.utils.SystemUtil;
   
   public class §_-I3c§ extends §_-v27§
   {
      
      private var §_-914§:Image;
      
      private var §_-6U§:ProgressBar;
      
      private var content:LayoutGroup;
      
      private var version:Sprite;
      
      public function §_-I3c§()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         var assetManager:AssetManager = null;
         assetManager = Application.assetManager;
         this.content = new LayoutGroup();
         this.content.width = 1920;
         this.content.height = 1080;
         addChild(this.content);
         this.§_-914§ = new Image(assetManager.getTexture("preloader_back"));
         this.content.addChild(this.§_-914§);
         this.§_-6U§ = new ProgressBar();
         this.§_-6U§.width = 340;
         this.§_-6U§.height = 6;
         this.§_-6U§.x = (this.content.width - this.§_-6U§.width) * 0.5 + 15;
         this.§_-6U§.y = 850;
         this.§_-6U§.backgroundSkin = new Image(Texture.fromColor(16,16,Color.BLACK));
         this.§_-6U§.fillSkin = new Image(Texture.fromColor(16,16,16777136));
         this.§_-6U§.value = 0;
         this.content.addChild(this.§_-6U§);
         Application.§_-i1N§.addEventListener(§_-A0§.PROGRESS,this.§_-4g§);
         setTimeout(function():void
         {
         },1);
         if(!_isDisposed)
         {
            this.§_-C3c§();
            addEventListener(EnterFrameEvent.ENTER_FRAME,this.onEnterFrame);
         }
      }
      
      private function §_-C3c§() : void
      {
         var _loc1_:String = Effects.COLOR_GREY9;
         if(§_-vR§.§_-pD§)
         {
            _loc1_ = Effects.TEXT_COLOR_RED;
         }
         if(§_-vR§.§_-I1D§)
         {
            _loc1_ = Effects.TEXT_COLOR_ORANGE;
         }
         if(§_-vR§.§_-42H§)
         {
            _loc1_ = Effects.TEXT_COLOR_BLUE;
         }
         var _loc2_:String = §_-vR§.§_-q18§;
         this.version = Effects.makeStarlingTextWithFont(BitmapFonts.AD_LIB,_loc2_,_loc1_,12);
         var _loc3_:Rectangle = SafeAreaUtils.§_-q1J§();
         this.version.x = _loc3_.x;
         Pool.putRectangle(_loc3_);
         addChild(this.version);
      }
      
      private function onEnterFrame(param1:EnterFrameEvent) : void
      {
         if(_isDisposed)
         {
            removeEventListener(EnterFrameEvent.ENTER_FRAME,this.onEnterFrame);
            return;
         }
         if(!§_-X1j§.§_-It§)
         {
            return;
         }
         removeEventListener(EnterFrameEvent.ENTER_FRAME,this.onEnterFrame);
         removeChild(this.version);
         this.version.dispose();
         this.§_-C3c§();
      }
      
      private function §_-4g§(param1:starling.events.Event) : void
      {
         if(param1.data)
         {
            this.§_-6U§.value = int(param1.data) / 100;
         }
      }
      
      override protected function draw() : void
      {
         super.draw();
         var _loc1_:Number = stage.stageWidth;
         var _loc2_:Number = stage.stageHeight;
         var _loc3_:Rectangle = Pool.getRectangle(0,0,1920,1080);
         var _loc4_:Rectangle = Pool.getRectangle(0,0,_loc1_,_loc2_);
         _loc3_ = RectangleUtil.fit(_loc3_,_loc4_,ScaleMode.NO_BORDER);
         var _loc5_:Number = Number(Math.max(_loc3_.width / 1920,_loc3_.height / 1080));
         this.content.scale = _loc5_;
         this.content.x = _loc3_.x;
         this.content.y = _loc3_.y;
         this.content.width = _loc3_.width;
         this.content.height = _loc3_.height;
         Pool.putRectangle(_loc3_);
         Pool.putRectangle(_loc4_);
      }
      
      override public function dispose() : void
      {
         if(this.version)
         {
            if(this.version.parent)
            {
               this.version.parent.removeChild(this.version);
            }
            this.version.dispose();
            this.version = null;
         }
         super.dispose();
         §_-L29§.§_-gs§(§_-21w§.§_-lv§);
         Application.§_-i1N§.removeEventListener(§_-A0§.PROGRESS,this.§_-4g§);
      }
      
      override protected function get openScreenSound() : §_-t1R§
      {
         return null;
      }
   }
}

