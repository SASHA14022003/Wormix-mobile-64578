package §_-w2W§
{
   import §_-03T§.§_-2p§;
   import §_-22z§.§_-f1b§;
   import §_-51j§.§_-C1L§;
   import §_-51j§.§_-X19§;
   import §_-51j§.§_-w17§;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-L1r§;
   import §_-62§.§_-gr§;
   import §_-73I§.§_-q15§;
   import §_-82l§.§_-1I§;
   import §_-B2z§.§_-63i§;
   import §_-CR§.§_-72p§;
   import §_-DJ§.§_-J2l§;
   import §_-H3§.*;
   import §_-J3L§.§_-h1D§;
   import §_-Nq§.*;
   import §_-TF§.§_-q1j§;
   import §_-Vg§.ClanCreateView;
   import §_-Y1Q§.§_-aG§;
   import §_-Y1Q§.§_-tc§;
   import §_-b1F§.§_-G4§;
   import §_-bI§.§_-E8§;
   import §_-bI§.§_-n2F§;
   import §_-d2p§.*;
   import §_-jF§.MinimalRatingLineItemRenderer;
   import §_-k2s§.§_-Go§;
   import §_-k2s§.§_-b0§;
   import §_-m1g§.*;
   import §_-r1C§.§_-h2B§;
   import §_-z1g§.§_-F4§;
   import §_-zI§.§_-8D§;
   import §_-zI§.§_-F3q§;
   import feathers.controls.Button;
   import feathers.controls.List;
   import feathers.controls.ScrollPolicy;
   import feathers.controls.renderers.IListItemRenderer;
   import feathers.core.ITextRenderer;
   import feathers.data.ListCollection;
   import feathers.layout.Direction;
   import feathers.layout.RelativePosition;
   import feathers.layout.VerticalLayout;
   import feathers.themes.styles.AlternateScrollBarStyles;
   import flash.geom.ColorTransform;
   import flash.geom.Rectangle;
   import flash.net.Socket;
   import flash.utils.ByteArray;
   import ru.pragmatix.flox.serialization.§_-616§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fonts.BitmapFonts;
   import ru.pragmatix.wormix.fx.EffectType;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.§_-3m§;
   import ru.pragmatix.wormix.gui.menu.shop.§_-P4§;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.items.craft.CraftedEquipFamily;
   import ru.pragmatix.wormix.model.rewards.*;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.pvp.messages.client.PvpEndTurn;
   import ru.pragmatix.wormix.pvp.messages.client.PvpEndTurnResponse;
   import ru.pragmatix.wormix.utils.*;
   import ru.pragmatix.wormix.weapons.*;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Quad;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.utils.MathUtil;
   import starling.utils.Pool;
   import starling.utils.RectangleUtil;
   import starling.utils.ScaleMode;
   
   public class ArmoryScreenMobile extends §_-o28§
   {
      
      private var binder:Binder;
      
      private var §_-Z1o§:§_-C1L§;
      
      private var §_-u1q§:§_-X19§;
      
      private var §_-13t§:§_-w17§;
      
      public function ArmoryScreenMobile()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         this.binder = new Binder();
         Application.uiBuilder.create(Application.assetManager.getObject("armory_room_back"),true,this.binder);
         addChild(this.binder._container);
         this.binder._items.dataProvider = new ListCollection();
         this.§_-Z1o§ = new §_-C1L§(this.binder._items,this.binder._prev,this.binder._next);
         this.§_-u1q§ = new §_-X19§(this.binder._items);
         this.§_-13t§ = new §_-w17§(this.binder._vipTimer);
         this.§_-13t§.addEventListener(Event.CHANGE,this.§_-iA§);
         this.§_-13t§.init();
         invalidate(INVALIDATION_FLAG_DATA);
      }
      
      override protected function draw() : void
      {
         var up:UserProfile = null;
         var stageWidth:Number = NaN;
         var stageHeight:Number = NaN;
         var scaledRect:Rectangle = null;
         var stageRect:Rectangle = null;
         var newScale:Number = NaN;
         super.draw();
         if(isInvalid(INVALIDATION_FLAG_DATA))
         {
            up = Application.§_-SH§.userProfile;
            this.§_-Z1o§.§_-Za§(up);
         }
         if(isInvalid(INVALIDATION_FLAG_SIZE))
         {
            stageWidth = stage.stageWidth;
            stageHeight = stage.stageHeight;
            scaledRect = Pool.getRectangle(0,0,1920,1080);
            stageRect = Pool.getRectangle(0,0,stageWidth,stageHeight);
            scaledRect = RectangleUtil.fit(scaledRect,stageRect,ScaleMode.NO_BORDER);
            newScale = Number(Math.max(scaledRect.width / 1920,scaledRect.height / 1080));
            Pool.putRectangle(scaledRect);
            Pool.putRectangle(stageRect);
            with(this.binder._container)
            {
               
               scale = newScale;
               width = stageWidth;
               height = stageHeight;
            }
         }
      }
      
      override public function dispose() : void
      {
         super.dispose();
         this.§_-Z1o§.dispose();
         this.§_-u1q§.dispose();
         this.§_-13t§.removeEventListener(Event.CHANGE,this.§_-iA§);
         this.§_-13t§.dispose();
      }
      
      override public function save(param1:Function) : void
      {
         §_-f1b§.§_-r1K§();
         super.save(param1);
      }
      
      private function §_-iA§(param1:Event) : void
      {
         invalidate(INVALIDATION_FLAG_DATA);
      }
   }
}

import feathers.controls.LayoutGroup;
import feathers.controls.List;
import starling.display.Button;

class Binder
{
   
   public var _container:LayoutGroup;
   
   public var _items:List;
   
   public var _prev:Button;
   
   public var _next:Button;
   
   public var _vipTimer:LayoutGroup;
   
   public function Binder()
   {
      super();
   }
}
