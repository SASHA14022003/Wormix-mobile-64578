package §_-w2W§
{
   import §_-31W§.*;
   import §_-62§.§_-G1p§;
   import §_-91B§.§_-QK§;
   import §_-91B§.§_-z2l§;
   import §_-A1K§.§_-TA§;
   import §_-H3§.*;
   import §_-N8§.§_-2C§;
   import §_-RE§.§_-D3v§;
   import §_-g2r§.§_-03A§;
   import §_-k1u§.§_-by§;
   import §_-z1g§.§_-4l§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controller.analytics.Analytics;
   import ru.pragmatix.wormix.messages.client.StartBattle;
   import ru.pragmatix.wormix.model.items.craft.CraftedEquipFamily;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.*;
   import starling.display.DisplayObjectContainer;
   
   public class §_-o28§ extends §_-v27§
   {
      
      public function §_-o28§()
      {
         super();
      }
      
      override public function §_-X2O§() : void
      {
         Application.§_-E1k§.showScreen(§_-21w§.§_-G31§);
      }
   }
}

