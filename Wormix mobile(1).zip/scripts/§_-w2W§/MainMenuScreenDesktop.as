package §_-w2W§
{
   import §_-62§.§_-F1D§;
   import §_-Bv§.§_-G3P§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-H2g§.§_-s1d§;
   import §_-Ly§.§_-81L§;
   import §_-S1N§.§_-D2B§;
   import §_-X14§.§_-03Y§;
   import §_-Y1Q§.§_-aG§;
   import §_-fo§.§_-v2P§;
   import §_-hO§.§_-03k§;
   import §_-l1K§.§_-E1n§;
   import §_-l1K§.§_-m2§;
   import §_-l1K§.§_-n2T§;
   import §_-l1g§.§_-L3Q§;
   import §_-r1C§.§_-h2B§;
   import §_-z20§.*;
   import §_-zI§.*;
   import com.distriqt.extension.cloudstorage.CloudStorage;
   import com.greensock.loading.DataLoader;
   import com.greensock.loading.XMLLoader;
   import com.hurlant.util.der.*;
   import feathers.controls.Button;
   import feathers.controls.ButtonState;
   import feathers.controls.Label;
   import feathers.controls.List;
   import feathers.core.ITextRenderer;
   import flash.display.DisplayObject;
   import flash.display.SimpleButton;
   import flash.geom.Rectangle;
   import flash.utils.ByteArray;
   import flash.utils.Dictionary;
   import ru.pragmatix.flox.social.utils.id.MobilePlatformAccountController;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-Qi§;
   import ru.pragmatix.wormix.utils.FrameTimer;
   import ru.pragmatix.wormix.weapons.ammo.VerticalDrillMissile;
   import ru.pragmatix.wormix.weapons.ammo.VerticalDrillStanding;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Quad;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.utils.Pool;
   import starling.utils.RectangleUtil;
   import starling.utils.ScaleMode;
   import starling.utils.SystemUtil;
   import starlingbuilder.engine.tween.WormixTweenBuilder;
   
   public class MainMenuScreenDesktop extends §_-v27§
   {
      
      private var binder:Binder;
      
      private var §_-W1B§:Object;
      
      private var §_-k17§:§_-03Y§;
      
      public function MainMenuScreenDesktop()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         var sprite:Sprite;
         var paramsDict:Dictionary;
         super.initialize();
         this.binder = new Binder();
         this.§_-W1B§ = Application.uiBuilder.load(Application.assetManager.getObject("main_menu_screen"),true,this.binder);
         sprite = this.§_-W1B§.object as Sprite;
         paramsDict = this.§_-W1B§.params;
         (Application.uiBuilder.tweenBuilder as WormixTweenBuilder).startWithRandomDelay(sprite,paramsDict,null,20);
         addChild(this.binder._content);
         this.binder._battleButton.convertIntoButton();
         this.binder._battleButton.button.addEventListener(Event.TRIGGERED,this.§_-82i§);
         this.binder._battleButton.button.useHandCursor = true;
         this.binder._battleButton.button.isQuickHitAreaEnabled = true;
         §_-X1j§.localizationService.§_-J36§(this.binder._battleButton.button,function(param1:Button):void
         {
            var text:String = null;
            var skinName:String = null;
            var button:Button = param1;
            text = §_-s2a§.§_-K3t§(§_-s2a§.BATTLE_BOSS_BTN);
            var setText:Function = function(param1:starling.display.DisplayObject):void
            {
               var _loc2_:DisplayObjectContainer = param1 as DisplayObjectContainer;
               var _loc3_:Label = _loc2_.getChildByName("label") as Label;
               _loc3_.text = text;
            };
            var states:Array = [ButtonState.UP,ButtonState.DOWN,ButtonState.HOVER];
            for each(skinName in states)
            {
               setText(button.getSkinForState(skinName));
            }
            setText(button.defaultSkin);
         });
         this.§_-k17§ = new §_-03Y§(this.binder._charsList,Application.userProfile);
      }
      
      override public function dispose() : void
      {
         this.binder._battleButton.button.removeEventListener(Event.TRIGGERED,this.§_-82i§);
         §_-X1j§.localizationService.removeObject(this.binder._battleButton);
         this.§_-k17§.dispose();
         super.dispose();
      }
      
      override protected function draw() : void
      {
         var stageWidth:Number;
         var stageHeight:Number;
         var scaledRect:Rectangle;
         var stageRect:Rectangle;
         var newScale:Number;
         super.draw();
         stageWidth = stage.stageWidth;
         stageHeight = stage.stageHeight;
         scaledRect = Pool.getRectangle(0,0,1920,1080);
         stageRect = Pool.getRectangle(0,0,stageWidth,stageHeight);
         scaledRect = RectangleUtil.fit(scaledRect,stageRect,ScaleMode.NO_BORDER);
         newScale = Number(Math.max(scaledRect.width / 1920,scaledRect.height / 1080));
         with(this.binder._background)
         {
            scale = newScale;
            x = scaledRect.x;
            y = scaledRect.y;
            width = scaledRect.width;
            height = scaledRect.height;
         }
         with(this.binder._uiContent)
         {
            scale = newScale;
            width = stageWidth;
            height = stageHeight;
         }
         Pool.putRectangle(scaledRect);
         Pool.putRectangle(stageRect);
      }
      
      private function §_-82i§(param1:Event) : void
      {
         this.binder._battleButton.button.isEnabled = false;
         this.binder._battleButton.button.isEnabled = true;
         §_-h2B§.play(§_-81L§.§_-o1Z§);
         §_-X1j§.§_-A24§.§_-KU§();
      }
      
      override public function §_-X2O§() : void
      {
         §_-fH§.§_-q1a§(§_-s2a§.§_-K3t§(§_-s2a§.TITLE_EXIT),§_-s2a§.§_-K3t§(§_-s2a§.DESCRIPTION_EXIT),§_-fH§.§_-X2g§,Application.§_-i1N§.§_-F3l§);
      }
   }
}

import feathers.controls.LayoutGroup;
import feathers.controls.List;
import starling.display.DisplayObject;
import starlingbuilder.extensions.uicomponents.ContainerButtonWithStates;

class Binder
{
   
   public var _content:LayoutGroup;
   
   public var _uiContent:LayoutGroup;
   
   public var _background:DisplayObject;
   
   public var _battleButton:ContainerButtonWithStates;
   
   public var _charsList:List;
   
   public function Binder()
   {
      super();
   }
}
