package §_-w2W§
{
   import §_-12W§.*;
   import §_-A1K§.§_-TA§;
   import §_-A2U§.§_-A23§;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-J2l§;
   import §_-E1I§.§_-b2n§;
   import §_-Y1b§.§_-22N§;
   import §_-b1R§.§_-Bx§;
   import §_-hO§.§_-y2Z§;
   import §_-j22§.§_-5g§;
   import §_-l1g§.§_-L3Q§;
   import §_-s20§.§_-J2g§;
   import com.distriqt.extension.inappbilling.Purchase;
   import com.distriqt.extension.inappbilling.events.PurchaseEvent;
   import com.greensock.TweenLite;
   import feathers.events.FeathersEventType;
   import flash.utils.ByteArray;
   import flash.utils.IDataOutput;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.wormix.Scene;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.screenOverlay.view.*;
   import ru.pragmatix.wormix.messages.clans.response.*;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.client.BuyReactionRate;
   import ru.pragmatix.wormix.messages.client.Disconnect;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.pvp.messages.ex.CancelBattle;
   import ru.pragmatix.wormix.social.*;
   import ru.pragmatix.wormix.weapons.*;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   import starling.utils.ScaleMode;
   
   public class §_-h1Z§ extends §_-v27§
   {
      
      public function §_-h1Z§()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         addEventListener(FeathersEventType.TRANSITION_IN_COMPLETE,this.§_-P29§);
      }
      
      private function §_-P29§(param1:Event) : void
      {
         §_-J2l§.§_-e1L§(§_-s2a§.BATTLE_CLEARING,this.§_-m24§);
      }
      
      private function §_-m24§() : void
      {
         Starling.juggler.delayCall(§_-X1j§.§_-12n§.§_-41l§,0.05);
         Starling.juggler.delayCall(Effects.clearAfterBattle,0.1);
         Starling.juggler.delayCall(this.§_-yk§,1);
      }
      
      private function §_-yk§() : void
      {
         §_-J2l§.§_-m1I§();
         dispatchEventWith(Event.COMPLETE);
      }
   }
}

