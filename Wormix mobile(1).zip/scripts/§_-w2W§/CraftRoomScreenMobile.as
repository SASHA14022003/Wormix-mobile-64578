package §_-w2W§
{
   import §_-31W§.*;
   import §_-73d§.§_-pT§;
   import §_-Cl§.*;
   import §_-L1H§.§_-b2K§;
   import §_-YF§.§_-q2v§;
   import §_-k2s§.§_-C3A§;
   import §_-k2s§.§_-Go§;
   import §_-l1K§.§_-W2f§;
   import §_-lh§.CraftRoomPanel;
   import §_-x2Q§.§_-dU§;
   import §_-zI§.§_-A1s§;
   import §_-zI§.§_-g1a§;
   import feathers.controls.Button;
   import feathers.controls.ScrollPolicy;
   import feathers.core.FeathersControl;
   import feathers.layout.AnchorLayoutData;
   import flash.display.DisplayObject;
   import flash.display.DisplayObjectContainer;
   import flash.display.MovieClip;
   import flash.display.Sprite;
   import flash.errors.IllegalOperationError;
   import flash.events.StatusEvent;
   import flash.geom.ColorTransform;
   import flash.geom.Rectangle;
   import flash.net.LocalConnection;
   import flash.utils.IDataOutput;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.model.user.§_-r1d§;
   import ru.pragmatix.wormix.objects.Direction;
   import ru.pragmatix.wormix.utils.*;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   import starling.utils.Pool;
   import starling.utils.RectangleUtil;
   import starling.utils.ScaleMode;
   
   public class CraftRoomScreenMobile extends §_-o28§
   {
      
      private var binder:Binder;
      
      private var §_-Rf§:CraftRoomPanel;
      
      public function CraftRoomScreenMobile()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         this.binder = new Binder();
         Application.uiBuilder.create(Application.assetManager.getObject("craft_room_screen"),true,this.binder);
         addChild(this.binder._container);
         §_-X1j§.§_-82T§.addEventListener(Event.CHANGE,this.§_-G1n§);
         this.§_-t2U§();
      }
      
      override public function dispose() : void
      {
         this.§_-Rf§.dispose();
         §_-X1j§.§_-82T§.removeEventListener(Event.CHANGE,this.§_-G1n§);
         super.dispose();
      }
      
      override protected function draw() : void
      {
         var _loc1_:Number = NaN;
         var _loc2_:Number = NaN;
         var _loc3_:Rectangle = null;
         var _loc4_:Rectangle = null;
         var _loc5_:Number = NaN;
         super.draw();
         if(isInvalid(INVALIDATION_FLAG_SIZE))
         {
            _loc1_ = stage.stageWidth;
            _loc2_ = stage.stageHeight;
            _loc3_ = Pool.getRectangle(0,0,this.binder._background.width,this.binder._background.height);
            _loc4_ = Pool.getRectangle(0,0,_loc1_,_loc2_);
            _loc3_ = RectangleUtil.fit(_loc3_,_loc4_,ScaleMode.NO_BORDER);
            this.binder._container.scale = _loc3_.height / this.binder._background.height;
            this.binder._container.x = _loc3_.x;
            this.binder._container.y = _loc3_.y;
            _loc5_ = this.binder._content.height / CraftRoomPanel.HEIGHT;
            this.§_-Rf§.display.scale = _loc5_;
            Pool.putRectangle(_loc3_);
            Pool.putRectangle(_loc4_);
         }
      }
      
      override public function §_-X2O§() : void
      {
         if(!this.§_-Rf§.§_-O1W§())
         {
            Application.§_-E1k§.showScreen(§_-21w§.§_-G31§);
         }
      }
      
      private function §_-G1n§(param1:Event) : void
      {
         this.§_-Rf§.display.removeFromParent();
         this.§_-Rf§.dispose();
         this.§_-t2U§();
      }
      
      private function §_-t2U§() : void
      {
         var _loc1_:§_-r1d§ = Application.§_-SH§;
         this.§_-Rf§ = new CraftRoomPanel();
         this.§_-Rf§.§_-82v§(_loc1_.userProfile,_loc1_.§_-x2k§);
         var _loc2_:FeathersControl = this.§_-Rf§.display;
         _loc2_.layoutData = new AnchorLayoutData(NaN,NaN,NaN,NaN,0,0);
         this.binder._content.addChild(_loc2_);
         invalidate();
      }
   }
}

import feathers.controls.LayoutGroup;
import starling.display.Image;

class Binder
{
   
   public var _container:LayoutGroup;
   
   public var _background:Image;
   
   public var _content:LayoutGroup;
   
   public function Binder()
   {
      super();
   }
}
