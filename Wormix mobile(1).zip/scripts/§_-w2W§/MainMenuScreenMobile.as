package §_-w2W§
{
   import §_-12W§.*;
   import §_-43V§.Random;
   import §_-62§.§_-gr§;
   import §_-73I§.§_-Y1l§;
   import §_-73I§.§_-q15§;
   import §_-A1K§.§_-6L§;
   import §_-A1K§.§_-U11§;
   import §_-DJ§.§_-fH§;
   import §_-H3§.*;
   import §_-Nq§.*;
   import §_-T2h§.*;
   import §_-TF§.§_-q1j§;
   import §_-X14§.§_-03Y§;
   import §_-Y1b§.§_-s2Z§;
   import §_-j22§.§_-5g§;
   import §_-l2r§.§_-K1t§;
   import §_-lh§.§_-z2A§;
   import §_-z1g§.§_-522§;
   import com.hurlant.crypto.tls.*;
   import com.worlize.websocket.*;
   import feathers.core.ITextRenderer;
   import feathers.layout.RelativePosition;
   import flash.display.MovieClip;
   import flash.geom.Point;
   import flash.geom.Rectangle;
   import flash.utils.ByteArray;
   import flash.utils.Dictionary;
   import flash.utils.IDataOutput;
   import flash.utils.getQualifiedClassName;
   import ru.pragmatix.wormix.fonts.BitmapFonts;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.client.SyncInvestedAwardPoints;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.utils.*;
   import ru.pragmatix.wormix.weapons.ammo.type.blocker.AirBlocker;
   import starling.display.DisplayObject;
   import starling.display.Quad;
   import starling.display.Sprite;
   import starling.utils.Pool;
   import starling.utils.RectangleUtil;
   import starling.utils.ScaleMode;
   import starlingbuilder.engine.tween.WormixTweenBuilder;
   
   public class MainMenuScreenMobile extends §_-v27§
   {
      
      private var binder:Binder;
      
      private var §_-W1B§:Object;
      
      private var §_-k17§:§_-03Y§;
      
      public function MainMenuScreenMobile()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         this.binder = new Binder();
         this.§_-W1B§ = Application.uiBuilder.load(Application.assetManager.getObject("main_menu_screen"),true,this.binder);
         var _loc1_:Sprite = this.§_-W1B§.object as Sprite;
         var _loc2_:Dictionary = this.§_-W1B§.params;
         (Application.uiBuilder.tweenBuilder as WormixTweenBuilder).startWithRandomDelay(_loc1_,_loc2_,null,20);
         addChild(this.binder._content);
         this.§_-k17§ = new §_-03Y§(this.binder._charsList,Application.userProfile);
      }
      
      override public function dispose() : void
      {
         this.§_-k17§.dispose();
         super.dispose();
      }
      
      override protected function draw() : void
      {
         var stageWidth:Number;
         var stageHeight:Number;
         var scaledRect:Rectangle;
         var stageRect:Rectangle;
         var newScale:Number;
         super.draw();
         stageWidth = stage.stageWidth;
         stageHeight = stage.stageHeight;
         scaledRect = Pool.getRectangle(0,0,1920,1080);
         stageRect = Pool.getRectangle(0,0,stageWidth,stageHeight);
         scaledRect = RectangleUtil.fit(scaledRect,stageRect,ScaleMode.NO_BORDER);
         newScale = Number(Math.max(scaledRect.width / 1920,scaledRect.height / 1080));
         with(this.binder._background)
         {
            scale = newScale;
            x = scaledRect.x;
            y = scaledRect.y;
            width = scaledRect.width;
            height = scaledRect.height;
         }
         with(this.binder._uiContent)
         {
            scale = newScale;
            width = stageWidth;
            height = stageHeight;
         }
         Pool.putRectangle(scaledRect);
         Pool.putRectangle(stageRect);
      }
      
      override public function §_-X2O§() : void
      {
         §_-fH§.§_-q1a§(§_-s2a§.§_-K3t§(§_-s2a§.TITLE_EXIT),§_-s2a§.§_-K3t§(§_-s2a§.DESCRIPTION_EXIT),§_-fH§.§_-X2g§,Application.§_-i1N§.§_-F3l§);
      }
   }
}

import feathers.controls.LayoutGroup;
import feathers.controls.List;
import starling.display.DisplayObject;

class Binder
{
   
   public var _content:LayoutGroup;
   
   public var _uiContent:LayoutGroup;
   
   public var _background:DisplayObject;
   
   public var _charsList:List;
   
   public function Binder()
   {
      super();
   }
}
