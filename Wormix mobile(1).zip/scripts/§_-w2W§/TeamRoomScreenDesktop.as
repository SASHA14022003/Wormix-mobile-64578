package §_-w2W§
{
   import §_-21p§.§_-4w§;
   import §_-52L§.*;
   import §_-62§.§_-o6§;
   import §_-A1K§.§_-6L§;
   import §_-A1K§.§_-U11§;
   import §_-CF§.§_-x2t§;
   import §_-DJ§.§_-fH§;
   import §_-F2M§.§_-Z2m§;
   import §_-F2M§.§_-pR§;
   import §_-TF§.§_-q1j§;
   import §_-Z1K§.§_-q24§;
   import §_-j1w§.*;
   import §_-j22§.§_-5g§;
   import §_-k1u§.§_-H2M§;
   import §_-k1u§.§_-Oi§;
   import §_-l1g§.§_-T2N§;
   import §_-s20§.§_-J2g§;
   import §_-s20§.§_-R1P§;
   import §_-sQ§.§_-V1n§;
   import com.greensock.TweenLite;
   import com.hurlant.crypto.tls.§_-21v§;
   import flash.events.Event;
   import flash.geom.Point;
   import flash.geom.Rectangle;
   import flash.utils.ByteArray;
   import flash.utils.IDataOutput;
   import flash.utils.getQualifiedClassName;
   import flash.utils.getTimer;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.wormix.controller.§_-I2Y§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.§_-3m§;
   import ru.pragmatix.wormix.messages.clans.response.PromoteRankInClanResponse;
   import ru.pragmatix.wormix.messages.client.EndBattle;
   import ru.pragmatix.wormix.messages.structures.WeaponStructure;
   import ru.pragmatix.wormix.model.§_-kQ§;
   import ru.pragmatix.wormix.model.items.craft.§_-Y2u§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.scene.tile.TileType;
   import ru.pragmatix.wormix.serialization.SerializationUtils;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.§_-6A§;
   import ru.pragmatix.wormix.weapons.ammo.type.blocker.AirBlocker;
   import starling.display.BlendMode;
   import starling.display.DisplayObject;
   import starling.display.Image;
   import starling.events.Event;
   import starling.textures.TextureSmoothing;
   import starling.utils.Pool;
   import starling.utils.RectangleUtil;
   import starling.utils.ScaleMode;
   
   public class TeamRoomScreenDesktop extends §_-o28§
   {
      
      private var binder:Binder;
      
      private var §_-j1t§:§_-pR§;
      
      private var §_-P2U§:§_-Z2m§;
      
      public function TeamRoomScreenDesktop()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         this.binder = new Binder();
         Application.uiBuilder.create(Application.assetManager.getObject("team_room_screen"),true,this.binder);
         addChild(this.binder._container);
         this.binder._foreground.touchable = false;
         this.§_-j1t§ = new §_-pR§(this.binder._charPlaces);
         this.§_-j1t§.§_-82v§(Application.§_-SH§.userProfile,Application.§_-SH§.§_-x2k§);
         this.§_-P2U§ = new §_-Z2m§(this.§_-j1t§.§_-w1S§());
         §_-X1j§.§_-D3H§.addEventListener(§_-I2Y§.EVENT_TEAM_CHANGED,this.§_-51F§);
         Application.§_-SH§.addEventListener(starling.events.Event.UPDATE,this.§_-D2H§);
      }
      
      private function §_-D2H§(param1:starling.events.Event) : void
      {
         this.update();
      }
      
      override public function update() : void
      {
         this.§_-j1t§.§_-82v§(Application.§_-SH§.userProfile,Application.§_-SH§.§_-x2k§);
      }
      
      private function §_-51F§(param1:Object) : void
      {
         this.update();
      }
      
      override protected function draw() : void
      {
         var _loc4_:Rectangle = null;
         super.draw();
         var _loc1_:Number = stage.stageWidth;
         var _loc2_:Number = stage.stageHeight;
         var _loc3_:Rectangle = Pool.getRectangle(0,0,this.binder._container.width,this.binder._container.height);
         _loc4_ = Pool.getRectangle(0,0,_loc1_,_loc2_);
         _loc3_ = RectangleUtil.fit(_loc3_,_loc4_,ScaleMode.NO_BORDER);
         this.binder._container.scale *= _loc3_.height / this.binder._container.height;
         this.binder._container.x = _loc1_ * 0.5;
         this.binder._container.y = _loc2_ * 0.5;
         Pool.putRectangle(_loc3_);
         Pool.putRectangle(_loc4_);
      }
      
      override public function dispose() : void
      {
         super.dispose();
         this.§_-j1t§.dispose();
         this.§_-j1t§ = null;
         this.§_-P2U§.dispose();
         this.§_-P2U§ = null;
         §_-X1j§.§_-D3H§.removeEventListener(§_-I2Y§.EVENT_TEAM_CHANGED,this.§_-51F§);
         Application.§_-SH§.removeEventListener(starling.events.Event.UPDATE,this.§_-D2H§);
      }
   }
}

import feathers.controls.LayoutGroup;
import starling.display.Sprite;

class Binder
{
   
   public var _container:LayoutGroup;
   
   public var _charPlaces:Sprite;
   
   public var _foreground:Sprite;
   
   public function Binder()
   {
      super();
   }
}
