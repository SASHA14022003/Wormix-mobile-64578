package §_-w2W§
{
   import §_-12W§.§_-221§;
   import §_-21p§.§_-4w§;
   import §_-31W§.AchievRoomPanel;
   import §_-62§.§_-L1r§;
   import §_-931§.§_-02O§;
   import §_-B2z§.Server;
   import §_-B2z§.§_-c1G§;
   import §_-DJ§.§_-J2l§;
   import §_-F39§.§_-a2W§;
   import §_-H3§.*;
   import §_-SP§.§_-M4§;
   import §_-T1t§.§_-u19§;
   import §_-r1C§.§_-h2B§;
   import §_-u2J§.§_-T1K§;
   import com.greensock.*;
   import com.greensock.plugins.*;
   import com.hurlant.crypto.tls.§_-Tx§;
   import com.hurlant.crypto.tls.§_-a2D§;
   import feathers.controls.Button;
   import feathers.core.FeathersControl;
   import feathers.core.ITextRenderer;
   import feathers.layout.AnchorLayoutData;
   import flash.geom.Point;
   import flash.geom.Rectangle;
   import flash.utils.ByteArray;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.arena.boss.BossTypesTab;
   import ru.pragmatix.wormix.messages.clans.structures.ClanMemberTO;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.physics.CollideType;
   import ru.pragmatix.wormix.physics.Force;
   import ru.pragmatix.wormix.physics.HitTest;
   import ru.pragmatix.wormix.physics.model.NotStuckingPhysicModel;
   import ru.pragmatix.wormix.physics.model.PhysParams;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   import starling.utils.Pool;
   import starling.utils.RectangleUtil;
   import starling.utils.ScaleMode;
   
   public class AchieveRoomScreenDesktop extends §_-o28§
   {
      
      private var binder:Binder;
      
      private var §_-43l§:AchievRoomPanel;
      
      public function AchieveRoomScreenDesktop()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         this.binder = new Binder();
         Application.uiBuilder.create(Application.assetManager.getObject("achieve_room_screen"),true,this.binder);
         addChild(this.binder._container);
         this.§_-z15§();
         §_-X1j§.§_-82T§.addEventListener(Event.CHANGE,this.§_-G1n§);
      }
      
      override public function dispose() : void
      {
         this.§_-43l§.dispose();
         §_-X1j§.§_-82T§.removeEventListener(Event.CHANGE,this.§_-G1n§);
         super.dispose();
      }
      
      override protected function draw() : void
      {
         var _loc1_:Number = NaN;
         var _loc2_:Number = NaN;
         var _loc3_:Rectangle = null;
         var _loc4_:Rectangle = null;
         var _loc5_:Number = NaN;
         super.draw();
         if(isInvalid(INVALIDATION_FLAG_DATA))
         {
            _loc1_ = stage.stageWidth;
            _loc2_ = stage.stageHeight;
            _loc3_ = Pool.getRectangle(0,0,1920,1080);
            _loc4_ = Pool.getRectangle(0,0,_loc1_,_loc2_);
            _loc3_ = RectangleUtil.fit(_loc3_,_loc4_,ScaleMode.NO_BORDER);
            _loc5_ = Number(Math.max(_loc3_.width / 1920,_loc3_.height / 1080));
            this.binder._container.scale = _loc5_;
            this.binder._container.x = _loc3_.x;
            this.binder._container.y = _loc3_.y;
            Pool.putRectangle(_loc3_);
            Pool.putRectangle(_loc4_);
         }
      }
      
      private function §_-G1n§(param1:Event) : void
      {
         this.§_-43l§.dispose();
         this.§_-z15§();
      }
      
      private function §_-z15§() : void
      {
         this.§_-43l§ = new AchievRoomPanel();
         var _loc1_:FeathersControl = this.§_-43l§.display;
         _loc1_.layoutData = new AnchorLayoutData(0,NaN,0,NaN,0);
         this.binder._content.addChild(_loc1_);
         _loc1_.validate();
      }
   }
}

import feathers.controls.LayoutGroup;
import starling.display.Sprite;

class Binder
{
   
   public var _container:Sprite;
   
   public var _background:LayoutGroup;
   
   public var _content:LayoutGroup;
   
   public function Binder()
   {
      super();
   }
}
