package §_-w2W§
{
   import §_-03T§.§_-2p§;
   import §_-12a§.§_-lc§;
   import §_-31W§.AchievRoomPanel;
   import §_-5Y§.§_-h2c§;
   import §_-62§.§_-zF§;
   import §_-91B§.§_-QK§;
   import §_-91B§.§_-z2l§;
   import §_-931§.§_-02O§;
   import §_-CF§.§_-x2t§;
   import §_-Ta§.*;
   import §_-Y1O§.*;
   import §_-Y1Q§.§_-aG§;
   import §_-b1F§.§_-G4§;
   import §_-gG§.§_-Z2z§;
   import §_-o14§.§_-Dd§;
   import §_-r1C§.§_-h2B§;
   import §_-z20§.*;
   import com.greensock.*;
   import com.greensock.core.*;
   import com.hurlant.math.BigInteger;
   import feathers.controls.Button;
   import feathers.controls.ToggleButton;
   import feathers.core.FeathersControl;
   import feathers.core.ITextRenderer;
   import flash.net.Socket;
   import flash.text.TextFormat;
   import flash.utils.ByteArray;
   import ru.pragmatix.flox.serialization.§_-616§;
   import ru.pragmatix.flox.social.model.PaymentOption;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.EffectType;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.messages.clans.structures.ClanAuditActionTO;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.§_-R2g§;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.DamageType;
   import starling.events.Event;
   import starling.utils.Pool;
   
   public class AchieveRoomScreenMobile extends §_-o28§
   {
      
      private var binder:Binder;
      
      private var §_-43l§:AchievRoomPanel;
      
      public function AchieveRoomScreenMobile()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         this.binder = new Binder();
         Application.uiBuilder.create(Application.assetManager.getObject("achieve_room_screen"),true,this.binder);
         addChild(this.binder._container);
         this.§_-z15§();
         §_-X1j§.§_-82T§.addEventListener(Event.CHANGE,this.§_-G1n§);
      }
      
      override public function dispose() : void
      {
         this.§_-43l§.dispose();
         §_-X1j§.§_-82T§.removeEventListener(Event.CHANGE,this.§_-G1n§);
         super.dispose();
      }
      
      override protected function draw() : void
      {
         super.draw();
         if(isInvalid(INVALIDATION_FLAG_DATA))
         {
         }
      }
      
      private function §_-G1n§(param1:Event) : void
      {
         this.§_-43l§.dispose();
         this.§_-z15§();
      }
      
      private function §_-z15§() : void
      {
         var _loc1_:FeathersControl = null;
         this.§_-43l§ = new AchievRoomPanel(500);
         _loc1_ = this.§_-43l§.display;
         _loc1_.width = 910;
         _loc1_.x = (stage.stageWidth - _loc1_.width) * 0.5 + 25;
         _loc1_.y = (stage.stageHeight - _loc1_.height) * 0.5;
         this.binder._content.addChild(_loc1_);
         _loc1_.validate();
      }
   }
}

import feathers.controls.LayoutGroup;
import starling.display.Sprite;

class Binder
{
   
   public var _container:Sprite;
   
   public var _background:LayoutGroup;
   
   public var _content:LayoutGroup;
   
   public function Binder()
   {
      super();
   }
}
