package §_-w2W§
{
   import §_-21p§.§_-4w§;
   import §_-31Y§.§_-D3B§;
   import §_-62§.§_-L1r§;
   import §_-62§.§_-O2H§;
   import §_-73I§.§_-Z2e§;
   import §_-9e§.§_-73e§;
   import §_-9e§.§_-8O§;
   import §_-9e§.§_-A18§;
   import §_-A1K§.§_-7u§;
   import §_-C2t§.§_-92W§;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-T22§;
   import §_-DJ§.§_-fH§;
   import §_-Ly§.§_-81L§;
   import §_-P1B§.§_-EB§;
   import §_-P1B§.§_-F1q§;
   import §_-P2i§.§_-G3J§;
   import §_-U1i§.§_-I3t§;
   import §_-Vg§.ClanEditView;
   import §_-W§.§_-Ap§;
   import §_-Y1Q§.§_-aG§;
   import §_-Y1Q§.§_-tc§;
   import §_-YF§.§_-L29§;
   import §_-Z1K§.§_-q24§;
   import §_-g2e§.§_-q2Z§;
   import §_-j2R§.§_-v1T§;
   import §_-k13§.§_-j23§;
   import §_-k1u§.§_-Oi§;
   import §_-l1g§.§_-L3Q§;
   import §_-l1g§.§_-T2N§;
   import §_-r1C§.*;
   import §_-u1P§.ShopResultEvent;
   import §_-zI§.§_-F3q§;
   import com.greensock.*;
   import com.greensock.plugins.*;
   import feathers.controls.LayoutGroup;
   import feathers.controls.List;
   import feathers.controls.Screen;
   import feathers.core.FeathersControl;
   import feathers.core.ToggleGroup;
   import feathers.data.ListCollection;
   import feathers.layout.AnchorLayoutData;
   import flash.display.DisplayObject;
   import flash.display.DisplayObjectContainer;
   import flash.events.Event;
   import flash.text.TextField;
   import flash.text.TextFormat;
   import flash.utils.ByteArray;
   import flash.utils.Dictionary;
   import flash.utils.IDataOutput;
   import ru.pragmatix.flox.gui.controls.§_-NY§;
   import ru.pragmatix.flox.serialization.§_-616§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.screenOverlay.view.*;
   import ru.pragmatix.wormix.messages.structures.BossWormStructure;
   import ru.pragmatix.wormix.messages.structures.TurnStructure;
   import ru.pragmatix.wormix.messages.structures.WeaponStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.bonus.§_-z17§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.*;
   import ru.pragmatix.wormix.pvp.messages.client.PvpActionEx;
   import ru.pragmatix.wormix.pvp.messages.client.PvpEndTurn;
   import ru.pragmatix.wormix.serialization.structures.*;
   import ru.pragmatix.wormix.utils.§_-Cq§;
   import ru.pragmatix.wormix.weapons.Weapon;
   import ru.pragmatix.wormix.weapons.§_-73v§;
   import starling.display.DisplayObject;
   import starling.events.Event;
   import starlingbuilder.extensions.uicomponents.ContainerButtonWithStates;
   
   public class §_-v27§ extends Screen implements §_-T22§
   {
      
      public function §_-v27§()
      {
         super();
         Application.§_-SH§.addEventListener(starling.events.Event.CHANGE,this.§_-f2I§);
      }
      
      override public function dispose() : void
      {
         Application.§_-SH§.removeEventListener(starling.events.Event.CHANGE,this.§_-f2I§);
         super.dispose();
      }
      
      override public function set screenID(param1:String) : void
      {
         if(param1 == null && _screenID != null)
         {
            §_-L29§.§_-gs§(_screenID);
         }
         super.screenID = param1;
      }
      
      private function §_-f2I§(param1:starling.events.Event) : void
      {
         this.invalidate(INVALIDATION_FLAG_DATA);
      }
      
      public function update() : void
      {
      }
      
      public function save(param1:Function) : void
      {
         if(param1 != null)
         {
            param1(true);
         }
      }
      
      override protected function screen_addedToStageHandler(param1:starling.events.Event) : void
      {
         var _loc2_:§_-t1R§ = this.openScreenSound;
         if(_loc2_)
         {
            §_-h2B§.play(this.openScreenSound);
         }
      }
      
      protected function get openScreenSound() : §_-t1R§
      {
         return §_-81L§.§_-q2C§;
      }
      
      public function §_-X2O§() : void
      {
      }
   }
}

