package §_-w2W§
{
   import ru.pragmatix.wormix.model.user.UserProfile;
   
   public interface §_-z25§
   {
      
      function §_-82v§(param1:UserProfile) : void;
   }
}

