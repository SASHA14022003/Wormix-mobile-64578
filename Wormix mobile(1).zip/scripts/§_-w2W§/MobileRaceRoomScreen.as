package §_-w2W§
{
   import §_-A1m§.MultipartURLLoader;
   import §_-B1y§.§_-83E§;
   import §_-B1y§.§_-F1P§;
   import §_-B1y§.§_-bs§;
   import §_-B2z§.§_-63i§;
   import §_-H2g§.§_-di§;
   import §_-H3§.*;
   import §_-Y1O§.§_-y1o§;
   import §_-ZP§.§_-YG§;
   import §_-ZP§.§_-w1J§;
   import §_-l2r§.§_-K1t§;
   import §_-q11§.RaceRoomAbilitiesPanel;
   import §_-q11§.RaceRoomDescriptionPanel;
   import §_-q11§.§_-V1F§;
   import §_-q11§.§_-i2T§;
   import §_-z1g§.§_-4l§;
   import §_-z1g§.§_-522§;
   import config.§_-vR§;
   import dragonBones.animation.WorldClock;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import flash.events.Event;
   import flash.events.IOErrorEvent;
   import flash.events.SecurityErrorEvent;
   import flash.geom.Point;
   import flash.geom.Rectangle;
   import flash.utils.ByteArray;
   import ru.pragmatix.flox.social.model.PaymentOption;
   import ru.pragmatix.flox.social.model.ResponseFormat;
   import ru.pragmatix.flox.social.response.SocialResponse;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.gui.§_-Q2v§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.server.VerifyPaymentResult;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.pvp.messages.ex.BattleCreated;
   import ru.pragmatix.wormix.pvp.messages.server.PvpEndBattle;
   import ru.pragmatix.wormix.pvp.messages.server.PvpRetryCommandRequestServer;
   import ru.pragmatix.wormix.pvp.messages.server.PvpStartTurn;
   import ru.pragmatix.wormix.pvp.messages.server.PvpSystemMessage;
   import ru.pragmatix.wormix.scene.SortingLayer;
   import ru.pragmatix.wormix.social.utils.FacebookTracking;
   import ru.pragmatix.wormix.utils.§_-72u§;
   import ru.pragmatix.wormix.utils.§_-YD§;
   import ru.pragmatix.wormix.weapons.Weapon;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   import starling.utils.Pool;
   import starling.utils.SystemUtil;
   
   public class MobileRaceRoomScreen extends §_-o28§ implements §_-z25§
   {
      
      private var binder:Binder;
      
      private var §_-A22§:Rectangle;
      
      private var §_-v1D§:§_-i2T§;
      
      private var §_-C3Q§:§_-V1F§;
      
      private var §_-02N§:RaceRoomDescriptionPanel;
      
      private var §_-q1Y§:RaceRoomAbilitiesPanel;
      
      public function MobileRaceRoomScreen()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         this.binder = new Binder();
         Application.uiBuilder.create(Application.assetManager.getObject("race_room_screen"),true,this.binder);
         addChild(this.binder._container);
         this.§_-A22§ = this.binder._container.bounds;
         this.§_-v1D§ = new §_-i2T§(this.binder._charPlace,this.binder._leftArrow,this.binder._rightArrow);
         this.§_-C3Q§ = new §_-V1F§(null,this.binder._selectedIndicator,this.§_-v1D§);
         this.§_-02N§ = new RaceRoomDescriptionPanel(this.binder._displayLeft,this.§_-v1D§);
         this.§_-q1Y§ = new RaceRoomAbilitiesPanel(this.binder._displayRight,this.§_-v1D§);
         Starling.juggler.add(this.binder._godRayPlane);
         Starling.juggler.add(this.binder._bubbles.particleSystem);
      }
      
      override public function dispose() : void
      {
         super.dispose();
         Starling.juggler.remove(this.binder._godRayPlane);
         Starling.juggler.remove(this.binder._bubbles.particleSystem);
         this.§_-v1D§.dispose();
         this.§_-C3Q§.dispose();
         this.§_-02N§.dispose();
         this.§_-q1Y§.dispose();
         this.§_-A22§ = null;
      }
      
      override protected function draw() : void
      {
         var _loc2_:Number = NaN;
         var _loc3_:Rectangle = null;
         var _loc4_:Rectangle = null;
         super.draw();
         var _loc1_:Number = stage.stageWidth;
         _loc2_ = stage.stageHeight;
         this.binder._background.x = 0;
         this.binder._background.y = 0;
         this.binder._background.width = _loc1_;
         this.binder._background.height = _loc2_;
         this.binder._content.scale = _loc2_ / this.§_-A22§.height;
         this.binder._content.y = 0;
         this.binder._content.x = (_loc1_ - this.binder._content.width) * 0.5 - this.binder._content.bounds.x;
         _loc3_ = this.binder._displayLeftBounds.getBounds(this.binder._container);
         this.binder._displayLeft.x = _loc3_.x;
         this.binder._displayLeft.y = _loc3_.y;
         this.binder._displayLeft.width = _loc3_.width;
         this.binder._displayLeft.height = _loc3_.height;
         Pool.putRectangle(_loc3_);
         _loc4_ = this.binder._displayRightBounds.getBounds(this.binder._container);
         this.binder._displayRight.x = _loc4_.x;
         this.binder._displayRight.y = _loc4_.y;
         this.binder._displayRight.width = _loc4_.width;
         this.binder._displayRight.height = _loc4_.height;
         Pool.putRectangle(_loc4_);
      }
      
      public function §_-82v§(param1:UserProfile) : void
      {
         this.§_-v1D§.§_-82v§(param1);
      }
   }
}

import feathers.controls.LayoutGroup;
import starling.display.Button;
import starling.display.Image;
import starling.display.Sprite;
import starling.extensions.GodRayPlane;
import starlingbuilder.extensions.particle.PDParticleSprite;

class Binder
{
   
   public var _container:LayoutGroup;
   
   public var _content:Sprite;
   
   public var _background:Sprite;
   
   public var _charPlace:Sprite;
   
   public var _displayLeftBounds:LayoutGroup;
   
   public var _displayRightBounds:LayoutGroup;
   
   public var _displayLeft:LayoutGroup;
   
   public var _displayRight:LayoutGroup;
   
   public var _leftArrow:Button;
   
   public var _rightArrow:Button;
   
   public var _godRayPlane:GodRayPlane;
   
   public var _bubbles:PDParticleSprite;
   
   public var _selectedIndicator:Image;
   
   public function Binder()
   {
      super();
   }
}
