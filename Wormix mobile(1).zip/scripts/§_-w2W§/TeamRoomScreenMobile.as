package §_-w2W§
{
   import §_-62§.§_-G1p§;
   import §_-91B§.§_-z2l§;
   import §_-A1K§.§_-6L§;
   import §_-A1K§.§_-U11§;
   import §_-C3f§.*;
   import §_-F2M§.§_-Z2m§;
   import §_-F2M§.§_-pR§;
   import §_-H2g§.§_-di§;
   import §_-P1z§.*;
   import §_-R2I§.PvpTab;
   import §_-RE§.§_-r2q§;
   import §_-Tm§.Action;
   import §_-Tm§.§_-K1I§;
   import §_-Tm§.§_-RF§;
   import §_-U1i§.§_-J1§;
   import §_-U1i§.§_-O2i§;
   import §_-bI§.§_-d2V§;
   import §_-fo§.§_-r5§;
   import §_-j22§.§_-5g§;
   import §_-p24§.MissionTab;
   import §_-z1g§.§_-y1S§;
   import com.distriqt.extension.inappbilling.InAppBilling;
   import com.distriqt.extension.inappbilling.Purchase;
   import feathers.controls.ScrollPolicy;
   import feathers.layout.AnchorLayout;
   import flash.events.Event;
   import flash.events.TimerEvent;
   import flash.geom.Rectangle;
   import flash.media.SoundMixer;
   import flash.media.SoundTransform;
   import flash.utils.ByteArray;
   import flash.utils.Dictionary;
   import flash.utils.IDataOutput;
   import ru.pragmatix.flox.social.model.PaymentOption;
   import ru.pragmatix.wormix.controller.§_-I2Y§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-Q2v§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.arena.boss.BossTypesTab;
   import ru.pragmatix.wormix.gui.menu.shop.mobile.*;
   import ru.pragmatix.wormix.messages.server.VerifyPaymentResult;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.pvp.messages.server.PvpRetryCommandRequestServer;
   import ru.pragmatix.wormix.serialization.SerializationUtils;
   import ru.pragmatix.wormix.social.common.post.*;
   import ru.pragmatix.wormix.utils.§_-J2h§;
   import ru.pragmatix.wormix.weapons.ammo.Ufo;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.events.Event;
   import starling.events.KeyboardEvent;
   import starling.utils.Pool;
   import starling.utils.RectangleUtil;
   import starling.utils.ScaleMode;
   
   public class TeamRoomScreenMobile extends §_-o28§
   {
      
      private var binder:Binder;
      
      private var §_-j1t§:§_-pR§;
      
      private var §_-P2U§:§_-Z2m§;
      
      public function TeamRoomScreenMobile()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         this.binder = new Binder();
         Application.uiBuilder.create(Application.assetManager.getObject("team_room_screen"),true,this.binder);
         addChild(this.binder._container);
         this.binder._foreground.touchable = false;
         this.§_-j1t§ = new §_-pR§(this.binder._charPlaces);
         this.§_-j1t§.§_-82v§(Application.§_-SH§.userProfile,Application.§_-SH§.§_-x2k§);
         this.§_-P2U§ = new §_-Z2m§(this.§_-j1t§.§_-w1S§());
         §_-X1j§.§_-D3H§.addEventListener(§_-I2Y§.EVENT_TEAM_CHANGED,this.§_-51F§);
         Application.§_-SH§.addEventListener(starling.events.Event.UPDATE,this.§_-D2H§);
      }
      
      private function §_-D2H§(param1:starling.events.Event) : void
      {
         this.update();
      }
      
      override public function update() : void
      {
         this.§_-j1t§.§_-82v§(Application.§_-SH§.userProfile,Application.§_-SH§.§_-x2k§);
      }
      
      private function §_-51F§(param1:Object) : void
      {
         this.update();
      }
      
      override protected function draw() : void
      {
         var _loc4_:Rectangle = null;
         super.draw();
         var _loc1_:Number = stage.stageWidth;
         var _loc2_:Number = stage.stageHeight;
         var _loc3_:Rectangle = Pool.getRectangle(0,0,this.binder._container.width,this.binder._container.height);
         _loc4_ = Pool.getRectangle(0,0,_loc1_,_loc2_);
         _loc3_ = RectangleUtil.fit(_loc3_,_loc4_,ScaleMode.NO_BORDER);
         this.binder._background.width = _loc3_.width;
         this.binder._background.height = _loc3_.height;
         this.binder._background.x = _loc3_.x;
         this.binder._background.y = _loc3_.y;
         this.binder._foreground.scaleX = this.binder._background.scaleX;
         this.binder._foreground.scaleY = this.binder._background.scaleY;
         this.binder._foreground.x = this.binder._background.x;
         this.binder._foreground.y = this.binder._background.y;
         this.binder._charsLayer.scale = _loc2_ / 1080;
         this.binder._charsLayer.y = 0;
         this.binder._charsLayer.x = (_loc1_ - this.binder._charsLayer.width) / 2;
         Pool.putRectangle(_loc3_);
         Pool.putRectangle(_loc4_);
      }
      
      override public function dispose() : void
      {
         super.dispose();
         this.§_-j1t§.dispose();
         this.§_-j1t§ = null;
         this.§_-P2U§.dispose();
         this.§_-P2U§ = null;
         §_-X1j§.§_-D3H§.removeEventListener(§_-I2Y§.EVENT_TEAM_CHANGED,this.§_-51F§);
         Application.§_-SH§.removeEventListener(starling.events.Event.UPDATE,this.§_-D2H§);
      }
   }
}

import feathers.controls.LayoutGroup;
import starling.display.Image;
import starling.display.Sprite;

class Binder
{
   
   public var _container:LayoutGroup;
   
   public var _charPlaces:Sprite;
   
   public var _foreground:Sprite;
   
   public var _background:Image;
   
   public var _charsLayer:Sprite;
   
   public function Binder()
   {
      super();
   }
}
