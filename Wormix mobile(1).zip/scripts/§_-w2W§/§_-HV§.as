package §_-w2W§
{
   import §_-02q§.§_-4s§;
   import §_-12W§.§_-X2w§;
   import §_-12W§.§_-l23§;
   import §_-5Y§.§_-h2c§;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-T1y§;
   import §_-72j§.§_-Z6§;
   import §_-72j§.§_-i2G§;
   import §_-A1K§.§_-TA§;
   import §_-B1y§.§_-bs§;
   import §_-CF§.§_-x2t§;
   import §_-D3A§.§_-TZ§;
   import §_-E1I§.§_-b2n§;
   import §_-T2h§.*;
   import §_-Ta§.*;
   import §_-Tm§.§_-RF§;
   import §_-U1i§.§_-J1§;
   import §_-Z1K§.§_-q24§;
   import §_-j1w§.§_-L1x§;
   import §_-j22§.§_-5g§;
   import §_-l1K§.§_-d2j§;
   import §_-l1g§.§_-L3Q§;
   import §_-o14§.§_-Dd§;
   import §_-r1C§.§_-h2B§;
   import §_-r1C§.§_-t1R§;
   import com.hurlant.math.BigInteger;
   import config.§_-xD§;
   import feathers.controls.text.TextFieldTextRenderer;
   import feathers.core.ITextRenderer;
   import feathers.events.FeathersEventType;
   import flash.display.MovieClip;
   import flash.events.Event;
   import flash.net.Socket;
   import flash.text.TextField;
   import flash.text.TextFormat;
   import flash.utils.ByteArray;
   import flash.utils.IDataOutput;
   import ru.pragmatix.flox.gui.controls.§_-zi§;
   import ru.pragmatix.flox.serialization.§_-616§;
   import ru.pragmatix.flox.social.controller.ISocialController;
   import ru.pragmatix.flox.social.model.PaymentOption;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.messages.server.GetFriendListPageResult;
   import ru.pragmatix.wormix.messages.structures.UserProfileStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   import ru.pragmatix.wormix.serialization.server.*;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import starling.core.Starling;
   import starling.events.Event;
   
   public class §_-HV§ extends §_-v27§
   {
      
      public function §_-HV§()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         addEventListener(FeathersEventType.TRANSITION_IN_COMPLETE,this.§_-l25§);
      }
      
      private function §_-l25§(param1:starling.events.Event) : void
      {
         removeEventListener(FeathersEventType.TRANSITION_IN_COMPLETE,this.§_-l25§);
         Starling.juggler.delayCall(this.§_-8t§,0.3);
      }
      
      private function §_-8t§() : void
      {
         §_-X1j§.§_-12n§.§_-41l§();
         Starling.juggler.delayCall(this.§_-12o§,0.3);
      }
      
      private function §_-12o§() : void
      {
         §_-X1j§.§_-12n§.addEventListener(starling.events.Event.COMPLETE,this.onSceneCreated);
         §_-X1j§.§_-12n§.§_-H1V§();
         Effects.initBeforeBattle();
      }
      
      private function onSceneCreated(param1:starling.events.Event) : void
      {
         §_-X1j§.§_-12n§.removeEventListener(starling.events.Event.COMPLETE,this.onSceneCreated);
         Application.§_-E1k§.showScreen(§_-21w§.BATTLE_SCENE,§_-21w§.§_-01l§);
      }
      
      override protected function get openScreenSound() : §_-t1R§
      {
         return null;
      }
   }
}

