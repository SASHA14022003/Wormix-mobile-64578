package §_-w2W§
{
   import §_-62§.§_-F1D§;
   import §_-B1y§.§_-bs§;
   import §_-H2g§.§_-di§;
   import §_-P1B§.§_-b21§;
   import §_-T1t§.§_-u19§;
   import §_-TF§.§_-P19§;
   import §_-Z1K§.§_-q24§;
   import §_-b1F§.§_-G4§;
   import §_-hO§.AttackDodgedEvent;
   import §_-k1u§.§_-2m§;
   import §_-k1u§.§_-Oi§;
   import §_-l2r§.§_-K1t§;
   import §_-qH§.§_-S25§;
   import §_-r1C§.§_-U2p§;
   import §_-s1Q§.Artifacts;
   import §_-u13§.MD5;
   import §_-u13§.SHA1;
   import §_-w2i§.§_-Zd§;
   import §_-z20§.*;
   import config.§_-V2w§;
   import dragonBones.animation.WorldClock;
   import flash.utils.ByteArray;
   import flash.utils.IDataOutput;
   import ru.pragmatix.flox.social.SocialAppContext;
   import ru.pragmatix.flox.social.controller.SocialApiSettings;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.game.§_-eX§;
   import ru.pragmatix.wormix.gui.§_-Q2v§;
   import ru.pragmatix.wormix.model.bonus.§_-x2M§;
   import ru.pragmatix.wormix.model.items.craft.§_-IE§;
   import ru.pragmatix.wormix.model.items.craft.§_-Y2u§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.social.§_-L23§;
   import ru.pragmatix.wormix.utils.*;
   import starling.display.DisplayObject;
   import starling.events.Event;
   
   public class §_-I2R§ extends §_-v27§
   {
      
      public function §_-I2R§()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         §_-X1j§.§_-zU§.§_-56§();
      }
      
      override public function dispose() : void
      {
         §_-X1j§.§_-zU§.§_-o17§();
         super.dispose();
      }
   }
}

