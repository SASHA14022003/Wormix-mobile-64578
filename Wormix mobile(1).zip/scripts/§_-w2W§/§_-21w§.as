package §_-w2W§
{
   import §_-31W§.*;
   import §_-31Y§.§_-D3B§;
   import §_-wD§.*;
   import feathers.motion.ColorFade;
   import ru.pragmatix.wormix.objects.*;
   import starling.events.Event;
   
   public class §_-21w§
   {
      
      public static const §_-lv§:String = "Preloader";
      
      public static const §_-G31§:String = "MainMenuScreen";
      
      public static const §_-81H§:String = "ShopMenu";
      
      public static const §_-43d§:String = "CraftRoom";
      
      public static const §_-l1e§:String = "AchieveRoom";
      
      public static const §_-jc§:String = "RaceRoom";
      
      public static const §_-G2M§:String = "WardrobeRoom";
      
      public static const §_-H2E§:String = "TeamRoom";
      
      public static const §_-F3d§:String = "ArmoryRoom";
      
      public static const BATTLE_SCENE:String = "BATTLE_SCENE";
      
      public static const BATTLE_LOADING:String = "BATTLE_LOADING";
      
      public static const BATTLE_CLEANING:String = "BATTLE_CLEANING";
      
      public static const §_-01l§:Function = ColorFade.createBlackFadeTransition(1);
      
      public function §_-21w§()
      {
         super();
      }
   }
}

