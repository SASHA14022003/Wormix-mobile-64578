package §_-w2W§
{
   import §_-12W§.*;
   import §_-22z§.§_-f1b§;
   import §_-51j§.§_-C1L§;
   import §_-51j§.§_-X19§;
   import §_-51j§.§_-w17§;
   import §_-5P§.§_-H1u§;
   import §_-62§.§_-T1y§;
   import §_-91A§.*;
   import §_-G2H§.§_-527§;
   import §_-Vg§.§_-M11§;
   import §_-l1g§.§_-L3Q§;
   import §_-lh§.§_-z2A§;
   import §_-nE§.SelectCraftWeaponScreen;
   import §_-nE§.§_-p16§;
   import com.distriqt.extension.inappbilling.InAppBilling;
   import com.distriqt.extension.inappbilling.Purchase;
   import feathers.core.FeathersControl;
   import feathers.data.ListCollection;
   import feathers.events.FeathersEventType;
   import flash.display.DisplayObject;
   import flash.events.Event;
   import flash.geom.Rectangle;
   import flash.utils.ByteArray;
   import ru.pragmatix.flox.social.utils.id.IPlatformAccountController;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.ClanMessages;
   import ru.pragmatix.wormix.messages.structures.UserProfileStructure;
   import ru.pragmatix.wormix.model.items.craft.§_-6S§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.pvp.messages.ex.ReconnectToBattle;
   import ru.pragmatix.wormix.pvp.messages.ex.StartPvpBattle;
   import ru.pragmatix.wormix.pvp.messages.server.BattleLoginError;
   import ru.pragmatix.wormix.utils.§_-71v§;
   import ru.pragmatix.wormix.utils.§_-J2h§;
   import starling.events.Event;
   import starling.utils.Pool;
   import starling.utils.RectangleUtil;
   import starling.utils.ScaleMode;
   
   public class ArmoryScreenDesktop extends §_-o28§
   {
      
      private var binder:Binder;
      
      private var §_-Z1o§:§_-C1L§;
      
      private var §_-u1q§:§_-X19§;
      
      private var §_-13t§:§_-w17§;
      
      public function ArmoryScreenDesktop()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         this.binder = new Binder();
         Application.uiBuilder.create(Application.assetManager.getObject("armory_room_back"),true,this.binder);
         addChild(this.binder._container);
         this.binder._items.dataProvider = new ListCollection();
         this.§_-Z1o§ = new §_-C1L§(this.binder._items,this.binder._prev,this.binder._next);
         this.§_-u1q§ = new §_-X19§(this.binder._items);
         this.§_-13t§ = new §_-w17§(this.binder._vipTimer);
         this.§_-13t§.addEventListener(starling.events.Event.CHANGE,this.§_-iA§);
         this.§_-13t§.init();
         invalidate(INVALIDATION_FLAG_DATA);
      }
      
      override protected function draw() : void
      {
         var _loc3_:Rectangle = null;
         var _loc4_:Rectangle = null;
         var _loc5_:UserProfile = null;
         super.draw();
         if(isInvalid(INVALIDATION_FLAG_DATA))
         {
            _loc5_ = Application.§_-SH§.userProfile;
            this.§_-Z1o§.§_-Za§(_loc5_);
         }
         var _loc1_:Number = stage.stageWidth;
         var _loc2_:Number = stage.stageHeight;
         _loc3_ = Pool.getRectangle(0,0,this.binder._container.width,this.binder._container.height);
         _loc4_ = Pool.getRectangle(0,0,_loc1_,_loc2_);
         _loc3_ = RectangleUtil.fit(_loc3_,_loc4_,ScaleMode.NO_BORDER);
         this.binder._container.scale *= _loc3_.height / this.binder._container.height;
         this.binder._container.x = _loc1_ * 0.5;
         this.binder._container.y = _loc2_ * 0.5;
         Pool.putRectangle(_loc3_);
         Pool.putRectangle(_loc4_);
      }
      
      override public function dispose() : void
      {
         super.dispose();
         this.§_-Z1o§.dispose();
         this.§_-u1q§.dispose();
         this.§_-13t§.removeEventListener(starling.events.Event.CHANGE,this.§_-iA§);
         this.§_-13t§.dispose();
      }
      
      override public function save(param1:Function) : void
      {
         §_-f1b§.§_-r1K§();
         super.save(param1);
      }
      
      private function §_-iA§(param1:starling.events.Event) : void
      {
         invalidate(INVALIDATION_FLAG_DATA);
      }
   }
}

import feathers.controls.LayoutGroup;
import feathers.controls.List;
import starling.display.Button;

class Binder
{
   
   public var _container:LayoutGroup;
   
   public var _items:List;
   
   public var _prev:Button;
   
   public var _next:Button;
   
   public var _vipTimer:LayoutGroup;
   
   public function Binder()
   {
      super();
   }
}
