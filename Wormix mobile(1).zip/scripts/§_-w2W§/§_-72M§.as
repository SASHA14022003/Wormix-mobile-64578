package §_-w2W§
{
   import §_-62§.§_-W1r§;
   import §_-931§.§_-02O§;
   import §_-DJ§.§_-J2l§;
   import §_-Y1O§.*;
   import §_-Y1Q§.§_-aG§;
   import §_-b1F§.§_-G4§;
   import §_-gG§.§_-Z2z§;
   import §_-j1w§.§_-B2i§;
   import §_-r1C§.§_-h2B§;
   import §_-r1C§.§_-t1R§;
   import §_-u2J§.§_-T1K§;
   import feathers.controls.Button;
   import feathers.controls.ToggleButton;
   import flash.display.DisplayObject;
   import flash.errors.IllegalOperationError;
   import ru.pragmatix.wormix.Scene;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.messages.clans.structures.ClanAuditActionTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanChatMessageTO;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.weapons.ammo.DamageType;
   
   public class §_-72M§ extends §_-v27§
   {
      
      private var scene:Scene;
      
      public function §_-72M§()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         this.scene = §_-X1j§.§_-12n§.scene;
         addChild(this.scene);
         §_-X1j§.§_-12n§.§_-Sd§();
         §_-J2l§.§_-m1I§();
      }
      
      override public function dispose() : void
      {
         this.scene.removeFromParent(true);
         this.scene = null;
         super.dispose();
      }
      
      override protected function get openScreenSound() : §_-t1R§
      {
         return null;
      }
   }
}

