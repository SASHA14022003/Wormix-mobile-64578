package §_-w2W§
{
   import §_-2k§.*;
   import §_-31N§.§_-42G§;
   import §_-31W§.§_-Kb§;
   import §_-31Y§.§_-D3B§;
   import §_-A1K§.§_-7u§;
   import §_-A2F§.§_-4B§;
   import §_-B1y§.§_-83E§;
   import §_-D3A§.§_-TZ§;
   import §_-F39§.*;
   import §_-L1H§.§_-C3e§;
   import §_-Y1O§.§_-V23§;
   import §_-YF§.§_-q2v§;
   import §_-Z1K§.§_-M6§;
   import §_-Z1L§.§_-A2V§;
   import §_-Z1L§.§_-H1K§;
   import §_-gG§.§_-M2S§;
   import §_-k1u§.§_-F3H§;
   import §_-k1u§.§_-Oi§;
   import §_-l1K§.§_-d2j§;
   import §_-l1g§.§_-L3Q§;
   import §_-lh§.CraftRoomPanel;
   import §_-r1C§.§_-U2p§;
   import §_-r1C§.§_-h2B§;
   import §_-rM§.§_-61j§;
   import §_-w2i§.§_-Ia§;
   import §_-x2Q§.§_-dU§;
   import §_-z1g§.§_-M2v§;
   import com.hurlant.crypto.tls.§_-21v§;
   import feathers.controls.ScrollPolicy;
   import feathers.core.FeathersControl;
   import feathers.data.VectorCollection;
   import feathers.layout.AnchorLayoutData;
   import flash.events.Event;
   import flash.geom.Rectangle;
   import flash.media.Sound;
   import flash.utils.IDataInput;
   import ru.pragmatix.flox.logger.*;
   import ru.pragmatix.wormix.Scene;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.sets.ControlSets;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.gui.*;
   import ru.pragmatix.wormix.gui.menu.clans.chat.*;
   import ru.pragmatix.wormix.messages.clans.main.server.ClanInviteStructure;
   import ru.pragmatix.wormix.messages.server.ShowSystemMessage;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.items.craft.*;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-r1d§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.LaserRay;
   import ru.pragmatix.wormix.weapons.ammo.StaticCharge;
   import starling.display.DisplayObject;
   import starling.display.Quad;
   import starling.events.Event;
   import starling.utils.Pool;
   import starling.utils.RectangleUtil;
   import starling.utils.ScaleMode;
   
   public class CraftRoomScreenDesktop extends §_-o28§
   {
      
      private var binder:Binder;
      
      private var §_-Rf§:CraftRoomPanel;
      
      public function CraftRoomScreenDesktop()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         this.binder = new Binder();
         Application.uiBuilder.create(Application.assetManager.getObject("craft_room_screen"),true,this.binder);
         addChild(this.binder._container);
         §_-X1j§.§_-82T§.addEventListener(starling.events.Event.CHANGE,this.§_-G1n§);
         Application.§_-SH§.userProfile.addEventListener(starling.events.Event.CHANGE,this.§_-Z2B§);
         this.§_-t2U§();
      }
      
      override public function dispose() : void
      {
         this.§_-Rf§.dispose();
         §_-X1j§.§_-82T§.removeEventListener(starling.events.Event.CHANGE,this.§_-G1n§);
         Application.§_-SH§.userProfile.removeEventListener(starling.events.Event.CHANGE,this.§_-Z2B§);
         super.dispose();
      }
      
      override protected function draw() : void
      {
         var _loc2_:Number = NaN;
         var _loc3_:Rectangle = null;
         var _loc4_:Rectangle = null;
         super.draw();
         var _loc1_:Number = stage.stageWidth;
         _loc2_ = stage.stageHeight;
         _loc3_ = Pool.getRectangle(0,0,this.binder._background.width,this.binder._background.height);
         _loc4_ = Pool.getRectangle(0,0,_loc1_,_loc2_);
         _loc3_ = RectangleUtil.fit(_loc3_,_loc4_,ScaleMode.NO_BORDER);
         this.binder._background.scale *= _loc3_.height / this.binder._background.height;
         this.binder._background.x = (_loc1_ - this.binder._background.width) * 0.5;
         this.binder._background.y = (_loc2_ - this.binder._background.height) * 0.5;
         this.binder._content.width = _loc1_;
         this.binder._content.height = _loc2_;
         Pool.putRectangle(_loc3_);
         Pool.putRectangle(_loc4_);
      }
      
      override public function §_-X2O§() : void
      {
         if(!this.§_-Rf§.§_-O1W§())
         {
            Application.§_-E1k§.showScreen(§_-21w§.§_-G31§);
         }
      }
      
      private function §_-Z2B§(param1:starling.events.Event) : void
      {
         this.§_-t2U§();
      }
      
      private function §_-G1n§(param1:starling.events.Event) : void
      {
         this.§_-Rf§.dispose();
         this.§_-t2U§();
      }
      
      private function §_-t2U§() : void
      {
         var _loc1_:§_-r1d§ = Application.§_-SH§;
         this.§_-Rf§ = new CraftRoomPanel();
         this.§_-Rf§.§_-82v§(_loc1_.userProfile,_loc1_.§_-x2k§);
         var _loc2_:FeathersControl = this.§_-Rf§.display;
         _loc2_.layoutData = new AnchorLayoutData(NaN,NaN,NaN,NaN,0,0);
         this.binder._content.addChild(_loc2_);
      }
   }
}

import feathers.controls.LayoutGroup;
import starling.display.Image;

class Binder
{
   
   public var _container:LayoutGroup;
   
   public var _background:Image;
   
   public var _content:LayoutGroup;
   
   public function Binder()
   {
      super();
   }
}
