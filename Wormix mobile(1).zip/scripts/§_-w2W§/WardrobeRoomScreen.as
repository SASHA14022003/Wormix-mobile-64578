package §_-w2W§
{
   import §_-23P§.§_-V2T§;
   import §_-23P§.§_-u1z§;
   import §_-62§.§_-O2H§;
   import §_-62§.§_-W1r§;
   import §_-931§.§_-02O§;
   import §_-CF§.§_-x2t§;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-fH§;
   import §_-J3L§.§_-h1D§;
   import §_-SP§.§_-M4§;
   import §_-T2h§.§_-43C§;
   import §_-T2h§.§_-C1R§;
   import §_-TF§.§_-y2n§;
   import §_-U1i§.§_-J1§;
   import §_-Vg§.*;
   import §_-Y1O§.§_-yA§;
   import §_-Y1Q§.§_-aG§;
   import §_-Z1K§.§_-q24§;
   import §_-b1F§.§_-G4§;
   import §_-d26§.§_-d1H§;
   import §_-gG§.§_-Z2z§;
   import §_-k1u§.§_-Oi§;
   import §_-l1g§.§_-L3Q§;
   import §_-l1g§.§_-T2N§;
   import §_-r1C§.§_-h2B§;
   import §_-s20§.§_-J2g§;
   import §_-s20§.§_-d21§;
   import §_-u1P§.ShopResultEvent;
   import config.§_-B1K§;
   import feathers.controls.Button;
   import feathers.controls.ScreenNavigator;
   import feathers.controls.ScreenNavigatorItem;
   import feathers.controls.ToggleButton;
   import feathers.data.ListCollection;
   import feathers.layout.AnchorLayoutData;
   import flash.display.DisplayObject;
   import flash.geom.Rectangle;
   import flash.utils.Dictionary;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.game.§_-eX§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.structures.ClanAuditActionTO;
   import ru.pragmatix.wormix.messages.client.BuyResetBonusItems;
   import ru.pragmatix.wormix.messages.server.BuyResetBonusItemsResult;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-r1d§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.Force;
   import ru.pragmatix.wormix.utils.§_-Cq§;
   import ru.pragmatix.wormix.utils.§_-J2h§;
   import ru.pragmatix.wormix.utils.§_-L2i§;
   import ru.pragmatix.wormix.weapons.Weapon;
   import ru.pragmatix.wormix.weapons.ammo.DamageType;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.utils.Pool;
   import starling.utils.RectangleUtil;
   import starling.utils.ScaleMode;
   import starling.utils.SystemUtil;
   
   public class WardrobeRoomScreen extends §_-o28§
   {
      
      public static var §_-H1z§:WardrobeRoomScreen;
      
      private var binder:Binder;
      
      private var §_-k17§:§_-C1R§;
      
      private var §_-229§:§_-43C§;
      
      private var §_-42i§:§_-43C§;
      
      private var §_-g11§:§_-d1H§;
      
      public function WardrobeRoomScreen()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         this.§_-g11§ = new §_-d1H§();
         this.binder = new Binder();
         Application.uiBuilder.create(Application.assetManager.getObject("wardrobe_room_screen"),true,this.binder);
         addChild(this.binder._content);
         this.binder._lights.touchable = false;
         this.§_-k17§ = new §_-C1R§(this.binder._charPlaces,this.§_-g11§);
         this.§_-229§ = new §_-43C§(this.binder._hatsList,§_-B1K§.HAT,this.§_-g11§);
         this.§_-42i§ = new §_-43C§(this.binder._artifactsList,§_-B1K§.ARTIFACT,this.§_-g11§);
         this.§_-229§.§_-N2T§(this.binder._hats_next_btn,this.binder._hats_prev_btn);
         this.§_-42i§.§_-N2T§(this.binder._artifacts_next_btn,this.binder._artifacts_prev_btn);
         var _loc1_:§_-r1d§ = Application.§_-SH§;
         this.§_-g11§.setData(_loc1_.userProfile,_loc1_.§_-x2k§);
         §_-H1z§ = this;
      }
      
      public function §_-M14§(param1:§_-W1r§) : void
      {
         this.§_-k17§.§_-M14§(param1);
      }
      
      override public function dispose() : void
      {
         this.§_-k17§.dispose();
         this.§_-229§.dispose();
         this.§_-42i§.dispose();
         super.dispose();
      }
      
      override protected function draw() : void
      {
         var stageWidth:Number;
         var stageHeight:Number;
         var scaledRect:Rectangle;
         var stageRect:Rectangle;
         var newScale:Number;
         super.draw();
         stageWidth = stage.stageWidth;
         stageHeight = stage.stageHeight;
         scaledRect = Pool.getRectangle(0,0,1920,1080);
         stageRect = Pool.getRectangle(0,0,stageWidth,stageHeight);
         scaledRect = RectangleUtil.fit(scaledRect,stageRect,ScaleMode.NO_BORDER);
         newScale = Number(Math.max(scaledRect.width / 1920,scaledRect.height / 1080));
         with(this.binder._content)
         {
            scale = newScale;
            x = scaledRect.x;
            y = scaledRect.y;
            width = scaledRect.width;
            height = scaledRect.height;
         }
         Pool.putRectangle(scaledRect);
         Pool.putRectangle(stageRect);
      }
      
      override public function save(param1:Function) : void
      {
         if(this.§_-g11§.§_-S2F§())
         {
            §_-X1j§.§_-t1T§.save(param1,this.§_-g11§.§_-72m§());
         }
         else
         {
            param1(true);
         }
      }
   }
}

import feathers.controls.LayoutGroup;
import feathers.controls.List;
import starling.display.Sprite;
import starlingbuilder.extensions.uicomponents.ContainerButtonWithStates;

class Binder
{
   
   public var _content:LayoutGroup;
   
   public var _charPlaces:Sprite;
   
   public var _lights:Sprite;
   
   public var _hats_prev_btn:ContainerButtonWithStates;
   
   public var _hats_next_btn:ContainerButtonWithStates;
   
   public var _artifacts_prev_btn:ContainerButtonWithStates;
   
   public var _artifacts_next_btn:ContainerButtonWithStates;
   
   public var _hatsList:List;
   
   public var _artifactsList:List;
   
   public function Binder()
   {
      super();
   }
}
