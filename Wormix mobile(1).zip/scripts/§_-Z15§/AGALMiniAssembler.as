package §_-Z15§
{
   import §_-D3A§.§_-TZ§;
   import §_-H2g§.§_-di§;
   import §_-J31§.§_-e2J§;
   import §_-N8§.§_-o2w§;
   import §_-SP§.§_-M4§;
   import §_-Y1Q§.§_-F1g§;
   import §_-Y1Q§.§_-aG§;
   import §_-Z1K§.*;
   import §_-Z1w§.§_-w1D§;
   import §_-ZP§.§_-b23§;
   import §_-j1w§.§_-B2i§;
   import §_-j1w§.§_-L1x§;
   import §_-l1K§.§_-cZ§;
   import §_-l1g§.§_-L3Q§;
   import com.greensock.*;
   import com.greensock.core.*;
   import com.greensock.loading.core.*;
   import com.greensock.plugins.*;
   import config.§_-vR§;
   import feathers.events.FeathersEventType;
   import flash.display.*;
   import flash.display3D.*;
   import flash.events.*;
   import flash.geom.Point;
   import flash.utils.*;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.server.VerifyPaymentResult;
   import ru.pragmatix.wormix.model.items.craft.CraftedEquipFamily;
   import ru.pragmatix.wormix.objects.Direction;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.physics.model.IPhysicModel;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.utils.Pool;
   
   public class AGALMiniAssembler
   {
      
      private static var §_-i2H§:Boolean = false;
      
      private static const §_-T2§:int = 4;
      
      private static const §_-M1M§:int = 4096;
      
      private static const §_-y6§:String = "fragment";
      
      private static const VERTEX:String = "vertex";
      
      private static const §_-g2v§:uint = 8;
      
      private static const §_-pJ§:uint = 12;
      
      private static const §_-T2p§:uint = 16;
      
      private static const §_-r1p§:uint = 20;
      
      private static const §_-Eg§:uint = 24;
      
      private static const §_-S12§:uint = 28;
      
      private static const §_-MT§:uint = 1;
      
      private static const §_-c2L§:uint = 2;
      
      private static const §_-D1K§:uint = 32;
      
      private static const §_-rL§:uint = 64;
      
      private static const §_-32l§:uint = 1;
      
      private static const §_-D2G§:uint = 8;
      
      private static const §_-v2Y§:uint = 16;
      
      private static const §_-Q27§:uint = 32;
      
      private static const §_-52N§:uint = 64;
      
      private static const §_-8e§:uint = 128;
      
      private static const §_-XS§:uint = 256;
      
      private static const §_-61Y§:uint = 512;
      
      private static const §_-cY§:uint = 1024;
      
      private static const §_-q1D§:String = "mov";
      
      private static const ADD:String = "add";
      
      private static const §_-qA§:String = "sub";
      
      private static const §_-64§:String = "mul";
      
      private static const §_-A3j§:String = "div";
      
      private static const §_-83F§:String = "rcp";
      
      private static const §_-e1P§:String = "min";
      
      private static const §_-sM§:String = "max";
      
      private static const §_-133§:String = "frc";
      
      private static const §_-E1J§:String = "sqt";
      
      private static const §_-k2U§:String = "rsq";
      
      private static const §_-A2m§:String = "pow";
      
      private static const LOG:String = "log";
      
      private static const §_-42Q§:String = "exp";
      
      private static const §_-D1z§:String = "nrm";
      
      private static const §_-Jt§:String = "sin";
      
      private static const §_-d2L§:String = "cos";
      
      private static const §_-037§:String = "crs";
      
      private static const DP3:String = "dp3";
      
      private static const DP4:String = "dp4";
      
      private static const §_-O2I§:String = "abs";
      
      private static const §_-Uz§:String = "neg";
      
      private static const §_-Wr§:String = "sat";
      
      private static const M33:String = "m33";
      
      private static const M44:String = "m44";
      
      private static const M34:String = "m34";
      
      private static const §_-m2q§:String = "ddx";
      
      private static const §_-639§:String = "ddy";
      
      private static const §_-41J§:String = "ife";
      
      private static const §_-V1Z§:String = "ine";
      
      private static const §_-B2y§:String = "ifg";
      
      private static const §_-L2c§:String = "ifl";
      
      private static const §_-ld§:String = "els";
      
      private static const §_-f2O§:String = "eif";
      
      private static const §_-51§:String = "ted";
      
      private static const §_-317§:String = "kil";
      
      private static const §_-Q2o§:String = "tex";
      
      private static const §_-r2w§:String = "sge";
      
      private static const §_-uG§:String = "slt";
      
      private static const §_-T1A§:String = "sgn";
      
      private static const §_-c1n§:String = "seq";
      
      private static const §_-72n§:String = "sne";
      
      private static const §_-V1s§:String = "tld";
      
      private static const §_-C1y§:String = "va";
      
      private static const §_-o27§:String = "vc";
      
      private static const §_-V1j§:String = "vt";
      
      private static const §_-63W§:String = "vo";
      
      private static const §_-H2m§:String = "vi";
      
      private static const §_-01e§:String = "fc";
      
      private static const §_-q1§:String = "ft";
      
      private static const §_-j1z§:String = "fs";
      
      private static const §_-x7§:String = "fo";
      
      private static const §_-m2o§:String = "fd";
      
      private static const §_-C3s§:String = "iid";
      
      private static const §_-63l§:String = "vs";
      
      private static const D2:String = "2d";
      
      private static const D3:String = "3d";
      
      private static const §_-92q§:String = "cube";
      
      private static const §_-11h§:String = "mipnearest";
      
      private static const §_-n2m§:String = "miplinear";
      
      private static const §_-12F§:String = "mipnone";
      
      private static const §_-A3R§:String = "nomip";
      
      private static const §_-l20§:String = "nearest";
      
      private static const LINEAR:String = "linear";
      
      private static const ANISOTROPIC2X:String = "anisotropic2x";
      
      private static const ANISOTROPIC4X:String = "anisotropic4x";
      
      private static const ANISOTROPIC8X:String = "anisotropic8x";
      
      private static const ANISOTROPIC16X:String = "anisotropic16x";
      
      private static const §_-R1E§:String = "centroid";
      
      private static const SINGLE:String = "single";
      
      private static const §_-D2g§:String = "ignoresampler";
      
      private static const REPEAT:String = "repeat";
      
      private static const §_-t1E§:String = "wrap";
      
      private static const §_-I3l§:String = "clamp";
      
      private static const §_-m11§:String = "repeat_u_clamp_v";
      
      private static const §_-W2A§:String = "clamp_u_repeat_v";
      
      private static const §_-y16§:String = "rgba";
      
      private static const COMPRESSED:String = "compressed";
      
      private static const §_-n2a§:String = "compressedalpha";
      
      private static const DXT1:String = "dxt1";
      
      private static const DXT5:String = "dxt5";
      
      private static const §_-vo§:String = "video";
      
      protected static const §_-D2K§:RegExp = /^\s+|\s+$/g;
      
      private static const §_-z2o§:Dictionary = new Dictionary();
      
      private static const §_-w1a§:Dictionary = new Dictionary();
      
      private static const §_-22B§:Dictionary = new Dictionary();
      
      private var §_-835§:ByteArray = null;
      
      private var §_-Xn§:String = "";
      
      private var §_-626§:Boolean = false;
      
      public var verbose:Boolean = false;
      
      public function AGALMiniAssembler(param1:Boolean = false)
      {
         super();
         §_-626§ = param1;
         if(!§_-i2H§)
         {
            init();
         }
      }
      
      private static function init() : void
      {
         §_-i2H§ = true;
         §_-z2o§["mov"] = new OpCode("mov",2,0,0);
         §_-z2o§["add"] = new OpCode("add",3,1,0);
         §_-z2o§["sub"] = new OpCode("sub",3,2,0);
         §_-z2o§["mul"] = new OpCode("mul",3,3,0);
         §_-z2o§["div"] = new OpCode("div",3,4,0);
         §_-z2o§["rcp"] = new OpCode("rcp",2,5,0);
         §_-z2o§["min"] = new OpCode("min",3,6,0);
         §_-z2o§["max"] = new OpCode("max",3,7,0);
         §_-z2o§["frc"] = new OpCode("frc",2,8,0);
         §_-z2o§["sqt"] = new OpCode("sqt",2,9,0);
         §_-z2o§["rsq"] = new OpCode("rsq",2,10,0);
         §_-z2o§["pow"] = new OpCode("pow",3,11,0);
         §_-z2o§["log"] = new OpCode("log",2,12,0);
         §_-z2o§["exp"] = new OpCode("exp",2,13,0);
         §_-z2o§["nrm"] = new OpCode("nrm",2,14,0);
         §_-z2o§["sin"] = new OpCode("sin",2,15,0);
         §_-z2o§["cos"] = new OpCode("cos",2,16,0);
         §_-z2o§["crs"] = new OpCode("crs",3,17,0);
         §_-z2o§["dp3"] = new OpCode("dp3",3,18,0);
         §_-z2o§["dp4"] = new OpCode("dp4",3,19,0);
         §_-z2o§["abs"] = new OpCode("abs",2,20,0);
         §_-z2o§["neg"] = new OpCode("neg",2,21,0);
         §_-z2o§["sat"] = new OpCode("sat",2,22,0);
         §_-z2o§["m33"] = new OpCode("m33",3,23,16);
         §_-z2o§["m44"] = new OpCode("m44",3,24,16);
         §_-z2o§["m34"] = new OpCode("m34",3,25,16);
         §_-z2o§["ddx"] = new OpCode("ddx",2,26,0x0100 | 0x20);
         §_-z2o§["ddy"] = new OpCode("ddy",2,27,0x0100 | 0x20);
         §_-z2o§["ife"] = new OpCode("ife",2,28,0x80 | 0x0100 | 0x0200 | 1);
         §_-z2o§["ine"] = new OpCode("ine",2,29,0x80 | 0x0100 | 0x0200 | 1);
         §_-z2o§["ifg"] = new OpCode("ifg",2,30,0x80 | 0x0100 | 0x0200 | 1);
         §_-z2o§["ifl"] = new OpCode("ifl",2,31,0x80 | 0x0100 | 0x0200 | 1);
         §_-z2o§["els"] = new OpCode("els",0,32,0x80 | 0x0100 | 0x0200 | 0x0400 | 1);
         §_-z2o§["eif"] = new OpCode("eif",0,33,0x80 | 0x0100 | 0x0400 | 1);
         §_-z2o§["kil"] = new OpCode("kil",1,39,0x80 | 0x20);
         §_-z2o§["tex"] = new OpCode("tex",3,40,0x20 | 8);
         §_-z2o§["sge"] = new OpCode("sge",3,41,0);
         §_-z2o§["slt"] = new OpCode("slt",3,42,0);
         §_-z2o§["sgn"] = new OpCode("sgn",2,43,0);
         §_-z2o§["seq"] = new OpCode("seq",3,44,0);
         §_-z2o§["sne"] = new OpCode("sne",3,45,0);
         §_-z2o§["tld"] = new OpCode("tld",3,46,0x40 | 8);
         §_-22B§["rgba"] = new Sampler("rgba",8,0);
         §_-22B§["compressed"] = new Sampler("compressed",8,1);
         §_-22B§["compressedalpha"] = new Sampler("compressedalpha",8,2);
         §_-22B§["dxt1"] = new Sampler("dxt1",8,1);
         §_-22B§["dxt5"] = new Sampler("dxt5",8,2);
         §_-22B§["video"] = new Sampler("video",8,3);
         §_-22B§["2d"] = new Sampler("2d",12,0);
         §_-22B§["3d"] = new Sampler("3d",12,2);
         §_-22B§["cube"] = new Sampler("cube",12,1);
         §_-22B§["mipnearest"] = new Sampler("mipnearest",24,1);
         §_-22B§["miplinear"] = new Sampler("miplinear",24,2);
         §_-22B§["mipnone"] = new Sampler("mipnone",24,0);
         §_-22B§["nomip"] = new Sampler("nomip",24,0);
         §_-22B§["nearest"] = new Sampler("nearest",28,0);
         §_-22B§["linear"] = new Sampler("linear",28,1);
         §_-22B§["anisotropic2x"] = new Sampler("anisotropic2x",28,2);
         §_-22B§["anisotropic4x"] = new Sampler("anisotropic4x",28,3);
         §_-22B§["anisotropic8x"] = new Sampler("anisotropic8x",28,4);
         §_-22B§["anisotropic16x"] = new Sampler("anisotropic16x",28,5);
         §_-22B§["centroid"] = new Sampler("centroid",16,1);
         §_-22B§["single"] = new Sampler("single",16,2);
         §_-22B§["ignoresampler"] = new Sampler("ignoresampler",16,4);
         §_-22B§["repeat"] = new Sampler("repeat",20,1);
         §_-22B§["wrap"] = new Sampler("wrap",20,1);
         §_-22B§["clamp"] = new Sampler("clamp",20,0);
         §_-22B§["clamp_u_repeat_v"] = new Sampler("clamp_u_repeat_v",20,2);
         §_-22B§["repeat_u_clamp_v"] = new Sampler("repeat_u_clamp_v",20,3);
      }
      
      public function get error() : String
      {
         return §_-Xn§;
      }
      
      public function get §_-j2D§() : ByteArray
      {
         return §_-835§;
      }
      
      public function assemble2(param1:Context3D, param2:uint, param3:String, param4:String) : Program3D
      {
         var _loc5_:ByteArray = §_-y1d§("vertex",param3,param2);
         var _loc6_:ByteArray = §_-y1d§("fragment",param4,param2);
         var _loc7_:Program3D = param1.createProgram();
         _loc7_.upload(_loc5_,_loc6_);
         return _loc7_;
      }
      
      public function §_-y1d§(param1:String, param2:String, param3:uint = 1, param4:Boolean = false) : ByteArray
      {
         var _loc41_:int = 0;
         var _loc29_:String = null;
         var _loc32_:int = 0;
         var _loc13_:int = 0;
         var _loc9_:Array = null;
         var _loc34_:Array = null;
         var _loc15_:OpCode = null;
         var _loc42_:Array = null;
         var _loc23_:Boolean = false;
         var _loc8_:* = 0;
         var _loc49_:* = 0;
         var _loc43_:int = 0;
         var _loc25_:Boolean = false;
         var _loc7_:Array = null;
         var _loc16_:Array = null;
         var _loc18_:Register = null;
         var _loc10_:Array = null;
         var _loc38_:* = 0;
         var _loc26_:* = 0;
         var _loc50_:Array = null;
         var _loc31_:Boolean = false;
         var _loc39_:Boolean = false;
         var _loc35_:* = 0;
         var _loc45_:* = 0;
         var _loc27_:int = 0;
         var _loc47_:* = 0;
         var _loc48_:* = 0;
         var _loc46_:int = 0;
         var _loc17_:Array = null;
         var _loc30_:Register = null;
         var _loc37_:Array = null;
         var _loc5_:Array = null;
         var _loc21_:* = 0;
         var _loc11_:* = 0;
         var _loc12_:Number = NaN;
         var _loc6_:Sampler = null;
         var _loc28_:String = null;
         var _loc33_:* = 0;
         var _loc22_:* = 0;
         var _loc20_:String = null;
         var _loc40_:uint = uint(getTimer());
         §_-835§ = new ByteArray();
         §_-Xn§ = "";
         var _loc14_:Boolean = false;
         if(param1 == "fragment")
         {
            _loc14_ = true;
         }
         else if(param1 != "vertex")
         {
            §_-Xn§ = "ERROR: mode needs to be \"fragment\" or \"vertex\" but is \"" + param1 + "\".";
         }
         §_-j2D§.endian = "littleEndian";
         §_-j2D§.writeByte(160);
         §_-j2D§.writeUnsignedInt(param3);
         §_-j2D§.writeByte(161);
         §_-j2D§.writeByte(_loc14_ ? 1 : 0);
         §_-E3r§(param3,param4);
         var _loc36_:Array = param2.replace(/[\f\n\r\v]+/g,"\n").split("\n");
         var _loc44_:int = 0;
         var _loc24_:int = 0;
         var _loc19_:int = int(_loc36_.length);
         _loc41_ = 0;
         while(_loc41_ < _loc19_ && §_-Xn§ == "")
         {
            _loc29_ = new String(_loc36_[_loc41_]);
            _loc29_ = _loc29_.replace(§_-D2K§,"");
            _loc32_ = int(_loc29_.search("//"));
            if(_loc32_ != -1)
            {
               _loc29_ = _loc29_.slice(0,_loc32_);
            }
            _loc13_ = int(_loc29_.search(/<.*>/g));
            if(_loc13_ != -1)
            {
               _loc9_ = _loc29_.slice(_loc13_).match(/([\w\.\-\+]+)/gi);
               _loc29_ = _loc29_.slice(0,_loc13_);
            }
            _loc34_ = _loc29_.match(/^\w{3}/gi);
            if(!_loc34_)
            {
               if(_loc29_.length >= 3)
               {
                  trace("warning: bad line " + _loc41_ + ": " + _loc36_[_loc41_]);
               }
            }
            else
            {
               _loc15_ = §_-z2o§[_loc34_[0]];
               if(§_-626§)
               {
                  trace(_loc15_);
               }
               if(_loc15_ == null)
               {
                  if(_loc29_.length >= 3)
                  {
                     trace("warning: bad line " + _loc41_ + ": " + _loc36_[_loc41_]);
                  }
               }
               else
               {
                  _loc29_ = _loc29_.slice(_loc29_.search(_loc15_.name) + _loc15_.name.length);
                  if(_loc15_.flags & 0x0100 && param3 < 2)
                  {
                     §_-Xn§ = "error: opcode requires version 2.";
                     break;
                  }
                  if(_loc15_.flags & 0x40 && _loc14_)
                  {
                     §_-Xn§ = "error: opcode is only allowed in vertex programs.";
                     break;
                  }
                  if(_loc15_.flags & 0x20 && !_loc14_)
                  {
                     §_-Xn§ = "error: opcode is only allowed in fragment programs.";
                     break;
                  }
                  if(verbose)
                  {
                     trace("emit opcode=" + _loc15_);
                  }
                  §_-j2D§.writeUnsignedInt(_loc15_.emitCode);
                  if(++_loc24_ > 4096)
                  {
                     §_-Xn§ = "error: too many opcodes. maximum is 4096.";
                     break;
                  }
                  _loc42_ = _loc29_.match(/vc\[([vofi][acostdip]?[d]?)(\d*)?((\.[xyzw])?(\+\d{1,3})?)?\](\.[xyzw]{1,4})?|([vofi][acostdip]?[d]?)(\d*)?(\.[xyzw]{1,4})?/gi);
                  if(!_loc42_ || _loc42_.length != _loc15_.numRegister)
                  {
                     §_-Xn§ = "error: wrong number of operands. found " + _loc42_.length + " but expected " + _loc15_.numRegister + ".";
                     break;
                  }
                  _loc23_ = false;
                  _loc8_ = 160;
                  _loc49_ = uint(_loc42_.length);
                  _loc43_ = 0;
                  while(_loc43_ < _loc49_)
                  {
                     _loc25_ = false;
                     _loc7_ = _loc42_[_loc43_].match(/\[.*\]/gi);
                     if(_loc7_ && _loc7_.length > 0)
                     {
                        _loc42_[_loc43_] = _loc42_[_loc43_].replace(_loc7_[0],"0");
                        if(verbose)
                        {
                           trace("IS REL");
                        }
                        _loc25_ = true;
                     }
                     _loc16_ = _loc42_[_loc43_].match(/^\b[A-Za-z]{1,3}/gi);
                     if(!_loc16_)
                     {
                        §_-Xn§ = "error: could not parse operand " + _loc43_ + " (" + _loc42_[_loc43_] + ").";
                        _loc23_ = true;
                        break;
                     }
                     _loc18_ = §_-w1a§[_loc16_[0]];
                     if(§_-626§)
                     {
                        trace(_loc18_);
                     }
                     if(_loc18_ == null)
                     {
                        §_-Xn§ = "error: could not find register name for operand " + _loc43_ + " (" + _loc42_[_loc43_] + ").";
                        _loc23_ = true;
                        break;
                     }
                     if(_loc14_)
                     {
                        if(!(_loc18_.flags & 0x20))
                        {
                           §_-Xn§ = "error: register operand " + _loc43_ + " (" + _loc42_[_loc43_] + ") only allowed in vertex programs.";
                           _loc23_ = true;
                           break;
                        }
                        if(_loc25_)
                        {
                           §_-Xn§ = "error: register operand " + _loc43_ + " (" + _loc42_[_loc43_] + ") relative adressing not allowed in fragment programs.";
                           _loc23_ = true;
                           break;
                        }
                     }
                     else if(!(_loc18_.flags & 0x40))
                     {
                        §_-Xn§ = "error: register operand " + _loc43_ + " (" + _loc42_[_loc43_] + ") only allowed in fragment programs.";
                        _loc23_ = true;
                        break;
                     }
                     _loc42_[_loc43_] = _loc42_[_loc43_].slice(_loc42_[_loc43_].search(_loc18_.name) + _loc18_.name.length);
                     _loc10_ = _loc25_ ? _loc7_[0].match(/\d+/) : _loc42_[_loc43_].match(/\d+/);
                     _loc38_ = 0;
                     if(_loc10_)
                     {
                        _loc38_ = uint(_loc10_[0]);
                     }
                     if(_loc18_.range < _loc38_)
                     {
                        §_-Xn§ = "error: register operand " + _loc43_ + " (" + _loc42_[_loc43_] + ") index exceeds limit of " + (_loc18_.range + 1) + ".";
                        _loc23_ = true;
                        break;
                     }
                     _loc26_ = 0;
                     _loc50_ = _loc42_[_loc43_].match(/(\.[xyzw]{1,4})/);
                     _loc31_ = _loc43_ == 0 && !(_loc15_.flags & 0x80);
                     _loc39_ = _loc43_ == 2 && _loc15_.flags & 8;
                     _loc35_ = 0;
                     _loc45_ = 0;
                     _loc27_ = 0;
                     if(_loc31_ && _loc25_)
                     {
                        §_-Xn§ = "error: relative can not be destination";
                        _loc23_ = true;
                        break;
                     }
                     if(_loc50_)
                     {
                        _loc26_ = 0;
                        _loc48_ = uint(_loc50_[0].length);
                        _loc46_ = 1;
                        while(_loc46_ < _loc48_)
                        {
                           _loc47_ = uint(_loc50_[0].charCodeAt(_loc46_) - "x".charCodeAt(0));
                           if(_loc47_ > 2)
                           {
                              _loc47_ = 3;
                           }
                           if(_loc31_)
                           {
                              _loc26_ |= 1 << _loc47_;
                           }
                           else
                           {
                              _loc26_ |= _loc47_ << (_loc46_ - 1 << 1);
                           }
                           _loc46_++;
                        }
                        if(!_loc31_)
                        {
                           while(_loc46_ <= 4)
                           {
                              _loc26_ |= _loc47_ << (_loc46_ - 1 << 1);
                              _loc46_++;
                           }
                        }
                     }
                     else
                     {
                        _loc26_ = uint(_loc31_ ? 15 : 228);
                     }
                     if(_loc25_)
                     {
                        _loc17_ = _loc7_[0].match(/[A-Za-z]{1,3}/gi);
                        _loc30_ = §_-w1a§[_loc17_[0]];
                        if(_loc30_ == null)
                        {
                           §_-Xn§ = "error: bad index register";
                           _loc23_ = true;
                           break;
                        }
                        _loc35_ = _loc30_.emitCode;
                        _loc37_ = _loc7_[0].match(/(\.[xyzw]{1,1})/);
                        if(_loc37_.length == 0)
                        {
                           §_-Xn§ = "error: bad index register select";
                           _loc23_ = true;
                           break;
                        }
                        _loc45_ = uint(_loc37_[0].charCodeAt(1) - "x".charCodeAt(0));
                        if(_loc45_ > 2)
                        {
                           _loc45_ = 3;
                        }
                        _loc5_ = _loc7_[0].match(/\+\d{1,3}/gi);
                        if(_loc5_.length > 0)
                        {
                           _loc27_ = int(_loc5_[0]);
                        }
                        if(_loc27_ < 0 || _loc27_ > 255)
                        {
                           §_-Xn§ = "error: index offset " + _loc27_ + " out of bounds. [0..255]";
                           _loc23_ = true;
                           break;
                        }
                        if(verbose)
                        {
                           trace("RELATIVE: type=" + _loc35_ + "==" + _loc17_[0] + " sel=" + _loc45_ + "==" + _loc37_[0] + " idx=" + _loc38_ + " offset=" + _loc27_);
                        }
                     }
                     if(verbose)
                     {
                        trace("  emit argcode=" + _loc18_ + "[" + _loc38_ + "][" + _loc26_ + "]");
                     }
                     if(_loc31_)
                     {
                        §_-j2D§.writeShort(_loc38_);
                        §_-j2D§.writeByte(_loc26_);
                        §_-j2D§.writeByte(_loc18_.emitCode);
                        _loc8_ -= 32;
                     }
                     else if(_loc39_)
                     {
                        if(verbose)
                        {
                           trace("  emit sampler");
                        }
                        _loc21_ = 5;
                        _loc11_ = uint(_loc9_?.length);
                        _loc12_ = 0;
                        _loc46_ = 0;
                        while(_loc46_ < _loc11_)
                        {
                           if(verbose)
                           {
                              trace("    opt: " + _loc9_[_loc46_]);
                           }
                           _loc6_ = §_-22B§[_loc9_[_loc46_]];
                           if(_loc6_ == null)
                           {
                              _loc12_ = Number(_loc9_[_loc46_]);
                              if(verbose)
                              {
                                 trace("    bias: " + _loc12_);
                              }
                           }
                           else
                           {
                              if(_loc6_.flag != 16)
                              {
                                 _loc21_ &= ~(15 << _loc6_.flag);
                              }
                              _loc21_ |= _loc6_.mask << _loc6_.flag;
                           }
                           _loc46_++;
                        }
                        §_-j2D§.writeShort(_loc38_);
                        §_-j2D§.writeByte(int(_loc12_ * 8));
                        §_-j2D§.writeByte(0);
                        §_-j2D§.writeUnsignedInt(_loc21_);
                        if(verbose)
                        {
                           trace("    bits: " + (_loc21_ - 5));
                        }
                        _loc8_ -= 64;
                     }
                     else
                     {
                        if(_loc43_ == 0)
                        {
                           §_-j2D§.writeUnsignedInt(0);
                           _loc8_ -= 32;
                        }
                        §_-j2D§.writeShort(_loc38_);
                        §_-j2D§.writeByte(_loc27_);
                        §_-j2D§.writeByte(_loc26_);
                        §_-j2D§.writeByte(_loc18_.emitCode);
                        §_-j2D§.writeByte(_loc35_);
                        §_-j2D§.writeShort(_loc25_ ? _loc45_ | 0x8000 : 0);
                        _loc8_ -= 64;
                     }
                     _loc43_++;
                  }
                  _loc43_ = 0;
                  while(_loc43_ < _loc8_)
                  {
                     §_-j2D§.writeByte(0);
                     _loc43_ += 8;
                  }
                  if(_loc23_)
                  {
                     break;
                  }
               }
            }
            _loc41_++;
         }
         if(§_-Xn§ != "")
         {
            §_-Xn§ += "\n  at line " + _loc41_ + " " + _loc36_[_loc41_];
            §_-j2D§.length = 0;
            trace(§_-Xn§);
         }
         if(§_-626§)
         {
            _loc28_ = "generated bytecode:";
            _loc33_ = uint(§_-j2D§.length);
            _loc22_ = 0;
            while(_loc22_ < _loc33_)
            {
               if(!(_loc22_ % 16))
               {
                  _loc28_ += "\n";
               }
               if(!(_loc22_ % 4))
               {
                  _loc28_ += " ";
               }
               _loc20_ = §_-j2D§[_loc22_].toString(16);
               if(_loc20_.length < 2)
               {
                  _loc20_ = "0" + _loc20_;
               }
               _loc28_ += _loc20_;
               _loc22_++;
            }
            trace(_loc28_);
         }
         if(verbose)
         {
            trace("AGALMiniAssembler.assemble time: " + (getTimer() - _loc40_) / 1000 + "s");
         }
         return §_-j2D§;
      }
      
      private function §_-E3r§(param1:uint, param2:Boolean) : void
      {
         §_-w1a§["va"] = new Register("va","vertex attribute",0,param2 ? 1024 : (param1 == 1 || param1 == 2 ? 7 : 15),0x40 | 2);
         §_-w1a§["vc"] = new Register("vc","vertex constant",1,param2 ? 1024 : (param1 == 1 ? 127 : 249),0x40 | 2);
         §_-w1a§["vt"] = new Register("vt","vertex temporary",2,param2 ? 1024 : (param1 == 1 ? 7 : 25),0x40 | 1 | 2);
         §_-w1a§["vo"] = new Register("vo","vertex output",3,param2 ? 1024 : 0,0x40 | 1);
         §_-w1a§["vi"] = new Register("vi","varying",4,param2 ? 1024 : (param1 == 1 ? 7 : 9),0x40 | 0x20 | 2 | 1);
         §_-w1a§["fc"] = new Register("fc","fragment constant",1,param2 ? 1024 : (param1 == 1 ? 27 : (param1 == 2 ? 63 : 199)),0x20 | 2);
         §_-w1a§["ft"] = new Register("ft","fragment temporary",2,param2 ? 1024 : (param1 == 1 ? 7 : 25),0x20 | 1 | 2);
         §_-w1a§["fs"] = new Register("fs","texture sampler",5,param2 ? 1024 : 15,0x20 | 2);
         §_-w1a§["fo"] = new Register("fo","fragment output",3,param2 ? 1024 : (param1 == 1 ? 0 : 3),0x20 | 1);
         §_-w1a§["fd"] = new Register("fd","fragment depth output",6,param2 ? 1024 : (param1 == 1 ? -1 : 0),0x20 | 1);
         §_-w1a§["iid"] = new Register("iid","instance id",7,param2 ? 1024 : 0,0x40 | 2);
         §_-w1a§["vs"] = new Register("vs","vertex texture sampler",5,param2 ? 1024 : 3,0x40 | 2);
         §_-w1a§["op"] = §_-w1a§["vo"];
         §_-w1a§["i"] = §_-w1a§["vi"];
         §_-w1a§["v"] = §_-w1a§["vi"];
         §_-w1a§["oc"] = §_-w1a§["fo"];
         §_-w1a§["od"] = §_-w1a§["fd"];
         §_-w1a§["fi"] = §_-w1a§["vi"];
      }
   }
}

class OpCode
{
   
   private var _emitCode:uint;
   
   private var _flags:uint;
   
   private var _name:String;
   
   private var _numRegister:uint;
   
   public function OpCode(param1:String, param2:uint, param3:uint, param4:uint)
   {
      super();
      _name = param1;
      _numRegister = param2;
      _emitCode = param3;
      _flags = param4;
   }
   
   public function get emitCode() : uint
   {
      return _emitCode;
   }
   
   public function get flags() : uint
   {
      return _flags;
   }
   
   public function get name() : String
   {
      return _name;
   }
   
   public function get numRegister() : uint
   {
      return _numRegister;
   }
   
   public function toString() : String
   {
      return "[OpCode name=\"" + _name + "\", numRegister=" + _numRegister + ", emitCode=" + _emitCode + ", flags=" + _flags + "]";
   }
}

class Register
{
   
   private var _emitCode:uint;
   
   private var _name:String;
   
   private var _longName:String;
   
   private var _flags:uint;
   
   private var _range:uint;
   
   public function Register(param1:String, param2:String, param3:uint, param4:uint, param5:uint)
   {
      super();
      _name = param1;
      _longName = param2;
      _emitCode = param3;
      _range = param4;
      _flags = param5;
   }
   
   public function get emitCode() : uint
   {
      return _emitCode;
   }
   
   public function get longName() : String
   {
      return _longName;
   }
   
   public function get name() : String
   {
      return _name;
   }
   
   public function get flags() : uint
   {
      return _flags;
   }
   
   public function get range() : uint
   {
      return _range;
   }
   
   public function toString() : String
   {
      return "[Register name=\"" + _name + "\", longName=\"" + _longName + "\", emitCode=" + _emitCode + ", range=" + _range + ", flags=" + _flags + "]";
   }
}

class Sampler
{
   
   private var _flag:uint;
   
   private var _mask:uint;
   
   private var _name:String;
   
   public function Sampler(param1:String, param2:uint, param3:uint)
   {
      super();
      _name = param1;
      _flag = param2;
      _mask = param3;
   }
   
   public function get flag() : uint
   {
      return _flag;
   }
   
   public function get mask() : uint
   {
      return _mask;
   }
   
   public function get name() : String
   {
      return _name;
   }
   
   public function toString() : String
   {
      return "[Sampler name=\"" + _name + "\", flag=\"" + _flag + "\", mask=" + mask + "]";
   }
}
