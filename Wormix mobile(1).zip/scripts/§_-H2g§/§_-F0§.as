package §_-H2g§
{
   import dragonBones.animation.IAnimateble;
   
   public interface §_-F0§ extends IAnimateble
   {
      
      
   }
}

