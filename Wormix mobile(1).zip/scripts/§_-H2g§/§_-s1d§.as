package §_-H2g§
{
   import §_-12W§.*;
   import §_-Y1O§.*;
   import §_-Z1K§.§_-q24§;
   import §_-fo§.*;
   import §_-hO§.§_-729§;
   import feathers.core.ITextRenderer;
   import flash.text.TextFormat;
   import ru.pragmatix.wormix.utils.§_-R2g§;
   import starling.events.Event;
   
   public class §_-s1d§ extends Event
   {
      
      public static const COMPLETE:String = "complete";
      
      public static const LOOP_COMPLETE:String = "loopComplete";
      
      public function §_-s1d§(param1:String, param2:Boolean = false, param3:Object = null)
      {
         super(param1,param2,param3);
      }
   }
}

