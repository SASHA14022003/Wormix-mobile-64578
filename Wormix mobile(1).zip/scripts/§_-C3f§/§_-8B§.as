package §_-C3f§
{
   public class §_-8B§
   {
      
      public static const §_-qk§:int = -1;
      
      public static const SUCCESS:int = 0;
      
      public static const ERROR:int = 1;
      
      public static const MIN_REQUIREMENTS_ERROR:int = 2;
      
      public static const NOT_ENOUGH_MONEY:int = 3;
      
      public static const CONFIRM_FAILURE:int = 4;
      
      public static const §_-d1N§:int = 5;
      
      public static const §_-t19§:int = 6;
      
      public static const §_-t2T§:int = 7;
      
      public static const §_-Pf§:int = 8;
      
      public static const §_-5X§:int = 99;
      
      public function §_-8B§()
      {
         super();
      }
   }
}

