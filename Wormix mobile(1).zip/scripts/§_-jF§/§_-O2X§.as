package §_-jF§
{
   import §_-A1K§.§_-TA§;
   import §_-D3A§.§_-TZ§;
   import §_-Vg§.ClanEditView;
   import §_-Y1Q§.§_-aG§;
   import §_-Y1Q§.§_-tc§;
   import §_-b1F§.*;
   import §_-k1u§.§_-2m§;
   import §_-l1g§.§_-L3Q§;
   import §_-z1g§.§_-lp§;
   import §_-zI§.§_-F3q§;
   import feathers.controls.GroupedList;
   import feathers.controls.LayoutGroup;
   import feathers.controls.renderers.DefaultGroupedListHeaderOrFooterRenderer;
   import feathers.controls.text.TextInstanceCreator;
   import feathers.core.ITextRenderer;
   import feathers.core.PopUpManager;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.VerticalAlign;
   import feathers.themes.FontColor;
   import feathers.themes.FontSize;
   import flash.text.TextFormatAlign;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.messages.structures.RatingProfileStructure;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.objects.§_-Qi§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.weapons.Weapon;
   import starling.display.DisplayObject;
   import starling.display.Sprite;
   import starling.events.Event;
   
   public class §_-O2X§ extends DefaultGroupedListHeaderOrFooterRenderer
   {
      
      public function §_-O2X§()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         this.height = 30;
         this.horizontalAlign = HorizontalAlign.CENTER;
         this.verticalAlign = VerticalAlign.MIDDLE;
         this.contentLabelFactory = function():ITextRenderer
         {
            return TextInstanceCreator.createTextRenderer(FontSize.NORMAL,FontColor.TAB_SELECTED,TextFormatAlign.CENTER);
         };
         this.contentLabelFunction = function(param1:Object):String
         {
            return String(param1);
         };
      }
      
      override public function set owner(param1:GroupedList) : void
      {
         super.owner = param1;
         invalidate(INVALIDATION_FLAG_SIZE);
      }
      
      override protected function draw() : void
      {
         var _loc1_:Boolean = isInvalid(INVALIDATION_FLAG_SIZE);
         if(_loc1_ && Boolean(_owner))
         {
            this.height = 30;
            this.width = _owner.width;
         }
         super.draw();
      }
   }
}

