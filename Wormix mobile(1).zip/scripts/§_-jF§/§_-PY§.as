package §_-jF§
{
   import §_-B1y§.§_-bs§;
   import §_-C3f§.§_-yG§;
   import §_-TF§.§_-q1j§;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import ru.pragmatix.wormix.messages.clans.request.edit.ChangeClanDescriptionRequest;
   import ru.pragmatix.wormix.messages.clans.response.edit.ChangeClanDescriptionResponse;
   
   public class §_-PY§ extends DefaultListItemRenderer
   {
      
      public function §_-PY§()
      {
         super();
      }
   }
}

