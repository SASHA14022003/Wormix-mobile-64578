package §_-jF§
{
   import §_-21p§.§_-4w§;
   import §_-62§.§_-W1r§;
   import §_-62§.§_-ou§;
   import §_-B2z§.Server;
   import §_-B2z§.§_-c1G§;
   import §_-CF§.§_-x2t§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-U1i§.§_-81M§;
   import §_-U1i§.§_-O2i§;
   import §_-dS§.§_-D3a§;
   import §_-j1w§.§_-B2i§;
   import §_-r1C§.§_-h2B§;
   import §_-x2Q§.§_-dU§;
   import §_-z1g§.§_-82X§;
   import com.distriqt.extension.cloudstorage.events.KeyValueStoreEvent;
   import feathers.controls.Label;
   import feathers.controls.LayoutGroup;
   import feathers.controls.List;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import feathers.core.PopUpManager;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.HorizontalLayout;
   import feathers.layout.VerticalAlign;
   import feathers.themes.styles.AlternateTextStyles;
   import flash.geom.Point;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import ru.pragmatix.flox.logger.§_-93v§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.§_-3m§;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.pvp.messages.ex.*;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.§_-J2h§;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.DamageType;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   import starlingbuilder.engine.UIBuilder;
   
   public class InviteFriendSocialITabItemRenderer extends DefaultListItemRenderer
   {
      
      private var binder:PanelBinder;
      
      public function InviteFriendSocialITabItemRenderer()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         itemHasIcon = false;
         itemHasLabel = false;
         itemHasAccessory = false;
         var _loc1_:UIBuilder = Application.uiBuilder;
         this.binder = new PanelBinder();
         _loc1_.create(Application.assetManager.getObject("invite_friend_list_item_renderer"),true,this.binder);
         this.binder._button.addEventListener(Event.TRIGGERED,this.§_-cW§);
         defaultAccessory = this.binder._container;
      }
      
      override protected function draw() : void
      {
         super.draw();
         if(Boolean(isInvalid(INVALIDATION_FLAG_SIZE)) && Boolean(_owner) && Boolean(this.binder))
         {
            this.binder._container.width = _owner.width;
         }
      }
      
      override protected function commitData() : void
      {
         if(_data)
         {
            this.binder._button.label = §_-s2a§.§_-K3t§("NEED_RUBY_BUTTON1_TEXT") + "!";
         }
      }
      
      override public function dispose() : void
      {
         super.dispose();
         if(_owner)
         {
            _owner.addEventListener(Event.RESIZE,this.§_-P12§);
         }
         this.binder._button.removeEventListener(Event.TRIGGERED,this.§_-cW§);
      }
      
      override public function set owner(param1:List) : void
      {
         if(_owner)
         {
            _owner.removeEventListener(Event.RESIZE,this.§_-P12§);
         }
         super.owner = param1;
         if(_owner)
         {
            _owner.addEventListener(Event.RESIZE,this.§_-P12§);
            this.§_-P12§();
         }
      }
      
      private function §_-P12§(param1:Event = null) : void
      {
         invalidate(INVALIDATION_FLAG_SIZE);
      }
      
      private function §_-cW§(param1:Event) : void
      {
         §_-N1V§.§_-J3X§();
      }
   }
}

import feathers.controls.Button;
import feathers.controls.LayoutGroup;

class PanelBinder
{
   
   public var _container:LayoutGroup;
   
   public var _button:Button;
   
   public function PanelBinder()
   {
      super();
   }
}
