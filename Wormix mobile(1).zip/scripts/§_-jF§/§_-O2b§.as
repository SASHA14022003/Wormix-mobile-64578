package §_-jF§
{
   import §_-43V§.*;
   import §_-A1K§.§_-TA§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-RE§.§_-D3v§;
   import §_-RE§.§_-r2q§;
   import §_-Y1O§.*;
   import §_-YF§.§_-q2v§;
   import §_-l1K§.*;
   import §_-l1g§.§_-L3Q§;
   import §_-r1C§.§_-h2B§;
   import §_-z1g§.§_-y1S§;
   import feathers.controls.ImageLoader;
   import feathers.controls.LayoutGroup;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import feathers.core.ITextRenderer;
   import flash.utils.ByteArray;
   import ru.pragmatix.flox.social.model.SocialUserData;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.objects.Direction;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   
   public class §_-O2b§ extends DefaultListItemRenderer
   {
      
      private var clip:LayoutGroup;
      
      private var §_-h3§:ITextRenderer;
      
      private var icon:ImageLoader;
      
      public function §_-O2b§()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         var _loc1_:DisplayObjectContainer = null;
         super.initialize();
         _isToggle = false;
         this.clip = §_-YQ§.§_-qM§(§_-q2v§.§_-xw§,§_-q2v§.§_-A2T§).getChildByName("panel") as LayoutGroup;
         addChild(this.clip);
         width = 290;
         height = 60;
         this.§_-h3§ = ITextRenderer(this.clip.getChildByName("name"));
         _loc1_ = §_-YQ§.getClip("icon.iconContainer",this.clip) as DisplayObjectContainer;
         this.icon = new ImageLoader();
         this.icon.width = 42;
         this.icon.height = 42;
         _loc1_.addChild(this.icon);
      }
      
      override protected function commitData() : void
      {
         if(Boolean(data) && data is SocialUserData)
         {
            this.§_-h3§.text = data.getFirstName() + " " + data.getLastName();
            this.icon.source = data.getPhoto();
         }
      }
      
      override public function dispose() : void
      {
         super.dispose();
      }
   }
}

