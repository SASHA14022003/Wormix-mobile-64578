package §_-jF§
{
   import §_-62§.*;
   import §_-B1y§.§_-ts§;
   import §_-j1w§.§_-B2i§;
   import §_-j1w§.§_-lD§;
   import §_-z1g§.§_-4l§;
   import §_-zI§.§_-X1q§;
   import com.distriqt.extension.inappbilling.events.ApplicationReceiptEvent;
   import com.greensock.loading.LoaderStatus;
   import com.mesmotronic.ane.AndroidID;
   import dragonBones.animation.WorldClock;
   import feathers.controls.ImageLoader;
   import feathers.controls.List;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.HorizontalLayout;
   import feathers.layout.VerticalAlign;
   import flash.events.Event;
   import flash.geom.Point;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.shop.*;
   import ru.pragmatix.wormix.gui.menu.shop.mobile.*;
   import ru.pragmatix.wormix.messages.clans.structures.ClanMemberTO;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.utils.StringUtil;
   import ru.pragmatix.wormix.utils.§_-6A§;
   import ru.pragmatix.wormix.utils.§_-72u§;
   import ru.pragmatix.wormix.utils.§_-c1S§;
   import ru.pragmatix.wormix.weapons.ammo.DamageType;
   import starling.events.Event;
   import starling.textures.Texture;
   import starling.utils.AssetManager;
   import starling.utils.ScaleMode;
   
   public class ClanMemberItemRenderer extends DefaultListItemRenderer
   {
      
      private static var §_-13M§:Texture;
      
      private static var §_-z19§:Texture;
      
      private static var §_-E3§:Texture;
      
      private static var §_-Ni§:Boolean = false;
      
      private var binder:Binder;
      
      public function ClanMemberItemRenderer()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         itemHasIcon = false;
         itemHasLabel = false;
         itemHasAccessory = false;
         this.binder = new Binder();
         var _loc1_:Object = Application.assetManager.getObject("clan_member_item_renderer");
         Application.uiBuilder.create(_loc1_,true,this.binder);
         defaultIcon = this.binder._container;
         this.binder._posDeltaIcon.scaleMode = ScaleMode.SHOW_ALL;
         this.binder._posDeltaIcon.maintainAspectRatio = true;
         if(!§_-Ni§)
         {
            §_-13M§ = Application.assetManager.getTexture("change_delta_up");
            §_-z19§ = Application.assetManager.getTexture("change_delta_down");
            §_-E3§ = Application.assetManager.getTexture("change_delta_equal");
            §_-Ni§ = true;
         }
         var _loc2_:HorizontalLayout = new HorizontalLayout();
         _loc2_.paddingLeft = _loc2_.paddingRight = 10;
         _loc2_.gap = 10;
         _loc2_.horizontalAlign = HorizontalAlign.CENTER;
         _loc2_.verticalAlign = VerticalAlign.MIDDLE;
         this.binder._status.layout = _loc2_;
      }
      
      override public function dispose() : void
      {
         super.dispose();
      }
      
      override protected function draw() : void
      {
         var _loc1_:Boolean = isInvalid(INVALIDATION_FLAG_SIZE);
         if(_loc1_ && Boolean(owner))
         {
            this.binder._container.width = owner.width;
         }
         super.draw();
      }
      
      override public function set owner(param1:List) : void
      {
         super.owner = param1;
         invalidate(INVALIDATION_FLAG_SIZE);
      }
      
      override protected function commitData() : void
      {
         var _loc4_:String = null;
         var _loc5_:AssetManager = null;
         var _loc6_:Boolean = false;
         var _loc7_:Number = NaN;
         var _loc8_:int = 0;
         if(!_data)
         {
            return;
         }
         var _loc1_:int = int(_data.place as int);
         var _loc2_:ClanMemberTO = _data.member as ClanMemberTO;
         var _loc3_:Boolean = Boolean(_data.isViewersClan as Boolean);
         this.binder._status.removeChildren();
         if(_loc2_)
         {
            §_-c1S§.§_-MU§(_loc1_,this.binder._position,null);
            §_-c1S§.§_-62q§(_loc1_,_loc2_.oldPlace,this.binder._posDeltaValue,20,this.binder._posDeltaIcon,false);
            this.binder._name.text = _loc2_.name;
            this.binder._rank.text = §_-6A§.§_-R1w§(_loc2_.rank);
            if(!_loc2_.online)
            {
               _loc7_ = §_-72u§.§_-q1c§(_loc2_.lastLoginTime / §_-72u§.§_-03d§);
               if(_loc7_ < 1)
               {
                  _loc4_ = §_-s2a§.§_-K3t§(§_-s2a§.ONLINE_HOUR);
               }
               else if(_loc7_ >= 1 && _loc7_ < 24)
               {
                  _loc4_ = §_-s2a§.§_-K3t§(§_-s2a§.ONLINE_TODAY);
               }
               else if(_loc7_ >= 24 && _loc7_ < 24 * 7 * 4)
               {
                  _loc8_ = _loc7_ / 24;
                  _loc4_ = StringUtil.format(§_-s2a§.ONLINE_DAYS,{"count":_loc8_});
               }
               else
               {
                  _loc4_ = §_-s2a§.§_-K3t§(§_-s2a§.ONLINE_MORE_MONTH_AGO);
               }
            }
            this.binder._onlineStatus.text = _loc2_.online ? §_-s2a§.§_-K3t§(§_-s2a§.ONLINE_INGAME) : _loc4_;
            this.binder._donationValue.text = _loc2_.donation.toString();
            this.binder._ratingValue.text = _loc2_.seasonRating.toString();
            this.binder._donationPanel.visible = _loc3_;
            this.binder._onlineStatus.visible = _loc3_;
            _loc5_ = Application.assetManager;
            _loc6_ = _loc2_.rank == §_-X1q§.OFFICER;
            if(_loc2_.muteMode)
            {
               this.binder._status.addChild(this.§_-N1T§(_loc5_.getTexture("icon_clan_mute_on"),§_-s2a§.§_-K3t§("MUTED_QTIP")));
            }
            if(_loc6_ && !_loc2_.expelPermit)
            {
               this.binder._status.addChild(this.§_-N1T§(_loc5_.getTexture("icon_clan_expel_off"),§_-s2a§.§_-K3t§("EXPPER_QTIP")));
            }
         }
      }
      
      private function §_-N1T§(param1:Texture, param2:String) : ImageLoader
      {
         var _loc3_:ImageLoader = new ImageLoader();
         _loc3_.source = param1;
         _loc3_.height = _loc3_.width = 35;
         _loc3_.scaleMode = ScaleMode.SHOW_ALL;
         _loc3_.maintainAspectRatio = true;
         _loc3_.toolTip = param2;
         return _loc3_;
      }
   }
}

import feathers.controls.ImageLoader;
import feathers.controls.Label;
import feathers.controls.LayoutGroup;

class Binder
{
   
   public var _container:LayoutGroup;
   
   public var _donationPanel:LayoutGroup;
   
   public var _status:LayoutGroup;
   
   public var _position:Label;
   
   public var _name:Label;
   
   public var _rank:Label;
   
   public var _onlineStatus:Label;
   
   public var _donationValue:Label;
   
   public var _ratingValue:Label;
   
   public var _posDeltaValue:Label;
   
   public var _posDeltaIcon:ImageLoader;
   
   public function Binder()
   {
      super();
   }
}
