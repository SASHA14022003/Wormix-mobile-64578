package §_-jF§
{
   import §_-B2z§.§_-63i§;
   import §_-DJ§.§_-73y§;
   import §_-DJ§.§_-fH§;
   import §_-L1H§.§_-b2K§;
   import §_-Ty§.§_-SC§;
   import §_-gG§.§_-M2S§;
   import §_-gG§.§_-Z2z§;
   import §_-j22§.§_-5g§;
   import §_-l1g§.§_-L3Q§;
   import §_-r1C§.§_-h2B§;
   import §_-w2i§.§_-Zd§;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import flash.display.Stage;
   import flash.geom.Point;
   import flash.text.TextField;
   import flash.text.TextFormat;
   import flash.utils.ByteArray;
   import flash.utils.IDataOutput;
   import flash.utils.getTimer;
   import org.gestouch.core.*;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.shop.§_-7D§;
   import ru.pragmatix.wormix.messages.server.WipeProfileResult;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.pvp.messages.ex.BattleCreationFailure;
   import ru.pragmatix.wormix.pvp.messages.ex.CallToBattleResultType;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.FreezingMissile;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.utils.ScaleMode;
   
   use namespace gestouch_internal;
   
   public class VipDescriptionFeatureRenderer extends DefaultListItemRenderer
   {
      
      private var binder:Binder;
      
      public function VipDescriptionFeatureRenderer()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         this.binder = new Binder();
         Application.uiBuilder.create(Application.assetManager.getObject("bank_vip_info_feature"),true,this.binder);
         addChild(this.binder._content);
         this.binder._icon.maintainAspectRatio = true;
         this.binder._icon.scaleMode = ScaleMode.SHOW_ALL;
         this.width = this.binder._content.width;
         this.height = this.binder._content.height;
      }
      
      override protected function commitData() : void
      {
         if(_data)
         {
            this.binder._text.text = _data.text;
            this.binder._icon.source = Application.assetManager.getTexture(_data.icon);
            this.binder._iconBack.color = _data.darkTheme ? 0 : 16777215;
            this.binder._iconBack.alpha = _data.darkTheme ? 0.5 : 1;
         }
      }
   }
}

import feathers.controls.ImageLoader;
import feathers.controls.Label;
import feathers.controls.LayoutGroup;
import starling.display.Image;

class Binder
{
   
   public var _content:LayoutGroup;
   
   public var _iconBack:Image;
   
   public var _icon:ImageLoader;
   
   public var _text:Label;
   
   public function Binder()
   {
      super();
   }
}
