package §_-jF§
{
   import §_-31N§.§_-42G§;
   import §_-91A§.*;
   import §_-A1K§.§_-6L§;
   import §_-A1K§.§_-TA§;
   import §_-A1K§.§_-U11§;
   import §_-A2U§.§_-A23§;
   import §_-D3A§.§_-TZ§;
   import §_-H16§.*;
   import §_-H2g§.§_-di§;
   import §_-L1H§.§_-C3e§;
   import §_-L2F§.§_-D2p§;
   import §_-P2i§.§_-G3J§;
   import §_-U1Y§.*;
   import §_-U1i§.§_-U16§;
   import §_-YF§.§_-q2v§;
   import §_-j22§.§_-5g§;
   import §_-l1g§.§_-L3Q§;
   import §_-l2r§.§_-K1t§;
   import §_-u1T§.§_-33B§;
   import §_-w2i§.§_-Zd§;
   import com.greensock.events.LoaderEvent;
   import com.greensock.loading.LoaderMax;
   import com.greensock.loading.LoaderStatus;
   import com.greensock.loading.core.*;
   import dragonBones.animation.WorldClock;
   import feathers.controls.Button;
   import feathers.core.ITextRenderer;
   import flash.events.Event;
   import flash.geom.ColorTransform;
   import flash.geom.Rectangle;
   import flash.utils.ByteArray;
   import flash.utils.IDataOutput;
   import flash.utils.getTimer;
   import org.swiftsuspenders.§_-71M§;
   import ru.pragmatix.flox.social.utils.id.UserIdType;
   import ru.pragmatix.wormix.controller.§_-J2d§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.Command;
   import ru.pragmatix.wormix.fonts.BitmapFonts;
   import ru.pragmatix.wormix.messages.clans.ClanMessages;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.model.user.§_-r1d§;
   import ru.pragmatix.wormix.objects.Direction;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.pvp.messages.ex.PvpBattleType;
   import ru.pragmatix.wormix.pvp.messages.ex.RejectBattleOffer;
   import ru.pragmatix.wormix.pvp.messages.server.PvpRetryCommandRequestServer;
   import ru.pragmatix.wormix.serialization.SerializationUtils;
   import ru.pragmatix.wormix.utils.§_-MN§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.AirCatAmmo;
   import ru.pragmatix.wormix.weapons.ammo.DamageType;
   import ru.pragmatix.wormix.weapons.ammo.Ufo;
   import ru.pragmatix.wormix.weapons.interfaces.§_-O1c§;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Image;
   import starling.display.Quad;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.events.Touch;
   import starling.events.TouchEvent;
   import starling.events.TouchPhase;
   import starling.text.TextField;
   import starling.text.TextFormat;
   import starling.textures.Texture;
   import starling.utils.Align;
   import starling.utils.AssetManager;
   import starling.utils.SystemUtil;
   
   public class §_-131§ extends §_-PY§
   {
      
      private static var §_-81P§:Texture;
      
      private static var §_-WQ§:Texture;
      
      private static var §_-81x§:Texture;
      
      private static var §_-1w§:Texture;
      
      private static const §_-q2k§:String = "bag_menu_cell_disabled";
      
      private static const §_-Uu§:String = "bag_menu_cell_enabled";
      
      private static const §_-w1d§:String = "bag_menu_green_cell_disabled";
      
      private static const §_-y2t§:String = "bag_menu_green_cell_enabled";
      
      private static const §_-72o§:Texture = Application.assetManager.getTexture("bag_menu_cell_icon_shot");
      
      private static const §_-n2g§:Texture = Application.assetManager.getTexture("bag_menu_cell_icon_shot_consumed");
      
      public static const §_-j2r§:uint = 85;
      
      private static const §_-l1E§:uint = 16;
      
      private static const §_-e2q§:Number = 2;
      
      private static const §_-e2R§:Rectangle = new Rectangle(15,15,2,2);
      
      protected var §_-nw§:uint;
      
      protected var §_-72P§:Button;
      
      protected var §_-v1v§:TextField;
      
      private var §_-wq§:Sprite;
      
      private var §_-kH§:§_-di§;
      
      private var §_-f1W§:Image;
      
      private var §_-M1q§:Boolean = false;
      
      public function §_-131§()
      {
         super();
         this._isQuickHitAreaEnabled = true;
         this._isLongPressEnabled = true;
         this.§_-nw§ = §_-A3h§();
      }
      
      public static function §_-A3h§() : uint
      {
         return (SystemUtil.isDesktop ? 0.8 : 1) * §_-j2r§;
      }
      
      public static function §_-PS§() : uint
      {
         return §_-l1E§;
      }
      
      override protected function initialize() : void
      {
         var _loc2_:AssetManager = null;
         super.initialize();
         if(§_-81P§ == null || §_-WQ§ == null)
         {
            _loc2_ = Application.assetManager;
            §_-81P§ = _loc2_.getTexture(§_-Uu§);
            §_-WQ§ = _loc2_.getTexture(§_-q2k§);
            §_-81x§ = _loc2_.getTexture(§_-y2t§);
            §_-1w§ = _loc2_.getTexture(§_-w1d§);
         }
         var _loc1_:Image = new Image(§_-81P§);
         _loc1_.scale9Grid = §_-e2R§;
         this.§_-72P§ = new Button();
         this.§_-72P§.defaultSkin = _loc1_;
         this.§_-72P§.width = this.§_-72P§.height = this.§_-nw§;
         this.§_-72P§.touchable = false;
         this.addChild(this.§_-72P§);
         this.§_-v1v§ = new TextField(this.§_-nw§ * 0.9,this.§_-nw§ * 0.25,"",new TextFormat(BitmapFonts.GROBOLD_WITH_SHADOWS,§_-PS§(),16777215));
         this.§_-v1v§.y = this.§_-nw§ * 0.05;
         this.§_-v1v§.batchable = true;
         this.§_-v1v§.format.horizontalAlign = Align.RIGHT;
         this.§_-v1v§.format.verticalAlign = Align.TOP;
         this.§_-v1v§.touchable = false;
         this.addChild(this.§_-v1v§);
         this.§_-wq§ = new Sprite();
         this.addChild(this.§_-wq§);
         this._isToggle = false;
         this.touchable = true;
         width = height = this.§_-nw§;
      }
      
      override protected function draw() : void
      {
         if(this.isInvalid(INVALIDATION_FLAG_DATA))
         {
            this.commitData();
         }
      }
      
      override public function dispose() : void
      {
         if(this.§_-v1v§)
         {
            this.§_-v1v§.removeFromParent(true);
            this.§_-v1v§ = null;
         }
         if(this.§_-wq§)
         {
            this.§_-wq§.removeFromParent(true);
            this.§_-wq§ = null;
         }
         if(this.§_-72P§)
         {
            this.§_-72P§.dispose();
            this.§_-72P§ = null;
         }
         if(this.§_-kH§)
         {
            this.§_-q10§();
         }
         if(§_-81P§)
         {
            §_-81P§.dispose();
            §_-81P§ = null;
         }
         if(§_-WQ§)
         {
            §_-WQ§.dispose();
            §_-WQ§ = null;
         }
         super.dispose();
      }
      
      override protected function commitData() : void
      {
         var _loc1_:§_-U16§ = null;
         var _loc2_:Texture = null;
         var _loc3_:DisplayObject = null;
         var _loc4_:Boolean = false;
         var _loc5_:Texture = null;
         var _loc6_:DisplayObject = null;
         super.commitData();
         _loc1_ = data as §_-U16§;
         if(!_loc1_)
         {
            return;
         }
         if(_loc1_.id == 0)
         {
            _loc2_ = _loc1_.green ? §_-1w§ : §_-WQ§;
            _loc3_ = null;
            this.§_-v1v§.text = "";
            this.§_-v1v§.batchable = true;
            this.§_-wq§.visible = false;
            §_-MN§.§_-6G§(this.§_-72P§);
            §_-MN§.§_-6G§(this.§_-wq§);
            if(!_loc1_.§_-u1M§)
            {
               this.§_-q10§();
            }
         }
         else
         {
            if(_loc1_.§_-u1M§)
            {
               if(!this.§_-kH§)
               {
                  this.§_-7v§();
               }
               WorldClock.clock.add(this.§_-kH§);
               this.§_-kH§.playAnimation("play",0,-1,0);
               _loc6_ = this.§_-kH§.display;
               _loc6_.x = this.§_-nw§ * 0.5;
               _loc6_.y = this.§_-nw§ * 0.1;
               _loc6_.touchable = false;
               addChild(_loc6_);
               this.§_-M1q§ = true;
            }
            else
            {
               this.§_-q10§();
            }
            _loc2_ = _loc1_.green ? §_-81x§ : §_-81P§;
            _loc5_ = Application.assetManager.getTexture(_loc1_.icon);
            if(_loc5_)
            {
               if(this.§_-f1W§ == null)
               {
                  this.§_-f1W§ = new Image(_loc5_);
               }
               else
               {
                  this.§_-f1W§.texture = _loc5_;
               }
               this.§_-f1W§.readjustSize(_loc5_.width,_loc5_.height);
               this.§_-f1W§.scaleX = this.§_-f1W§.scaleY = this.§_-nw§ * 0.7 / Math.max(_loc5_.width,_loc5_.height);
               _loc4_ = _loc1_.delay > -1 && _loc1_.shots != 0 && _loc1_.count != 0 && !§_-X1j§.§_-12n§.isLearning;
               if(_loc4_)
               {
                  §_-MN§.§_-lM§(this.§_-72P§);
                  §_-MN§.§_-lM§(this.§_-wq§);
               }
               else
               {
                  this.§_-f1W§.alpha = _loc1_.disabled ? 0.5 : 0.99;
                  §_-MN§.§_-6G§(this.§_-72P§);
                  §_-MN§.§_-6G§(this.§_-wq§);
               }
               _loc3_ = _loc4_ ? this.showDelay(this.§_-f1W§ as Image,_loc1_.delay + 1) : this.§_-f1W§;
            }
            this.§_-v1v§.text = _loc1_.text;
            this.§_-v1v§.batchable = true;
            if(_loc1_.maxShots > 0)
            {
               this.§_-Db§(_loc1_.maxShots,_loc1_.shots);
            }
         }
         if(this.§_-72P§)
         {
            Image(this.§_-72P§.defaultSkin).texture = _loc2_;
            Image(this.§_-72P§.defaultSkin).scale9Grid = §_-e2R§;
            this.§_-FT§(_isSelected && _loc1_.isSelectable());
            this.§_-72P§.defaultIcon = _loc3_;
            this.§_-72P§.invalidate(INVALIDATION_FLAG_DATA);
         }
      }
      
      private function §_-q10§() : void
      {
         var _loc1_:DisplayObject = null;
         if(this.§_-kH§)
         {
            _loc1_ = this.§_-kH§.display;
            _loc1_.removeFromParent();
            WorldClock.clock.remove(this.§_-kH§);
            this.§_-kH§.dispose();
            this.§_-kH§ = null;
         }
      }
      
      private function §_-7v§() : void
      {
         this.§_-kH§ = §_-K1t§.buildArmature("TutorialArrowUI");
      }
      
      private function showDelay(param1:Image, param2:int) : DisplayObject
      {
         var _loc3_:DisplayObjectContainer = §_-YQ§.§_-qM§(§_-q2v§.§_-i1Y§);
         _loc3_.width = width / 4;
         _loc3_.scale = _loc3_.scaleX;
         if(!_loc3_)
         {
            return param1;
         }
         var _loc4_:Sprite = new Sprite();
         var _loc5_:Quad = new Quad(this.§_-nw§,this.§_-nw§);
         _loc5_.alpha = 0;
         var _loc6_:ITextRenderer = _loc3_.getChildByName("turns") as ITextRenderer;
         if(_loc6_)
         {
            _loc6_.text = String(param2);
         }
         _loc3_.x = §_-e2q§;
         _loc3_.y = §_-e2q§;
         param1.x = (_loc5_.width - param1.texture.width * param1.scaleX) * 0.5;
         param1.y = (_loc5_.height - param1.texture.height * param1.scaleY) * 0.5;
         _loc4_.addChild(_loc5_);
         _loc4_.addChild(param1);
         _loc4_.addChild(_loc3_);
         return _loc4_;
      }
      
      private function §_-Db§(param1:int, param2:int) : void
      {
         var _loc3_:int = 0;
         var _loc4_:Image = null;
         var _loc5_:Texture = null;
         var _loc6_:* = this.§_-wq§.numChildren;
         if(param1 < _loc6_)
         {
            while(_loc6_-- > param1)
            {
               this.§_-wq§.removeChildAt(_loc6_,true);
            }
         }
         _loc3_ = 0;
         while(_loc3_ < param1)
         {
            _loc5_ = _loc3_ < param2 ? §_-72o§ : §_-n2g§;
            if(_loc3_ < _loc6_)
            {
               _loc4_ = this.§_-wq§.getChildAt(_loc3_) as Image;
               _loc4_.texture = _loc5_;
            }
            else
            {
               _loc4_ = new Image(_loc5_);
               _loc4_.width = width / 6;
               _loc4_.scale = _loc4_.scaleX;
               _loc4_.alignPivot(Align.RIGHT,Align.BOTTOM);
               this.§_-wq§.addChild(_loc4_);
            }
            _loc4_.x = this.§_-nw§ * 0.9;
            _loc4_.y = this.§_-nw§ * 0.9 - _loc4_.height * 1.5 * _loc3_;
            _loc3_++;
         }
         this.§_-wq§.visible = true;
      }
      
      override public function set isSelected(param1:Boolean) : void
      {
         super.isSelected = param1;
         var _loc2_:§_-U16§ = _data as §_-U16§;
         if(Boolean(_loc2_) && _loc2_.isSelectable())
         {
            this.§_-FT§(param1);
         }
      }
      
      private function §_-FT§(param1:Boolean) : void
      {
         Image(this.§_-72P§.defaultSkin).color = param1 ? 8175626 : 16777215;
      }
   }
}

