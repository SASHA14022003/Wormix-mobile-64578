package §_-jF§
{
   import §_-52L§.§_-u2x§;
   import §_-62§.*;
   import §_-A1K§.§_-TA§;
   import §_-L1H§.§_-b2K§;
   import §_-Tm§.§_-RF§;
   import §_-Vg§.*;
   import §_-Y1Q§.§_-61Z§;
   import §_-j22§.§_-5g§;
   import §_-k2s§.§_-b0§;
   import §_-k2s§.§_-e1U§;
   import §_-k2s§.§_-e1k§;
   import §_-k2s§.§_-iI§;
   import §_-l1g§.§_-L3Q§;
   import feathers.controls.LayoutGroup;
   import feathers.core.ITextRenderer;
   import feathers.data.IListCollection;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.ILayout;
   import feathers.layout.VerticalAlign;
   import feathers.layout.VerticalLayout;
   import flash.geom.ColorTransform;
   import flash.utils.ByteArray;
   import flash.utils.IDataOutput;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fonts.BitmapFonts;
   import ru.pragmatix.wormix.gui.§_-Q2v§;
   import ru.pragmatix.wormix.gui.menu.§_-3m§;
   import ru.pragmatix.wormix.messages.clans.request.treasury.CashMedalsClanRequest;
   import ru.pragmatix.wormix.messages.server.Pong;
   import ru.pragmatix.wormix.model.items.craft.*;
   import ru.pragmatix.wormix.utils.*;
   import ru.pragmatix.wormix.weapons.*;
   import starling.display.DisplayObject;
   import starling.display.Image;
   import starling.events.Event;
   import starling.utils.Pool;
   
   public class §_-Q2P§ extends §_-x19§
   {
      
      public static const WIDTH:Number = 50;
      
      private static const §_-32v§:Number = 20;
      
      private static const §_-v2H§:uint = 16777215;
      
      protected static var §_-C1p§:String = "+";
      
      protected static const §_-cb§:String = "moneyIcon";
      
      protected var itemIcon:§_-3m§;
      
      protected var §_-qv§:ITextRenderer;
      
      protected var §_-We§:LayoutGroup;
      
      public function §_-Q2P§()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         var _loc1_:LayoutGroup = new LayoutGroup();
         var _loc2_:VerticalLayout = new VerticalLayout();
         _loc2_.horizontalAlign = HorizontalAlign.CENTER;
         _loc2_.verticalAlign = VerticalAlign.TOP;
         _loc1_.layout = _loc2_;
         addChild(_loc1_);
         this.§_-We§ = new LayoutGroup();
         this.§_-We§.setSize(WIDTH,WIDTH);
         _loc1_.addChild(this.§_-We§);
         this.itemIcon = new §_-3m§(this.§_-We§);
         this.§_-qv§ = §_-R2g§.createTextRenderer(BitmapFonts.AD_LIB,§_-32v§,§_-v2H§);
         this.§_-qv§.width = NaN;
         this.§_-qv§.text = "0";
         this.§_-qv§.validate();
         _loc1_.addChild(this.§_-qv§ as DisplayObject);
         width = WIDTH;
         height = WIDTH + this.§_-qv§.height;
      }
      
      override protected function §_-a1u§() : void
      {
         var _loc1_:DisplayObject = this.§_-We§.getChildByName(§_-cb§);
         if(_loc1_)
         {
            this.§_-We§.removeChild(_loc1_);
         }
         this.§_-qv§.text = "";
      }
      
      override protected function §_-S2T§(param1:§_-b0§) : void
      {
         this.§_-qv§.text = String(§_-C1p§ + §_-b0§(data).getCount());
         this.itemIcon.setItem(§_-bt§(param1),1,true);
      }
      
      override protected function §_-Gd§(param1:§_-e1k§) : void
      {
         this.§_-qv§.text = String(§_-C1p§ + param1.getCount());
         this.itemIcon.setItem(§_-bt§(param1),1,true);
      }
      
      override protected function §_-B3Y§(param1:§_-e1U§) : void
      {
         var _loc2_:§_-L1r§ = §_-bt§(param1) as §_-L1r§;
         if(param1.getCount() > 0)
         {
            _loc2_ = §_-2t§.§_-91M§(_loc2_,param1.getCount());
         }
         this.itemIcon.setItem(_loc2_,1,true);
         this.§_-qv§.text = _loc2_.§_-x1n§().toString();
      }
      
      override protected function §_-k2t§(param1:§_-iI§) : void
      {
         this.itemIcon.setItem(null);
         var _loc2_:§_-iI§ = param1 as §_-iI§;
         var _loc3_:DisplayObject = §_-YQ§.§_-l21§(_loc2_.§_-7i§());
         _loc3_.name = §_-cb§;
         this.§_-We§.addChild(_loc3_);
         this.§_-qv§.text = String(§_-C1p§ + param1.getCount());
      }
      
      override public function dispose() : void
      {
         if(this.itemIcon)
         {
            this.itemIcon.dispose();
            this.itemIcon = null;
         }
         if(this.§_-qv§)
         {
            this.§_-qv§.dispose();
         }
         this.§_-qv§ = null;
         super.dispose();
      }
   }
}

