package §_-jF§
{
   import §_-51p§.§_-W2e§;
   import §_-62§.§_-G1p§;
   import §_-GQ§.§_-31v§;
   import §_-TF§.§_-q1j§;
   import §_-Vg§.*;
   import §_-Y1b§.§_-OP§;
   import §_-hO§.§_-v24§;
   import §_-l1g§.§_-L3Q§;
   import §_-m0§.§_-X1F§;
   import §_-o14§.§_-Dd§;
   import §_-r1C§.§_-h2B§;
   import §_-w2i§.§_-Ia§;
   import §_-x2Q§.§_-dU§;
   import §_-zI§.§_-X1q§;
   import com.mesmotronic.ane.AndroidFullScreen;
   import feathers.controls.Button;
   import feathers.controls.List;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import feathers.themes.FontColor;
   import feathers.themes.styles.AlternateTextStyles;
   import feathers.utils.textures.TextureCache;
   import flash.geom.Point;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.main.server.ClanInviteStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.bonus.§_-x2M§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.weapons.ammo.ammoFactory.AmmosFactory;
   import ru.pragmatix.wormix.weapons.ammo.ammoFactory.IPooledAmmo;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Quad;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.utils.Color;
   import starling.utils.Pool;
   
   public class ClanInviteRenderer extends DefaultListItemRenderer
   {
      
      private var binder:Binder;
      
      private var _textureCache:TextureCache;
      
      private var §_-fY§:§_-M11§;
      
      public function ClanInviteRenderer()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         isQuickHitAreaEnabled = true;
         itemHasIcon = false;
         itemHasLabel = false;
         itemHasAccessory = false;
         this.binder = new Binder();
         var _loc1_:Object = Application.assetManager.getObject("clan_invite_renderer");
         Application.uiBuilder.create(_loc1_,true,this.binder);
         defaultIcon = this.binder._container;
         this.§_-fY§ = new §_-M11§();
         this.§_-fY§.size = this.binder._emblemContainer.height;
         this.binder._emblemContainer.addChild(this.§_-fY§);
      }
      
      override protected function draw() : void
      {
         if(isInvalid(INVALIDATION_FLAG_SIZE) && Boolean(owner))
         {
            this.binder._container.width = owner.width;
         }
         if(isInvalid(§_-dU§.CLAN_EMBLEM))
         {
            this.§_-fY§.textureCache = this._textureCache;
         }
         super.draw();
      }
      
      override protected function commitData() : void
      {
         var _loc1_:ClanInviteStructure = _data as ClanInviteStructure;
         if(_loc1_)
         {
            this.§_-fY§.§_-6B§ = _loc1_.clanEmblem;
            this.binder._inviteText.styleName = AlternateTextStyles.NEW_WHITE_NORMAL_LEFT;
            this.binder._inviteText.textRendererProperties.isHTML = true;
            this.binder._inviteText.text = "<font width=\"20\" color=\"#8698A7\">" + _loc1_.name + "</font> " + "<font>" + §_-s2a§.§_-K3t§("INVITE_TEXT") + "</font> " + "<font color=\"#628FC8\">" + _loc1_.clanName + "</font>";
         }
      }
      
      override public function set owner(param1:List) : void
      {
         if(owner)
         {
            owner.removeEventListener(Event.RESIZE,this.§_-P12§);
         }
         super.owner = param1;
         if(owner)
         {
            owner.addEventListener(Event.RESIZE,this.§_-P12§);
         }
         invalidate(INVALIDATION_FLAG_SIZE);
      }
      
      private function §_-P12§(param1:Event) : void
      {
         invalidate(INVALIDATION_FLAG_SIZE);
      }
      
      override public function dispose() : void
      {
         this.binder = null;
         this._textureCache = null;
         super.dispose();
      }
      
      public function set textureCache(param1:TextureCache) : void
      {
         this._textureCache = param1;
         invalidate(§_-dU§.CLAN_EMBLEM);
      }
   }
}

import feathers.controls.Label;
import feathers.controls.LayoutGroup;

class Binder
{
   
   public var _container:LayoutGroup;
   
   public var _emblemContainer:LayoutGroup;
   
   public var _inviteText:Label;
   
   public function Binder()
   {
      super();
   }
}
