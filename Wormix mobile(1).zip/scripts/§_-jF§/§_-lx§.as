package §_-jF§
{
   import §_-B2z§.Server;
   import §_-D3A§.§_-TZ§;
   import §_-l1K§.§_-W2f§;
   import §_-l1g§.§_-L3Q§;
   import §_-l2r§.§_-K1t§;
   import §_-s20§.§_-6a§;
   import §_-x2Q§.§_-dU§;
   import dragonBones.animation.WorldClock;
   import feathers.controls.LayoutGroup;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.VerticalAlign;
   import feathers.layout.VerticalLayout;
   import feathers.themes.FontColor;
   import flash.events.Event;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.sets.ControlSets;
   import ru.pragmatix.wormix.fonts.BitmapFonts;
   import ru.pragmatix.wormix.gui.menu.§_-3m§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.pvp.messages.ex.BattleCreated;
   import ru.pragmatix.wormix.utils.§_-R2g§;
   import ru.pragmatix.wormix.weapons.*;
   import starling.display.DisplayObject;
   import starling.events.Event;
   
   public class §_-lx§ extends §_-Q2P§
   {
      
      public static const WIDTH:Number = 50;
      
      private static const §_-32v§:Number = 20;
      
      public function §_-lx§()
      {
         super();
         §_-C1p§ = "";
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         var _loc1_:LayoutGroup = new LayoutGroup();
         var _loc2_:VerticalLayout = new VerticalLayout();
         _loc2_.horizontalAlign = HorizontalAlign.CENTER;
         _loc2_.verticalAlign = VerticalAlign.TOP;
         _loc1_.layout = _loc2_;
         addChild(_loc1_);
         §_-We§ = new LayoutGroup();
         §_-We§.setSize(WIDTH,WIDTH);
         _loc1_.addChild(§_-We§);
         itemIcon = new §_-3m§(§_-We§);
         §_-qv§ = §_-R2g§.createTextRenderer(BitmapFonts.AD_LIB,§_-32v§,FontColor.LIGHT_BROWN);
         §_-qv§.width = NaN;
         §_-qv§.text = "0";
         §_-qv§.validate();
         §_-qv§.name = "countLabel";
         _loc1_.addChild(§_-qv§ as DisplayObject);
         width = WIDTH;
         height = WIDTH + §_-qv§.height;
      }
      
      override public function dispose() : void
      {
         if(itemIcon)
         {
            itemIcon.dispose();
            itemIcon = null;
         }
         if(§_-qv§)
         {
            §_-qv§.dispose();
         }
         §_-qv§ = null;
         super.dispose();
      }
   }
}

