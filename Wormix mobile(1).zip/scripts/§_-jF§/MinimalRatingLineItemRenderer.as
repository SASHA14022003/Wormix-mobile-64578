package §_-jF§
{
   import §_-31W§.*;
   import §_-63U§.*;
   import §_-91B§.§_-QK§;
   import §_-A1K§.§_-TA§;
   import §_-C3f§.§_-Z1Y§;
   import §_-H3§.*;
   import §_-N8§.§_-2C§;
   import §_-TF§.§_-P19§;
   import §_-TF§.§_-Z1U§;
   import §_-TF§.§_-q1j§;
   import §_-Tm§.§_-RF§;
   import §_-U1i§.§_-J1§;
   import §_-Y1Q§.§_-tc§;
   import §_-g2r§.§_-03A§;
   import §_-zI§.§_-sI§;
   import feathers.controls.GroupedList;
   import feathers.controls.List;
   import feathers.controls.ScrollPolicy;
   import feathers.controls.Scroller;
   import feathers.controls.renderers.DefaultGroupedListHeaderOrFooterRenderer;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import feathers.data.VectorCollection;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.VerticalLayout;
   import flash.events.Event;
   import flash.geom.Point;
   import flash.utils.ByteArray;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controller.analytics.Analytics;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.client.StartBattle;
   import ru.pragmatix.wormix.model.user.*;
   import ru.pragmatix.wormix.objects.§_-8K§;
   import ru.pragmatix.wormix.pvp.messages.ex.BattleCreationFailure;
   import ru.pragmatix.wormix.pvp.messages.ex.StartPvpBattle;
   import ru.pragmatix.wormix.utils.§_-J2h§;
   import ru.pragmatix.wormix.weapons.Weapon;
   import starling.animation.Tween;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   import starling.utils.Pool;
   
   public class MinimalRatingLineItemRenderer extends DefaultListItemRenderer implements §_-Z1U§
   {
      
      private var binder:Binder;
      
      public function MinimalRatingLineItemRenderer()
      {
         super();
         isQuickHitAreaEnabled = true;
         itemHasAccessory = false;
         itemHasLabel = false;
         itemHasIcon = false;
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         this.binder = new Binder();
         var _loc1_:Object = Application.assetManager.getObject("rating_list_devider");
         Application.uiBuilder.create(_loc1_,true,this.binder);
         defaultIcon = this.binder._container;
         padding = 10;
         §_-q1j§.register(this);
      }
      
      override protected function commitData() : void
      {
         if(Boolean(_data) && Boolean(_data.rating))
         {
            this.binder._minRatingLabel.text = §_-s2a§.§_-K3t§(§_-s2a§.MIN_RATING);
            this.binder._minRatingValue.text = _data.rating.toString();
         }
      }
      
      override protected function draw() : void
      {
         super.draw();
         if(isInvalid(INVALIDATION_FLAG_SIZE) && Boolean(_owner))
         {
            this.binder._container.width = _owner.width;
         }
      }
      
      override public function dispose() : void
      {
         super.dispose();
         if(owner)
         {
            owner.removeEventListener(starling.events.Event.RESIZE,this.onResize);
         }
         §_-q1j§.remove(this);
      }
      
      public function getOrigin() : DisplayObject
      {
         return this;
      }
      
      public function §_-8I§() : DisplayObject
      {
         return new §_-P19§(§_-s2a§.§_-K3t§(§_-s2a§.MINIMAL_RATING_QTIP));
      }
      
      public function §_-52e§() : Object
      {
         return null;
      }
      
      override public function set owner(param1:List) : void
      {
         if(owner)
         {
            owner.removeEventListener(starling.events.Event.RESIZE,this.onResize);
         }
         super.owner = param1;
         if(owner)
         {
            owner.addEventListener(starling.events.Event.RESIZE,this.onResize);
         }
         invalidate(INVALIDATION_FLAG_SIZE);
      }
      
      private function onResize(param1:starling.events.Event) : void
      {
         invalidate(INVALIDATION_FLAG_SIZE);
      }
   }
}

import feathers.controls.Label;
import feathers.controls.LayoutGroup;

class Binder
{
   
   public var _container:LayoutGroup;
   
   public var _minRatingLabel:Label;
   
   public var _minRatingValue:Label;
   
   public function Binder()
   {
      super();
   }
}
