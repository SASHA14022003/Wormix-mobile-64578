package §_-jF§
{
   import §_-12W§.*;
   import §_-5Y§.*;
   import §_-73I§.§_-Y1l§;
   import §_-A1K§.§_-7u§;
   import §_-A1K§.§_-TA§;
   import §_-A2U§.§_-A23§;
   import §_-Af§.§_-k1I§;
   import §_-CR§.§_-72p§;
   import §_-K35§.§_-99§;
   import §_-TF§.§_-q1j§;
   import §_-Vg§.*;
   import §_-Y1Q§.§_-vx§;
   import §_-Y1b§.§_-81l§;
   import §_-YF§.§_-Zi§;
   import §_-aM§.§_-P1N§;
   import §_-p14§.§_-A3Y§;
   import §_-q26§.*;
   import §_-xu§.§_-a1B§;
   import com.hurlant.util.§_-a2P§;
   import feathers.controls.List;
   import feathers.controls.ScrollPolicy;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import feathers.data.ArrayCollection;
   import feathers.layout.AnchorLayout;
   import feathers.layout.Direction;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.RelativePosition;
   import feathers.layout.TiledColumnsLayout;
   import feathers.layout.VerticalAlign;
   import feathers.layout.VerticalLayout;
   import feathers.themes.styles.AlternateButtonsStyles;
   import feathers.utils.textures.TextureCache;
   import flash.events.Event;
   import flash.events.TimerEvent;
   import flash.utils.ByteArray;
   import flash.utils.Dictionary;
   import ru.pragmatix.flox.social.model.SocialUserData;
   import ru.pragmatix.flox.social.response.*;
   import ru.pragmatix.wormix.gui.§_-eP§;
   import ru.pragmatix.wormix.messages.clans.main.IncomingClanMessage;
   import ru.pragmatix.wormix.messages.clans.main.server.InviteFriendToClan;
   import ru.pragmatix.wormix.messages.clans.response.LoginClanEnterAccount;
   import ru.pragmatix.wormix.messages.clans.response.PostToClanChatResponse;
   import ru.pragmatix.wormix.messages.clans.structures.ClanChatMessageTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanMemberTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   import ru.pragmatix.wormix.model.user.§_-r1d§;
   import ru.pragmatix.wormix.pvp.messages.client.PvpActionEx;
   import ru.pragmatix.wormix.utils.StringUtil;
   import ru.pragmatix.wormix.utils.§_-6A§;
   import starling.display.Sprite;
   import starling.events.Event;
   import starlingbuilder.engine.UIBuilder;
   
   public class FriendSocialITabItemRenderer extends DefaultListItemRenderer
   {
      
      private var avatar:§_-a1B§;
      
      private var binder:PanelBinder;
      
      public function FriendSocialITabItemRenderer()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         itemHasIcon = false;
         itemHasLabel = false;
         itemHasAccessory = false;
         isQuickHitAreaEnabled = true;
         var _loc1_:UIBuilder = Application.uiBuilder;
         this.binder = new PanelBinder();
         _loc1_.create(Application.assetManager.getObject("friend_list_item_renderer"),true,this.binder);
         this.avatar = new §_-a1B§(this.binder._avatarPlace,false);
         defaultAccessory = this.binder._container;
      }
      
      override protected function draw() : void
      {
         super.draw();
         if(Boolean(isInvalid(INVALIDATION_FLAG_SIZE)) && Boolean(_owner) && Boolean(this.binder))
         {
            this.binder._container.width = _owner.width;
         }
      }
      
      override protected function commitData() : void
      {
         var _loc1_:UserProfile = null;
         if(_data)
         {
            _loc1_ = UserProfile(data.userProfile);
            this.§_-Y2H§(data);
            if(_loc1_)
            {
               this.binder._name.text = _loc1_.§_-K3u§() ? _loc1_.§_-K3u§() : StringUtil.§_-43t§;
            }
         }
      }
      
      override public function dispose() : void
      {
         super.dispose();
         if(_owner)
         {
            _owner.addEventListener(starling.events.Event.RESIZE,this.§_-P12§);
         }
      }
      
      private function §_-Y2H§(param1:Object) : void
      {
         this.avatar.setItem(param1.userProfile,true);
         this.avatar.§_-L3§(param1.index);
      }
      
      override public function set owner(param1:List) : void
      {
         if(_owner)
         {
            _owner.removeEventListener(starling.events.Event.RESIZE,this.§_-P12§);
         }
         super.owner = param1;
         if(_owner)
         {
            _owner.addEventListener(starling.events.Event.RESIZE,this.§_-P12§);
            this.§_-P12§();
         }
      }
      
      private function §_-P12§(param1:starling.events.Event = null) : void
      {
         invalidate(INVALIDATION_FLAG_SIZE);
      }
   }
}

import feathers.controls.Label;
import feathers.controls.LayoutGroup;

class PanelBinder
{
   
   public var _container:LayoutGroup;
   
   public var _avatarPlace:LayoutGroup;
   
   public var _name:Label;
   
   public function PanelBinder()
   {
      super();
   }
}
