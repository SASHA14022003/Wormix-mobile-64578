package §_-jF§
{
   import §_-62§.*;
   import §_-73I§.§_-q15§;
   import §_-C3f§.§_-yG§;
   import §_-P1z§.*;
   import §_-TF§.§_-Z1U§;
   import §_-TF§.§_-q1j§;
   import §_-TF§.§_-y2n§;
   import §_-Y1O§.§_-V23§;
   import §_-Y1O§.§_-y1o§;
   import §_-Y1b§.§_-81l§;
   import §_-j1w§.§_-L1x§;
   import §_-j1y§.§_-i1b§;
   import §_-k1u§.§_-Oi§;
   import §_-l1K§.*;
   import §_-l2r§.§_-K1t§;
   import §_-n1w§.*;
   import §_-q26§.*;
   import §_-r1C§.§_-h2B§;
   import §_-w§.§_-63m§;
   import §_-x2Q§.§_-dU§;
   import §_-zI§.§_-X1q§;
   import com.greensock.*;
   import com.greensock.plugins.*;
   import feathers.controls.Label;
   import feathers.controls.NumericStepper;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import feathers.layout.RelativePosition;
   import feathers.themes.styles.AlternateTextStyles;
   import flash.geom.Point;
   import flash.geom.Rectangle;
   import flash.text.TextField;
   import flash.utils.getTimer;
   import flash.utils.setTimeout;
   import org.gestouch.core.*;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fonts.BitmapFonts;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.request.login.LoginClanBase;
   import ru.pragmatix.wormix.messages.clans.response.LoginClanEnterAccount;
   import ru.pragmatix.wormix.messages.clans.response.LoginClanErrorResponse;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.physics.GameObjectUtils;
   import ru.pragmatix.wormix.utils.§_-c1S§;
   import ru.pragmatix.wormix.weapons.Girder;
   import ru.pragmatix.wormix.weapons.Weapon;
   import starling.display.DisplayObject;
   import starling.display.Image;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.text.TextField;
   import starling.text.TextFormat;
   import starling.utils.Align;
   import starling.utils.MathUtil;
   import starling.utils.Pool;
   import starling.utils.RectangleUtil;
   import starling.utils.ScaleMode;
   import starling.utils.SystemUtil;
   
   public class §_-R1a§ extends DefaultListItemRenderer implements §_-Z1U§
   {
      
      public static const §_-K2K§:int = 120;
      
      public static const §_-r1a§:int = 120;
      
      private static const §_-s1w§:Number = 0.6;
      
      private const §_-R2E§:String = "TempTimerIcon";
      
      private var §_-v1v§:starling.text.TextField;
      
      private var §_-B37§:Label;
      
      private var weaponClip:DisplayObject;
      
      private var §_-43j§:DisplayObject;
      
      public function §_-R1a§()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         this.isQuickHitAreaEnabled = true;
         this.§_-v1v§ = new starling.text.TextField(§_-K2K§ * 0.9,§_-r1a§ * 0.25,"",new TextFormat(BitmapFonts.GROBOLD_WITH_SHADOWS,20,16777215));
         this.§_-v1v§.y = §_-r1a§ * 0.6;
         this.§_-v1v§.batchable = true;
         this.§_-v1v§.format.horizontalAlign = Align.RIGHT;
         this.§_-v1v§.touchable = false;
         addChild(this.§_-v1v§);
         this.§_-B37§ = new Label();
         this.§_-B37§.x = 5;
         this.§_-B37§.y = 5;
         this.§_-B37§.styleName = AlternateTextStyles.WHITE_NORMAL_CENTER;
         addChild(this.§_-B37§);
         this.§_-43j§ = new Image(Application.assetManager.getTexture(this.§_-R2E§));
         this.§_-43j§.x = §_-K2K§ * 0.7;
         this.§_-43j§.y = §_-r1a§ * (SystemUtil.isDesktop ? 0.7 : 0.8);
         addChild(this.§_-43j§);
         §_-q1j§.register(this);
         width = §_-K2K§;
         height = §_-r1a§;
         addEventListener(Event.TRIGGERED,this.§_-p2v§);
      }
      
      override protected function commitData() : void
      {
         var _loc2_:§_-Oi§ = null;
         var _loc3_:Rectangle = null;
         var _loc4_:Rectangle = null;
         var _loc1_:§_-63m§ = data as §_-63m§;
         if(this.weaponClip)
         {
            this.weaponClip.removeFromParent(true);
            this.weaponClip = null;
         }
         if(_loc1_)
         {
            _loc2_ = _loc1_.§_-13k§;
            this.weaponClip = §_-q15§.§_-K2x§(_loc1_.§_-13k§.getRecord());
            _loc3_ = Pool.getRectangle(0,0,§_-K2K§ * §_-s1w§,§_-r1a§ * §_-s1w§);
            _loc4_ = Pool.getRectangle();
            RectangleUtil.fit(this.weaponClip.bounds,_loc3_,ScaleMode.SHOW_ALL,false,_loc4_);
            this.weaponClip.width = _loc4_.width;
            this.weaponClip.height = _loc4_.height;
            this.weaponClip.alignPivot();
            this.weaponClip.x = §_-K2K§ * 0.5;
            this.weaponClip.y = §_-r1a§ * 0.5;
            addChildAt(this.weaponClip,0);
            Pool.putRectangle(_loc3_);
            Pool.putRectangle(_loc4_);
            this.§_-v1v§.text = !_loc2_.isInfinite() ? "x" + String(_loc2_.getCount()) : "";
            this.§_-B37§.text = _loc1_.§_-i7§ ? "[" + _loc1_.§_-i7§ + "]" : "";
            this.§_-43j§.visible = _loc1_.§_-9m§;
         }
         else
         {
            this.§_-v1v§.text = "";
            this.§_-B37§.text = "";
            this.§_-43j§.visible = false;
         }
      }
      
      protected function §_-p2v§(param1:Event) : void
      {
      }
      
      public function getOrigin() : DisplayObject
      {
         return this;
      }
      
      public function §_-8I§() : DisplayObject
      {
         var _loc2_:§_-O2H§ = null;
         var _loc1_:§_-63m§ = data as §_-63m§;
         if(Boolean(_loc1_) && Boolean(_loc1_.§_-13k§))
         {
            _loc2_ = _loc1_.§_-13k§.getRecord() as §_-O2H§;
            return §_-y2n§.§_-i1N§.§_-e21§(_loc2_,_loc1_.§_-13k§.getLevel());
         }
         return null;
      }
      
      public function §_-52e§() : Object
      {
         return new <String>[RelativePosition.BOTTOM,RelativePosition.RIGHT,RelativePosition.LEFT];
      }
      
      override public function dispose() : void
      {
         §_-q1j§.remove(this);
         this.§_-v1v§ = §_-c1S§.dispose(this.§_-v1v§ as DisplayObject) as starling.text.TextField;
         this.weaponClip = §_-c1S§.dispose(this.weaponClip);
         removeEventListener(Event.TRIGGERED,this.§_-p2v§);
         super.dispose();
      }
   }
}

