package §_-jF§
{
   import §_-51p§.§_-W2e§;
   import §_-62§.§_-G1p§;
   import §_-A2U§.§_-A23§;
   import §_-CR§.§_-S2o§;
   import §_-DJ§.§_-J2l§;
   import §_-H3§.*;
   import §_-K35§.§_-S18§;
   import §_-d26§.*;
   import §_-g2r§.§_-03A§;
   import §_-hO§.§_-v24§;
   import §_-l1g§.§_-L3Q§;
   import §_-z1g§.§_-lp§;
   import feathers.controls.List;
   import flash.geom.Point;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.client.StartBattle;
   import ru.pragmatix.wormix.messages.server.GetFriendsForBossResult;
   import ru.pragmatix.wormix.model.user.*;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.weapons.*;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Quad;
   import starling.events.Event;
   import starling.utils.Pool;
   
   public class §_-82f§ extends §_-U2u§
   {
      
      private var hint:§_-S18§;
      
      private var state:uint;
      
      public function §_-82f§()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         addEventListener(Event.TRIGGERED,this.§_-p2v§);
      }
      
      override protected function commitData() : void
      {
         if(_data)
         {
            if(!(_data is UserProfile))
            {
               this.state = _data.state;
               _data = _data.profile;
            }
            super.commitData();
            avatar.§_-93J§(_data.getOnline());
            if(_data)
            {
               §_-mH§(this.state != GetFriendsForBossResult.STATE_SUCCESS);
            }
         }
      }
      
      protected function §_-p2v§(param1:Event) : void
      {
         var _loc2_:UserProfile = data as UserProfile;
         if(_loc2_)
         {
            this.hint = new §_-S18§(_loc2_.getId(),_loc2_);
            this.hint.§_-x21§ = false;
            §_-S2o§.§_-02T§(this.hint,this,null,false,true);
         }
      }
      
      override public function dispose() : void
      {
         if(this.hint)
         {
            this.hint.close();
            this.hint.dispose();
            this.hint = null;
         }
         removeEventListener(Event.TRIGGERED,this.§_-p2v§);
         super.dispose();
      }
   }
}

