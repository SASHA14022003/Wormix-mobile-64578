package §_-jF§
{
   import §_-62§.§_-O2H§;
   import §_-B2z§.Server;
   import §_-B2z§.§_-c1G§;
   import §_-DJ§.§_-fH§;
   import §_-Ly§.§_-81L§;
   import §_-U1i§.§_-81M§;
   import §_-U1i§.§_-O2i§;
   import §_-Y1b§.§_-OP§;
   import §_-ZP§.§_-YG§;
   import §_-nE§.SelectCraftWeaponScreen;
   import §_-nE§.§_-p16§;
   import §_-o14§.*;
   import §_-r1C§.§_-h2B§;
   import §_-t2x§.§_-53b§;
   import §_-t2x§.§_-H12§;
   import §_-t2x§.§_-nH§;
   import §_-t2x§.§_-v2c§;
   import §_-t2x§.§_-w1o§;
   import §_-x2Q§.§_-dU§;
   import §_-z1g§.§_-82X§;
   import §_-zI§.§_-91X§;
   import com.distriqt.extension.cloudstorage.events.KeyValueStoreEvent;
   import com.distriqt.extension.inappbilling.Purchase;
   import com.greensock.events.LoaderEvent;
   import com.greensock.loading.core.*;
   import config.§_-vR§;
   import feathers.controls.GroupedList;
   import feathers.controls.ScrollPolicy;
   import feathers.controls.renderers.DefaultGroupedListItemRenderer;
   import feathers.core.FeathersControl;
   import feathers.data.VectorCollection;
   import flash.display.DisplayObject;
   import flash.events.Event;
   import ru.pragmatix.flox.social.model.PaymentOption;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.server.VerifyPaymentResult;
   import ru.pragmatix.wormix.messages.structures.WeaponStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.platform.§_-WK§;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.weapons.*;
   import starling.display.DisplayObject;
   import starling.events.Event;
   import starling.utils.SystemUtil;
   
   public class ClanActivityItemRenderer extends DefaultGroupedListItemRenderer
   {
      
      private var binder:Binder;
      
      public function ClanActivityItemRenderer()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         isQuickHitAreaEnabled = true;
         itemHasLabel = false;
         itemHasIcon = false;
         itemHasAccessory = false;
         this.binder = new Binder();
         var _loc1_:Object = Application.assetManager.getObject("clan_activity_item_renderer");
         Application.uiBuilder.create(_loc1_,true,this.binder);
         defaultAccessory = this.binder._container;
      }
      
      override public function set owner(param1:GroupedList) : void
      {
         super.owner = param1;
         invalidate(INVALIDATION_FLAG_SIZE);
      }
      
      override protected function draw() : void
      {
         var _loc1_:Boolean = isInvalid(INVALIDATION_FLAG_SIZE);
         if(_loc1_ && Boolean(_owner))
         {
            this.binder._container.width = _owner.width;
         }
         super.draw();
      }
      
      override protected function commitData() : void
      {
         if(data)
         {
            this.binder._date.text = String(data.date);
            this.binder._time.text = String(data.time);
            this.binder._log.text = §_-91X§.§_-K3t§(data.action);
         }
      }
      
      override public function dispose() : void
      {
         super.dispose();
         this.binder = null;
      }
   }
}

import feathers.controls.Label;
import feathers.controls.LayoutGroup;

class Binder
{
   
   public var _container:LayoutGroup;
   
   public var _date:Label;
   
   public var _time:Label;
   
   public var _log:Label;
   
   public function Binder()
   {
      super();
   }
}
