package §_-jF§
{
   import §_-73I§.§_-Z2e§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-P2i§.§_-G3J§;
   import §_-Tm§.§_-RF§;
   import §_-YF§.§_-L29§;
   import §_-k1u§.§_-H2M§;
   import feathers.controls.List;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import flash.geom.Point;
   import org.gestouch.core.*;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.wormix.controls.Command;
   import ru.pragmatix.wormix.fonts.FontColor;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.interfaces.§_-O1c§;
   import starling.animation.Transitions;
   import starling.animation.Tween;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.Image;
   import starling.events.Touch;
   import starling.events.TouchEvent;
   import starling.events.TouchPhase;
   
   use namespace gestouch_internal;
   
   public class MainMenuTeamMemberRenderer extends DefaultListItemRenderer
   {
      
      private static const §_-12Q§:String = "main_menu_char_platform_0";
      
      private static const §_-hc§:String = "main_menu_char_platform_1";
      
      private static const §_-n21§:String = "main_menu_name_orange";
      
      private static const §_-B25§:String = "main_menu_name_green";
      
      private var binder:Binder;
      
      private var §_-C1U§:Image;
      
      private var §_-23A§:§_-Z2e§;
      
      public function MainMenuTeamMemberRenderer()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         this.binder = new Binder();
         Application.uiBuilder.create(Application.assetManager.getObject("main_menu_teammate_renderer"),true,this.binder);
         this.binder._name.textRendererProperties.pixelSnapping = false;
         this.binder._name.maxWidth = 300;
         this.binder._name.minWidth = 50;
         this.§_-C1U§ = this.binder._name.backgroundSkin as Image;
         var _loc1_:Number = Math.random() * 10;
         var _loc2_:Tween = this.§_-61K§(this.binder._platform);
         _loc2_.animate("y",this.binder._platform.y - 20);
         _loc2_.advanceTime(_loc1_);
         Starling.juggler.add(_loc2_);
         _loc2_ = this.§_-61K§(this.binder._platformBlick);
         _loc2_.animate("scaleX",this.binder._platformBlick.scaleX - 0.1);
         _loc2_.animate("scaleY",this.binder._platformBlick.scaleY - 0.1);
         _loc2_.advanceTime(_loc1_);
         Starling.juggler.add(_loc2_);
         this.binder._container.x = 0;
         this.binder._container.y = 0;
         addChild(this.binder._container);
      }
      
      override protected function commitData() : void
      {
         var _loc1_:UserProfile = null;
         var _loc2_:Number = NaN;
         this.§_-L3C§();
         if(Boolean(data) && Boolean(data.up))
         {
            if(data)
            {
               _loc1_ = data.up as UserProfile;
               _loc2_ = 1.2;
               this.§_-23A§ = new §_-Z2e§(_loc1_.§_-P2e§(),_loc2_);
               this.§_-23A§.§_-L§(_loc1_.getHat());
               this.§_-23A§.§_-aV§(_loc1_.§_-32q§());
               this.§_-23A§.§_-N1h§(false);
               this.§_-23A§.getArmature().advanceTime(Math.random() * 10);
               this.§_-23A§.getContainer().y = -55 * _loc2_;
               this.binder._charPlace.addChild(this.§_-23A§.getContainer());
               this.binder._platformImage.texture = Application.assetManager.getTexture(data.isLeader ? §_-12Q§ : §_-hc§);
               this.binder._name.textFormat.color = data.isLeader ? FontColor.NAME_ORANGE_COLOR : FontColor.NAME_GREEN_COLOR;
               this.binder._platformBlick.color = data.isLeader ? FontColor.NAME_ORANGE_COLOR : FontColor.NAME_GREEN_COLOR;
               if(this.§_-C1U§)
               {
                  this.§_-C1U§.texture = Application.assetManager.getTexture(data.isLeader ? §_-n21§ : §_-B25§);
               }
               this.binder._name.text = _loc1_.getCharName();
               §_-YQ§.§_-pL§(280,this.binder._name);
            }
            else
            {
               this.binder._name.text = "";
            }
         }
         this.binder._name.width = NaN;
         this.binder._name.validate();
         this.binder._container.readjustLayout();
         this.binder._container.validate();
         this.width = this.binder._container.width;
         this.height = this.binder._container.height;
      }
      
      override public function dispose() : void
      {
         super.dispose();
         this.§_-L3C§();
         Starling.juggler.removeTweens(this.binder._platform);
         Starling.juggler.removeTweens(this.binder._platformBlick);
      }
      
      private function §_-L3C§() : void
      {
         if(this.§_-23A§)
         {
            this.binder._charPlace.removeChild(this.§_-23A§.getContainer());
            this.§_-23A§.dispose();
            this.§_-23A§ = null;
         }
      }
      
      private function §_-61K§(param1:DisplayObject) : Tween
      {
         var _loc2_:Tween = new Tween(param1,5,Transitions.EASE_IN_OUT);
         _loc2_.repeatCount = 0;
         _loc2_.reverse = true;
         return _loc2_;
      }
   }
}

import feathers.controls.LayoutGroup;
import starling.display.Image;
import starling.display.Sprite;
import starlingbuilder.extensions.uicomponents.CustomLabel;

class Binder
{
   
   public var _container:LayoutGroup;
   
   public var _name:CustomLabel;
   
   public var _charPlace:Sprite;
   
   public var _platformImage:Image;
   
   public var _platformBlick:Image;
   
   public var _platform:Sprite;
   
   public function Binder()
   {
      super();
   }
}
