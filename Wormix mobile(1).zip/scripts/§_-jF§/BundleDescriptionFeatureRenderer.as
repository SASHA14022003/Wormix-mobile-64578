package §_-jF§
{
   import §_-62§.*;
   import §_-73I§.§_-K2s§;
   import §_-CF§.§_-E19§;
   import §_-Y1O§.§_-42h§;
   import §_-Y1O§.§_-V23§;
   import §_-j1y§.§_-i1b§;
   import §_-j22§.§_-5g§;
   import §_-l1K§.*;
   import §_-l1g§.§_-L3Q§;
   import §_-l2r§.§_-K1t§;
   import §_-w2i§.§_-Zd§;
   import §_-z1g§.*;
   import §_-z1w§.*;
   import dragonBones.animation.WorldClock;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import feathers.layout.HorizontalAlign;
   import flash.display.Shape;
   import flash.events.Event;
   import flash.utils.ByteArray;
   import flash.utils.IDataOutput;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.game.§_-eX§;
   import ru.pragmatix.wormix.messages.clans.response.*;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.server.AchieveLoginError;
   import ru.pragmatix.wormix.messages.server.GetRatingResult;
   import ru.pragmatix.wormix.messages.structures.RatingProfileStructure;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.*;
   import ru.pragmatix.wormix.scene.SortingLayer;
   import ru.pragmatix.wormix.utils.§_-2t§;
   import ru.pragmatix.wormix.utils.§_-c1S§;
   import ru.pragmatix.wormix.utils.§_-z1x§;
   import ru.pragmatix.wormix.weapons.Girder;
   import ru.pragmatix.wormix.weapons.ammo.Mine;
   import starling.display.Image;
   import starling.events.Event;
   import starling.utils.MathUtil;
   import starling.utils.ScaleMode;
   import starlingbuilder.extensions.uicomponents.ContainerButtonWithStates;
   
   public class BundleDescriptionFeatureRenderer extends DefaultListItemRenderer
   {
      
      private var binder:Binder;
      
      public function BundleDescriptionFeatureRenderer()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         this.binder = new Binder();
         Application.uiBuilder.create(Application.assetManager.getObject("bank_bundle_info_feature"),true,this.binder);
         addChild(this.binder._content);
         this.binder._icon.maintainAspectRatio = true;
         this.binder._icon.scaleMode = ScaleMode.SHOW_ALL;
         this.width = this.binder._content.width;
         this.height = this.binder._content.height;
         _horizontalAlign = HorizontalAlign.CENTER;
      }
      
      override protected function commitData() : void
      {
         if(_data)
         {
            this.binder._count.text = _data.count.toString();
            this.binder._note.text = _data.note;
            this.binder._icon.source = Application.assetManager.getTexture(_data.icon);
            this.binder._content.readjustLayout();
         }
      }
      
      override protected function draw() : void
      {
         super.draw();
         if(Boolean(INVALIDATION_FLAG_DATA) || Boolean(INVALIDATION_FLAG_TEXT_RENDERER))
         {
            if(this.binder._note.text)
            {
               if(this.binder._note.parent.getChildIndex(this.binder._note) > 0)
               {
                  this.binder._note.parent.swapChildren(this.binder._note,this.binder._dot);
               }
            }
            this.binder._dot.visible = !this.binder._note.text;
         }
      }
   }
}

import feathers.controls.ImageLoader;
import feathers.controls.Label;
import feathers.controls.LayoutGroup;
import starling.display.Image;
import starling.text.TextField;

class Binder
{
   
   public var _content:LayoutGroup;
   
   public var _count:TextField;
   
   public var _icon:ImageLoader;
   
   public var _note:Label;
   
   public var _dot:Image;
   
   public function Binder()
   {
      super();
   }
}
