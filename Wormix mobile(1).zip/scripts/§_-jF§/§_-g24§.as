package §_-jF§
{
   import §_-B1y§.§_-bs§;
   import §_-C3f§.§_-yG§;
   import §_-GQ§.§_-31v§;
   import §_-k2s§.§_-8c§;
   import §_-k2s§.§_-Go§;
   import §_-k2s§.§_-b0§;
   import §_-k2s§.§_-iI§;
   import §_-k2s§.§_-uU§;
   import §_-l1g§.§_-L3Q§;
   import §_-w2i§.§_-Ia§;
   import feathers.controls.Label;
   import feathers.controls.LayoutGroup;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.HorizontalLayout;
   import feathers.layout.VerticalAlign;
   import feathers.themes.styles.AlternateTextStyles;
   import flash.display.DisplayObject;
   import flash.display.DisplayObjectContainer;
   import flash.geom.Rectangle;
   import flash.text.TextField;
   import flash.text.TextFormat;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import ru.pragmatix.wormix.gui.menu.§_-3m§;
   import ru.pragmatix.wormix.messages.clans.request.edit.ChangeClanDescriptionRequest;
   import ru.pragmatix.wormix.messages.clans.response.edit.ChangeClanDescriptionResponse;
   import ru.pragmatix.wormix.model.bonus.§_-x2M§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.pvp.messages.client.PvpActionEx;
   import ru.pragmatix.wormix.pvp.messages.client.PvpEndTurn;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import starling.display.DisplayObject;
   import starling.display.Image;
   import starling.display.Quad;
   import starling.events.Event;
   import starling.utils.Pool;
   import starling.utils.RectangleUtil;
   import starling.utils.ScaleMode;
   
   public class §_-g24§ extends §_-x19§
   {
      
      private static const §_-N1c§:Number = 50;
      
      private var §_-qm§:LayoutGroup;
      
      private var iconContainer:LayoutGroup;
      
      private var itemIcon:§_-3m§;
      
      private var countLabel:Label;
      
      public function §_-g24§()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         this.§_-qm§ = new LayoutGroup();
         var _loc1_:HorizontalLayout = new HorizontalLayout();
         _loc1_.verticalAlign = VerticalAlign.MIDDLE;
         _loc1_.horizontalAlign = HorizontalAlign.LEFT;
         _loc1_.gap = 5;
         this.§_-qm§.layout = _loc1_;
         addChild(this.§_-qm§);
         this.iconContainer = new LayoutGroup();
         this.iconContainer.setSize(§_-N1c§,§_-N1c§);
         this.§_-qm§.addChild(this.iconContainer);
         this.itemIcon = new §_-3m§(this.iconContainer);
         this.countLabel = new Label();
         this.countLabel.styleName = AlternateTextStyles.BITMAP_DARK_BROWN_GIANT_LEFT;
         this.countLabel.height = 40;
         this.§_-qm§.addChild(this.countLabel);
      }
      
      override protected function draw() : void
      {
         var _loc1_:§_-Go§ = null;
         var _loc2_:int = 0;
         var _loc3_:§_-iI§ = null;
         if(isInvalid(INVALIDATION_FLAG_DATA))
         {
            _loc1_ = _data as §_-Go§;
            if(_loc1_)
            {
               _loc2_ = _loc1_.getCount();
               if(_loc1_ is §_-iI§)
               {
                  this.itemIcon.setItem(null);
                  _loc3_ = _loc1_ as §_-iI§;
                  this.§_-U2N§(§_-YQ§.§_-l21§(_loc3_.§_-7i§()));
                  this.countLabel.text = _loc2_.toString();
               }
               else if(_loc1_ is §_-uU§)
               {
                  this.itemIcon.setItem(null);
                  this.§_-U2N§(new Image(Application.assetManager.getTexture("ExperienceIcon")));
                  this.countLabel.text = _loc2_.toString();
               }
               else if(_loc1_ is §_-b0§)
               {
                  this.itemIcon.setItem(§_-bt§(_loc1_ as §_-8c§),1);
                  this.countLabel.text = _loc2_ > 0 ? _loc2_.toString() : "";
               }
               else
               {
                  this.itemIcon.setItem(§_-bt§(_loc1_ as §_-8c§),1);
                  this.countLabel.text = _loc2_ > 1 ? _loc2_.toString() : "";
               }
               this.countLabel.validate();
               this.§_-qm§.validate();
               this.width = this.§_-qm§.width;
               this.height = this.§_-qm§.height;
            }
         }
      }
      
      private function §_-U2N§(param1:starling.display.DisplayObject) : void
      {
         var _loc2_:Rectangle = null;
         _loc2_ = Pool.getRectangle(0,0,§_-N1c§,§_-N1c§);
         var _loc3_:Rectangle = Pool.getRectangle();
         RectangleUtil.fit(param1.bounds,_loc2_,ScaleMode.SHOW_ALL,false,_loc3_);
         param1.width = _loc3_.width;
         param1.height = _loc3_.height;
         param1.x = _loc3_.x;
         param1.y = _loc3_.y;
         param1.name = "iconDisplayObject";
         Pool.putRectangle(_loc2_);
         Pool.putRectangle(_loc3_);
         var _loc4_:starling.display.DisplayObject = this.iconContainer.getChildByName("iconDisplayObject");
         if(_loc4_)
         {
            _loc4_.removeFromParent(true);
         }
         this.iconContainer.addChild(param1);
      }
   }
}

