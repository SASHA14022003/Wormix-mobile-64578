package §_-jF§
{
   import §_-31N§.§_-42G§;
   import §_-31Y§.§_-D3B§;
   import §_-5Y§.§_-h2c§;
   import §_-B1y§.Cookie;
   import §_-D3A§.§_-TZ§;
   import §_-F39§.*;
   import §_-G2H§.*;
   import §_-L1H§.§_-C3e§;
   import §_-L1H§.§_-b2K§;
   import §_-TF§.§_-q1j§;
   import §_-YF§.§_-q2v§;
   import §_-l1K§.§_-W2f§;
   import §_-l1g§.§_-L3Q§;
   import §_-r1C§.§_-h2B§;
   import §_-sQ§.§_-H3D§;
   import §_-xu§.§_-a1B§;
   import §_-z1g§.*;
   import com.distriqt.extension.inappbilling.Product;
   import com.distriqt.extension.inappbilling.SubscriptionOffer;
   import com.distriqt.extension.inappbilling.SubscriptionPhase;
   import com.distriqt.extension.inappbilling.events.ProductEvent;
   import feathers.controls.LayoutGroup;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import feathers.events.FeathersEventType;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.*;
   import ru.pragmatix.wormix.gui.menu.§_-3m§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.HitTest;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.utils.§_-F2L§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.LaserRay;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Image;
   import starling.display.Sprite;
   import starling.events.Event;
   
   public class §_-U2u§ extends DefaultListItemRenderer
   {
      
      private static const §_-K2O§:String = "cellBackground";
      
      private static const §_-Al§:String = "cellBackgroundSelected";
      
      private static const §_-n2P§:String = "cellBackgroundDisabled";
      
      private static const §_-41o§:Number = 97.25;
      
      protected var §_-mu§:Sprite;
      
      protected var §_-G3W§:DisplayObject;
      
      protected var cellBackgroundSelected:DisplayObject;
      
      protected var cellBackgroundDisabled:DisplayObject;
      
      protected var avatar:§_-a1B§;
      
      public function §_-U2u§()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         _isToggle = false;
         this.§_-mu§ = §_-YQ§.§_-qM§(§_-q2v§.§_-02l§,§_-q2v§.§_-A2T§);
         addChild(this.§_-mu§);
         this.avatar = new §_-a1B§(this.§_-mu§.getChildByName("friendCell") as DisplayObjectContainer);
         addChild(this.avatar);
         this.§_-G3W§ = this.§_-mu§.getChildByName(§_-K2O§);
         this.cellBackgroundSelected = this.§_-mu§.getChildByName(§_-Al§);
         this.cellBackgroundDisabled = this.§_-mu§.getChildByName(§_-n2P§);
         this.§_-G3W§.touchable = true;
         this.cellBackgroundSelected.touchable = true;
         this.cellBackgroundDisabled.touchable = true;
         this.cellBackgroundDisabled.visible = false;
         width = height = §_-41o§;
      }
      
      override public function set isSelected(param1:Boolean) : void
      {
         super.isSelected = param1;
         this.§_-k27§(param1);
      }
      
      override protected function commitData() : void
      {
         var _loc1_:UserProfile = _data as UserProfile;
         this.avatar.setItem(_loc1_);
         this.§_-k27§(isSelected);
      }
      
      protected function §_-k27§(param1:Boolean) : void
      {
         if(this.§_-mu§)
         {
            this.§_-G3W§.visible = !param1;
            this.cellBackgroundSelected.visible = param1;
         }
      }
      
      protected function §_-mH§(param1:Boolean) : void
      {
         if(this.§_-mu§)
         {
            this.cellBackgroundDisabled.visible = param1;
            this.§_-G3W§.visible = !this.cellBackgroundSelected.visible && !this.cellBackgroundDisabled.visible;
            this.avatar.§_-tx§(param1);
         }
      }
      
      override public function dispose() : void
      {
         removeChild(this.avatar).dispose();
         removeChild(this.§_-mu§).dispose();
         this.§_-G3W§ = null;
         this.cellBackgroundSelected = null;
         this.cellBackgroundDisabled = null;
         this.avatar = null;
         this.§_-mu§ = null;
         super.dispose();
      }
   }
}

