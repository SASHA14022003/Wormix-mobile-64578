package §_-jF§
{
   import §_-62§.§_-W1r§;
   import §_-B1y§.§_-bs§;
   import §_-C3f§.§_-yG§;
   import §_-Vg§.§_-M11§;
   import §_-q26§.§_-52J§;
   import §_-r1C§.§_-h2B§;
   import §_-x2Q§.§_-dU§;
   import §_-zI§.§_-92Q§;
   import com.greensock.loading.LoaderMax;
   import com.greensock.loading.display.ContentDisplay;
   import feathers.controls.List;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import feathers.utils.textures.TextureCache;
   import ru.pragmatix.wormix.messages.clans.request.edit.ChangeClanDescriptionRequest;
   import ru.pragmatix.wormix.messages.clans.response.edit.ChangeClanDescriptionResponse;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.model.§_-d27§;
   import starling.events.Event;
   
   public class ClanItemRenderer extends DefaultListItemRenderer
   {
      
      private var binder:Binder;
      
      private var _textureCache:TextureCache;
      
      private var §_-a1g§:§_-52J§;
      
      private var §_-fY§:§_-M11§;
      
      public function ClanItemRenderer()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         isQuickHitAreaEnabled = true;
         itemHasIcon = false;
         itemHasLabel = false;
         itemHasAccessory = false;
         this.binder = new Binder();
         var _loc1_:Object = Application.assetManager.getObject("clan_item_renderer");
         Application.uiBuilder.create(_loc1_,true,this.binder);
         defaultIcon = this.binder._container;
         this.§_-fY§ = new §_-M11§();
         this.§_-fY§.size = this.binder._emblemContainer.height;
         this.binder._emblemContainer.addChild(this.§_-fY§);
      }
      
      override protected function draw() : void
      {
         if(isInvalid(INVALIDATION_FLAG_SIZE) && Boolean(owner))
         {
            this.binder._container.width = owner.width;
         }
         if(isInvalid(§_-dU§.CLAN_EMBLEM))
         {
            this.§_-fY§.textureCache = this._textureCache;
         }
         super.draw();
      }
      
      override protected function commitData() : void
      {
         var _loc1_:ClanTO = _data as ClanTO;
         if(_loc1_)
         {
            this.§_-fY§.§_-6B§ = _loc1_.emblem;
            this.binder._clanName.text = _loc1_.name;
            this.binder._membersCount.text = _loc1_.size.toString() + "/" + §_-92Q§.getLevel(_loc1_.level).capacity;
            this.binder._rating.text = _loc1_.seasonRating.toString();
            if(this.§_-a1g§)
            {
               this.binder._requiredRating.text = this.§_-a1g§.§_-b1X§(_loc1_);
            }
         }
      }
      
      override public function set owner(param1:List) : void
      {
         super.owner = param1;
         invalidate(INVALIDATION_FLAG_SIZE);
      }
      
      override public function dispose() : void
      {
         this.binder = null;
         this._textureCache = null;
         super.dispose();
      }
      
      public function set textureCache(param1:TextureCache) : void
      {
         this._textureCache = param1;
         invalidate(§_-dU§.CLAN_EMBLEM);
      }
      
      public function get clanParamHelper() : §_-52J§
      {
         return this.§_-a1g§;
      }
      
      public function set clanParamHelper(param1:§_-52J§) : void
      {
         this.§_-a1g§ = param1;
         invalidate(INVALIDATION_FLAG_DATA);
      }
   }
}

import feathers.controls.Label;
import feathers.controls.LayoutGroup;

class Binder
{
   
   public var _container:LayoutGroup;
   
   public var _emblemContainer:LayoutGroup;
   
   public var _clanName:Label;
   
   public var _requiredRating:Label;
   
   public var _membersCount:Label;
   
   public var _rating:Label;
   
   public function Binder()
   {
      super();
   }
}
