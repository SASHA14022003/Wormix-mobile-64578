package §_-jF§
{
   import §_-31N§.§_-42G§;
   import §_-31Y§.§_-D3B§;
   import §_-3D§.§_-E3x§;
   import §_-A2U§.§_-A23§;
   import §_-D3A§.§_-TZ§;
   import §_-F39§.*;
   import §_-K3q§.*;
   import §_-L1H§.§_-C3e§;
   import §_-S§.*;
   import §_-Z1L§.§_-A2V§;
   import §_-l1K§.§_-W2f§;
   import §_-l1g§.§_-L3Q§;
   import §_-n1w§.X509CertificateCollection;
   import §_-z1g§.§_-M2v§;
   import §_-zI§.§_-F3q§;
   import com.hurlant.crypto.tls.*;
   import flash.display.DisplayObject;
   import flash.utils.ByteArray;
   import flash.utils.Dictionary;
   import flash.utils.IDataInput;
   import flash.utils.IDataOutput;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.flox.social.utils.id.*;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.*;
   import ru.pragmatix.wormix.messages.structures.*;
   import ru.pragmatix.wormix.model.rewards.§_-qU§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.*;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.pvp.messages.client.PvpEndTurn;
   import ru.pragmatix.wormix.scene.SortingLayer;
   import ru.pragmatix.wormix.utils.§_-c1S§;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.LaserRay;
   import starling.display.DisplayObject;
   import starling.display.Image;
   import starling.display.Sprite;
   import starlingbuilder.engine.tween.WormixTweenBuilder;
   
   public class §_-E2y§ extends §_-U2u§
   {
      
      public function §_-E2y§()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
      }
      
      override public function set isSelected(param1:Boolean) : void
      {
         super.isSelected = param1;
      }
      
      override protected function draw() : void
      {
         super.draw();
      }
      
      override public function set index(param1:int) : void
      {
         super.index = param1;
      }
      
      override public function set data(param1:Object) : void
      {
         super.data = param1;
      }
      
      override protected function commitData() : void
      {
         super.commitData();
         var _loc1_:UserProfile = _data as UserProfile;
      }
      
      override protected function §_-k27§(param1:Boolean) : void
      {
         super.§_-k27§(param1);
      }
      
      override protected function §_-mH§(param1:Boolean) : void
      {
         super.§_-mH§(param1);
      }
      
      override public function dispose() : void
      {
         super.dispose();
      }
   }
}

