package §_-e2h§
{
   import §_-Vg§.*;
   import §_-x2Q§.§_-dU§;
   import §_-zI§.*;
   import feathers.themes.FontColor;
   import flash.display.InteractiveObject;
   import flash.display.Stage;
   import flash.events.EventPhase;
   import flash.events.MouseEvent;
   import flash.events.TouchEvent;
   import flash.ui.Multitouch;
   import flash.ui.MultitouchInputMode;
   import org.gestouch.core.§_-B2V§;
   import org.gestouch.core.§_-T2w§;
   import org.gestouch.core.gestouch_internal;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import starling.utils.Color;
   
   use namespace gestouch_internal;
   
   public class §_-U1M§ implements §_-B2V§
   {
      
      protected static const §_-Cn§:uint = 0;
      
      Multitouch.inputMode = MultitouchInputMode.TOUCH_POINT;
      
      protected var _stage:Stage;
      
      protected var §_-eV§:Boolean;
      
      protected var §_-C1f§:Boolean;
      
      protected var §_-m1f§:§_-T2w§;
      
      public function §_-U1M§(param1:Stage, param2:Boolean = false, param3:Boolean = false)
      {
         super();
         if(!param1)
         {
            throw new ArgumentError("Stage must be not null.");
         }
         this._stage = param1;
         this.§_-eV§ = param2;
         this.§_-C1f§ = param3;
      }
      
      public function set touchesManager(param1:§_-T2w§) : void
      {
         this.§_-m1f§ = param1;
      }
      
      public function init() : void
      {
         if(Boolean(Multitouch.supportsTouchEvents) || this.§_-eV§)
         {
            this._stage.addEventListener(TouchEvent.TOUCH_BEGIN,this.§_-k1j§,true);
            this._stage.addEventListener(TouchEvent.TOUCH_BEGIN,this.§_-k1j§,false);
            this._stage.addEventListener(TouchEvent.TOUCH_MOVE,this.§_-wt§,true);
            this._stage.addEventListener(TouchEvent.TOUCH_MOVE,this.§_-wt§,false);
            this._stage.addEventListener(TouchEvent.TOUCH_END,this.§_-2Y§,true,int.MAX_VALUE);
            this._stage.addEventListener(TouchEvent.TOUCH_END,this.§_-2Y§,false,int.MAX_VALUE);
         }
         if(!Multitouch.supportsTouchEvents || this.§_-C1f§)
         {
            this._stage.addEventListener(MouseEvent.MOUSE_DOWN,this.§_-e1w§,true);
            this._stage.addEventListener(MouseEvent.MOUSE_DOWN,this.§_-e1w§,false);
         }
      }
      
      public function §_-e1y§() : void
      {
         this.§_-m1f§ = null;
         this._stage.removeEventListener(TouchEvent.TOUCH_BEGIN,this.§_-k1j§,true);
         this._stage.removeEventListener(TouchEvent.TOUCH_BEGIN,this.§_-k1j§,false);
         this._stage.removeEventListener(TouchEvent.TOUCH_MOVE,this.§_-wt§,true);
         this._stage.removeEventListener(TouchEvent.TOUCH_MOVE,this.§_-wt§,false);
         this._stage.removeEventListener(TouchEvent.TOUCH_END,this.§_-2Y§,true);
         this._stage.removeEventListener(TouchEvent.TOUCH_END,this.§_-2Y§,false);
         this._stage.removeEventListener(MouseEvent.MOUSE_DOWN,this.§_-e1w§,true);
         this._stage.removeEventListener(MouseEvent.MOUSE_DOWN,this.§_-e1w§,false);
         this.§_-IQ§();
      }
      
      protected function §_-TG§() : void
      {
         this._stage.addEventListener(MouseEvent.MOUSE_MOVE,this.§_-y2x§,true);
         this._stage.addEventListener(MouseEvent.MOUSE_MOVE,this.§_-y2x§,false);
         this._stage.addEventListener(MouseEvent.MOUSE_UP,this.§_-q2x§,true,int.MAX_VALUE);
         this._stage.addEventListener(MouseEvent.MOUSE_UP,this.§_-q2x§,false,int.MAX_VALUE);
      }
      
      protected function §_-IQ§() : void
      {
         this._stage.removeEventListener(MouseEvent.MOUSE_MOVE,this.§_-y2x§,true);
         this._stage.removeEventListener(MouseEvent.MOUSE_MOVE,this.§_-y2x§,false);
         this._stage.removeEventListener(MouseEvent.MOUSE_UP,this.§_-q2x§,true);
         this._stage.removeEventListener(MouseEvent.MOUSE_UP,this.§_-q2x§,false);
      }
      
      protected function §_-k1j§(param1:TouchEvent) : void
      {
         if(param1.eventPhase == EventPhase.BUBBLING_PHASE)
         {
            return;
         }
         this.§_-m1f§.§_-x1f§(param1.touchPointID,param1.stageX,param1.stageY,param1.target as InteractiveObject);
      }
      
      protected function §_-wt§(param1:TouchEvent) : void
      {
         if(param1.eventPhase == EventPhase.BUBBLING_PHASE)
         {
            return;
         }
         this.§_-m1f§.§_-H1f§(param1.touchPointID,param1.stageX,param1.stageY);
      }
      
      protected function §_-2Y§(param1:TouchEvent) : void
      {
         if(param1.eventPhase == EventPhase.BUBBLING_PHASE)
         {
            return;
         }
         if(Boolean(param1.hasOwnProperty("isTouchPointCanceled")) && Boolean(param1["isTouchPointCanceled"]))
         {
            this.§_-m1f§.§_-P18§(param1.touchPointID,param1.stageX,param1.stageY);
         }
         else
         {
            this.§_-m1f§.§_-C1j§(param1.touchPointID,param1.stageX,param1.stageY);
         }
      }
      
      protected function §_-e1w§(param1:MouseEvent) : void
      {
         if(param1.eventPhase == EventPhase.BUBBLING_PHASE)
         {
            return;
         }
         var _loc2_:Boolean = this.§_-m1f§.§_-x1f§(§_-Cn§,param1.stageX,param1.stageY,param1.target as InteractiveObject);
         if(_loc2_)
         {
            this.§_-TG§();
         }
      }
      
      protected function §_-y2x§(param1:MouseEvent) : void
      {
         if(param1.eventPhase == EventPhase.BUBBLING_PHASE)
         {
            return;
         }
         this.§_-m1f§.§_-H1f§(§_-Cn§,param1.stageX,param1.stageY);
      }
      
      protected function §_-q2x§(param1:MouseEvent) : void
      {
         if(param1.eventPhase == EventPhase.BUBBLING_PHASE)
         {
            return;
         }
         this.§_-m1f§.§_-C1j§(§_-Cn§,param1.stageX,param1.stageY);
         if(this.§_-m1f§.§_-w2F§ == 0)
         {
            this.§_-IQ§();
         }
      }
   }
}

