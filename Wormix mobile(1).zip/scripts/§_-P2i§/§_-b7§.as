package §_-P2i§
{
   import §_-12a§.§_-B16§;
   import §_-62§.§_-zF§;
   import §_-9e§.§_-73e§;
   import §_-9e§.§_-8O§;
   import §_-9e§.§_-A18§;
   import §_-A1K§.§_-6L§;
   import §_-A1K§.§_-7u§;
   import §_-A1K§.§_-U11§;
   import §_-A2U§.§_-A23§;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-L1H§.§_-C3e§;
   import §_-QD§.§_-G2z§;
   import §_-Tm§.§_-RF§;
   import §_-l1g§.§_-L3Q§;
   import §_-rM§.§_-61j§;
   import §_-s20§.§_-J2g§;
   import com.distriqt.extension.application.Application;
   import com.distriqt.extension.application.display.Display;
   import com.distriqt.extension.application.display.DisplayCutout;
   import feathers.controls.List;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import flash.geom.Point;
   import flash.geom.Rectangle;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import ru.pragmatix.wormix.controller.§_-J2d§;
   import ru.pragmatix.wormix.controls.Command;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.response.TopClansResponse;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.server.EndBattleResult;
   import ru.pragmatix.wormix.messages.structures.AdvertisingPurchaseStructure;
   import ru.pragmatix.wormix.messages.structures.GenericAwardStructure;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.serialization.SerializationUtils;
   import ru.pragmatix.wormix.utils.§_-J2h§;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.AirCatAmmo;
   import ru.pragmatix.wormix.weapons.ammo.DamageType;
   import ru.pragmatix.wormix.weapons.interfaces.§_-O1c§;
   import ru.pragmatix.wormix.weapons.interfaces.§_-b29§;
   import ru.pragmatix.wormix.weapons.interfaces.§_-y2Q§;
   import starling.display.DisplayObjectContainer;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.events.Touch;
   import starling.events.TouchEvent;
   import starling.events.TouchPhase;
   import starling.utils.Pool;
   import starling.utils.SystemUtil;
   
   public class §_-b7§
   {
      
      public static var §_-C3S§:Boolean;
      
      public function §_-b7§()
      {
         super();
      }
      
      public static function §_-11U§(param1:§_-01J§) : void
      {
         var _loc3_:Weapon = null;
         var _loc4_:Boolean = false;
         var _loc5_:Boolean = false;
         var _loc6_:Boolean = false;
         var _loc2_:§_-G3J§ = param1.controlsMap;
         _loc3_ = param1.weapon;
         _loc4_ = _loc3_ is §_-b29§;
         _loc5_ = _loc3_ is §_-O1c§;
         _loc6_ = _loc3_ is §_-y2Q§;
         var _loc7_:Boolean = _loc4_ || _loc5_ || _loc6_;
         _loc2_.isActive = true;
         _loc2_.§_-A2D§(true);
         _loc2_.§_-DV§(Command.Alt.name,_loc4_ && _loc5_);
         _loc2_.§_-DV§(Command.Shoot.name,_loc7_);
         _loc2_.§_-DV§(Command.Shift.name,§_-C3S§ || param1.stable);
         _loc2_.§_-DV§(Command.Bag.name,param1.§_-vp§ && param1.§_-9u§);
         _loc2_.§_-01B§();
         §_-C3S§ = false;
      }
      
      public static function §_-63Q§(param1:§_-01J§) : void
      {
         var _loc2_:§_-G3J§ = param1.controlsMap;
         var _loc3_:Weapon = param1.weapon;
         _loc2_.isActive = true;
         _loc2_.§_-A2D§(true);
         _loc2_.§_-DV§(Command.Bag.name,_loc3_.shotsLeft.value == _loc3_.shots.value);
         _loc2_.§_-DV§(Command.Alt.name,_loc3_ is §_-O1c§);
         _loc2_.§_-01B§();
      }
      
      public static function §_-z2s§(param1:§_-01J§) : void
      {
         var _loc2_:§_-G3J§ = param1.controlsMap;
         var _loc3_:Weapon = param1.weapon;
         _loc2_.isActive = true;
         _loc2_.§_-A2D§(true);
         _loc2_.§_-DV§(Command.Bag.name,false);
         _loc2_.§_-DV§(Command.Shoot.name,true);
         _loc2_.§_-DV§(Command.Alt.name,_loc3_ is §_-O1c§);
         _loc2_.§_-01B§();
      }
      
      public static function §_-13Z§(param1:§_-01J§) : void
      {
         var _loc2_:§_-G3J§ = param1.controlsMap;
         _loc2_.isActive = true;
         _loc2_.§_-A2D§(true);
         _loc2_.§_-DV§(Command.Shoot.name,false);
         _loc2_.§_-DV§(Command.Alt.name,false);
         _loc2_.§_-01B§();
      }
      
      public static function §_-j1X§(param1:§_-01J§) : void
      {
         var _loc2_:§_-G3J§ = param1.controlsMap;
         _loc2_.isActive = true;
         _loc2_.§_-A2D§(true);
         _loc2_.§_-DV§(Command.Jump.name,false);
         _loc2_.§_-DV§(Command.BackJump.name,false);
         _loc2_.§_-DV§(Command.Shift.name,false);
         _loc2_.§_-DV§(Command.Bag.name,false);
         _loc2_.§_-DV§(Command.Alt.name,false);
         _loc2_.§_-01B§();
      }
      
      public static function §_-K3b§(param1:§_-01J§) : void
      {
         var _loc2_:§_-G3J§ = param1.controlsMap;
         _loc2_.isActive = true;
         _loc2_.§_-A2D§(true);
         _loc2_.§_-DV§(Command.Up.name,false);
         _loc2_.§_-DV§(Command.Down.name,false);
         _loc2_.§_-DV§(Command.Shift.name,false);
         _loc2_.§_-DV§(Command.Bag.name,false);
         _loc2_.§_-DV§(Command.Alt.name,false);
         _loc2_.§_-DV§(Command.Shoot.name,false);
         _loc2_.§_-01B§();
      }
      
      public static function §_-X1o§(param1:§_-01J§) : void
      {
         var _loc2_:§_-G3J§ = param1.controlsMap;
         _loc2_.isActive = true;
         _loc2_.§_-A2D§(true);
         _loc2_.§_-DV§(Command.Shift.name,false);
         _loc2_.§_-DV§(Command.Bag.name,false);
         _loc2_.§_-DV§(Command.Alt.name,false);
         _loc2_.§_-DV§(Command.Shoot.name,false);
         _loc2_.§_-01B§();
      }
      
      public static function §_-q2s§(param1:§_-01J§) : void
      {
         var _loc2_:§_-G3J§ = param1.controlsMap;
         _loc2_.isActive = true;
         _loc2_.§_-A2D§(true);
         var _loc3_:Weapon = param1.weapon;
         _loc2_.§_-DV§(Command.Up.name,false);
         _loc2_.§_-DV§(Command.Down.name,false);
         _loc2_.§_-DV§(Command.Jump.name,false);
         _loc2_.§_-DV§(Command.BackJump.name,false);
         _loc2_.§_-DV§(Command.Shift.name,false);
         _loc2_.§_-DV§(Command.Alt.name,_loc3_ is §_-O1c§);
         _loc2_.§_-01B§();
      }
      
      public static function §_-H33§(param1:§_-01J§) : void
      {
         var _loc2_:§_-G3J§ = param1.controlsMap;
         _loc2_.isActive = true;
         _loc2_.§_-A2D§(true);
         var _loc3_:Weapon = param1.weapon;
         _loc2_.§_-DV§(Command.Jump.name,false);
         _loc2_.§_-DV§(Command.BackJump.name,false);
         _loc2_.§_-DV§(Command.Shift.name,false);
         _loc2_.§_-DV§(Command.Shoot.name,true);
         _loc2_.§_-DV§(Command.Alt.name,_loc3_ is §_-O1c§);
         _loc2_.§_-01B§();
      }
      
      public static function §_-G3i§(param1:§_-01J§) : void
      {
         var _loc2_:§_-G3J§ = param1.controlsMap;
         _loc2_.isActive = true;
         _loc2_.§_-A2D§(true);
         var _loc3_:Weapon = param1.weapon;
         _loc2_.§_-DV§(Command.Up.name,false);
         _loc2_.§_-DV§(Command.Down.name,false);
         _loc2_.§_-DV§(Command.Jump.name,false);
         _loc2_.§_-DV§(Command.BackJump.name,false);
         _loc2_.§_-DV§(Command.Shift.name,false);
         _loc2_.§_-DV§(Command.Alt.name,_loc3_ is §_-O1c§);
         _loc2_.§_-01B§();
      }
      
      public static function §_-R1R§(param1:§_-01J§) : void
      {
         var _loc2_:§_-G3J§ = param1.controlsMap;
         _loc2_.isActive = true;
         _loc2_.§_-A2D§(true);
         var _loc3_:Weapon = param1.weapon;
         _loc2_.§_-DV§(Command.Up.name,§_-7u§(_loc3_.getProperty("resizable")).value);
         _loc2_.§_-DV§(Command.Down.name,§_-7u§(_loc3_.getProperty("resizable")).value);
         _loc2_.§_-DV§(Command.Jump.name,false);
         _loc2_.§_-DV§(Command.BackJump.name,false);
         _loc2_.§_-DV§(Command.Shift.name,false);
         _loc2_.§_-DV§(Command.Alt.name,_loc3_ is §_-O1c§);
         _loc2_.§_-01B§();
      }
      
      public static function §_-I21§(param1:§_-01J§) : void
      {
         var _loc2_:§_-G3J§ = param1.controlsMap;
         _loc2_.isActive = true;
         _loc2_.§_-A2D§(false);
         _loc2_.§_-DV§(Command.Shoot.name,true);
         _loc2_.§_-01B§();
      }
   }
}

