package §_-P2i§
{
   import §_-A1K§.§_-7u§;
   import §_-A1K§.§_-TA§;
   import §_-Y1b§.§_-OP§;
   import §_-hO§.§_-03k§;
   import §_-l1g§.§_-L3Q§;
   import §_-r1C§.§_-h2B§;
   import config.§_-vR§;
   import flash.geom.Point;
   import flash.utils.Dictionary;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.Command;
   import ru.pragmatix.wormix.messages.server.VerifyPaymentResult;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.§_-r1d§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-Qi§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.utils.FrameTimer;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.weapons.ammo.VerticalDrillMissile;
   import ru.pragmatix.wormix.weapons.ammo.VerticalDrillStanding;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.utils.Pool;
   
   public class §_-G3J§ extends EventDispatcher
   {
      
      private var §_-12S§:Dictionary;
      
      private var _isActive:Boolean;
      
      public function §_-G3J§()
      {
         super();
         this.§_-12S§ = new Dictionary();
         this._isActive = false;
      }
      
      public function §_-DV§(param1:String, param2:Boolean) : void
      {
         this.§_-12S§[param1] = param2;
      }
      
      public function §_-C26§(param1:String) : Boolean
      {
         return Boolean(this.§_-12S§[param1]);
      }
      
      public function §_-A2D§(param1:Boolean) : void
      {
         var _loc2_:Command = null;
         for each(_loc2_ in Command.all)
         {
            this.§_-12S§[_loc2_.name] = param1;
         }
      }
      
      public function get isActive() : Boolean
      {
         return this._isActive;
      }
      
      public function set isActive(param1:Boolean) : void
      {
         this._isActive = param1;
      }
      
      public function §_-01B§() : void
      {
         dispatchEventWith(§_-L3Q§.UNIT_CONTROL_CHANGED);
      }
   }
}

