package §_-nE§
{
   import §_-9e§.§_-A18§;
   import §_-Bv§.§_-G3P§;
   import §_-Ly§.§_-81L§;
   import §_-b1F§.§_-v2Q§;
   import §_-l1g§.§_-L3Q§;
   import §_-n1w§.*;
   import §_-r1C§.§_-h2B§;
   import §_-u13§.MD2;
   import §_-u13§.MD5;
   import §_-u13§.SHA1;
   import §_-u13§.§_-F3§;
   import com.greensock.events.LoaderEvent;
   import com.hurlant.util.der.Sequence;
   import com.hurlant.util.der.§_-cz§;
   import com.hurlant.util.der.§_-l1b§;
   import feathers.layout.AnchorLayout;
   import flash.events.Event;
   import flash.events.MouseEvent;
   import flash.events.TouchEvent;
   import flash.utils.ByteArray;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.model.items.craft.§_-6S§;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   
   public class InfoCraftWeaponScreen extends §_-i1A§
   {
      
      private var binder:Binder;
      
      public function InfoCraftWeaponScreen()
      {
         super();
         this.binder = new Binder();
         Application.uiBuilder.create(Application.assetManager.getObject("craft_weapon_info_screen"),true,this.binder);
      }
      
      override protected function initialize() : void
      {
         var _loc1_:Number = NaN;
         super.initialize();
         this.layout = new AnchorLayout();
         addChild(this.binder._panel);
         this.binder._panel.validate();
         _loc1_ = this.binder._textContainer.width;
         this.binder._description.width = _loc1_;
         this.binder._damage.width = _loc1_;
         this.binder._maxShots.width = _loc1_;
         this.binder._backButton.addEventListener(starling.events.Event.TRIGGERED,this.§_-52C§);
      }
      
      override public function dispose() : void
      {
         super.dispose();
         if(_isInitialized)
         {
            this.binder._backButton.removeEventListener(starling.events.Event.TRIGGERED,this.§_-52C§);
         }
      }
      
      override protected function draw() : void
      {
         super.draw();
         var _loc1_:§_-6S§ = §_-H2U§.data;
         if(_loc1_)
         {
            this.binder._title.text = §_-s2a§.§_-K3t§(_loc1_.weapon.getName());
            this.binder._description.text = _loc1_.weapon.§_-m1k§();
            if(_loc1_.weapon.§_-C33§())
            {
               this.binder._damage.text = §_-s2a§.§_-K3t§(§_-s2a§.DAMAGE) + ": " + §_-s2a§.§_-K3t§(_loc1_.weapon.§_-C33§());
            }
            else
            {
               this.binder._damage.text = "";
            }
            if(_loc1_.weapon.getMaxShots() > 0)
            {
               this.binder._maxShots.text = §_-s2a§.§_-K3t§(§_-s2a§.COUNT_LABEL) + ": " + _loc1_.weapon.getMaxShots() + " " + §_-s2a§.§_-K3t§(§_-s2a§.QUANTITY_PER_BATTLE);
            }
            else
            {
               this.binder._maxShots.text = §_-s2a§.§_-K3t§(§_-s2a§.COUNT_LABEL) + ": " + §_-s2a§.§_-K3t§(§_-s2a§.QUANTITY_INFINITY);
            }
            this.binder._textContainer.invalidate(INVALIDATION_FLAG_SIZE);
         }
      }
      
      private function §_-52C§(param1:starling.events.Event) : void
      {
         SelectCraftWeaponScreen.§_-m15§ = false;
         §_-h2B§.play(§_-81L§.§_-o1Z§);
         dispatchEventWith(starling.events.Event.CLOSE);
      }
   }
}

import feathers.controls.Label;
import feathers.controls.LayoutGroup;
import starlingbuilder.extensions.uicomponents.ContainerButtonWithStates;

class Binder
{
   
   public var _panel:LayoutGroup;
   
   public var _textContainer:LayoutGroup;
   
   public var _backButton:ContainerButtonWithStates;
   
   public var _title:Label;
   
   public var _description:Label;
   
   public var _damage:Label;
   
   public var _maxShots:Label;
   
   public function Binder()
   {
      super();
   }
}
