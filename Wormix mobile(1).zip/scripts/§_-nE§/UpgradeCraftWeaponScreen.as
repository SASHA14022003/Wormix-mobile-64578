package §_-nE§
{
   import §_-31N§.§_-42G§;
   import §_-31Y§.§_-D3B§;
   import §_-62§.§_-O2H§;
   import §_-9e§.*;
   import §_-Bv§.§_-G3P§;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-L1H§.§_-C3e§;
   import §_-Ly§.§_-81L§;
   import §_-b1F§.§_-G4§;
   import §_-gG§.§_-Z2z§;
   import §_-hO§.§_-BY§;
   import §_-kP§.*;
   import §_-l1g§.§_-L3Q§;
   import §_-lh§.§_-z2A§;
   import §_-n1w§.*;
   import §_-r1C§.§_-h2B§;
   import §_-u13§.MD2;
   import §_-u13§.MD5;
   import §_-u13§.SHA1;
   import §_-u13§.§_-F3§;
   import §_-y1s§.§_-A1I§;
   import §_-z1g§.§_-M2v§;
   import com.distriqt.extension.inappbilling.events.InAppBillingEvent;
   import com.hurlant.util.der.Sequence;
   import com.hurlant.util.der.§_-cz§;
   import com.hurlant.util.der.§_-l1b§;
   import feathers.controls.ScrollPolicy;
   import feathers.data.ListCollection;
   import feathers.events.FeathersEventType;
   import feathers.layout.AnchorLayout;
   import feathers.layout.AnchorLayoutData;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.HorizontalLayout;
   import flash.utils.ByteArray;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.game.ai.*;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.shop.§_-7D§;
   import ru.pragmatix.wormix.messages.structures.WeaponStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.items.craft.§_-13q§;
   import ru.pragmatix.wormix.model.items.craft.§_-6S§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.DamageType;
   import ru.pragmatix.wormix.weapons.ammo.LaserRay;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   
   public class UpgradeCraftWeaponScreen extends §_-i1A§
   {
      
      private var binder:Binder;
      
      private var §_-f2e§:UpgradeWeaponCell;
      
      private var §_-F2t§:int;
      
      public function UpgradeCraftWeaponScreen()
      {
         super();
         this.binder = new Binder();
         Application.uiBuilder.create(Application.assetManager.getObject("craft_weapon_upgrade_screen"),true,this.binder);
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         this.layout = new AnchorLayout();
         addChild(this.binder._panel);
         this.§_-f2e§ = new UpgradeWeaponCell();
         this.binder._weapon.addChild(this.§_-f2e§.getContainer());
         this.binder._ingridients.horizontalScrollPolicy = ScrollPolicy.OFF;
         this.binder._ingridients.verticalScrollPolicy = ScrollPolicy.OFF;
         var _loc1_:HorizontalLayout = new HorizontalLayout();
         _loc1_.horizontalAlign = HorizontalAlign.CENTER;
         _loc1_.gap = 10;
         this.binder._ingridients.layout = _loc1_;
         this.binder._ingridients.itemRendererType = §_-A1I§;
         this.binder._upgradeButton.setTextInSkins("label",§_-s2a§.§_-K3t§(§_-s2a§.COLLECT_FOR_REAGENT_BTN));
         this.binder._upgradeRubyButton.setTextInSkins("label",§_-s2a§.§_-K3t§(§_-s2a§.COLLECT_FOR_RUBY_BTN));
         this.binder._orLabel.text = §_-s2a§.§_-K3t§(§_-s2a§.PRICE_OR_LABEL);
         var _loc2_:AnchorLayoutData = new AnchorLayoutData(20);
         _loc2_.topAnchorDisplayObject = this.binder._center;
         this.binder._bottom.layoutData = _loc2_;
      }
      
      override public function dispose() : void
      {
         super.dispose();
         if(_isInitialized)
         {
            this.§_-f2e§.dispose();
         }
      }
      
      override protected function screen_addedToStageHandler(param1:Event) : void
      {
         super.screen_addedToStageHandler(param1);
         this.binder._backButton.addEventListener(Event.TRIGGERED,this.§_-52C§);
         this.binder._infoButton.addEventListener(Event.TRIGGERED,this.§_-A3L§);
         this.binder._upgradeButton.addEventListener(Event.TRIGGERED,this.§_-pZ§);
         this.binder._upgradeRubyButton.addEventListener(Event.TRIGGERED,this.§_-T1P§);
      }
      
      override protected function screen_removedFromStageHandler(param1:Event) : void
      {
         this.binder._backButton.removeEventListener(Event.TRIGGERED,this.§_-52C§);
         this.binder._infoButton.removeEventListener(Event.TRIGGERED,this.§_-A3L§);
         this.binder._upgradeButton.removeEventListener(Event.TRIGGERED,this.§_-pZ§);
         this.binder._upgradeRubyButton.removeEventListener(Event.TRIGGERED,this.§_-T1P§);
         super.screen_removedFromStageHandler(param1);
      }
      
      override protected function draw() : void
      {
         super.draw();
         §_-H2U§.§_-4f§ = §_-p16§.UPGRADE;
         var _loc1_:§_-6S§ = §_-H2U§.data;
         if(_loc1_)
         {
            if(this.§_-f2e§)
            {
               this.§_-f2e§.setItem(_loc1_);
               this.§_-f2e§.setState(§_-z2A§.AVAILABLE);
               this.§_-f2e§.§_-v12§(false);
               this.binder._ingridients.dataProvider = new ListCollection(_loc1_.§_-HS§.reagents);
            }
            this.binder._title.text = §_-s2a§.§_-K3t§(§_-s2a§.COLLECT_FOR_REAGENT_BTN) + ": " + §_-s2a§.§_-K3t§(_loc1_.weapon.getName());
            this.binder._title.invalidate();
            this.§_-F2t§ = §_-X1j§.§_-Y2W§.§_-L2D§(Application.§_-SH§.userProfile,_loc1_.§_-HS§);
            this.binder._upgradeRubyButton.setTextInSkins("price",this.§_-F2t§.toString());
            this.§_-I27§(this.§_-F2t§ <= 0);
         }
         if(SelectCraftWeaponScreen.§_-m15§)
         {
            dispatchEventWith(§_-p16§.INFO);
         }
      }
      
      private function §_-I27§(param1:Boolean) : void
      {
         this.binder._upgradeButton.enabled = param1;
         if(param1 && Boolean(this.binder._upgradeRubyButton.parent))
         {
            this.binder._upgradeRubyButton.removeFromParent();
            this.binder._orLabelContainer.removeFromParent();
         }
         else if(!param1 && !this.binder._upgradeRubyButton.parent)
         {
            this.binder._bottom.addChild(this.binder._orLabelContainer);
            this.binder._bottom.addChild(this.binder._upgradeRubyButton);
         }
      }
      
      private function §_-52C§(param1:Event) : void
      {
         SelectCraftWeaponScreen.§_-V1r§ = null;
         §_-h2B§.play(§_-81L§.§_-o1Z§);
         dispatchEventWith(§_-p16§.SELECT);
      }
      
      private function §_-A3L§(param1:Event) : void
      {
         SelectCraftWeaponScreen.§_-m15§ = true;
         §_-h2B§.play(§_-81L§.§_-o1Z§);
         dispatchEventWith(§_-p16§.INFO);
      }
      
      private function §_-pZ§(param1:Event) : void
      {
         §_-fH§.§_-q1a§(§_-s2a§.§_-K3t§(§_-s2a§.TITLE_CONFIRMATION),§_-s2a§.§_-K3t§("CONFIRMATION_COLLECT_TEXT"),§_-fH§.§_-X2g§,this.§_-A3A§);
      }
      
      private function §_-T1P§(param1:Event) : void
      {
         if(Application.userProfile.§_-o1N§() >= this.§_-F2t§)
         {
            §_-fH§.§_-q1a§(§_-s2a§.§_-K3t§(§_-s2a§.TITLE_CONFIRMATION),§_-s2a§.§_-K3t§("CONFIRMATION_COLLECT_FOR_RUBIES_TEXT"),§_-fH§.§_-X2g§,this.§_-A3A§);
         }
         else
         {
            new §_-7D§().show();
         }
      }
      
      private function §_-A3A§() : void
      {
         §_-J2l§.§_-u2b§.show(§_-X1j§.§_-Y2W§.§_-u11§,§_-H2U§.data,this.§_-F2t§,this.§_-KR§);
      }
      
      protected function §_-KR§(param1:Boolean) : void
      {
         §_-J2l§.§_-u2b§.hide();
         if(!param1)
         {
            §_-fH§.§_-h2r§(§_-s2a§.§_-K3t§(§_-s2a§.TITLE_ERROR),§_-s2a§.§_-K3t§(§_-s2a§.ERROR_SAVING));
         }
         SelectCraftWeaponScreen.§_-V1r§ = null;
         dispatchEventWith(§_-p16§.SELECT);
      }
   }
}

import feathers.controls.Label;
import feathers.controls.LayoutGroup;
import feathers.controls.List;
import starlingbuilder.extensions.uicomponents.ContainerButtonWithStates;

class Binder
{
   
   public var _panel:LayoutGroup;
   
   public var _weapon:LayoutGroup;
   
   public var _center:LayoutGroup;
   
   public var _bottom:LayoutGroup;
   
   public var _orLabelContainer:LayoutGroup;
   
   public var _backButton:ContainerButtonWithStates;
   
   public var _infoButton:ContainerButtonWithStates;
   
   public var _upgradeButton:ContainerButtonWithStates;
   
   public var _upgradeRubyButton:ContainerButtonWithStates;
   
   public var _title:Label;
   
   public var _orLabel:Label;
   
   public var _ingridients:List;
   
   public function Binder()
   {
      super();
   }
}
