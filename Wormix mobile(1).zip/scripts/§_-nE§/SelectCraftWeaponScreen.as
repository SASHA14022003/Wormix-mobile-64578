package §_-nE§
{
   import §_-22z§.§_-f1b§;
   import §_-51j§.*;
   import §_-62§.§_-O2H§;
   import §_-62§.§_-ou§;
   import §_-73d§.§_-V19§;
   import §_-73d§.§_-x2C§;
   import §_-A1K§.§_-TA§;
   import §_-C2M§.DesktopTutorialPanel;
   import §_-C2M§.MobileTutorialPanel;
   import §_-C2M§.§_-o2f§;
   import §_-CR§.§_-72p§;
   import §_-DJ§.§_-fH§;
   import §_-F39§.§_-Ey§;
   import §_-K35§.§_-99§;
   import §_-SP§.§_-M4§;
   import §_-TF§.§_-q1j§;
   import §_-Vg§.*;
   import §_-W§.§_-ix§;
   import §_-Y1O§.*;
   import §_-YF§.§_-q2v§;
   import §_-jF§.ClanMemberItemRenderer;
   import §_-jF§.§_-U17§;
   import §_-k1u§.§_-2m§;
   import §_-k1u§.§_-F3H§;
   import §_-k1u§.§_-Oi§;
   import §_-kP§.CraftTreePanel;
   import §_-l1K§.*;
   import §_-l1g§.§_-L3Q§;
   import §_-r1C§.§_-h2B§;
   import §_-u1P§.ShopResultEvent;
   import §_-w§.§_-63m§;
   import §_-y1s§.§_-O1z§;
   import §_-y1s§.§_-p6§;
   import feathers.controls.LayoutGroup;
   import feathers.controls.List;
   import feathers.controls.ScrollPolicy;
   import feathers.data.ArrayCollection;
   import feathers.data.ListCollection;
   import feathers.layout.AnchorLayout;
   import feathers.layout.AnchorLayoutData;
   import feathers.layout.Direction;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.HorizontalLayout;
   import feathers.layout.HorizontalLayoutData;
   import feathers.layout.RelativePosition;
   import feathers.layout.TiledColumnsLayout;
   import feathers.layout.VerticalAlign;
   import feathers.layout.VerticalLayout;
   import feathers.themes.styles.AlternateButtonsStyles;
   import flash.geom.Point;
   import flash.text.TextFormatAlign;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.sets.ControlSets;
   import ru.pragmatix.wormix.gui.§_-eP§;
   import ru.pragmatix.wormix.gui.§_-fT§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.screenOverlay.view.§_-B1m§;
   import ru.pragmatix.wormix.messages.clans.ClanServiceResult;
   import ru.pragmatix.wormix.messages.structures.WeaponStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.items.craft.§_-13q§;
   import ru.pragmatix.wormix.model.items.craft.§_-Y2u§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   import ru.pragmatix.wormix.objects.Direction;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.physics.Force;
   import ru.pragmatix.wormix.utils.§_-Cq§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.Bullet;
   import starling.display.DisplayObject;
   import starling.events.Event;
   import starling.utils.Color;
   import starling.utils.Pool;
   import starling.utils.SystemUtil;
   import starlingbuilder.extensions.uicomponents.CustomLabel;
   
   public class SelectCraftWeaponScreen extends §_-i1A§
   {
      
      public static var §_-V1r§:Object;
      
      private static var selectedIndex:int = 0;
      
      public static var §_-m15§:Boolean = false;
      
      private var §_-828§:CraftTreePanel;
      
      private var binder:Binder;
      
      public function SelectCraftWeaponScreen()
      {
         super();
         this.binder = new Binder();
         §_-YQ§.§_-qM§(§_-q2v§.§_-U2c§,§_-q2v§.§_-A2T§,this.binder);
         §_-X1j§.§_-zU§.addEventListener(ShopResultEvent.BUY_SUCCESS,this.§_-w2b§);
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         this.layout = new AnchorLayout();
         addChild(this.binder._panel);
         this.binder._panel.layoutData = new AnchorLayoutData(0,0,0,0);
         this.§_-828§ = new CraftTreePanel(this.binder._content);
         this.§_-828§.addEventListener(Event.SELECT,this.§_-9N§);
         this.§_-828§.addEventListener(CraftTreePanel.BUY_EVENT,this.§_-bQ§);
         this.initList();
         if(SystemUtil.isDesktop)
         {
            this.§_-Nh§();
         }
         else
         {
            this.§_-hm§();
         }
         if(§_-V1r§)
         {
            dispatchEventWith(§_-p16§.UPGRADE,false,§_-V1r§);
         }
      }
      
      private function initList() : void
      {
         var _loc1_:List = null;
         _loc1_ = this.binder._itemsList;
         _loc1_.itemRendererType = §_-p6§;
         _loc1_.dataProvider = new ListCollection(this.§_-w1S§());
         _loc1_.verticalScrollPolicy = ScrollPolicy.OFF;
         var _loc2_:HorizontalLayout = new HorizontalLayout();
         _loc2_.paddingTop = 17;
         _loc1_.layout = _loc2_;
         _loc1_.selectedIndex = selectedIndex;
         _loc1_.addEventListener(Event.CHANGE,this.§_-up§);
      }
      
      private function §_-Nh§() : void
      {
         (this.binder._itemsList.layout as HorizontalLayout).gap = 6;
         this.binder._prev.scaleWhenDown = 0.8;
         this.binder._next.scaleWhenDown = 0.8;
         this.binder._prev.useHandCursor = true;
         this.binder._next.useHandCursor = true;
         this.binder._prev.addEventListener(Event.TRIGGERED,this.§_-w11§);
         this.binder._next.addEventListener(Event.TRIGGERED,this.§_-m1u§);
      }
      
      private function §_-hm§() : void
      {
         this.binder._prev.removeFromParent(true);
         this.binder._next.removeFromParent(true);
         (this.binder._itemsList.layoutData as AnchorLayoutData).left = 10;
         (this.binder._itemsList.layoutData as AnchorLayoutData).right = 10;
      }
      
      private function §_-w11§(param1:Event) : void
      {
         --this.binder._itemsList.selectedIndex;
      }
      
      private function §_-m1u§(param1:Event) : void
      {
         ++this.binder._itemsList.selectedIndex;
      }
      
      private function §_-g2j§() : void
      {
         this.binder._itemsList.scrollToDisplayIndex(this.binder._itemsList.selectedIndex);
         this.§_-L36§();
      }
      
      private function §_-L36§() : void
      {
         this.binder._prev.isEnabled = this.binder._itemsList.selectedIndex != 0;
         this.binder._next.isEnabled = this.binder._itemsList.selectedIndex != this.binder._itemsList.dataProvider.length - 1;
      }
      
      override protected function draw() : void
      {
         super.draw();
         this.§_-up§();
      }
      
      private function §_-bQ§(param1:Event) : void
      {
         §_-X1j§.§_-zU§.§_-G3L§(this.§_-828§.§_-A39§);
      }
      
      private function §_-51q§() : void
      {
         var _loc1_:§_-O1z§ = null;
         var _loc2_:UserProfile = null;
         var _loc3_:§_-O2H§ = null;
         var _loc4_:int = 0;
         if(Boolean(this.binder) && Boolean(this.binder._itemsList))
         {
            _loc1_ = this.binder._itemsList.selectedItem as §_-O1z§;
            if(_loc1_)
            {
               _loc2_ = Application.§_-SH§.userProfile;
               _loc3_ = _loc1_.§_-l1u§.§_-A39§;
               _loc1_.§_-I1O§ = §_-Cq§.§_-33I§(_loc3_.getId(),_loc2_);
               _loc4_ = this.binder._itemsList.selectedIndex;
               this.binder._itemsList.dataProvider.updateItemAt(_loc4_);
               this.§_-828§.§_-u2§(_loc1_.§_-l1u§);
            }
         }
      }
      
      private function §_-9N§(param1:Event) : void
      {
         §_-V1r§ = param1.data;
         dispatchEventWith(§_-p16§.UPGRADE,false,param1.data);
      }
      
      public function §_-up§(param1:Event = null) : void
      {
         if(this.binder._itemsList.selectedItem == null)
         {
            return;
         }
         selectedIndex = this.binder._itemsList.selectedIndex;
         §_-H2U§.selectedIndex = this.binder._itemsList.selectedIndex;
         var _loc2_:§_-O1z§ = this.binder._itemsList.selectedItem as §_-O1z§;
         if(_loc2_)
         {
            this.§_-828§.§_-u2§(_loc2_.§_-l1u§);
            this.§_-g2j§();
         }
      }
      
      private function §_-w1S§() : Array
      {
         var _loc1_:§_-13q§ = null;
         var _loc3_:UserProfile = null;
         var _loc4_:Array = null;
         var _loc5_:§_-O2H§ = null;
         var _loc2_:Array = [];
         for each(_loc1_ in §_-Y2u§.§_-22E§())
         {
            if(_loc1_.§_-A39§.§_-92P§())
            {
               _loc2_.push(_loc1_);
            }
         }
         _loc2_.sort(§_-ou§.§_-X1B§);
         _loc3_ = Application.§_-SH§.userProfile;
         _loc4_ = [];
         for each(_loc1_ in _loc2_)
         {
            _loc5_ = _loc1_.§_-A39§;
            if(_loc5_.§_-92P§())
            {
               _loc4_.push(new §_-O1z§(_loc1_,§_-Cq§.§_-33I§(_loc5_.getId(),_loc3_)));
            }
         }
         return _loc4_;
      }
      
      override public function dispose() : void
      {
         this.§_-828§.removeEventListener(Event.SELECT,this.§_-9N§);
         this.§_-828§.removeEventListener(CraftTreePanel.BUY_EVENT,this.§_-bQ§);
         this.§_-828§.dispose();
         this.binder._itemsList.removeEventListener(Event.CHANGE,this.§_-up§);
         §_-H2U§.§_-km§ = this.binder._itemsList.horizontalScrollPosition;
         §_-X1j§.§_-zU§.removeEventListener(ShopResultEvent.BUY_SUCCESS,this.§_-w2b§);
         super.dispose();
      }
      
      private function §_-w2b§(param1:Event) : void
      {
         this.§_-51q§();
      }
   }
}

import feathers.controls.Button;
import feathers.controls.LayoutGroup;
import feathers.controls.List;

class Binder
{
   
   public var _panel:LayoutGroup;
   
   public var _content:LayoutGroup;
   
   public var _prev:Button;
   
   public var _next:Button;
   
   public var _itemsList:List;
   
   public function Binder()
   {
      super();
   }
}
