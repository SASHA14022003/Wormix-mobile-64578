package §_-nE§
{
   import §_-31W§.AchievLevelUpMessage;
   import §_-31W§.§_-8§;
   import §_-31W§.§_-c2J§;
   import §_-DJ§.§_-T2G§;
   import §_-N8§.§_-o2w§;
   import §_-r1C§.§_-h2B§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controller.analytics.Analytics;
   import ru.pragmatix.wormix.model.§_-d27§;
   import starling.core.Starling;
   import starling.display.Stage;
   import starling.events.Event;
   
   public class §_-p16§
   {
      
      public static const SELECT:String = "SELECT";
      
      public static const UPGRADE:String = "UPGRADE";
      
      public static const DOWNGRADE:String = "DOWNGRADE";
      
      public static const INFO:String = "INFO";
      
      public function §_-p16§()
      {
         super();
      }
   }
}

