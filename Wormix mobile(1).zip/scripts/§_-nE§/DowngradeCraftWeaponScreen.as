package §_-nE§
{
   import §_-63U§.§_-21K§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-Ly§.§_-81L§;
   import §_-Vg§.§_-M11§;
   import §_-Y1b§.§_-OP§;
   import §_-ZP§.§_-YG§;
   import §_-kP§.UpgradeWeaponCell;
   import §_-lh§.§_-z2A§;
   import §_-r1C§.§_-h2B§;
   import §_-y1s§.§_-g2p§;
   import com.distriqt.extension.inappbilling.Purchase;
   import com.greensock.events.LoaderEvent;
   import com.greensock.loading.core.*;
   import feathers.controls.ScrollPolicy;
   import feathers.controls.text.TextFieldTextRenderer;
   import feathers.controls.text.TextInstanceCreator;
   import feathers.data.ListCollection;
   import feathers.layout.AnchorLayout;
   import feathers.layout.AnchorLayoutData;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.HorizontalLayout;
   import feathers.themes.FontSize;
   import flash.display.DisplayObject;
   import flash.errors.IllegalOperationError;
   import flash.events.Event;
   import flash.text.TextFormatAlign;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import flash.utils.getQualifiedClassName;
   import ru.pragmatix.flox.social.model.PaymentOption;
   import ru.pragmatix.wormix.controller.§_-J2d§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.shop.§_-7D§;
   import ru.pragmatix.wormix.messages.server.VerifyPaymentResult;
   import ru.pragmatix.wormix.model.items.craft.§_-6S§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.utils.MathUtil;
   import starling.events.Event;
   import starling.utils.ScaleMode;
   
   public class DowngradeCraftWeaponScreen extends §_-i1A§
   {
      
      private var binder:Binder;
      
      private var §_-f2e§:UpgradeWeaponCell;
      
      public function DowngradeCraftWeaponScreen()
      {
         super();
         this.binder = new Binder();
         Application.uiBuilder.create(Application.assetManager.getObject("craft_weapon_downgrade_screen"),true,this.binder);
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         this.layout = new AnchorLayout();
         addChild(this.binder._panel);
         this.§_-f2e§ = new UpgradeWeaponCell();
         this.binder._weapon.addChild(this.§_-f2e§.getContainer());
         this.binder._ingridients.horizontalScrollPolicy = ScrollPolicy.OFF;
         this.binder._ingridients.verticalScrollPolicy = ScrollPolicy.OFF;
         var _loc1_:HorizontalLayout = new HorizontalLayout();
         _loc1_.horizontalAlign = HorizontalAlign.CENTER;
         _loc1_.gap = 10;
         this.binder._ingridients.layout = _loc1_;
         this.binder._ingridients.itemRendererType = §_-g2p§;
         this.binder._ingridients.dataProvider = new ListCollection();
         this.binder._downgradeRubyButton.setTextInSkins("label",§_-s2a§.§_-K3t§(§_-s2a§.DOWNGRADE_BTN2));
         this.binder._downgradeRubyButton.setTextInSkins("price",§_-J2d§.§_-73s§.value.toString());
         this.binder._orLabel.text = §_-s2a§.§_-K3t§(§_-s2a§.PRICE_OR_LABEL);
         this.binder._adsButton.label = §_-s2a§.§_-K3t§(§_-s2a§.FREE_LABEL);
         var _loc2_:AnchorLayoutData = new AnchorLayoutData(20);
         _loc2_.topAnchorDisplayObject = this.binder._center;
         this.binder._bottom.layoutData = _loc2_;
      }
      
      override public function dispose() : void
      {
         super.dispose();
         if(_isInitialized)
         {
            this.§_-f2e§.dispose();
         }
      }
      
      override protected function screen_addedToStageHandler(param1:starling.events.Event) : void
      {
         super.screen_addedToStageHandler(param1);
         this.binder._backButton.addEventListener(starling.events.Event.TRIGGERED,this.§_-52C§);
         this.binder._infoButton.addEventListener(starling.events.Event.TRIGGERED,this.§_-A3L§);
         this.binder._downgradeRubyButton.addEventListener(starling.events.Event.TRIGGERED,this.§_-V2A§);
      }
      
      override protected function screen_removedFromStageHandler(param1:starling.events.Event) : void
      {
         this.binder._backButton.removeEventListener(starling.events.Event.TRIGGERED,this.§_-52C§);
         this.binder._infoButton.removeEventListener(starling.events.Event.TRIGGERED,this.§_-A3L§);
         this.binder._downgradeRubyButton.removeEventListener(starling.events.Event.TRIGGERED,this.§_-V2A§);
         super.screen_removedFromStageHandler(param1);
      }
      
      override protected function draw() : void
      {
         super.draw();
         §_-H2U§.§_-4f§ = §_-p16§.DOWNGRADE;
         var _loc1_:§_-6S§ = §_-H2U§.data;
         if(_loc1_)
         {
            if(this.§_-f2e§)
            {
               this.§_-f2e§.setItem(_loc1_);
               this.§_-f2e§.setState(§_-z2A§.AVAILABLE);
               this.§_-f2e§.§_-v12§(false);
               (this.binder._ingridients.dataProvider as ListCollection).data = _loc1_.§_-HS§.reagents;
            }
            this.binder._title.text = §_-s2a§.§_-K3t§(§_-s2a§.DOWNGRADE_TITLE) + ": " + §_-s2a§.§_-K3t§(_loc1_.weapon.getName());
            this.§_-I27§(true);
         }
         if(SelectCraftWeaponScreen.§_-m15§)
         {
            dispatchEventWith(§_-p16§.INFO);
         }
      }
      
      private function §_-I27§(param1:Boolean) : void
      {
         this.binder._adsButton.isEnabled = !param1;
         if(param1 && Boolean(this.binder._adsButton.parent))
         {
            this.binder._adsButton.removeFromParent();
            this.binder._orLabelContainer.removeFromParent();
         }
         else if(!param1 && !this.binder._adsButton.parent)
         {
            this.binder._bottom.addChild(this.binder._orLabelContainer);
            this.binder._bottom.addChild(this.binder._adsButton);
         }
      }
      
      private function §_-52C§(param1:starling.events.Event) : void
      {
         SelectCraftWeaponScreen.§_-V1r§ = null;
         §_-h2B§.play(§_-81L§.§_-o1Z§);
         dispatchEventWith(§_-p16§.SELECT);
      }
      
      private function §_-A3L§(param1:starling.events.Event) : void
      {
         SelectCraftWeaponScreen.§_-m15§ = true;
         §_-h2B§.play(§_-81L§.§_-o1Z§);
         dispatchEventWith(§_-p16§.INFO);
      }
      
      private function §_-V2A§(param1:starling.events.Event) : void
      {
         if(Application.userProfile.§_-o1N§() >= §_-J2d§.§_-73s§.value)
         {
            §_-fH§.§_-q1a§(§_-s2a§.§_-K3t§(§_-s2a§.TITLE_CONFIRMATION),§_-s2a§.§_-K3t§(§_-s2a§.CONFIRMATION_DOWNGRADE_TEXT),§_-fH§.§_-X2g§,this.§_-A3A§);
         }
         else
         {
            new §_-7D§().show();
         }
      }
      
      private function §_-A3A§() : void
      {
         §_-J2l§.§_-u2b§.show(§_-X1j§.§_-Y2W§.§_-n27§,§_-H2U§.data,this.§_-KR§);
      }
      
      protected function §_-KR§(param1:Boolean) : void
      {
         §_-J2l§.§_-u2b§.hide();
         if(!param1)
         {
            §_-fH§.§_-h2r§(§_-s2a§.§_-K3t§(§_-s2a§.TITLE_ERROR),§_-s2a§.§_-K3t§(§_-s2a§.ERROR_SAVING));
         }
         dispatchEventWith(§_-p16§.SELECT);
      }
   }
}

import feathers.controls.Button;
import feathers.controls.Label;
import feathers.controls.LayoutGroup;
import feathers.controls.List;
import starlingbuilder.extensions.uicomponents.ContainerButtonWithStates;

class Binder
{
   
   public var _panel:LayoutGroup;
   
   public var _weapon:LayoutGroup;
   
   public var _center:LayoutGroup;
   
   public var _bottom:LayoutGroup;
   
   public var _orLabelContainer:LayoutGroup;
   
   public var _backButton:ContainerButtonWithStates;
   
   public var _infoButton:ContainerButtonWithStates;
   
   public var _downgradeRubyButton:ContainerButtonWithStates;
   
   public var _adsButton:Button;
   
   public var _title:Label;
   
   public var _orLabel:Label;
   
   public var _ingridients:List;
   
   public function Binder()
   {
      super();
   }
}
