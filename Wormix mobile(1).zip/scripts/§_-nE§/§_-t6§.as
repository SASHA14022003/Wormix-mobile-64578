package §_-nE§
{
   import ru.pragmatix.wormix.model.items.craft.§_-6S§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import starling.events.Event;
   
   public class §_-t6§
   {
      
      public var selectedIndex:int;
      
      public var data:§_-6S§;
      
      public var §_-4f§:String;
      
      public var §_-km§:Number = 0;
      
      public var userProfile:UserProfile;
      
      public function §_-t6§()
      {
         super();
      }
   }
}

