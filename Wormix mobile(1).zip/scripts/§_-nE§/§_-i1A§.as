package §_-nE§
{
   import §_-F39§.§_-a2W§;
   import §_-Y1b§.§_-OP§;
   import feathers.controls.Screen;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.weapons.ammo.type.blocker.HealBlocker;
   
   public class §_-i1A§ extends Screen
   {
      
      protected var §_-H2U§:§_-t6§;
      
      public function §_-i1A§()
      {
         super();
      }
      
      public function get currentUpgradeData() : §_-t6§
      {
         return this.§_-H2U§;
      }
      
      public function set currentUpgradeData(param1:§_-t6§) : void
      {
         this.§_-H2U§ = param1;
         this.invalidate(INVALIDATION_FLAG_DATA);
      }
   }
}

