package §_-Ty§
{
   import §_-21A§.ChooseFriendForBossMenu;
   import §_-B2z§.§_-63i§;
   import §_-C3f§.§_-4I§;
   import §_-CF§.§_-E19§;
   import §_-D3A§.§_-TZ§;
   import §_-E1Z§.§_-E2i§;
   import §_-F39§.*;
   import §_-RE§.§_-52p§;
   import §_-RE§.§_-qW§;
   import §_-Tm§.§_-RF§;
   import §_-b1R§.§_-81E§;
   import §_-l1g§.§_-L3Q§;
   import §_-x2Q§.§_-dU§;
   import feathers.controls.Button;
   import feathers.controls.List;
   import feathers.core.FeathersControl;
   import feathers.core.ITextRenderer;
   import feathers.data.ListCollection;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.game.§_-eX§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.structures.HeroicMissionStructure;
   import ru.pragmatix.wormix.model.rewards.§_-P2q§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.utils.StringUtil;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   import starlingbuilder.extensions.uicomponents.ContainerButtonWithStates;
   
   public class §_-Z2E§ extends §_-1R§
   {
      
      private var playBtn:Button;
      
      private var §_-n2D§:List;
      
      private var structure:HeroicMissionStructure;
      
      private var §_-jz§:ChooseFriendForBossMenu;
      
      public function §_-Z2E§(param1:DisplayObject = null)
      {
         super(param1);
         this.§_-n2D§ = this.§_-i1o§(getChildByName("awardPanel") as DisplayObjectContainer);
      }
      
      private function §_-i1o§(param1:DisplayObjectContainer) : List
      {
         var _loc2_:List = null;
         _loc2_ = new §_-E2i§();
         param1.touchable = true;
         _loc2_.touchable = true;
         param1.addChild(_loc2_);
         _loc2_.width = param1.width / param1.scaleX;
         _loc2_.height = param1.height;
         return _loc2_;
      }
      
      override protected function initButtons() : void
      {
         this.playBtn = getChildByName("playBtn") as Button;
         this.playBtn.label = §_-s2a§.§_-K3t§(§_-s2a§.BATTLE_BOSS_BTN);
         this.playBtn.addEventListener(Event.TRIGGERED,this.§_-U2n§);
      }
      
      private function §_-U2n§(param1:Event) : void
      {
         §_-81E§.§_-S7§(this.structure,§_-X1j§.§_-A24§.§_-mV§);
      }
      
      override public function §_-X2n§(param1:§_-52p§) : void
      {
         super.§_-X2n§(param1);
         var _loc2_:int = int(§_-52p§.§_-g2U§().indexOf(param1));
         this.structure = §_-qW§.getInstance().§_-L1D§(_loc2_);
         (getChildByName("bossName") as ITextRenderer).text = §_-cK§(this.structure.bossId1) + " & " + §_-cK§(this.structure.bossId2);
         (getChildByName("description") as Object).text = §_-s2a§.§_-K3t§(§_-s2a§.AVAILABLE_PANEL_DESCRIPTION);
         var _loc3_:§_-P2q§ = param1.§_-4z§();
         var _loc4_:Array = _loc3_.§_-q1L§();
         this.§_-n2D§.dataProvider = new ListCollection(_loc4_);
         this.§_-n2D§.invalidate(FeathersControl.INVALIDATION_FLAG_DATA);
      }
      
      override public function dispose() : void
      {
         if(this.playBtn)
         {
            this.playBtn.removeEventListener(Event.TRIGGERED,this.§_-U2n§);
            this.playBtn.dispose();
            this.playBtn = null;
         }
         if(this.§_-n2D§)
         {
            this.§_-n2D§.dispose();
            this.§_-n2D§ = null;
         }
         super.dispose();
      }
   }
}

