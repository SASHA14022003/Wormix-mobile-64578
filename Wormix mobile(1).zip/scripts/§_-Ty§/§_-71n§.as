package §_-Ty§
{
   import §_-62§.§_-O2H§;
   import §_-DJ§.§_-fH§;
   import §_-RE§.§_-52p§;
   import §_-RE§.§_-qW§;
   import §_-RE§.§_-r2q§;
   import §_-Z1K§.§_-q24§;
   import §_-k1u§.§_-Oi§;
   import §_-l1g§.§_-T2N§;
   import §_-u1P§.ShopResultEvent;
   import feathers.core.ITextRenderer;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.structures.HeroicMissionStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.utils.§_-Cq§;
   import ru.pragmatix.wormix.weapons.Weapon;
   import starling.display.DisplayObject;
   
   public class §_-71n§ extends §_-1R§
   {
      
      public function §_-71n§(param1:DisplayObject = null)
      {
         super(param1);
      }
      
      override public function §_-X2n§(param1:§_-52p§) : void
      {
         super.§_-X2n§(param1);
         var _loc2_:String = "";
         var _loc3_:int = int(§_-52p§.§_-g2U§().indexOf(param1));
         var _loc4_:HeroicMissionStructure = §_-qW§.getInstance().§_-L1D§(_loc3_);
         if(!§_-r2q§.§_-Q2p§(_loc4_.bossId1))
         {
            _loc2_ += §_-cK§(_loc4_.bossId1);
         }
         if(!§_-r2q§.§_-Q2p§(_loc4_.bossId2))
         {
            _loc2_ += (_loc2_ != "" ? ", " : "") + §_-cK§(_loc4_.bossId2);
         }
         (getChildByName("title") as ITextRenderer).text = §_-s2a§.§_-K3t§(§_-s2a§.UNAVAILABLE_PANEL_TITLE);
         (getChildByName("description1") as ITextRenderer).text = §_-s2a§.§_-K3t§(§_-s2a§.UNAVAILABLE_PANEL_DESCRIPTION_1);
         (getChildByName("description2") as ITextRenderer).text = §_-s2a§.§_-K3t§(§_-s2a§.UNAVAILABLE_PANEL_DESCRIPTION_2) + " " + _loc2_;
      }
   }
}

