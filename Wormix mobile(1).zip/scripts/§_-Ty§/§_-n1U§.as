package §_-Ty§
{
   import §_-5Y§.§_-h2c§;
   import §_-DJ§.§_-J2l§;
   import §_-G2H§.*;
   import §_-L2F§.§_-D2p§;
   import §_-l1K§.§_-W2f§;
   import §_-sQ§.§_-H3D§;
   import com.distriqt.extension.inappbilling.Product;
   import com.distriqt.extension.inappbilling.SubscriptionOffer;
   import com.distriqt.extension.inappbilling.SubscriptionPhase;
   import com.distriqt.extension.inappbilling.events.ProductEvent;
   import feathers.core.ITextRenderer;
   import flash.errors.IllegalOperationError;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.EffectType;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.HitTest;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.utils.§_-F2L§;
   import ru.pragmatix.wormix.weapons.ammo.GuardingBot;
   import starling.display.DisplayObject;
   import starling.events.Event;
   
   public class §_-n1U§ extends §_-K3a§
   {
      
      public function §_-n1U§(param1:DisplayObject = null)
      {
         super(param1);
      }
      
      override public function §_-X2n§(param1:§_-D2p§) : void
      {
         super.§_-X2n§(param1);
         (getChildByName("bossName") as ITextRenderer).text = §_-s2a§.§_-K3t§(§_-s2a§.LEVEL_NOT_APPROPRIATE_PANEL_NAME);
         (getChildByName("description") as ITextRenderer).text = §_-s2a§.§_-K3t§(§_-s2a§.LEVEL_NOT_APPROPRIATE_PANEL_DESCR);
         (getChildByName("requiredLevel") as ITextRenderer).text = §_-s2a§.§_-K3t§(§_-s2a§.BOSS_UNAVAILABLE_REQUIRED_LEVEL);
         (getChildByName("requiredLevelText") as ITextRenderer).text = §_-s2a§.§_-K3t§(§_-s2a§.BOSS_UNAVAILABLE_REQUIRED_LEVEL_TEXT);
         (getChildByName("requiredLevelValue") as ITextRenderer).text = String(param1.§_-eH§());
      }
   }
}

