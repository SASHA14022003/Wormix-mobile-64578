package §_-Ty§
{
   import §_-L2F§.§_-D2p§;
   import §_-T2V§.§_-13F§;
   import §_-r1C§.§_-h2B§;
   import §_-rM§.§_-61j§;
   import com.distriqt.extension.cloudstorage.events.KeyValueStoreEvent;
   import flash.geom.Point;
   import flash.utils.IDataInput;
   import ru.pragmatix.flox.serialization.§_-616§;
   import ru.pragmatix.flox.social.utils.id.UserIdType;
   import ru.pragmatix.wormix.gui.§_-E2w§;
   import ru.pragmatix.wormix.messages.server.ProfilesResult;
   import ru.pragmatix.wormix.messages.structures.UserProfileStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.physics.HitTest;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.serialization.server.*;
   import ru.pragmatix.wormix.weapons.*;
   import starling.display.DisplayObject;
   
   public class §_-K3a§ extends §_-E2w§
   {
      
      protected var §_-jh§:§_-D2p§;
      
      public function §_-K3a§(param1:DisplayObject = null)
      {
         super(param1);
         this.initButtons();
      }
      
      public function §_-X2n§(param1:§_-D2p§) : void
      {
         if(param1 == null)
         {
            return;
         }
         this.§_-jh§ = param1;
      }
      
      protected function initButtons() : void
      {
      }
   }
}

