package §_-Ty§
{
   import §_-5Y§.§_-h2c§;
   import §_-62§.§_-gr§;
   import §_-73I§.§_-q15§;
   import §_-G2H§.*;
   import §_-L2F§.§_-D2p§;
   import §_-Nq§.*;
   import §_-RE§.§_-52p§;
   import §_-TF§.§_-q1j§;
   import §_-Vg§.*;
   import §_-Z1K§.§_-q24§;
   import §_-l1K§.§_-W2f§;
   import §_-l1g§.§_-L3Q§;
   import §_-sQ§.§_-H3D§;
   import com.distriqt.extension.inappbilling.Product;
   import com.distriqt.extension.inappbilling.SubscriptionOffer;
   import com.distriqt.extension.inappbilling.SubscriptionPhase;
   import com.distriqt.extension.inappbilling.events.ProductEvent;
   import feathers.core.ITextRenderer;
   import feathers.layout.RelativePosition;
   import flash.geom.Rectangle;
   import flash.text.TextFormat;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fonts.BitmapFonts;
   import ru.pragmatix.wormix.gui.§_-E2w§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.request.PostToClanChatRequest;
   import ru.pragmatix.wormix.messages.clans.structures.ClanMemberTO;
   import ru.pragmatix.wormix.messages.structures.RatingProfileStructure;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.HitTest;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.§_-F2L§;
   import ru.pragmatix.wormix.utils.§_-R2g§;
   import starling.display.DisplayObject;
   import starling.display.Quad;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.utils.Pool;
   import starling.utils.RectangleUtil;
   import starling.utils.ScaleMode;
   
   public class §_-1R§ extends §_-E2w§
   {
      
      protected var §_-k1T§:§_-52p§;
      
      public function §_-1R§(param1:DisplayObject = null)
      {
         super(param1);
         this.initButtons();
      }
      
      public static function §_-cK§(param1:int) : String
      {
         var _loc2_:§_-D2p§ = §_-N1V§.§_-I39§.§_-X1P§().§_-7k§(param1);
         return _loc2_ ? §_-s2a§.§_-K3t§(_loc2_.getName()) : "";
      }
      
      public function §_-X2n§(param1:§_-52p§) : void
      {
         if(param1 == null)
         {
            return;
         }
         this.§_-k1T§ = param1;
      }
      
      protected function initButtons() : void
      {
      }
      
      override public function dispose() : void
      {
         this.§_-k1T§ = null;
         super.dispose();
      }
   }
}

