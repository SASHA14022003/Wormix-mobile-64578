package §_-Ty§
{
   import §_-12a§.§_-6p§;
   import §_-DJ§.§_-fH§;
   import §_-L2F§.§_-D2p§;
   import §_-P1z§.*;
   import §_-RE§.§_-D3v§;
   import §_-RE§.§_-r2q§;
   import §_-S§.*;
   import §_-Y1O§.§_-V23§;
   import §_-Y1O§.§_-y1o§;
   import §_-Y1b§.§_-81l§;
   import §_-Y1b§.§_-OP§;
   import §_-j1w§.§_-L1x§;
   import §_-l1g§.§_-L3Q§;
   import §_-r1C§.§_-h2B§;
   import §_-w2i§.§_-Zd§;
   import feathers.controls.Button;
   import feathers.controls.NumericStepper;
   import feathers.core.ITextRenderer;
   import flash.geom.Point;
   import flash.text.TextFormatAlign;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.game.§_-eX§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.shop.§_-7D§;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.utils.§_-72u§;
   import ru.pragmatix.wormix.utils.§_-R2g§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.weapons.PushingMineWeapon;
   import ru.pragmatix.wormix.weapons.SwitchTurn;
   import ru.pragmatix.wormix.weapons.Weapon;
   import ru.pragmatix.wormix.weapons.§_-73v§;
   import starling.display.DisplayObject;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   
   public class §_-o1U§ extends §_-K3a§
   {
      
      private var §_-l1W§:Button;
      
      public function §_-o1U§(param1:DisplayObject = null)
      {
         super(param1);
         param1.touchable = true;
      }
      
      override protected function initButtons() : void
      {
         this.§_-l1W§ = getChildByName("unlockBossBtn") as Button;
         §_-YQ§.§_-z2y§(this.§_-l1W§,§_-s2a§.UNLOCK_BOSS_TEXT);
         this.§_-l1W§.addEventListener(Event.TRIGGERED,this.§_-93h§);
      }
      
      override public function §_-X2n§(param1:§_-D2p§) : void
      {
         super.§_-X2n§(param1);
         §_-YQ§.§_-z2y§(this.§_-l1W§,String(this.§_-ED§()),"price",false);
         (getChildByName("title") as ITextRenderer).text = §_-s2a§.§_-K3t§(param1.getName());
         var _loc2_:ITextRenderer = getChildByName("description") as ITextRenderer;
         _loc2_.text = §_-s2a§.§_-K3t§(§_-s2a§.§_-3g§);
         §_-R2g§.§_-1c§(_loc2_,TextFormatAlign.CENTER);
      }
      
      private function §_-ED§() : int
      {
         var _loc1_:int = §_-jh§.getId();
         var _loc2_:§_-D3v§ = §_-r2q§.§_-r9§(_loc1_);
         return §_-D3v§.§_-C1q§ * (_loc1_ - _loc2_.§_-I3b§() - 1);
      }
      
      private function §_-93h§(param1:Event) : void
      {
         var _loc3_:§_-fH§ = null;
         var _loc2_:uint = uint(this.§_-ED§());
         if(Application.userProfile.§_-o1N§() < _loc2_)
         {
            _loc3_ = new §_-7D§();
         }
         else
         {
            _loc3_ = new §_-SC§(§_-jh§.getId(),_loc2_);
         }
         _loc3_.show();
      }
      
      override public function dispose() : void
      {
         if(this.§_-l1W§)
         {
            this.§_-l1W§.removeEventListener(Event.TRIGGERED,this.§_-93h§);
            this.§_-l1W§.dispose();
            this.§_-l1W§ = null;
         }
         super.dispose();
      }
   }
}

