package §_-Ty§
{
   import §_-RE§.§_-52p§;
   import §_-U1i§.§_-O2i§;
   import §_-l1K§.*;
   import §_-x2Q§.§_-dU§;
   import feathers.core.ITextRenderer;
   import flash.text.TextFormatAlign;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.utils.§_-R2g§;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.type.grenade.cluster.*;
   import starling.display.DisplayObject;
   import starling.events.Event;
   
   public class §_-Jb§ extends §_-1R§
   {
      
      public function §_-Jb§(param1:DisplayObject = null)
      {
         super(param1);
         param1.touchable = true;
      }
      
      override public function §_-X2n§(param1:§_-52p§) : void
      {
         super.§_-X2n§(param1);
         var _loc2_:ITextRenderer = getChildByName("description") as ITextRenderer;
         _loc2_.text = §_-s2a§.§_-K3t§(§_-s2a§.§_-3g§);
         §_-R2g§.§_-1c§(_loc2_,TextFormatAlign.CENTER);
      }
      
      override public function dispose() : void
      {
         super.dispose();
      }
   }
}

