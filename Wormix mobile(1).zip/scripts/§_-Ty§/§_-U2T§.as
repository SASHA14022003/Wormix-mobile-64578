package §_-Ty§
{
   import §_-L2F§.§_-D2p§;
   import §_-Y1b§.§_-OP§;
   import §_-rM§.§_-61j§;
   import feathers.core.ITextRenderer;
   import flash.utils.IDataInput;
   import ru.pragmatix.flox.serialization.§_-616§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.game.§_-eX§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.structures.ClanChatMessageTO;
   import ru.pragmatix.wormix.messages.server.BuyVipResult;
   import ru.pragmatix.wormix.messages.structures.RentedItemsStructure;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.utils.MathUtil;
   import starling.display.DisplayObject;
   import starling.events.Event;
   
   public class §_-U2T§ extends §_-K3a§
   {
      
      public function §_-U2T§(param1:DisplayObject = null)
      {
         super(param1);
      }
      
      override public function §_-X2n§(param1:§_-D2p§) : void
      {
         super.§_-X2n§(param1);
         (getChildByName("namePanel") as ITextRenderer).text = §_-s2a§.§_-K3t§(§_-s2a§.ONE_DAY_PANEL_NAME);
         (getChildByName("descrPanel") as ITextRenderer).text = §_-s2a§.§_-K3t§(§_-s2a§.ONE_DAY_PANEL_DESCR);
         (getChildByName("returnTomorrow") as ITextRenderer).text = §_-s2a§.§_-K3t§(§_-s2a§.ONE_DAY_PANEL_RETURN_TOMORROW);
      }
   }
}

