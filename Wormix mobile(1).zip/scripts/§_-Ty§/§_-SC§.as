package §_-Ty§
{
   import §_-62§.§_-O2H§;
   import §_-73d§.§_-w1O§;
   import §_-CF§.§_-E19§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-RE§.§_-D3v§;
   import §_-RE§.§_-r2q§;
   import §_-Z1K§.§_-q24§;
   import §_-k1u§.§_-Oi§;
   import §_-l1g§.§_-T2N§;
   import §_-r1C§.§_-h2B§;
   import §_-u1P§.ShopResultEvent;
   import §_-w2W§.§_-21w§;
   import com.distriqt.extension.inappbilling.InAppBilling;
   import com.distriqt.extension.inappbilling.Purchase;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.Direction;
   import ru.pragmatix.wormix.utils.§_-Cq§;
   import ru.pragmatix.wormix.weapons.Weapon;
   
   public class §_-SC§ extends §_-fH§
   {
      
      private var §_-B3d§:int;
      
      private var price:uint;
      
      public function §_-SC§(param1:int, param2:uint)
      {
         super(§_-s2a§.§_-K3t§(§_-s2a§.TITLE_CONFIRMATION),§_-s2a§.§_-K3t§(§_-s2a§.UNLOCK_BOSS_PANEL_TEXT),§_-fH§.§_-X2g§,null);
         this.§_-B3d§ = param1;
         this.price = param2;
         destroyOnRemove = true;
         §_-F11§ = null;
         soundOnShow = §_-d27§.§_-md§;
      }
      
      override protected function §_-b1H§() : void
      {
         §_-J2l§.§_-R25§.show(§_-X1j§.§_-02s§.§_-b15§,this.§_-B3d§,§_-E19§.§_-51D§,this.price,this.§_-O2Y§);
         hide();
      }
      
      private function §_-O2Y§(param1:Boolean) : void
      {
         var _loc2_:String = null;
         var _loc3_:§_-D3v§ = null;
         §_-J2l§.§_-R25§.hide();
         if(param1)
         {
            §_-h2B§.play(§_-d27§.§_-sg§);
            _loc2_ = §_-s2a§.§_-K3t§(§_-s2a§.UNLOCK_BOSS_RESULT_SUCCESS);
            _loc3_ = §_-r2q§.§_-r9§(this.§_-B3d§);
            _loc3_.§_-rm§ = this.§_-B3d§ - 1;
            §_-X1j§.§_-A24§.§_-73E§().§_-E3E§();
            §_-fH§.§_-q1a§(§_-s2a§.§_-K3t§(§_-s2a§.UNLOCK_BOSS_RESULT_TITLE),_loc2_,0);
         }
      }
   }
}

