package §_-Ty§
{
   import §_-21A§.ChooseFriendForBossMenu;
   import §_-31W§.§_-Kb§;
   import §_-73d§.§_-v1o§;
   import §_-79§.§_-ps§;
   import §_-A1K§.§_-6L§;
   import §_-A1K§.§_-TA§;
   import §_-A1K§.§_-U11§;
   import §_-DJ§.§_-J2l§;
   import §_-E1Z§.§_-E2i§;
   import §_-J3L§.§_-h1D§;
   import §_-L2F§.§_-D2p§;
   import §_-N8§.*;
   import §_-RE§.§_-r2q§;
   import §_-TF§.§_-y2n§;
   import §_-Tm§.§_-RF§;
   import §_-U1i§.§_-J1§;
   import §_-Vu§.MD5;
   import §_-Y1O§.*;
   import §_-Y1b§.*;
   import §_-b1R§.§_-C3P§;
   import §_-hO§.§_-v24§;
   import §_-j22§.§_-5g§;
   import §_-l1K§.§_-W2f§;
   import §_-r1C§.§_-h2B§;
   import §_-s20§.§_-J2g§;
   import feathers.controls.Button;
   import feathers.controls.List;
   import feathers.core.FeathersControl;
   import feathers.core.ITextRenderer;
   import feathers.data.ListCollection;
   import feathers.events.CollectionEventType;
   import flash.utils.ByteArray;
   import flash.utils.Dictionary;
   import flash.utils.IDataOutput;
   import flash.utils.clearTimeout;
   import flash.utils.setTimeout;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.server.IncomingPayment;
   import ru.pragmatix.wormix.messages.structures.GenericAwardStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.rewards.§_-P2q§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.ZombieGrave;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.serialization.SerializationUtils;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.§_-MN§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.weapons.ammo.Mine;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   import starling.events.KeyboardEvent;
   
   public class §_-83N§ extends §_-K3a§
   {
      
      private var playBtn:Button;
      
      private var §_-n2D§:List;
      
      private var §_-jz§:ChooseFriendForBossMenu;
      
      public function §_-83N§(param1:DisplayObject = null)
      {
         super(param1);
         this.§_-n2D§ = this.§_-i1o§(getChildByName("awardPanel") as DisplayObjectContainer);
      }
      
      private function §_-i1o§(param1:DisplayObjectContainer) : List
      {
         var _loc2_:List = null;
         _loc2_ = new §_-E2i§();
         param1.addChild(_loc2_);
         param1.parent.touchable = true;
         param1.touchable = true;
         _loc2_.touchable = true;
         _loc2_.width = param1.width / param1.scaleX;
         _loc2_.height = param1.height;
         return _loc2_;
      }
      
      override protected function initButtons() : void
      {
         this.playBtn = getChildByName("playBtn") as Button;
         §_-YQ§.§_-z2y§(this.playBtn,§_-s2a§.BATTLE_BOSS_BTN);
         this.playBtn.addEventListener(Event.TRIGGERED,this.§_-U2n§);
      }
      
      private function §_-U2n§(param1:Event) : void
      {
         if(§_-N1V§.§_-I39§.§_-X1P§().contains(§_-jh§.getId()))
         {
            this.§_-33U§();
         }
         else if(§_-N1V§.§_-I39§.§_-N1i§().contains(§_-jh§.getId()))
         {
            if(§_-X1j§.§_-A24§.§_-mV§)
            {
               this.§_-v1G§(§_-X1j§.§_-A24§.§_-mV§);
            }
            else
            {
               this.§_-J1b§();
            }
         }
      }
      
      private function §_-33U§() : void
      {
         var record:§_-D2p§ = null;
         §_-J2l§.§_-e1L§(§_-s2a§.LOADING);
         §_-X1j§.§_-A24§.§_-Z2j§();
         record = §_-jh§;
         setTimeout(function():void
         {
            §_-J2l§.§_-m1I§();
            §_-X1j§.§_-12n§.§_-IT§(record);
         },150);
      }
      
      private function §_-J1b§() : void
      {
         var _loc1_:Vector.<int> = null;
         if(§_-N1V§.settings.§_-03F§)
         {
            _loc1_ = new Vector.<int>();
            _loc1_.push(§_-jh§.getId());
            this.§_-jz§ = new ChooseFriendForBossMenu(_loc1_,this.§_-v1G§,this.§_-K3j§);
            this.§_-jz§.show();
         }
         else
         {
            this.§_-K3j§(§_-jh§.getId());
         }
      }
      
      private function §_-v1G§(param1:UserProfile) : void
      {
         §_-J2l§.§_-u2b§.show();
         if(this.§_-jz§)
         {
            this.§_-jz§.hide();
         }
         §_-C3P§.§_-o2h§(§_-jh§,param1);
         if(§_-X1j§.§_-A24§.§_-73E§())
         {
            §_-X1j§.§_-A24§.§_-73E§().hide();
         }
      }
      
      private function §_-K3j§(param1:int) : void
      {
         §_-J2l§.§_-u2b§.show();
         if(this.§_-jz§)
         {
            this.§_-jz§.hide();
         }
         §_-C3P§.§_-o2h§(§_-jh§);
         if(§_-X1j§.§_-A24§.§_-73E§())
         {
            §_-X1j§.§_-A24§.§_-73E§().hide();
         }
      }
      
      override public function §_-X2n§(param1:§_-D2p§) : void
      {
         var _loc4_:§_-P2q§ = null;
         if(!param1)
         {
            return;
         }
         super.§_-X2n§(param1);
         (getChildByName("bossName") as ITextRenderer).text = §_-s2a§.§_-K3t§(param1.getName());
         var _loc2_:String = "<br>";
         var _loc3_:String = §_-s2a§.§_-K3t§(param1.§_-p1§());
         (getChildByName("description") as ITextRenderer).text = _loc3_.replace(_loc2_,"\n");
         var _loc5_:Boolean = param1.getId() > §_-r2q§.§_-r9§(param1.getId()).§_-rm§;
         if(_loc5_)
         {
            _loc4_ = param1.§_-K1z§();
         }
         else if(§_-X1j§.§_-A24§.§_-X2A§())
         {
            _loc4_ = param1.§_-814§();
         }
         else
         {
            _loc4_ = param1.§_-ky§();
         }
         var _loc6_:Array = _loc4_.§_-q1L§();
         this.§_-n2D§.dataProvider = new ListCollection(_loc6_);
         this.§_-n2D§.invalidate(FeathersControl.INVALIDATION_FLAG_DATA);
      }
      
      override public function dispose() : void
      {
         if(this.playBtn)
         {
            this.playBtn.removeEventListener(Event.TRIGGERED,this.§_-U2n§);
            this.playBtn.dispose();
            this.playBtn = null;
         }
         if(this.§_-n2D§)
         {
            this.§_-n2D§.dispose();
            this.§_-n2D§ = null;
         }
         super.dispose();
      }
   }
}

