package §_-Ty§
{
   import §_-B2z§.§_-63i§;
   import §_-RE§.§_-52p§;
   import §_-W§.§_-ix§;
   import feathers.core.ITextRenderer;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.pvp.messages.server.PvpSystemMessage;
   import starling.display.DisplayObject;
   
   public class §_-M1h§ extends §_-1R§
   {
      
      public function §_-M1h§(param1:DisplayObject = null)
      {
         super(param1);
      }
      
      override public function §_-X2n§(param1:§_-52p§) : void
      {
         super.§_-X2n§(param1);
         (getChildByName("namePanel") as ITextRenderer).text = §_-s2a§.§_-K3t§(§_-s2a§.ONE_DAY_PANEL_NAME);
         (getChildByName("descrPanel") as ITextRenderer).text = §_-s2a§.§_-K3t§(§_-s2a§.ONE_DAY_PANEL_DESCR);
         (getChildByName("returnTomorrow") as ITextRenderer).text = §_-s2a§.§_-K3t§(§_-s2a§.ONE_DAY_PANEL_RETURN_TOMORROW);
      }
   }
}

