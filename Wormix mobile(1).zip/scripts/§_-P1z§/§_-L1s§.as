package §_-P1z§
{
   import §_-31N§.§_-42G§;
   import §_-31W§.§_-r26§;
   import §_-62§.*;
   import §_-73d§.§_-x2C§;
   import §_-9e§.§_-73e§;
   import §_-9e§.§_-8O§;
   import §_-9e§.§_-A18§;
   import §_-A1K§.§_-TA§;
   import §_-C2M§.§_-u2T§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-H2g§.§_-di§;
   import §_-L1H§.§_-C3e§;
   import §_-P1B§.§_-b21§;
   import §_-Tm§.§_-RF§;
   import §_-U1i§.§_-J1§;
   import §_-Y1b§.§_-o2i§;
   import §_-YF§.§_-q2v§;
   import §_-Z1K§.§_-q24§;
   import §_-Z2S§.§_-c2q§;
   import §_-hO§.§_-729§;
   import §_-l1K§.§_-W2f§;
   import §_-l1K§.§_-d2j§;
   import §_-l1g§.§_-L3Q§;
   import §_-v2t§.§_-03r§;
   import §_-w2i§.§_-Zd§;
   import feathers.controls.Button;
   import flash.geom.ColorTransform;
   import flash.geom.Point;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.Command;
   import ru.pragmatix.wormix.controls.system.ControlSystems;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.game.§_-eX§;
   import ru.pragmatix.wormix.game.ai.§_-L1S§;
   import ru.pragmatix.wormix.game.ai.§_-n2q§;
   import ru.pragmatix.wormix.gui.§_-Q2v§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.structures.WeaponStructure;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.Direction;
   import ru.pragmatix.wormix.objects.§_-V1L§;
   import ru.pragmatix.wormix.platform.§_-WK§;
   import ru.pragmatix.wormix.utils.StringUtil;
   import ru.pragmatix.wormix.utils.§_-72u§;
   import ru.pragmatix.wormix.utils.§_-MN§;
   import ru.pragmatix.wormix.weapons.Weapon;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.utils.Pool;
   import starling.utils.SystemUtil;
   
   public class §_-L1s§ extends §_-o2i§
   {
      
      private static const §_-J2F§:int = 1;
      
      private static const §_-B1g§:int = 2;
      
      private static const §_-22C§:int = 3;
      
      private static const STATE_SHOOT_THIRD_TARGET:int = 4;
      
      private static const §_-kj§:int = 130;
      
      private var state:int = 0;
      
      private var §_-b2i§:§_-03r§ = new §_-03r§();
      
      private var arrow:DisplayObject;
      
      private var §_-Y1n§:§_-V1L§;
      
      private var §_-52q§:uint;
      
      private var center:Point;
      
      private var §_-73D§:Number;
      
      private var §_-C1a§:Boolean = false;
      
      private var shootBtn:Button;
      
      private const HELP_RECORD_TURN1:Array = [{"text":§_-u2T§.LEARNING_3_TURN_1_TEXT}];
      
      private const HELP_RECORD_TURN2:Array = [{"text":§_-u2T§.LEARNING_3_TURN_2_TEXT}];
      
      private const HELP_RECORD_TURN3:Array = [{"text":§_-u2T§.LEARNING_3_TURN_3_TEXT}];
      
      private const HELP_RECORD_TURN4:Array = [{
         "text":§_-u2T§.LEARNING_3_TURN_4_TEXT,
         "graphic":"bag"
      }];
      
      private const HELP_RECORD_TURN5:Array = [{
         "text":§_-u2T§.LEARNING_3_TURN_5_N1_TEXT,
         "graphic":"bazooka"
      },{
         "text":§_-u2T§.LEARNING_3_TURN_5_N2_TEXT,
         "graphic":"space"
      }];
      
      private const HELP_RECORD_TURN6:Array = [{"text":§_-u2T§.LEARNING_3_TURN_6_TEXT}];
      
      private const HELP_RECORD_TURN7:Array = [{"text":§_-u2T§.LEARNING_3_TURN_7_TEXT}];
      
      private const HELP_RECORD_TURN8:Array = [{"text":§_-u2T§.LEARNING_3_TURN_8_TEXT}];
      
      private const HELP_RECORD_TURN9:Array = [{"text":§_-u2T§.LEARNING_3_TURN_9_TEXT}];
      
      private var §_-R1d§:Point;
      
      private var timeout:uint;
      
      public function §_-L1s§()
      {
         super(58,true,true);
      }
      
      override public function §_-H1J§() : §_-73e§
      {
         var _loc1_:§_-73e§ = new §_-73e§();
         _loc1_.online = false;
         _loc1_.backpackEnabled = true;
         _loc1_.§_-v17§ = false;
         _loc1_.§_-f2m§ = false;
         _loc1_.§_-724§ = false;
         _loc1_.§_-z2U§ = false;
         _loc1_.§_-nA§ = false;
         _loc1_.achievements = false;
         _loc1_.water = §_-A18§.§_-J24§;
         _loc1_.timer = §_-8O§.OFF;
         _loc1_.§_-b2i§ = this.§_-b2i§;
         return _loc1_;
      }
      
      override protected function §_-C2E§() : void
      {
         super.§_-C2E§();
         §_-132§ = 1;
         this.center = Pool.getPoint(§_-X1j§.§_-12n§.scene.width / 2,§_-X1j§.§_-12n§.scene.height / 2);
         this.§_-R1d§ = Pool.getPoint();
         §_-32L§ = [[this.center]];
         this.§_-52q§ = 1;
      }
      
      override public function §_-9T§() : void
      {
         super.§_-9T§();
         §_-e1r§("LearningMission3_CentralPart",this.center.x,this.center.y + 300,0,1);
         §_-e1r§("LearningMission3_RightPart",this.center.x + 370,this.center.y + 80,0,1);
         §_-e1r§("LearningMission3_LeftDownPart",this.center.x - 660,this.center.y - 5,0,1);
         §_-e1r§("LearningMission3_LeftUpPart",this.center.x - 370 - 247,this.center.y - 90 - 280,0,1);
         §_-X1j§.§_-12n§.scene.gotoNextTurn(new §_-TA§(1),false);
         §_-4O§.§_-41§(this.HELP_RECORD_TURN1,true);
         §_-4O§.§_-VT§().addEventListener(Event.TRIGGERED,this.§_-zl§);
         §_-4O§.hide();
         this.shootBtn = §_-X1j§.§_-12n§.scene.gameInterface.controlsLayout.shootButton;
         this.shootBtn.visible = false;
         this.§_-73N§(false);
      }
      
      private function §_-zl§(param1:Event) : void
      {
         if(this.§_-52q§ == 1)
         {
            this.§_-X18§();
         }
         else if(this.§_-52q§ == 2)
         {
            §_-4O§.moveBy(0,-§_-kj§);
            §_-4O§.§_-41§(this.HELP_RECORD_TURN3,true);
            this.§_-Q25§();
         }
         else if(this.§_-52q§ == 3)
         {
            §_-4O§.§_-41§(this.HELP_RECORD_TURN4);
            this.showBackpack();
         }
         else if(this.§_-52q§ == 4)
         {
            this.§_-vM§();
         }
         ++this.§_-52q§;
      }
      
      private function §_-7j§(param1:Event) : void
      {
         (currentUnit as EventDispatcher).removeEventListener(§_-L3Q§.WEAPON_SELECT,this.§_-7j§);
         this.§_-E1K§();
         §_-4O§.§_-41§(this.HELP_RECORD_TURN5);
         if(Boolean(currentUnit.weapon) && Boolean(currentUnit.weapon.§_-R1d§))
         {
            this.§_-R1d§.copyFrom(currentUnit.weapon.§_-R1d§);
         }
      }
      
      private function §_-92z§(param1:Event) : void
      {
         (currentUnit as EventDispatcher).removeEventListener(§_-L3Q§.WEAPON_SELECT,this.§_-92z§);
         this.§_-E1K§();
         this.§_-R1d§.setTo(0,0);
         this.§_-V1h§(true);
         §_-4O§.§_-41§(this.HELP_RECORD_TURN9);
         this.§_-033§();
         §_-X1j§.§_-12n§.scene.gameInterface.§_-z26§(true);
      }
      
      override protected function §_-03f§(param1:uint) : void
      {
         /*
          * Decompilation error
          * Code may be obfuscated
          * Error type: ClassCastException (class com.jpexs.decompiler.graph.model.CommaExpressionItem cannot be cast to class com.jpexs.decompiler.flash.abc.avm2.model.NewFunctionAVM2Item (com.jpexs.decompiler.graph.model.CommaExpressionItem and com.jpexs.decompiler.flash.abc.avm2.model.NewFunctionAVM2Item are in unnamed module of loader 'app'))
          */
         throw new flash.errors.IllegalOperationError("Not decompiled due to error");
      }
      
      private function §_-X18§() : void
      {
         var _loc1_:§_-O2H§ = §_-G1p§.§_-I4§(§_-q24§.BAZOOKA);
         var _loc2_:§_-C3e§ = _loc1_.§_-wF§.clone();
         _loc2_.explosionRadius = new §_-TA§(0);
         var _loc3_:Weapon = _loc1_.getWeapon();
         _loc3_.§_-d1P§(_loc2_);
         §_-72U§().build.§_-cr§([new WeaponStructure(§_-q24§.BAZOOKA,-1)]);
         §_-4O§.moveBy(0,§_-kj§);
         §_-4O§.§_-41§(this.HELP_RECORD_TURN2,true);
         §_-X1j§.§_-12n§.scene.gameInterface.§_-iu§();
      }
      
      private function showBackpack() : void
      {
         showGlowBag(§_-q24§.BAZOOKA);
         ControlSystems.instance.setCommandDisabled(Command.Bag,false);
         §_-X1j§.§_-12n§.scene.gameInterface.§_-z26§(false);
         var _loc1_:§_-c2q§ = §_-X1j§.§_-12n§.scene.gameInterface.§_-Fb§;
         _loc1_.addEventListener(§_-L3Q§.AFTER_OPEN_CLOSE_BAG,this.openBag);
         this.shootBtn.addEventListener(§_-L3Q§.AFTER_OPEN_CLOSE_BAG,this.openBag);
      }
      
      private function openBag(param1:§_-729§) : void
      {
         var _loc2_:DisplayObject = null;
         if(param1.value)
         {
            _loc2_ = §_-4O§.getContainer();
            §_-4O§.moveBy(0,-_loc2_.height - _loc2_.y);
            if(§_-427§ == §_-q24§.BAZOOKA)
            {
               showGlowBag(§_-q24§.BAZOOKA);
               §_-4O§.§_-41§(this.HELP_RECORD_TURN4);
               if(!(currentUnit as EventDispatcher).hasEventListener(§_-L3Q§.WEAPON_SELECT,this.§_-7j§))
               {
                  (currentUnit as EventDispatcher).addEventListener(§_-L3Q§.WEAPON_SELECT,this.§_-7j§);
               }
            }
            else if(§_-427§ == §_-q24§.GRENADE)
            {
               showGlowBag(§_-q24§.GRENADE);
               if(!(currentUnit as EventDispatcher).hasEventListener(§_-L3Q§.WEAPON_SELECT,this.§_-92z§))
               {
                  (currentUnit as EventDispatcher).addEventListener(§_-L3Q§.WEAPON_SELECT,this.§_-92z§);
               }
            }
         }
         else
         {
            §_-4O§.§_-yR§();
         }
      }
      
      private function §_-vM§() : void
      {
         §_-X1j§.§_-12n§.scene.sceneCamera.moveTo(currentUnit.x - 300,currentUnit.y - 150);
         this.§_-Y1n§ = this.§_-j2V§(this.center.x - 560,this.center.y + 50,this.§_-8U§);
         mark = §_-X1j§.§_-12n§.scene.showUIClip(§_-q2v§.§_-y26§,0,0);
         §_-MN§.§_-H1e§(mark,new ColorTransform(1.2,0.6,0.6,0.5));
         §_-Zd§.once(this.§_-Y1n§.§_-Y2I§ as EventDispatcher,§_-42G§.§_-K2J§,function(param1:Event):void
         {
            var _loc2_:int = currentUnit.direction;
            currentUnit.turn(Direction.LEFT.value);
            §_-P2a§(1);
            currentUnit.turn(_loc2_);
            §_-X1j§.§_-12n§.scene.addEventListener(§_-L3Q§.FRAME,§_-w1e§);
            §_-V1h§(true);
            §_-73N§(true);
         });
      }
      
      private function §_-8U§(param1:Event = null) : void
      {
         this.§_-73N§(false);
         §_-X1j§.§_-12n§.scene.removeEventListener(§_-L3Q§.FRAME,this.§_-w1e§);
         §_-4O§.§_-41§(this.HELP_RECORD_TURN6);
         mark.visible = false;
         §_-X1j§.§_-12n§.scene.addEventListener(§_-L3Q§.SOT,this.§_-W2G§);
      }
      
      private function §_-W2G§(param1:Event) : void
      {
         var _loc2_:§_-eX§ = §_-X1j§.§_-12n§.gameMaster;
         if(Boolean(_loc2_) && _loc2_.§_-E3b§())
         {
            §_-X1j§.§_-12n§.scene.removeEventListener(§_-L3Q§.SOT,this.§_-W2G§);
            this.§_-A2O§();
         }
      }
      
      private function §_-A2O§() : void
      {
         this.state = §_-B1g§;
         §_-X1j§.§_-12n§.scene.sceneCamera.moveTo(currentUnit.x + 330,currentUnit.y - 150);
         this.§_-Y1n§ = this.§_-j2V§(this.center.x + 650,this.center.y + 150,this.§_-g2Q§);
         mark.visible = true;
         §_-Zd§.once(this.§_-Y1n§.§_-Y2I§ as EventDispatcher,§_-42G§.§_-K2J§,function(param1:Event):void
         {
            var _loc2_:int = currentUnit.direction;
            currentUnit.turn(Direction.RIGHT.value);
            §_-P2a§(0);
            currentUnit.turn(_loc2_);
            §_-X1j§.§_-12n§.scene.addEventListener(§_-L3Q§.FRAME,§_-w1e§);
            §_-73N§(true);
         });
      }
      
      private function §_-g2Q§(param1:Event = null) : void
      {
         var grenadeRecord:§_-O2H§;
         var grenadeParamSet:§_-C3e§;
         var grenade:Weapon;
         var rec:§_-O2H§;
         var gameInterface:§_-Q2v§ = null;
         var e:Event = param1;
         this.§_-73N§(false);
         this.state = §_-22C§;
         §_-X1j§.§_-12n§.scene.removeEventListener(§_-L3Q§.FRAME,this.§_-w1e§);
         grenadeRecord = §_-G1p§.§_-I4§(§_-q24§.GRENADE);
         grenadeParamSet = grenadeRecord.§_-wF§.clone();
         grenadeParamSet.explosionRadius = new §_-TA§(0);
         grenade = grenadeRecord.getWeapon();
         grenade.§_-d1P§(grenadeParamSet);
         currentUnit.§_-81o§ = null;
         rec = §_-G1p§.§_-I4§(§_-q24§.GRENADE);
         §_-72U§().§_-V2J§().replaceItem(§_-q24§.BAZOOKA,rec,-1);
         mark.visible = false;
         §_-4O§.§_-41§(this.HELP_RECORD_TURN7);
         gameInterface = §_-X1j§.§_-12n§.scene.gameInterface;
         if(gameInterface.§_-Fb§.hasEventListener(§_-L3Q§.AFTER_OPEN_CLOSE_BAG))
         {
            gameInterface.§_-Fb§.removeEventListener(§_-L3Q§.AFTER_OPEN_CLOSE_BAG,this.openBag);
         }
         if(this.shootBtn.hasEventListener(§_-L3Q§.AFTER_OPEN_CLOSE_BAG))
         {
            this.shootBtn.removeEventListener(§_-L3Q§.AFTER_OPEN_CLOSE_BAG,this.openBag);
         }
         §_-X1j§.§_-12n§.scene.addEventListener(§_-L3Q§.NEXT_TURN,function(param1:Event):void
         {
            showBackpack();
            showGlowBag(§_-q24§.GRENADE);
            §_-X1j§.§_-12n§.scene.removeEventListener(§_-L3Q§.NEXT_TURN,arguments.callee);
            gameInterface.§_-Fb§.addEventListener(§_-L3Q§.AFTER_OPEN_CLOSE_BAG,openBag);
            shootBtn.addEventListener(§_-L3Q§.AFTER_OPEN_CLOSE_BAG,openBag);
            state = STATE_SHOOT_THIRD_TARGET;
         });
      }
      
      private function §_-033§() : void
      {
         §_-X1j§.§_-12n§.scene.sceneCamera.moveTo(currentUnit.x - 160,currentUnit.y - 380);
         mark.visible = true;
         this.§_-Y1n§ = this.§_-j2V§(this.center.x - 520,this.center.y - 360,this.§_-o2a§);
         mark.y = -100;
         §_-Zd§.once(this.§_-Y1n§.§_-Y2I§ as EventDispatcher,§_-42G§.§_-K2J§,function(param1:Event):void
         {
            var _loc2_:int = currentUnit.direction;
            currentUnit.turn(Direction.LEFT.value);
            §_-P2a§(0,false);
            currentUnit.turn(_loc2_);
            §_-X1j§.§_-12n§.scene.addEventListener(§_-L3Q§.FRAME,§_-w1e§);
            §_-73N§(true);
         });
         this.§_-C1a§ = true;
      }
      
      private function §_-o2a§(param1:Event = null) : void
      {
         this.§_-73N§(false);
         §_-X1j§.§_-12n§.scene.removeEventListener(§_-L3Q§.FRAME,this.§_-w1e§);
         §_-X1j§.§_-12n§.scene.hideUIClip(mark);
         mark = null;
         §_-4O§.§_-VT§().removeEventListener(Event.TRIGGERED,this.§_-zl§);
         this.timeout = Starling.juggler.delayCall(this.exit,1.5);
      }
      
      private function exit() : void
      {
         §_-4O§.hide();
         §_-4O§.dispose();
         §_-RF§.fire(§_-RF§.§_-y1J§);
         this.§_-b2i§.§_-BR§(§_-J1§.WINNER);
      }
      
      override public function clear() : void
      {
         if(this.timeout)
         {
            Starling.juggler.removeByID(this.timeout);
         }
         super.clear();
         this.§_-Y1n§ = null;
         if(this.arrow != null)
         {
            §_-X1j§.§_-12n§.scene.hideClip(this.arrow);
            this.arrow.dispose();
            this.arrow = null;
         }
         Pool.putPoint(this.§_-R1d§);
         this.§_-R1d§ = null;
         Pool.putPoint(this.center);
         this.center = null;
      }
      
      private function §_-j2V§(param1:int, param2:int, param3:Function) : §_-V1L§
      {
         var _loc4_:§_-V1L§ = new §_-V1L§(param1,param2);
         _loc4_.addEventListener(§_-L3Q§.§_-Qw§,param3);
         _loc4_.§_-l2l§(2);
         return _loc4_;
      }
      
      private function §_-P2a§(param1:uint, param2:Boolean = true) : void
      {
         var _loc3_:Vector.<§_-L1S§> = new Vector.<§_-L1S§>(0);
         §_-n2q§.§_-Tp§(currentUnit.x,currentUnit.y,this.§_-Y1n§.x,this.§_-Y1n§.y,45,_loc3_,param2,true);
         var _loc4_:§_-L1S§ = _loc3_[param1];
         var _loc5_:Point = Pool.getPoint();
         this.§_-73D§ = _loc4_.angle;
         §_-W2f§.§_-m1l§(currentUnit,this.§_-73D§,§_-W2f§.§_-o18§,currentUnit.x,currentUnit.y,_loc5_);
         mark.x = _loc5_.x;
         mark.y = _loc5_.y;
         this.§_-73D§ = _loc4_.angle;
         Pool.putPoint(_loc5_);
      }
      
      private function §_-w1e§(param1:Event = null) : void
      {
         if(Boolean(currentUnit) && Boolean(currentUnit.weapon))
         {
            if(Math.abs(§_-W2f§(currentUnit.weapon.§_-G3H§()).getAngle() - this.§_-73D§) < 0.1)
            {
               §_-W2f§(currentUnit.weapon.§_-G3H§()).setAngle(this.§_-73D§);
            }
         }
      }
      
      private function §_-L1m§(param1:Event) : void
      {
         currentUnit.attributes.hp.restore(currentUnit.attributes.hp.§_-33H§() - currentUnit.hp,§_-b21§.§_-h1U§,false,false);
         currentUnit.setSpeedXY(0,0);
      }
      
      private function §_-Q25§() : void
      {
         §_-X1j§.§_-12n§.scene.gameInterface.§_-q10§();
      }
      
      private function §_-E1K§() : void
      {
         §_-X1j§.§_-12n§.scene.gameInterface.§_-z26§(true);
         this.§_-V1h§(false);
         §_-62Y§();
         §_-X1j§.§_-12n§.scene.gameInterface.§_-Fb§.removeEventListener(§_-L3Q§.AFTER_OPEN_CLOSE_BAG,this.openBag);
         this.shootBtn.removeEventListener(§_-L3Q§.AFTER_OPEN_CLOSE_BAG,this.openBag);
         §_-4O§.§_-yR§();
      }
      
      private function §_-V1h§(param1:Boolean) : void
      {
         if(SystemUtil.platform == §_-WK§.§_-c1l§ || SystemUtil.platform == §_-WK§.IOS)
         {
            this.shootBtn.visible = param1;
         }
      }
      
      private function §_-73N§(param1:Boolean) : void
      {
         var _loc2_:Boolean = !param1;
         ControlSystems.instance.setCommandDisabled(Command.Shoot,_loc2_);
         ControlSystems.instance.setCommandDisabled(Command.Left,_loc2_);
         ControlSystems.instance.setCommandDisabled(Command.Right,_loc2_);
         ControlSystems.instance.setCommandDisabled(Command.Up,_loc2_);
         ControlSystems.instance.setCommandDisabled(Command.Down,_loc2_);
      }
   }
}

