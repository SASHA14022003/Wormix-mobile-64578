package §_-P1z§
{
   import §_-51p§.§_-W2e§;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-O2H§;
   import §_-9e§.§_-73e§;
   import §_-9e§.§_-8O§;
   import §_-9e§.§_-A18§;
   import §_-A1K§.§_-TA§;
   import §_-C2M§.§_-u2T§;
   import §_-H2g§.§_-di§;
   import §_-L1H§.§_-C3e§;
   import §_-P1B§.§_-b21§;
   import §_-Tm§.§_-RF§;
   import §_-U1i§.§_-J1§;
   import §_-Y1b§.§_-o2i§;
   import §_-YF§.§_-q2v§;
   import §_-Z1K§.§_-q24§;
   import §_-ZP§.§_-YG§;
   import §_-ZP§.§_-w1J§;
   import §_-hO§.§_-v24§;
   import §_-l1K§.§_-W2f§;
   import §_-l1g§.§_-L3Q§;
   import §_-l2r§.§_-K1t§;
   import §_-sQ§.§_-H3D§;
   import §_-v2t§.§_-03r§;
   import dragonBones.animation.WorldClock;
   import flash.geom.ColorTransform;
   import flash.geom.Point;
   import ru.pragmatix.flox.social.model.PaymentOption;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.gui.§_-Q2v§;
   import ru.pragmatix.wormix.messages.server.VerifyPaymentResult;
   import ru.pragmatix.wormix.messages.utils.Result;
   import ru.pragmatix.wormix.objects.§_-V1L§;
   import ru.pragmatix.wormix.scene.SortingLayer;
   import ru.pragmatix.wormix.social.utils.FacebookTracking;
   import ru.pragmatix.wormix.utils.§_-72u§;
   import ru.pragmatix.wormix.utils.§_-MN§;
   import ru.pragmatix.wormix.weapons.§_-73v§;
   import starling.animation.IAnimatable;
   import starling.core.Starling;
   import starling.display.Canvas;
   import starling.display.DisplayObject;
   import starling.events.Event;
   import starling.utils.Pool;
   
   public class §_-k2X§ extends §_-o2i§ implements IAnimatable
   {
      
      private var §_-b2i§:§_-03r§ = new §_-03r§();
      
      private var center:Point;
      
      private var arrow:§_-di§;
      
      private var §_-e13§:Canvas;
      
      private var §_-Y1n§:§_-V1L§;
      
      private const HELP_RECORD_TURN1:Array = [{
         "text":§_-u2T§.LEARNING_1_TURN_1_TEXT,
         "graphic":"leftright"
      }];
      
      private const HELP_RECORD_TURN2:Array = [{
         "text":§_-u2T§.LEARNING_1_TURN_2_TEXT,
         "graphic":"updown"
      }];
      
      private const HELP_RECORD_TURN3:Array = [{
         "text":§_-u2T§.LEARNING_1_TURN_3_TEXT,
         "graphic":"space"
      }];
      
      private const HELP_RECORD_TURN4:Array = [{"text":§_-u2T§.LEARNING_1_TURN_4_TEXT}];
      
      private var §_-D1R§:Number;
      
      private var §_-On§:Boolean;
      
      private var §_-q2D§:Boolean;
      
      public function §_-k2X§()
      {
         super(42,true,true);
      }
      
      override public function §_-H1J§() : §_-73e§
      {
         var _loc1_:§_-73e§ = null;
         _loc1_ = new §_-73e§();
         _loc1_.online = false;
         _loc1_.backpackEnabled = false;
         _loc1_.§_-724§ = false;
         _loc1_.§_-z2U§ = false;
         _loc1_.§_-nA§ = false;
         _loc1_.achievements = false;
         _loc1_.water = §_-A18§.§_-J24§;
         _loc1_.timer = §_-8O§.OFF;
         _loc1_.§_-b2i§ = this.§_-b2i§;
         return _loc1_;
      }
      
      override protected function §_-C2E§() : void
      {
         super.§_-C2E§();
         §_-72U§().build.§_-cr§([]);
         this.center = Pool.getPoint(§_-X1j§.§_-12n§.scene.sceneW / 2,§_-X1j§.§_-12n§.scene.sceneH / 2);
         §_-132§ = 1;
         §_-32L§ = [[Pool.getPoint(this.center.x,this.center.y - 50)]];
      }
      
      override public function §_-9T§() : void
      {
         super.§_-9T§();
         §_-e1r§("LearningMission1_LeftPart",this.center.x - 208,this.center.y + 50,0,1);
         §_-e1r§("LearningMission1_CentralPart",this.center.x + 100,this.center.y + 50,0,1);
         §_-e1r§("LearningMission1_RightPart",this.center.x + 309,this.center.y + 50,0,1);
         §_-X1j§.§_-12n§.scene.gotoNextTurn(new §_-TA§(1),false);
         §_-4O§.§_-41§(this.HELP_RECORD_TURN1);
         §_-X1j§.§_-12n§.scene.gameInterface.§_-QQ§();
      }
      
      override public function §_-e2d§() : void
      {
         §_-73v§.getWeapon(§_-q24§.RIFLE).shots.value = 999999;
      }
      
      override protected function §_-03f§(param1:uint) : void
      {
         var _loc2_:§_-O2H§ = null;
         var _loc3_:§_-C3e§ = null;
         var _loc4_:Point = null;
         var _loc5_:§_-W2e§ = null;
         if(param1 == 1)
         {
            currentUnit.§_-e14§(true);
            _loc2_ = §_-G1p§.§_-I4§(§_-q24§.RIFLE);
            _loc3_ = _loc2_.§_-wF§.clone();
            _loc3_.explosionRadius = new §_-TA§(0);
            _loc3_.damageRadius = new §_-TA§(0);
            _loc3_.damage = new §_-TA§(0);
            _loc2_.getWeapon().§_-d1P§(_loc3_);
            _loc4_ = Pool.getPoint(this.center.x + 120,this.center.y);
            _loc5_ = new §_-W2e§(_loc4_,_loc2_,-1);
            _loc5_.addEventListener(§_-v24§.NAME,this.§_-vM§);
            Pool.putPoint(_loc4_);
            this.arrow = §_-X1j§.§_-12n§.scene.showDragonBonedClip("TutorialArrowMap",_loc5_.x,_loc5_.y - _loc5_.clip.height / 2 + 20);
            currentUnit.addEventListener(§_-L3Q§.§_-Qw§,this.§_-L1m§);
            currentUnit.§_-e14§(false);
            §_-X1j§.§_-12n§.scene.gameInterface.§_-Bn§(§_-Q2v§.§_-J1S§);
            §_-X1j§.§_-12n§.scene.gameInterface.§_-z26§(true);
         }
      }
      
      private function §_-vM§(param1:Event) : void
      {
         §_-4O§.§_-41§(this.HELP_RECORD_TURN2);
         currentUnit.§_-P1W§(§_-q24§.RIFLE);
         this.§_-D1R§ = currentUnit.weapon.§_-R1d§.length;
         §_-X1j§.§_-12n§.scene.sceneCamera.moveTo(currentUnit.x + 60,currentUnit.y - 120);
         §_-X1j§.§_-12n§.scene.hideDragonBonedClip(this.arrow);
         this.arrow = null;
         currentUnit.§_-e14§(true);
         this.§_-Y1n§ = this.§_-j2V§(this.center.x + 400,this.center.y - 90,this.§_-A2O§);
         mark = this.§_-ea§();
         this.§_-On§ = true;
         this.§_-q2D§ = true;
         Starling.juggler.add(this);
         §_-X1j§.§_-12n§.scene.gameInterface.§_-Bn§(§_-Q2v§.§_-33f§);
      }
      
      private function §_-A2O§(param1:Event) : void
      {
         this.§_-Y1n§.removeEventListener(§_-L3Q§.§_-Qw§,this.§_-A2O§);
         currentUnit.§_-P1W§(§_-q24§.RIFLE);
         §_-X1j§.§_-12n§.scene.sceneCamera.moveTo(currentUnit.x - 120,currentUnit.y - 120);
         §_-4O§.§_-41§(this.HELP_RECORD_TURN4);
         this.§_-Y1n§ = this.§_-j2V§(this.center.x - 290,this.center.y - 180,this.§_-o2a§);
         §_-4O§.§_-yR§();
         §_-X1j§.§_-12n§.scene.gameInterface.§_-q10§();
      }
      
      private function §_-o2a§(param1:Event) : void
      {
         if(Boolean(§_-X1j§.§_-12n§) && Boolean(§_-X1j§.§_-12n§.scene))
         {
            §_-X1j§.§_-12n§.scene.hideUIClip(mark);
            §_-X1j§.§_-12n§.scene.removeElement(this.§_-e13§);
         }
         mark = null;
         this.§_-e13§ = null;
         this.§_-On§ = false;
         if(Boolean(currentUnit) && Boolean(currentUnit.weapon))
         {
            currentUnit.weapon.detach();
         }
         if(this.§_-b2i§)
         {
            this.§_-b2i§.§_-BR§(§_-J1§.WINNER);
         }
         if(§_-4O§)
         {
            §_-4O§.hide();
            §_-4O§.dispose();
            §_-4O§ = null;
         }
         §_-RF§.fire(§_-RF§.§_-y1J§);
      }
      
      private function §_-L1m§(param1:Event) : void
      {
         currentUnit.attributes.hp.restore(currentUnit.attributes.hp.§_-33H§() - currentUnit.hp,§_-b21§.§_-h1U§,false,false);
         currentUnit.setSpeedXY(0,0);
      }
      
      private function §_-j2V§(param1:int, param2:int, param3:Function) : §_-V1L§
      {
         var _loc4_:§_-V1L§ = new §_-V1L§(param1,param2);
         _loc4_.addEventListener(§_-L3Q§.§_-Qw§,param3);
         _loc4_.§_-l2l§(2);
         return _loc4_;
      }
      
      private function §_-ea§() : DisplayObject
      {
         mark = §_-X1j§.§_-12n§.scene.showUIClip(§_-q2v§.§_-y26§,0,0);
         §_-MN§.§_-H1e§(mark,new ColorTransform(1.2,0.6,0.6,0.5));
         this.§_-138§();
         return mark;
      }
      
      public function advanceTime(param1:Number) : void
      {
         if(this.§_-On§)
         {
            this.§_-138§();
         }
         if(this.§_-q2D§)
         {
            this.§_-q1m§();
         }
      }
      
      private function §_-138§() : void
      {
         var _loc1_:Number = NaN;
         if(this.§_-Y1n§)
         {
            _loc1_ = Number(Math.atan2(this.§_-Y1n§.y - currentUnit.y,this.§_-Y1n§.x - currentUnit.x));
            mark.x = currentUnit.x + (§_-W2f§.§_-o18§ + this.§_-D1R§) * Math.cos(_loc1_);
            mark.y = currentUnit.y + (§_-W2f§.§_-o18§ + this.§_-D1R§) * Math.sin(_loc1_);
            if(!this.§_-e13§)
            {
               this.§_-e13§ = new Canvas();
               §_-X1j§.§_-12n§.scene.addElementToCertainSortingLayer(this.§_-e13§,SortingLayer.POINTERS_LAYER);
            }
            §_-s1i§(currentUnit.x,currentUnit.y,_loc1_,100,true,false,§_-H3D§.distance(this.§_-Y1n§.x - currentUnit.x,this.§_-Y1n§.y - currentUnit.y),5,this.§_-e13§);
            §_-MN§.§_-H1e§(this.§_-e13§,new ColorTransform(1,1,1,0.5));
         }
      }
      
      private function §_-q1m§() : void
      {
         var _loc1_:Number = NaN;
         if(Boolean(currentUnit) && Boolean(currentUnit.weapon))
         {
            _loc1_ = Number(Math.atan2(this.§_-Y1n§.y - currentUnit.y,this.§_-Y1n§.x - currentUnit.x));
            if(Math.abs(§_-W2f§(currentUnit.weapon.§_-G3H§()).getAngle() - _loc1_) < 0.02)
            {
               §_-4O§.§_-41§(this.HELP_RECORD_TURN3);
               this.§_-q2D§ = false;
               §_-X1j§.§_-12n§.scene.gameInterface.§_-Bn§(§_-Q2v§.§_-619§);
            }
         }
      }
      
      override public function clear() : void
      {
         super.clear();
         this.§_-Y1n§ = null;
         if(this.arrow != null)
         {
            §_-X1j§.§_-12n§.scene.hideDragonBonedClip(this.arrow);
            this.arrow = null;
         }
         if(mark != null)
         {
            §_-X1j§.§_-12n§.scene.hideUIClip(mark);
            mark.dispose();
            mark = null;
         }
         if(this.§_-e13§ != null)
         {
            §_-X1j§.§_-12n§.scene.removeElement(this.§_-e13§);
            this.§_-e13§.dispose();
            this.§_-e13§ = null;
         }
         Starling.juggler.remove(this);
         §_-73v§.getWeapon(§_-q24§.RIFLE).shots.value = 2;
         §_-G1p§.§_-I4§(§_-q24§.RIFLE).bagX = 4;
      }
   }
}

