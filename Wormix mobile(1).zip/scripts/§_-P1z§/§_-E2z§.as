package §_-P1z§
{
   import §_-03T§.§_-2p§;
   import §_-21p§.§_-4w§;
   import §_-31N§.§_-42G§;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-O2H§;
   import §_-82l§.§_-A2Y§;
   import §_-9e§.§_-73e§;
   import §_-9e§.§_-8O§;
   import §_-9e§.§_-A18§;
   import §_-A1K§.§_-TA§;
   import §_-C2M§.§_-u2T§;
   import §_-L1H§.§_-C3e§;
   import §_-SP§.§_-M4§;
   import §_-TF§.§_-y2n§;
   import §_-Tm§.§_-RF§;
   import §_-U1i§.§_-J1§;
   import §_-Vg§.*;
   import §_-Vu§.MD5;
   import §_-Y1O§.§_-V23§;
   import §_-Y1O§.§_-y1o§;
   import §_-Y1b§.§_-81l§;
   import §_-Y1b§.§_-o2i§;
   import §_-Z1K§.§_-q24§;
   import §_-b1F§.§_-G4§;
   import §_-hO§.§_-729§;
   import §_-hO§.§_-v24§;
   import §_-j1w§.§_-L1x§;
   import §_-k1u§.§_-2m§;
   import §_-l1K§.*;
   import §_-l1g§.§_-L3Q§;
   import §_-lh§.§_-z2A§;
   import §_-m2s§.§_-R11§;
   import §_-o14§.*;
   import §_-r1C§.§_-h2B§;
   import §_-sQ§.§_-H3D§;
   import §_-v2t§.§_-03r§;
   import §_-w2i§.§_-Ia§;
   import §_-w2i§.§_-Zd§;
   import §_-zI§.§_-A1s§;
   import §_-zI§.§_-X1q§;
   import com.distriqt.extension.inappbilling.events.ApplicationReceiptEvent;
   import feathers.controls.NumericStepper;
   import feathers.controls.ScreenNavigator;
   import feathers.controls.ScreenNavigatorItem;
   import feathers.controls.ScrollPolicy;
   import feathers.data.ArrayCollection;
   import feathers.data.ListCollection;
   import feathers.layout.AnchorLayoutData;
   import flash.display.Shape;
   import flash.events.Event;
   import flash.geom.Point;
   import flash.net.Socket;
   import flash.system.Security;
   import flash.utils.ByteArray;
   import flash.utils.clearInterval;
   import flash.utils.setInterval;
   import ru.pragmatix.flox.serialization.§_-616§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.EffectType;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.gui.§_-Q2v§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.structures.ClanMemberTO;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-8K§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.scene.SortingLayer;
   import ru.pragmatix.wormix.utils.§_-6A§;
   import ru.pragmatix.wormix.utils.§_-c1S§;
   import ru.pragmatix.wormix.utils.§_-g20§;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.Mine;
   import ru.pragmatix.wormix.weapons.ammo.phase.PhaseAmmo;
   import ru.pragmatix.wormix.weapons.ammo.type.grenade.Parasite;
   import starling.display.DisplayObject;
   import starling.display.Image;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.utils.Pool;
   
   public class §_-E2z§ extends §_-o2i§
   {
      
      private static const §_-X1z§:int = 0;
      
      private static const §_-Ky§:int = 1;
      
      private static const §_-B1R§:int = 2;
      
      private static const §_-G1b§:int = 3;
      
      private static const §_-S2n§:int = 4;
      
      private static const §_-D6§:int = 5;
      
      private static const §_-xL§:int = 6;
      
      private var state:int;
      
      private var §_-b2i§:§_-03r§ = new §_-03r§();
      
      private var center:Point;
      
      private var §_-DB§:UserProfile;
      
      private var activeUnit:§_-01J§;
      
      private var hitByMine:Boolean;
      
      private var §_-52§:int;
      
      private var mine:Mine;
      
      private var §_-s2J§:Image;
      
      protected const §_-aP§:Array = [{"text":§_-u2T§.LEARNING_5_TURN_1_TEXT},{"text":§_-u2T§.LEARNING_5_TURN_2_TEXT},{"text":§_-u2T§.LEARNING_5_TURN_3_TEXT},{"text":§_-u2T§.LEARNING_5_TURN_4_TEXT},{"text":§_-u2T§.LEARNING_5_TURN_5_TEXT},{"text":§_-u2T§.LEARNING_5_TURN_6_TEXT},{"text":§_-u2T§.LEARNING_5_TURN_7_TEXT},{"text":§_-u2T§.LEARNING_5_TURN_8_TEXT},{"text":§_-u2T§.LEARNING_5_TURN_9_TEXT},{"text":§_-u2T§.LEARNING_5_TURN_10_TEXT},{"text":§_-u2T§.LEARNING_5_TURN_11_TEXT},{"text":§_-u2T§.LEARNING_5_TURN_12_TEXT},{"text":§_-u2T§.LEARNING_5_TURN_13_TEXT},{"text":§_-u2T§.LEARNING_5_TURN_14_TEXT}];
      
      public function §_-E2z§()
      {
         super(5,true,false);
         §_-qe§ = this.§_-aP§;
      }
      
      override public function §_-H1J§() : §_-73e§
      {
         var _loc1_:§_-73e§ = new §_-73e§();
         _loc1_.online = false;
         _loc1_.backpackEnabled = true;
         _loc1_.§_-v17§ = false;
         _loc1_.§_-f2m§ = false;
         _loc1_.§_-724§ = false;
         _loc1_.§_-z2U§ = false;
         _loc1_.§_-nA§ = false;
         _loc1_.achievements = false;
         _loc1_.water = §_-A18§.§_-J24§;
         _loc1_.timer = §_-8O§.OFF;
         _loc1_.§_-b2i§ = this.§_-b2i§;
         return _loc1_;
      }
      
      override protected function §_-C2E§() : void
      {
         super.§_-C2E§();
         §_-132§ = 1;
         §_-72U§().build.§_-cr§([]);
         this.center = Pool.getPoint(§_-X1j§.§_-12n§.scene.width / 2 + 55,§_-X1j§.§_-12n§.scene.height / 2);
         §_-32L§ = [[Pool.getPoint(this.center.x + 15,this.center.y - 50)],[Pool.getPoint(this.center.x - 85,this.center.y - 50)]];
         this.§_-DB§ = UserProfile.custom(§_-s2a§.§_-K3t§("RACE_ZOMBIE_NAME"),1,§_-L1x§.§_-p21§,75,0,0);
         §_-J1q§ = [new §_-81l§(§_-s2a§.§_-K3t§("TEAM_NAME_LEARNING_ZOMBIES"),[this.§_-DB§])];
         §_-F2Z§ = 0;
      }
      
      override public function §_-9T§() : void
      {
         super.§_-9T§();
         §_-e1r§("LearningMission5_CentralPart",this.center.x + 50,this.center.y + 40,0,1);
         §_-X1j§.§_-12n§.scene.gotoNextTurn(new §_-TA§(1),false);
         §_-4O§.hide();
      }
      
      override protected function §_-03f§(param1:uint) : void
      {
         if(param1 == 1)
         {
            this.state = §_-X1z§;
            this.firstTurn();
            currentUnit.addEventListener(§_-L3Q§.DISPOSED,this.§_-135§);
            §_-336§[0].getUnits()[0].turn(§_-8K§.RIGHT);
         }
         if(§_-X1j§.§_-12n§.gameMaster.§_-y2v§())
         {
            §_-X1j§.§_-12n§.gameMaster.§_-f13§();
            return;
         }
         this.activeUnit = currentUnit;
         if(!this.hitByMine)
         {
            this.§_-22Q§();
         }
         switch(this.state)
         {
            case §_-Ky§:
            case §_-B1R§:
               this.§_-t2§(false);
               break;
            case §_-G1b§:
               currentUnit.§_-P1W§(§_-q24§.RIFLE);
               break;
            case §_-S2n§:
               §_-72U§().build.§_-cr§([]);
               §_-X1j§.§_-12n§.gameMaster.nextTurnOnStable();
               this.state = §_-D6§;
               break;
            case §_-D6§:
               showTurnTip(this.§_-C8§);
               this.§_-t2§(true);
               break;
            case §_-xL§:
               currentUnit.§_-P1W§(§_-q24§.BAT);
         }
         if(§_-F2Z§ > 5 && §_-F2Z§ != 9 && §_-F2Z§ != 8)
         {
            this.§_-t2§(false);
         }
         else if(§_-F2Z§ == 9 || §_-F2Z§ == 8)
         {
            this.§_-t2§(true);
         }
      }
      
      private function firstTurn() : void
      {
         showTurnTip();
         currentUnit.§_-e14§(false);
         §_-4O§.show();
         §_-f2C§(§_-Q2v§.§_-k2S§);
         §_-X1j§.§_-12n§.scene.gameInterface.§_-Fb§.addEventListener(§_-L3Q§.AFTER_OPEN_CLOSE_BAG,this.openBag);
         currentUnit.addEventListener(§_-L3Q§.WEAPON_SELECT,this.§_-ZC§);
         this.§_-t2§(true);
      }
      
      private function openBag(param1:§_-729§) : void
      {
         showGlowBag(§_-q24§.MINE);
      }
      
      private function §_-ZC§(param1:starling.events.Event) : void
      {
         this.state = §_-Ky§;
         §_-X1j§.§_-12n§.scene.gameInterface.§_-Fb§.removeEventListener(§_-L3Q§.AFTER_OPEN_CLOSE_BAG,this.openBag);
         §_-z9§();
         §_-62Y§();
         this.§_-t2§(false);
         this.activeUnit.removeEventListener(§_-L3Q§.WEAPON_SELECT,this.§_-ZC§);
         showTurnTip(this.§_-J23§);
         §_-1b§(Mine,§_-q24§.MINE,this.center.x - 200,this.center.y,50,this.§_-J1L§);
      }
      
      private function §_-J23§(param1:starling.events.Event) : void
      {
         showTurnTip();
         §_-z9§();
         var _loc2_:Point = Pool.getPoint(this.center.x - 200,this.center.y);
         replaceRedArrow(_loc2_);
         Pool.putPoint(_loc2_);
      }
      
      private function §_-J1L§(param1:Mine) : void
      {
         var rifleRecord:§_-O2H§;
         var rifleParamSet:§_-C3e§;
         var rifle:Weapon;
         var point:Point;
         var mine:Mine = param1;
         this.mine = mine;
         §_-F2Z§ = 3;
         this.state = §_-B1R§;
         §_-62Y§();
         this.§_-t2§(false);
         §_-Zd§.once(mine.§_-Y2I§ as EventDispatcher,§_-42G§.§_-X1C§,function():void
         {
            makeMineHelper(mine);
         });
         this.§_-4Q§(mine,1,300,-25);
         showTurnTip();
         rifleRecord = §_-G1p§.§_-I4§(§_-q24§.RIFLE);
         rifleParamSet = rifleRecord.§_-wF§.clone();
         rifleParamSet.explosionRadius = new §_-TA§(0);
         rifle = rifleRecord.getWeapon();
         rifle.§_-d1P§(rifleParamSet);
         point = Pool.getPoint(this.center.x + 50,this.center.y);
         §_-9q§(point,§_-q24§.RIFLE,this.§_-q2p§);
         Pool.putPoint(point);
         Application.userProfile.build.§_-cr§([]);
      }
      
      private function §_-q2p§(param1:§_-v24§) : void
      {
         var zombie:§_-01J§;
         var event:§_-v24§ = param1;
         this.state = §_-G1b§;
         replaceRedArrow();
         showTurnTip();
         this.activeUnit.§_-e14§(true);
         this.activeUnit.§_-P1W§(§_-q24§.RIFLE);
         zombie = §_-336§[0].getUnits()[0];
         §_-Zd§.once(zombie as EventDispatcher,§_-L3Q§.§_-Qw§,function(param1:starling.events.Event):void
         {
            replaceRedArrow();
            showTurnTip();
         });
         zombie.§_-e14§(true);
         zombie.addEventListener(§_-L3Q§.DISPOSED,function(param1:starling.events.Event):void
         {
            if(§_-X1j§.§_-12n§.gameMaster == null)
            {
               return;
            }
            §_-EL§(§_-q24§.RIFLE);
            §_-X1j§.§_-12n§.scene.gameInterface.§_-Q2D§();
            state = §_-S2n§;
         });
         this.§_-t2§(false);
      }
      
      private function §_-C8§(param1:starling.events.Event = null) : void
      {
         if(§_-336§[0].§_-Z2G§() == 1)
         {
            return;
         }
         this.§_-DB§.§_-q28§(700);
         var _loc2_:§_-01J§ = §_-L1x§.create(this.§_-DB§,this.center.x + 250,this.center.y + 27);
         _loc2_.§_-o1z§();
         §_-336§[0].§_-D3t§(_loc2_);
         _loc2_.§_-e14§(true);
         showTurnTip();
         this.§_-22Q§();
         this.activeUnit.addEventListener(§_-L3Q§.WEAPON_SELECT,this.§_-A2O§);
         this.§_-t2§(true);
         §_-X1j§.§_-12n§.scene.gameInterface.§_-Fb§.addEventListener(§_-L3Q§.AFTER_OPEN_CLOSE_BAG,this.openBag);
         §_-f2C§(§_-Q2v§.§_-k2S§);
         §_-X1j§.§_-12n§.scene.gameInterface.§_-9M§();
      }
      
      private function §_-A2O§(param1:starling.events.Event = null) : void
      {
         §_-X1j§.§_-12n§.scene.gameInterface.§_-Fb§.removeEventListener(§_-L3Q§.AFTER_OPEN_CLOSE_BAG,this.openBag);
         §_-z9§();
         §_-62Y§();
         this.activeUnit.removeEventListener(§_-L3Q§.WEAPON_SELECT,this.§_-A2O§);
         this.§_-t2§(false);
         showTurnTip();
         var _loc2_:Point = Pool.getPoint(this.center.x + 380,this.center.y);
         replaceRedArrow(_loc2_);
         Pool.putPoint(_loc2_);
         this.activeUnit.§_-e14§(false);
         §_-1b§(Mine,§_-q24§.MINE,this.center.x + 380,this.center.y,50,this.§_-18§);
      }
      
      private function §_-18§(param1:Mine) : void
      {
         var mine:Mine = param1;
         replaceRedArrow();
         mine.x = this.center.x + 395;
         mine.y = this.center.y + 35;
         §_-EL§();
         Application.userProfile.build.§_-cr§([]);
         showTurnTip();
         this.makeMineHelper(mine);
         §_-Zd§.once(this.activeUnit as EventDispatcher,§_-L3Q§.§_-Qw§,function(param1:starling.events.Event = null):void
         {
            hitByMine = true;
         });
         §_-Zd§.once(mine,§_-L3Q§.DISPOSED,this.§_-I3L§);
      }
      
      private function §_-I3L§(param1:starling.events.Event = null) : void
      {
         if(!this.activeUnit || this.activeUnit.disposed)
         {
            return;
         }
         §_-EL§();
         Application.userProfile.build.§_-cr§([]);
         if(!this.hitByMine)
         {
            var _temp_2:* = §§findproperty(§_-F2Z§);
            ++§_-F2Z§;
         }
         showTurnTip();
         var _loc2_:Point = Pool.getPoint(this.center.x + 150,this.center.y);
         §_-9q§(_loc2_,§_-q24§.BAT,this.§_-53V§);
         Pool.putPoint(_loc2_);
      }
      
      private function §_-53V§(param1:starling.events.Event = null) : void
      {
         var zombie:§_-01J§;
         var point:Point;
         var e:starling.events.Event = param1;
         this.state = §_-xL§;
         showTurnTip();
         this.activeUnit.§_-P1W§(§_-q24§.BAT);
         zombie = §_-336§[0].getUnits()[0];
         point = Pool.getPoint(zombie.x - 35,zombie.y - 20);
         replaceRedArrow(point);
         Pool.putPoint(point);
         §_-Zd§.once(zombie as EventDispatcher,§_-L3Q§.§_-Qw§,function(param1:starling.events.Event):void
         {
            replaceRedArrow();
         });
         zombie.addEventListener(§_-L3Q§.DISPOSED,function(param1:starling.events.Event):void
         {
            if(§_-X1j§.§_-12n§.gameMaster == null || !activeUnit)
            {
               return;
            }
            activeUnit.§_-e14§(false);
            ++state;
            §_-o2a§();
         });
      }
      
      private function §_-o2a§() : void
      {
         §_-EL§();
         showTurnTip(this.§_-W16§);
      }
      
      private function §_-W16§(param1:starling.events.Event = null) : void
      {
         this.§_-A1H§(§_-J1§.WINNER);
      }
      
      private function §_-135§(param1:starling.events.Event = null) : void
      {
         this.§_-A1H§(§_-J1§.§_-23m§);
      }
      
      private function §_-A1H§(param1:§_-J1§) : void
      {
         if(§_-X1j§.§_-12n§.gameMaster == null)
         {
            return;
         }
         §_-X1j§.§_-12n§.scene.removeEventListener(§_-L3Q§.FRAME,this.onFrame);
         this.mine = null;
         this.§_-s2J§ = null;
         this.§_-b2i§.§_-BR§(param1);
         §_-RF§.fire(§_-RF§.§_-y1J§);
         if(Boolean(§_-4O§) && §_-4O§.exists)
         {
            §_-4O§.hide();
            §_-4O§.dispose();
            §_-4O§ = null;
         }
         if(this.§_-52§ >= 0)
         {
            clearInterval(this.§_-52§);
            this.§_-52§ = -1;
         }
      }
      
      private function makeMineHelper(param1:Mine) : Image
      {
         var helper:Shape;
         var helperImage:Image = null;
         var mine:Mine = param1;
         this.mine = mine;
         helper = new Shape();
         helper.x = mine.x;
         helper.y = mine.y;
         helper.graphics.beginFill(16737894,0.3);
         helper.graphics.drawCircle(0,0,60);
         helperImage = this.§_-s2J§ = §_-c1S§.§_-q13§(helper);
         §_-X1j§.§_-12n§.scene.addElementToCertainSortingLayer(helperImage,SortingLayer.UNIT_LAYER);
         §_-X1j§.§_-12n§.scene.addEventListener(§_-L3Q§.FRAME,this.onFrame);
         §_-Zd§.once(mine,§_-L3Q§.DISPOSED,function(param1:starling.events.Event):void
         {
            §_-X1j§.§_-12n§.scene.removeEventListener(§_-L3Q§.FRAME,onFrame);
            §_-X1j§.§_-12n§.scene.removeElement(helperImage);
         });
         return helperImage;
      }
      
      private function onFrame(param1:starling.events.Event) : void
      {
         this.§_-s2J§.x = this.mine.x - this.§_-s2J§.width / 2;
         this.§_-s2J§.y = this.mine.y - this.§_-s2J§.height / 2;
      }
      
      private function §_-4Q§(param1:Mine, param2:int, param3:int, param4:int) : void
      {
         §_-Ia§.§_-33o§(40,this.§_-L3U§,param1,param2,param3,param4);
      }
      
      private function §_-L3U§(param1:Mine, param2:int, param3:int, param4:int) : void
      {
         if(Boolean(param1) && Boolean(param1.§_-Y2I§))
         {
            this.§_-52§ = setInterval(this.§_-C3z§,20,param2,param3,param4);
         }
      }
      
      private function §_-C3z§(param1:int, param2:int, param3:int) : void
      {
         if(!this.mine || !this.mine.§_-Y2I§ || this.activeUnit == null)
         {
            clearInterval(this.§_-52§);
            this.§_-52§ = -1;
            return;
         }
         if(§_-H3D§.distance(Math.abs(this.mine.x - this.activeUnit.x),Math.abs(this.mine.y - this.activeUnit.y)) < 80 || §_-H3D§.sign(this.activeUnit.x - this.mine.x) != param1)
         {
            new PhaseAmmo(this.activeUnit,this.activeUnit.x,this.activeUnit.y,true,this.activeUnit as §_-F3o§,16777215,60);
            §_-h2B§.play(§_-d27§.EMERGENCY_TELEPORT);
            Physics.teleportUnit(this.activeUnit as §_-F3o§,this.mine.x + param2,this.mine.y + param3);
         }
      }
      
      override protected function §_-A3c§(param1:uint, param2:§_-81l§, param3:Array) : §_-V23§
      {
         var _loc5_:int = 0;
         var _loc6_:UserProfile = null;
         var _loc7_:Point = null;
         var _loc8_:§_-01J§ = null;
         var _loc4_:§_-V23§ = new §_-V23§(param2.name,param1,§_-y1o§.§_-Y2B§,§_-g1d§);
         _loc4_.§_-uR§(param2.units[0]);
         _loc5_ = 0;
         while(_loc5_ < param2.units.length)
         {
            _loc6_ = param2.units[_loc5_];
            _loc7_ = param3[_loc5_];
            _loc8_ = §_-L1x§.create(_loc6_,_loc7_.x,_loc7_.y);
            _loc8_.§_-o1z§();
            _loc4_.§_-D3t§(_loc8_);
            _loc5_++;
         }
         return _loc4_;
      }
      
      private function §_-22Q§() : void
      {
         var _loc2_:§_-O2H§ = null;
         var _loc1_:§_-2m§ = §_-72U§().§_-V2J§();
         if(_loc1_.§_-d3§(§_-q24§.MINE) < 1)
         {
            _loc2_ = §_-G1p§.§_-I4§(§_-q24§.MINE);
            _loc1_.§_-Um§(_loc2_,1);
         }
      }
      
      private function §_-t2§(param1:Boolean) : void
      {
         §_-X1j§.§_-12n§.scene.gameInterface.§_-z26§(!param1);
         (currentUnit || this.activeUnit).§_-vp§ = param1;
      }
      
      override public function clear() : void
      {
         var _loc1_:Array = null;
         var _loc2_:Point = null;
         for each(_loc1_ in §_-32L§)
         {
            for each(_loc2_ in _loc1_)
            {
               Pool.putPoint(_loc2_);
            }
            _loc1_.length = 0;
            _loc1_ = null;
         }
         §_-32L§.length = 0;
         §_-32L§ = null;
         Pool.putPoint(this.center);
         this.center = null;
         this.§_-DB§ = null;
         this.activeUnit = null;
         super.clear();
      }
   }
}

