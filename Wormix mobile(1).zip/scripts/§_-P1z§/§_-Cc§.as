package §_-P1z§
{
   import §_-31N§.§_-42G§;
   import §_-51p§.§_-W2e§;
   import §_-5Y§.§_-t2O§;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-O2H§;
   import §_-9e§.§_-73e§;
   import §_-9e§.§_-8O§;
   import §_-9e§.§_-A18§;
   import §_-A1K§.§_-TA§;
   import §_-C2M§.§_-u2T§;
   import §_-H2g§.§_-di§;
   import §_-P1B§.§_-b21§;
   import §_-Tm§.Action;
   import §_-Tm§.§_-K1I§;
   import §_-Tm§.§_-RF§;
   import §_-U1i§.§_-J1§;
   import §_-Y1b§.§_-o2i§;
   import §_-YF§.§_-q2v§;
   import §_-Z1K§.§_-q24§;
   import §_-l1K§.§_-W2f§;
   import §_-l1g§.§_-L3Q§;
   import §_-v2t§.§_-03r§;
   import §_-w2i§.§_-Zd§;
   import feathers.events.FeathersEventType;
   import flash.geom.ColorTransform;
   import flash.geom.Point;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-Q2v§;
   import ru.pragmatix.wormix.objects.Waypoint;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-8K§;
   import ru.pragmatix.wormix.objects.§_-V1L§;
   import ru.pragmatix.wormix.utils.§_-MN§;
   import ru.pragmatix.wormix.weapons.Weapon;
   import ru.pragmatix.wormix.weapons.§_-73v§;
   import starling.display.DisplayObject;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.utils.Pool;
   
   public class §_-Cc§ extends §_-o2i§
   {
      
      private var §_-b2i§:§_-03r§ = new §_-03r§();
      
      private var arrow:§_-di§;
      
      private var §_-L1d§:§_-W2e§;
      
      private var target:§_-V1L§;
      
      private const HELP_RECORD_TURN1:Array = [{"text":§_-u2T§.LEARNING_2_TURN_1_N1_TEXT},{
         "text":§_-u2T§.LEARNING_2_TURN_1_N2_TEXT,
         "graphic":"jump"
      }];
      
      private const HELP_RECORD_TURN2:Array = [{
         "text":§_-u2T§.LEARNING_2_TURN_2_TEXT,
         "graphic":"backjump"
      }];
      
      private const HELP_RECORD_TURN3:Array = [{"text":§_-u2T§.LEARNING_2_TURN_3_TEXT}];
      
      private const HELP_RECORD_TURN4:Array = [{"text":§_-u2T§.LEARNING_2_TURN_4_TEXT}];
      
      private var §_-D1R§:Number;
      
      public function §_-Cc§()
      {
         super(44,true,true);
      }
      
      override public function §_-H1J§() : §_-73e§
      {
         var _loc1_:§_-73e§ = null;
         _loc1_ = new §_-73e§();
         _loc1_.online = false;
         _loc1_.backpackEnabled = false;
         _loc1_.§_-v17§ = false;
         _loc1_.§_-f2m§ = false;
         _loc1_.§_-724§ = false;
         _loc1_.§_-z2U§ = false;
         _loc1_.§_-nA§ = false;
         _loc1_.achievements = false;
         _loc1_.water = §_-A18§.§_-J24§;
         _loc1_.timer = §_-8O§.OFF;
         _loc1_.§_-b2i§ = this.§_-b2i§;
         return _loc1_;
      }
      
      override protected function §_-C2E§() : void
      {
         super.§_-C2E§();
         §_-72U§().build.§_-cr§([]);
         §_-132§ = 1;
         §_-32L§ = [[map.§_-FV§[4]]];
      }
      
      override public function §_-9T§() : void
      {
         super.§_-9T§();
         §_-e1r§("LearningMission2_MovingPart",map.§_-FV§[4].x - 20,map.§_-FV§[4].y + 30,0,1);
         §_-e1r§("LearningMission2_MovingPart",map.§_-FV§[4].x + 70,map.§_-FV§[4].y - 90,0,1);
         §_-e1r§("LearningMission2_StandingPart",map.§_-FV§[4].x - 850,map.§_-FV§[4].y + 60,0,1);
         §_-X1j§.§_-12n§.scene.gotoNextTurn(new §_-TA§(1),false);
         §_-4O§.§_-41§([this.HELP_RECORD_TURN1[0]]);
         §_-X1j§.§_-12n§.scene.gameInterface.§_-Bn§(§_-Q2v§.§_-BG§);
      }
      
      override protected function §_-03f§(param1:uint) : void
      {
         /*
          * Decompilation error
          * Code may be obfuscated
          * Error type: ClassCastException (null)
          */
         throw new flash.errors.IllegalOperationError("Not decompiled due to error");
      }
      
      private function §_-l2l§(param1:Number, param2:Number) : void
      {
         if(this.arrow)
         {
            §_-X1j§.§_-12n§.scene.hideDragonBonedClip(this.arrow);
         }
         this.arrow = §_-X1j§.§_-12n§.scene.showDragonBonedClip("TutorialArrowMap",param1,param2);
      }
      
      private function §_-a28§() : void
      {
         §_-X1j§.§_-12n§.scene.sceneCamera.moveTo(currentUnit.x - 200,currentUnit.y);
         §_-X1j§.§_-12n§.scene.hideDragonBonedClip(this.arrow);
         this.arrow = null;
         currentUnit.§_-01D§();
         currentUnit.turnLeft();
         §_-X1j§.§_-12n§.scene.gameObjectProcessor.§_-9I§([§_-RF§.§_-K1K§,§_-RF§.§_-Z24§,§_-RF§.§_-h2w§,§_-RF§.§_-m2J§]);
         §_-Zd§.once(currentUnit.getPhysicModel() as EventDispatcher,§_-42G§.§_-K2J§,this.§_-X27§);
         §_-4O§.§_-41§([this.HELP_RECORD_TURN1[1]]);
         §_-X1j§.§_-12n§.scene.gameInterface.§_-Bn§(§_-Q2v§.§_-t1o§);
      }
      
      private function §_-X27§(param1:Event = null) : void
      {
         §_-4O§.§_-41§(this.HELP_RECORD_TURN2);
         var _loc2_:Point = Pool.getPoint(map.§_-FV§[4].x - 390,map.§_-FV§[4].y + 230);
         this.§_-l2l§(_loc2_.x,_loc2_.y);
         §_-X1j§.§_-12n§.scene.gameObjectProcessor.§_-9I§([]);
         Waypoint.§_-22P§(_loc2_.x,_loc2_.y,20,currentUnit,this.§_-pB§);
         §_-X1j§.§_-12n§.scene.sceneCamera.moveTo(currentUnit.x - 100,currentUnit.y + 50);
         §_-X1j§.§_-12n§.scene.gameInterface.§_-Bn§(§_-Q2v§.§_-BG§);
         Pool.putPoint(_loc2_);
      }
      
      private function §_-pB§() : void
      {
         if(currentUnit.weapon)
         {
            return;
         }
         this.§_-B11§();
         §_-X1j§.§_-12n§.scene.gameInterface.§_-Bn§(§_-Q2v§.§_-J1S§);
         this.§_-l2l§(this.§_-L1d§.x,this.§_-L1d§.y - 20);
         Waypoint.§_-22P§(map.§_-FV§[4].x - 430,map.§_-FV§[4].y + 160,25,currentUnit,this.§_-s2L§);
      }
      
      private function §_-s2L§() : void
      {
         §_-4O§.§_-41§(this.HELP_RECORD_TURN3);
         §_-X1j§.§_-12n§.scene.gameInterface.§_-Bn§(§_-Q2v§.§_-BG§);
      }
      
      private function §_-S1G§(param1:Event) : void
      {
         §_-X1j§.§_-12n§.scene.gameInterface.§_-q10§();
         §_-4O§.§_-41§(this.HELP_RECORD_TURN4);
         currentUnit.§_-P1W§(§_-q24§.SHOTGUN);
         §_-X1j§.§_-12n§.scene.hideDragonBonedClip(this.arrow);
         this.arrow = null;
         this.target = new §_-V1L§(map.§_-FV§[4].x - 800,map.§_-FV§[4].y + 50);
         this.target.addEventListener(§_-L3Q§.§_-Qw§,this.§_-o2a§);
         this.target.§_-l2l§(2);
         this.§_-D1R§ = currentUnit.weapon.§_-R1d§.length;
         mark = this.§_-ea§();
         §_-X1j§.§_-12n§.scene.addEventListener(§_-L3Q§.FRAME,this.§_-138§);
         §_-X1j§.§_-12n§.scene.addEventListener(§_-L3Q§.FRAME,this.§_-q1m§);
         §_-X1j§.§_-12n§.scene.gameInterface.§_-Bn§(§_-Q2v§.§_-33f§);
      }
      
      private function §_-ea§() : DisplayObject
      {
         mark = §_-X1j§.§_-12n§.scene.showUIClip(§_-q2v§.§_-y26§,0,0);
         §_-MN§.§_-H1e§(mark,new ColorTransform(1.2,0.6,0.6,0.5));
         this.§_-138§();
         return mark;
      }
      
      private function §_-q1m§(param1:Event = null) : void
      {
         var _loc2_:Number = NaN;
         if(Boolean(currentUnit) && Boolean(currentUnit.weapon))
         {
            _loc2_ = Number(Math.atan2(this.target.y - currentUnit.y,this.target.x - currentUnit.x));
            if(Math.abs(§_-W2f§(currentUnit.weapon.§_-G3H§()).getAngle() - _loc2_) < 0.02)
            {
               §_-X1j§.§_-12n§.scene.removeEventListener(§_-L3Q§.FRAME,this.§_-q1m§);
               §_-X1j§.§_-12n§.scene.gameInterface.§_-Bn§(§_-Q2v§.§_-619§);
            }
         }
      }
      
      private function §_-138§(param1:Event = null) : void
      {
         var _loc3_:Number = NaN;
         var _loc2_:§_-01J§ = currentUnit;
         if(Boolean(this.target) && Boolean(_loc2_) && !_loc2_.disposed)
         {
            _loc3_ = Number(Math.atan2(this.target.y - _loc2_.y,this.target.x - _loc2_.x));
            mark.x = _loc2_.x + (§_-W2f§.§_-o18§ + this.§_-D1R§) * Math.cos(_loc3_);
            mark.y = _loc2_.y + (§_-W2f§.§_-o18§ + this.§_-D1R§) * Math.sin(_loc3_);
         }
      }
      
      private function §_-o2a§(param1:Event) : void
      {
         if(currentUnit.weapon)
         {
            currentUnit.weapon.detach();
         }
         currentUnit.§_-e14§(true);
         currentUnit.§_-81o§ = null;
         this.clear();
         §_-4O§.hide();
         §_-4O§.dispose();
         §_-RF§.fire(§_-RF§.§_-y1J§);
         this.§_-b2i§.§_-BR§(§_-J1§.WINNER);
      }
      
      override public function clear() : void
      {
         super.clear();
         this.target = null;
         if(this.arrow != null)
         {
            §_-X1j§.§_-12n§.scene.hideDragonBonedClip(this.arrow);
            this.arrow = null;
         }
         if(mark)
         {
            §_-X1j§.§_-12n§.scene.hideUIClip(mark);
            mark.dispose();
            mark = null;
         }
         §_-X1j§.§_-12n§.scene.gameInterface.§_-q10§();
         this.§_-L1d§ = null;
         var _loc1_:§_-O2H§ = §_-G1p§.§_-I4§(§_-q24§.SHOTGUN);
         _loc1_.bagX = 4;
         §_-73v§.getWeapon(§_-q24§.SHOTGUN).shots.value = 1;
         this.§_-6g§();
      }
      
      private function §_-L1m§(param1:Event) : void
      {
         currentUnit.attributes.hp.restore(currentUnit.attributes.hp.§_-33H§() - currentUnit.hp,§_-b21§.§_-h1U§,false,false);
         currentUnit.setSpeedXY(0,0);
      }
      
      private function §_-B11§() : void
      {
         §_-X1j§.§_-12n§.scene.addEventListener(§_-K1I§.ACTION,this.§_-R1G§);
      }
      
      private function §_-6g§() : void
      {
         §_-X1j§.§_-12n§.scene.removeEventListener(§_-K1I§.ACTION,this.§_-R1G§);
      }
      
      private function §_-R1G§(param1:§_-K1I§) : void
      {
         var _loc2_:int = 0;
         while(_loc2_ < param1.actions.length)
         {
            if(Action(param1.actions[_loc2_]).commandId == §_-RF§.§_-m2J§)
            {
               this.§_-6g§();
               §_-X1j§.§_-12n§.scene.gameInterface.§_-Bn§(§_-Q2v§.§_-Z1A§);
            }
            _loc2_++;
         }
      }
   }
}

