package §_-P1z§
{
   import §_-533§.§_-c2b§;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-zF§;
   import §_-9e§.§_-73e§;
   import §_-9e§.§_-8O§;
   import §_-9e§.§_-A18§;
   import §_-A1K§.§_-TA§;
   import §_-C2M§.§_-u2T§;
   import §_-Tm§.§_-RF§;
   import §_-U1i§.§_-J1§;
   import §_-Y1b§.§_-o2i§;
   import §_-Z1K§.§_-q24§;
   import §_-hO§.§_-v24§;
   import §_-l1K§.*;
   import §_-l1g§.§_-L3Q§;
   import §_-v2t§.§_-03r§;
   import §_-w2i§.§_-Ia§;
   import com.distriqt.extension.application.Application;
   import com.distriqt.extension.application.display.Display;
   import com.distriqt.extension.application.display.DisplayCutout;
   import flash.geom.Point;
   import flash.geom.Rectangle;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.Command;
   import ru.pragmatix.wormix.controls.system.ControlSystems;
   import ru.pragmatix.wormix.gui.§_-Q2v§;
   import ru.pragmatix.wormix.messages.structures.WeaponStructure;
   import ru.pragmatix.wormix.objects.Waypoint;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.objects.§_-V1L§;
   import ru.pragmatix.wormix.weapons.Girder;
   import ru.pragmatix.wormix.weapons.ammo.DynamiteStick;
   import starling.core.Starling;
   import starling.events.Event;
   import starling.utils.AssetManager;
   import starling.utils.Pool;
   import starling.utils.SystemUtil;
   
   public class §_-j2E§ extends §_-o2i§
   {
      
      private static const §_-yc§:int = 1;
      
      private static const §_-w1r§:int = 2;
      
      private static const §_-x17§:int = 3;
      
      private static const §_-D39§:int = 4;
      
      private static const §_-p2n§:int = 5;
      
      private static const §_-K6§:int = 6;
      
      private static const §_-d6§:int = 7;
      
      private var state:int;
      
      private var §_-b2i§:§_-03r§ = new §_-03r§();
      
      private var §_-Y1n§:§_-V1L§;
      
      private var center:Point;
      
      private const §_-aP§:Array = [{"text":§_-u2T§.LEARNING_4_TURN_1_TEXT},{"text":§_-u2T§.LEARNING_4_TURN_2_TEXT},{"text":§_-u2T§.LEARNING_4_TURN_3_TEXT},{"text":§_-u2T§.LEARNING_4_TURN_4_TEXT},{"text":§_-u2T§.LEARNING_4_TURN_5_TEXT},{"text":§_-u2T§.LEARNING_4_TURN_6_TEXT},{"text":§_-u2T§.LEARNING_4_TURN_7_TEXT},{"text":§_-u2T§.LEARNING_4_TURN_8_TEXT},{"text":§_-u2T§.LEARNING_4_TURN_9_TEXT}];
      
      public function §_-j2E§()
      {
         super(39,true,false);
         §_-qe§ = this.§_-aP§;
         this.state = 0;
      }
      
      override public function §_-H1J§() : §_-73e§
      {
         var _loc1_:§_-73e§ = new §_-73e§();
         _loc1_.online = false;
         _loc1_.backpackEnabled = true;
         _loc1_.§_-v17§ = false;
         _loc1_.§_-f2m§ = false;
         _loc1_.§_-724§ = false;
         _loc1_.§_-z2U§ = false;
         _loc1_.§_-nA§ = false;
         _loc1_.achievements = false;
         _loc1_.water = §_-A18§.§_-J24§;
         _loc1_.timer = §_-8O§.OFF;
         _loc1_.§_-b2i§ = this.§_-b2i§;
         return _loc1_;
      }
      
      override protected function §_-C2E§() : void
      {
         super.§_-C2E§();
         §_-132§ = 1;
         §_-72U§().build.§_-cr§([]);
         this.center = Pool.getPoint(§_-X1j§.§_-12n§.scene.width / 2 + 55,§_-X1j§.§_-12n§.scene.height / 2 - 130);
         §_-32L§ = [[Pool.getPoint(this.center.x - 120,this.center.y - 50)]];
         §_-F2Z§ = 0;
      }
      
      override public function §_-9T§() : void
      {
         super.§_-9T§();
         §_-e1r§("LearningMission4_CentralPart",this.center.x - 90,this.center.y + 190,0,1);
         §_-X1j§.§_-12n§.scene.gotoNextTurn(new §_-TA§(1),false);
         §_-4O§.hide();
         §_-X1j§.§_-12n§.scene.addPermanentZone(Pool.getRectangle(this.center.x + 140,this.center.y + 550,100,100));
      }
      
      override protected function §_-03f§(param1:uint) : void
      {
         if(param1 == 1)
         {
            this.state = §_-yc§;
         }
         switch(this.state)
         {
            case §_-yc§:
               currentUnit.§_-e14§(false);
               §_-4O§.show();
               §_-72U§().build.§_-cr§([]);
               this.§_-u1H§();
               break;
            case §_-w1r§:
               §_-72U§().build.§_-cr§([new WeaponStructure(§_-q24§.PNEUMATIC_DRILL,-1)]);
               currentUnit.§_-P1W§(§_-q24§.PNEUMATIC_DRILL);
               §_-z9§();
               §_-X1j§.§_-12n§.scene.gameInterface.controlsLayout.addEventListener(Event.TRIGGERED,this.§_-X2b§);
               this.§_-z2V§();
               break;
            case §_-D39§:
               §_-72U§().build.§_-cr§([new WeaponStructure(§_-q24§.AUGER,-1)]);
               currentUnit.§_-P1W§(§_-q24§.AUGER);
               break;
            case §_-p2n§:
            case §_-d6§:
               §_-72U§().build.§_-cr§([]);
               break;
            case §_-K6§:
               §_-72U§().build.§_-cr§([new WeaponStructure(§_-q24§.DYNAMITE,-1)]);
               currentUnit.§_-P1W§(§_-q24§.DYNAMITE);
         }
         §_-X1j§.§_-12n§.scene.gameInterface.§_-z26§(true);
      }
      
      private function §_-u1H§() : void
      {
         var _loc1_:Point = Pool.getPoint(this.center.x + 20,this.center.y + 160);
         §_-9q§(_loc1_,§_-q24§.PNEUMATIC_DRILL,this.§_-S1s§);
         Pool.putPoint(_loc1_);
         §_-f2C§(§_-Q2v§.§_-J1S§);
         showTurnTip();
      }
      
      private function §_-S1s§(param1:§_-v24§) : void
      {
         this.state = §_-w1r§;
         currentUnit.x = this.center.x + 20;
         currentUnit.§_-e14§(true);
         currentUnit.§_-P1W§(§_-q24§.PNEUMATIC_DRILL);
         replaceRedArrow();
         §_-X1j§.§_-12n§.scene.gameInterface.§_-q10§();
         Waypoint.§_-22P§(currentUnit.x,this.center.y + 490,40,currentUnit,this.§_-r2R§);
         this.§_-z2V§();
         §_-X1j§.§_-12n§.scene.gameInterface.controlsLayout.shootButton.addEventListener(Event.TRIGGERED,this.§_-X2b§);
         showTurnTip();
      }
      
      private function §_-X2b§(param1:Event) : void
      {
         §_-X1j§.§_-12n§.scene.gameInterface.controlsLayout.shootButton.removeEventListener(Event.TRIGGERED,this.§_-X2b§);
         §_-z9§();
      }
      
      private function §_-r2R§() : void
      {
         this.state = §_-x17§;
         currentUnit.§_-e14§(false);
         §_-EL§();
         var _loc1_:Point = Pool.getPoint(this.center.x + 100,this.center.y + 590);
         §_-9q§(_loc1_,§_-q24§.AUGER,this.§_-11y§);
         Pool.putPoint(_loc1_);
         §_-f2C§(§_-Q2v§.§_-J1S§);
         showTurnTip();
      }
      
      private function §_-11y§(param1:§_-v24§) : void
      {
         this.state = §_-D39§;
         currentUnit.§_-P1W§(§_-q24§.AUGER);
         §_-X1j§.§_-12n§.scene.gameObjectProcessor.§_-9I§([§_-RF§.§_-XX§,§_-RF§.§_-537§,§_-RF§.§_-o1G§,§_-RF§.§_-gI§,§_-RF§.§_-E3N§,§_-RF§.§_-N2h§]);
         replaceRedArrow(Pool.getPoint(this.center.x - 70,this.center.y + 600));
         Waypoint.§_-22P§(this.center.x - 65,currentUnit.y,40,currentUnit,this.§_-K1v§);
         Waypoint.§_-22P§(currentUnit.x - 10,currentUnit.y,40,currentUnit,§_-z9§);
         §_-f2C§(§_-Q2v§.§_-BG§);
         showTurnTip();
      }
      
      private function §_-K1v§() : void
      {
         var _loc1_:Point = Pool.getPoint(this.center.x - 330,this.center.y + 570);
         §_-9q§(_loc1_,§_-q24§.DYNAMITE,this.§_-L2R§);
         Pool.putPoint(_loc1_);
         Waypoint.§_-22P§(currentUnit.x - 320,currentUnit.y,140,currentUnit,this.§_-s1t§);
         Waypoint.§_-22P§(currentUnit.x - 100,currentUnit.y,40,currentUnit,§_-z9§);
         this.§_-z2V§();
         showTurnTip();
      }
      
      private function §_-s1t§() : void
      {
         this.state = §_-p2n§;
         §_-EL§();
         currentUnit.§_-e14§(true);
         §_-X1j§.§_-12n§.scene.sceneCamera.moveTo(this.center.x - 300,this.center.y + 450);
         §_-Ia§.§_-33o§(30,currentUnit.§_-e14§,false);
         §_-EL§();
         showTurnTip();
      }
      
      private function §_-L2R§(param1:§_-v24§) : void
      {
         replaceRedArrow();
         currentUnit.§_-P1W§(§_-q24§.DYNAMITE);
         showTurnTip(this.§_-m1S§);
         currentUnit.§_-e14§(true);
         ControlSystems.instance.setCommandDisabled(Command.Shoot,true);
         this.state = §_-K6§;
      }
      
      private function §_-m1S§(param1:Event) : void
      {
         §_-1b§(DynamiteStick,§_-q24§.DYNAMITE,this.center.x - 400,this.center.y + 570,50,this.§_-12V§);
         ControlSystems.instance.setCommandDisabled(Command.Shoot,false);
         currentUnit.§_-e14§(false);
         this.§_-Y1n§ = this.§_-j2V§(this.center.x - 400,this.center.y + 570,this.§_-R2k§);
         §_-4O§.§_-VT§().addEventListener(Event.TRIGGERED,this.§_-m1S§);
         showTurnTip();
      }
      
      private function §_-12V§(param1:§_-F3o§) : void
      {
         this.state = §_-d6§;
      }
      
      private function §_-R2k§(param1:Event = null) : void
      {
         §_-EL§();
         showTurnTip(this.finish);
      }
      
      private function finish(param1:Event = null) : void
      {
         this.§_-b2i§.§_-BR§(§_-J1§.WINNER);
         §_-RF§.fire(§_-RF§.§_-y1J§);
         if(§_-4O§)
         {
            §_-4O§.hide();
            §_-4O§.dispose();
            §_-4O§ = null;
         }
      }
      
      private function §_-z2V§() : void
      {
         §_-f2C§(§_-Q2v§.§_-619§);
      }
      
      private function §_-j2V§(param1:int, param2:int, param3:Function) : §_-V1L§
      {
         var _loc4_:§_-V1L§ = new §_-V1L§(param1,param2);
         _loc4_.addEventListener(§_-L3Q§.§_-Qw§,param3);
         _loc4_.§_-l2l§(2);
         return _loc4_;
      }
      
      override public function clear() : void
      {
         super.clear();
         this.§_-Y1n§ = null;
         ControlSystems.instance.setCommandDisabled(Command.Shoot,false);
      }
   }
}

