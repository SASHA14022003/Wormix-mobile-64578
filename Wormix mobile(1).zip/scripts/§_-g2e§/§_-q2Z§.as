package §_-g2e§
{
   import §_-62§.§_-G1p§;
   import §_-79§.§_-ps§;
   import §_-A1K§.§_-LE§;
   import §_-A1K§.§_-TA§;
   import §_-GQ§.§_-31v§;
   import §_-P2i§.§_-b7§;
   import §_-l1g§.§_-L3Q§;
   import §_-w2i§.§_-Ia§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.model.bonus.§_-x2M§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.physics.model.UnitPhysicModel;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.weapons.Jetpack;
   import starling.events.Event;
   
   public class §_-q2Z§
   {
      
      private static const §_-r23§:§_-TA§ = new §_-TA§(5);
      
      private static const §_-Q10§:§_-TA§ = new §_-TA§(§_-r23§.value + 7);
      
      private static var §_-o12§:§_-TA§ = new §_-TA§(10);
      
      private static var §_-lk§:§_-TA§ = new §_-TA§(9);
      
      protected var §_-o2N§:§_-TA§ = new §_-TA§(15);
      
      private var §_-016§:§_-LE§ = new §_-LE§(§_-o12§.value);
      
      private var §_-81D§:§_-LE§ = new §_-LE§(§_-lk§.value);
      
      private var jumping:Boolean = false;
      
      protected var §_-J2§:§_-TA§ = new §_-TA§(0);
      
      protected var §_-l1J§:§_-TA§ = new §_-TA§(0);
      
      protected var §_-G33§:uint = 0;
      
      protected var §_-r21§:Boolean = true;
      
      protected var owner:§_-01J§;
      
      public function §_-q2Z§(param1:§_-01J§, param2:§_-q2Z§ = null)
      {
         super();
         this.owner = param1;
         if(param2)
         {
            this.§_-016§.value = param2.§_-016§.value;
            this.§_-81D§.value = param2.§_-81D§.value;
            this.§_-l1J§.value = param2.§_-l1J§.value;
         }
      }
      
      public function §_-qX§(param1:Number) : void
      {
         this.§_-016§.value += param1;
      }
      
      public function §_-J3s§(param1:Number) : void
      {
         this.§_-81D§.value += param1;
      }
      
      public function §_-T1k§(param1:Boolean) : void
      {
         var _loc2_:Number = NaN;
         var _loc3_:Number = NaN;
         if(!this.owner || !this.owner.getPhysicModel())
         {
            return;
         }
         _loc2_ = this.owner.direction * MathUtil.§_-CZ§ - MathUtil.PI_HALF;
         _loc3_ = this.§_-K12§(param1);
         var _loc4_:Boolean = this.§_-eC§(_loc2_,_loc3_);
         if(!_loc4_ && !this.owner.disposed && this.owner.stable && !this.owner.isImmobile())
         {
            this.§_-j2S§(param1);
         }
      }
      
      protected function §_-K12§(param1:Boolean) : Number
      {
         return param1 ? this.§_-81D§.value : this.§_-016§.value;
      }
      
      protected function §_-j2S§(param1:Boolean) : void
      {
         var _loc2_:Number = NaN;
         var _loc3_:Number = NaN;
         if(§_-X1j§.§_-12n§.scene.hitTestPoint(this.owner.x + this.owner.speedX,this.owner.y + this.owner.speedY))
         {
            this.owner.setSpeedXY(0,0);
         }
         else
         {
            _loc2_ = this.owner.direction * MathUtil.§_-CZ§ - MathUtil.PI_HALF;
            _loc3_ = param1 ? this.§_-81D§.value : this.§_-016§.value;
            this.jump(_loc2_,_loc3_,true);
            §_-ps§.§_-h2Y§(this.owner);
         }
      }
      
      public function §_-iU§(param1:Boolean) : void
      {
         var _loc2_:Number = NaN;
         var _loc3_:Number = NaN;
         _loc2_ = -this.owner.direction * MathUtil.§_-J3v§ - MathUtil.PI_HALF;
         _loc3_ = this.§_-K12§(param1);
         var _loc4_:Boolean = this.§_-eC§(_loc2_,_loc3_);
         if(!_loc4_ && !this.owner.disposed && this.owner.stable && !this.owner.isImmobile())
         {
            this.§_-s2o§(param1);
         }
      }
      
      protected function §_-s2o§(param1:Boolean) : void
      {
         var _loc2_:Number = NaN;
         if(§_-X1j§.§_-12n§.scene.hitTestPoint(this.owner.x - this.owner.speedX,this.owner.y + this.owner.speedY))
         {
            this.owner.setSpeedXY(0,0);
         }
         else
         {
            if(this.owner.crawling)
            {
               this.owner.§_-01D§();
            }
            _loc2_ = this.§_-K12§(param1);
            this.jump(-MathUtil.PI_HALF,_loc2_,false);
            §_-ps§.§_-h2Y§(this.owner);
            §_-Ia§.§_-33o§(§_-Q10§.value,this.§_-m1c§);
         }
      }
      
      protected function §_-m1c§() : void
      {
         if(Boolean(this.owner) && Boolean(!this.owner.disposed) && !this.owner.stable)
         {
            this.owner.setSpeedVector(-this.owner.direction * MathUtil.PI_ONE_SIX - MathUtil.PI_HALF,6);
         }
      }
      
      private function §_-eC§(param1:Number, param2:Number) : Boolean
      {
         var _loc4_:uint = 0;
         var _loc3_:Boolean = false;
         if(this.§_-SX§() && !this.owner.disposed && !this.owner.stable)
         {
            _loc4_ = uint(§_-X1j§.§_-12n§.scene.gameObjectProcessor.§_-O1C§());
            if(_loc4_ - this.§_-G33§ >= this.§_-o2N§.value)
            {
               this.extraJump(param1,param2);
               this.§_-G33§ = _loc4_;
               _loc3_ = true;
            }
         }
         return _loc3_;
      }
      
      protected function extraJump(param1:Number, param2:Number) : void
      {
         this.owner.setSpeedVector(param1,param2);
         --this.§_-J2§.value;
      }
      
      protected function jump(param1:Number, param2:Number, param3:Boolean) : void
      {
         §_-b7§.§_-C3S§ = true;
         this.owner.graphics.§_-l1j§();
         this.owner.getPhysicModel().keepUnstable = true;
         §_-Ia§.§_-33o§(§_-r23§.value,this.§_-GJ§,this.owner,param1,param2,param3);
         this.§_-G33§ = §_-X1j§.§_-12n§.scene.gameObjectProcessor.§_-O1C§();
         this.owner.addEventListener(§_-L3Q§.§_-a1V§,this.stabilize);
      }
      
      private function §_-GJ§(param1:§_-01J§, param2:Number, param3:Number, param4:Boolean) : void
      {
         if(!param1.disposed && !param1.stable)
         {
            this.jumping = true;
            param1.setSpeedVector(param2,param3);
            param1.graphics.getContainer().rotation = 0;
            this.§_-J2§.value = this.§_-l1J§.value;
            if(param1.getPhysicModel() is UnitPhysicModel && !(Boolean(param1.weapon) && param1.weapon is Jetpack && Jetpack(param1.weapon).isUsed()))
            {
               param1.getPhysicModel().keepUnstable = false;
               if(param4)
               {
                  param1.graphics.jump();
               }
               else
               {
                  param1.graphics.§_-iU§();
               }
               param1.graphics.§_-i§();
            }
         }
      }
      
      public function stabilize(param1:Event) : void
      {
         if(this.owner.hasEventListener(§_-L3Q§.§_-a1V§))
         {
            this.owner.removeEventListener(§_-L3Q§.§_-a1V§,this.stabilize);
         }
         this.owner.§_-l2A§();
         this.§_-J2§.value = 0;
         if(this.jumping)
         {
            this.jumping = false;
            if(this.owner.bonuses.§_-yQ§(§_-x2M§.MIGHTY_JUMP))
            {
               this.owner.attributes.§_-kN§.§_-Y2z§(§_-31v§.§_-U2i§.value);
               §_-Ia§.§_-33o§(§_-31v§.DURATION.value,this.§_-ZU§,this.owner);
            }
         }
      }
      
      private function §_-ZU§(param1:§_-01J§) : void
      {
         if(!param1.disposed)
         {
            param1.attributes.§_-kN§.§_-Y2z§(-§_-31v§.§_-U2i§.value);
         }
      }
      
      public function §_-81t§(param1:int) : void
      {
         this.§_-l1J§.value += param1;
      }
      
      public function §_-03m§() : void
      {
         this.§_-J2§.value = 0;
         this.§_-r21§ = false;
      }
      
      public function §_-ZG§() : void
      {
         this.§_-r21§ = true;
      }
      
      public function §_-SX§() : Boolean
      {
         var _loc1_:uint = uint(§_-X1j§.§_-12n§.scene.gameObjectProcessor.§_-O1C§());
         return this.§_-r21§ && _loc1_ - this.§_-G33§ >= this.§_-o2N§.value && this.§_-J2§.value > 0;
      }
      
      public function §_-C9§() : Boolean
      {
         return this.jumping;
      }
      
      public function destroy() : void
      {
         this.owner = null;
      }
   }
}

