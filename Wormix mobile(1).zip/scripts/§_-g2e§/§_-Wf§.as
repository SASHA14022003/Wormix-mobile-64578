package §_-g2e§
{
   import §_-31N§.§_-42G§;
   import §_-51M§.Cat;
   import §_-533§.§_-c2b§;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-zF§;
   import §_-A1K§.§_-7u§;
   import §_-A1K§.§_-TA§;
   import §_-D3A§.§_-TZ§;
   import §_-P2i§.§_-b7§;
   import §_-l1g§.§_-L3Q§;
   import com.distriqt.extension.inappbilling.InAppBilling;
   import flash.geom.Point;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.Command;
   import ru.pragmatix.wormix.game.§_-eX§;
   import ru.pragmatix.wormix.physics.HitTest;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.utils.MathUtil;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.utils.AssetManager;
   import starling.utils.Pool;
   
   public class §_-Wf§ extends §_-q2Z§
   {
      
      private static const POWER:§_-TA§ = new §_-TA§(5);
      
      private static const §_-U1N§:§_-TA§ = new §_-TA§(7);
      
      private var §_-G2X§:§_-7u§ = new §_-7u§();
      
      private var §_-FE§:§_-7u§ = new §_-7u§(false);
      
      private var §_-Kf§:Boolean;
      
      private var §_-13§:Cat;
      
      private var enabled:Boolean;
      
      public function §_-Wf§(param1:Cat, param2:§_-q2Z§)
      {
         super(param1,param2);
         this.§_-13§ = param1;
         §_-o2N§.value = 6;
         this.enabled = true;
      }
      
      private function §_-t1v§(param1:Boolean) : void
      {
         var _loc3_:uint = 0;
         if(!this.enabled)
         {
            return;
         }
         if(§_-X1j§.§_-12n§.gameMaster.§_-Rk§())
         {
            return;
         }
         var _loc2_:Point = Pool.getPoint();
         if(Physics.nearestFreePoint(owner.x,owner.y,HitTest.circle,20,_loc2_))
         {
            owner.x = _loc2_.x;
            owner.y = _loc2_.y;
            this.§_-13§.§_-X9§();
            owner.getPhysicModel().keepUnstable = false;
            owner.graphics.§_-fr§("CatFlying",true,false,false,false);
            this.§_-FE§.value = true;
            if(owner.weapon)
            {
               owner.weapon.deactivate();
            }
            _loc3_ = param1 ? uint(§_-U1N§.value) : uint(POWER.value);
            owner.setSpeedVector(owner.direction * MathUtil.PI_QUARTER - MathUtil.PI_HALF,_loc3_);
            owner.getPhysicModel().addEventListener(§_-42G§.§_-o1a§,this.§_-1E§);
            §_-TZ§.addListener(owner as EventDispatcher,§_-L3Q§.§_-Qw§,this.§_-C17§);
            this.§_-Kf§ = false;
            §_-X1j§.§_-12n§.gameMaster.activeUnit.§_-vp§ = false;
            §_-b7§.§_-K3b§(owner);
            this.§_-G2X§.value = false;
         }
         Pool.putPoint(_loc2_);
      }
      
      private function §_-C17§(param1:Event) : void
      {
         §_-TZ§.removeListener(owner as EventDispatcher,§_-L3Q§.§_-Qw§,this.§_-C17§);
         if(this.§_-FE§.value)
         {
            this.§_-Kf§ = true;
         }
      }
      
      override protected function jump(param1:Number, param2:Number, param3:Boolean) : void
      {
         super.jump(param1,param2,param3);
         if(this.enabled)
         {
            this.§_-G2X§.value = true;
         }
      }
      
      override public function stabilize(param1:Event) : void
      {
         this.§_-G2X§.value = false;
         super.stabilize(param1);
      }
      
      private function §_-1E§(param1:Event = null) : void
      {
         if(owner.getPhysicModel().hasEventListener(§_-42G§.§_-o1a§))
         {
            owner.getPhysicModel().removeEventListener(§_-42G§.§_-o1a§,this.§_-1E§);
         }
         §_-TZ§.removeListener(owner as EventDispatcher,§_-L3Q§.§_-Qw§,this.§_-C17§);
         owner.§_-dz§();
         owner.setSpeedXY(0,-POWER.value);
         this.§_-FE§.value = false;
         var _loc2_:§_-eX§ = §_-X1j§.§_-12n§.gameMaster;
         if(!_loc2_.§_-Rk§() && !_loc2_.§_-U2O§() && !_loc2_.§_-v1V§())
         {
            if(owner.weapon == null)
            {
               owner.reattachWeapon();
            }
            if(!owner.disposed)
            {
               _loc2_.activeUnit.§_-vp§ = true;
            }
         }
         if(this.§_-Kf§)
         {
            if(_loc2_.§_-E3b§())
            {
               owner.controlsMap.§_-DV§(Command.Bag.name,true);
               owner.controlsMap.§_-01B§();
            }
         }
         §_-b7§.§_-11U§(owner);
      }
      
      override public function §_-SX§() : Boolean
      {
         var _loc1_:uint = uint(§_-X1j§.§_-12n§.scene.gameObjectProcessor.§_-O1C§());
         return _loc1_ - §_-G33§ >= §_-o2N§.value && (§_-J2§.value > 0 || this.§_-G2X§.value);
      }
      
      override public function §_-T1k§(param1:Boolean) : void
      {
         var _loc3_:uint = 0;
         var _loc2_:Boolean = this.§_-G2X§.value && (§_-l1J§.value == 0 || §_-J2§.value == 1);
         if(_loc2_ && !owner.disposed && !owner.stable)
         {
            _loc3_ = uint(§_-X1j§.§_-12n§.scene.gameObjectProcessor.§_-O1C§());
            if(this.enabled && _loc3_ - §_-G33§ >= §_-o2N§.value)
            {
               this.§_-t1v§(§_-J2§.value == 1);
               §_-G33§ = _loc3_;
               §_-J2§.value = 0;
            }
         }
         else
         {
            super.§_-T1k§(param1);
         }
      }
      
      override protected function §_-j2S§(param1:Boolean) : void
      {
         if(this.§_-FE§.value)
         {
            owner.stable = false;
         }
         else
         {
            super.§_-j2S§(param1);
         }
      }
      
      override protected function §_-m1c§() : void
      {
         if(!this.§_-FE§.value)
         {
            super.§_-m1c§();
         }
      }
      
      override public function §_-iU§(param1:Boolean) : void
      {
         if(§_-J2§.value == 0)
         {
            if(!owner.disposed && owner.stable && !owner.isImmobile())
            {
               this.§_-s2o§(param1);
            }
         }
         else
         {
            if(§_-l1J§.value > 0 && §_-J2§.value == 1)
            {
               this.§_-G2X§.value = false;
            }
            super.§_-iU§(param1);
         }
      }
      
      override protected function §_-s2o§(param1:Boolean) : void
      {
         if(this.§_-FE§.value)
         {
            owner.stable = false;
         }
         else
         {
            super.§_-s2o§(param1);
         }
      }
      
      public function §_-D3M§() : Boolean
      {
         return this.§_-FE§.value;
      }
      
      override public function §_-03m§() : void
      {
         super.§_-03m§();
         this.§_-G2X§.value = false;
      }
      
      public function §_-b2N§() : void
      {
         this.enabled = false;
      }
      
      public function §_-B7§() : void
      {
         this.enabled = true;
      }
   }
}

