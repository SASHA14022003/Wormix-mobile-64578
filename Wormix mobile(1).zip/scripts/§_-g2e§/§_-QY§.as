package §_-g2e§
{
   import §_-51M§.Dragon;
   import §_-A1K§.§_-7u§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.model.items.craft.§_-6S§;
   
   public class §_-QY§ extends §_-q2Z§
   {
      
      private var §_-t27§:§_-7u§ = new §_-7u§();
      
      public function §_-QY§(param1:Dragon, param2:§_-q2Z§)
      {
         super(param1,param2);
      }
      
      override protected function jump(param1:Number, param2:Number, param3:Boolean) : void
      {
         this.§_-t27§.value = true;
         super.jump(param1,param2,param3);
      }
      
      override protected function extraJump(param1:Number, param2:Number) : void
      {
         if(§_-J2§.value > 1)
         {
            super.extraJump(param1,param2);
         }
         else if(§_-r21§ && this.§_-t27§.value && !owner.isImmobile())
         {
            Dragon(owner).startFlight(§_-J2§.value > 0);
            §_-J2§.value = 0;
            this.§_-t27§.value = false;
         }
      }
      
      override public function §_-SX§() : Boolean
      {
         var _loc1_:uint = uint(§_-X1j§.§_-12n§.scene.gameObjectProcessor.§_-O1C§());
         return _loc1_ - §_-G33§ >= §_-o2N§.value && (§_-J2§.value > 0 || this.§_-t27§.value);
      }
      
      override public function §_-03m§() : void
      {
         super.§_-03m§();
         this.§_-t27§.value = false;
      }
   }
}

