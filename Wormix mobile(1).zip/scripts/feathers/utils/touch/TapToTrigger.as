package feathers.utils.touch
{
   import starling.display.DisplayObject;
   
   public class TapToTrigger extends TapToEvent
   {
      
      public function TapToTrigger(param1:DisplayObject = null)
      {
         super(param1,"triggered");
      }
   }
}

