package feathers.utils.focus
{
   import feathers.core.IFocusDisplayObject;
   import flash.geom.Rectangle;
   import starling.utils.Pool;
   
   public function isBetterFocusForRelativePosition(param1:IFocusDisplayObject, param2:IFocusDisplayObject, param3:Rectangle, param4:String) : Boolean
   {
      var _loc16_:Number = NaN;
      var _loc11_:Number = NaN;
      var _loc8_:Number = NaN;
      var _loc5_:Boolean = false;
      var _loc10_:Rectangle = param1.getBounds(param1.stage,Pool.getRectangle());
      var _loc14_:Number = Number(calculateMinPrimaryAxisDistanceForRelativePosition(param3,_loc10_,param4));
      if(_loc14_ === Infinity)
      {
         return false;
      }
      var _loc9_:Number = Number(calculateMaxPrimaryAxisDistanceForRelativePosition(param3,_loc10_,param4));
      var _loc6_:Number = Number(calculateSecondaryAxisDistanceForRelativePosition(param3,_loc10_,param4));
      var _loc7_:Boolean = Boolean(itemsAreOnSameAxis(param3,_loc10_,param4));
      if(param2 === null)
      {
         _loc16_ = Infinity;
         _loc11_ = Infinity;
         _loc8_ = Infinity;
         _loc5_ = false;
      }
      else
      {
         param2.getBounds(param2.stage,_loc10_);
         _loc16_ = Number(calculateMinPrimaryAxisDistanceForRelativePosition(param3,_loc10_,param4));
         _loc11_ = Number(calculateMaxPrimaryAxisDistanceForRelativePosition(param3,_loc10_,param4));
         _loc8_ = Number(calculateSecondaryAxisDistanceForRelativePosition(param3,_loc10_,param4));
         _loc5_ = Boolean(itemsAreOnSameAxis(param3,_loc10_,param4));
      }
      Pool.putRectangle(_loc10_);
      if(_loc7_ && _loc5_)
      {
         return _loc14_ > 0 && _loc14_ < _loc16_;
      }
      var _loc12_:Boolean = param4 === "top" || param4 === "bottom";
      if(_loc7_)
      {
         if(!_loc12_)
         {
            return true;
         }
         if(_loc14_ > 0 && _loc14_ < _loc11_)
         {
            return true;
         }
      }
      else if(_loc5_)
      {
         if(!_loc12_)
         {
            return false;
         }
         if(_loc16_ > 0 && _loc16_ < _loc9_)
         {
            return false;
         }
      }
      var _loc15_:Number = 13 * _loc14_ * _loc14_ + _loc6_ * _loc6_;
      var _loc13_:Number = 13 * _loc16_ * _loc16_ + _loc8_ * _loc8_;
      return _loc15_ < _loc13_;
   }
}

import flash.geom.Rectangle;

function calculateSecondaryAxisDistanceForRelativePosition(param1:Rectangle, param2:Rectangle, param3:String):Number
{
   if(param3 === "top" || param3 === "bottom")
   {
      return Math.abs(param1.x + param1.width / 2 - (param2.x + param2.width / 2));
   }
   return Math.abs(param1.y + param1.height / 2 - (param2.y + param2.height / 2));
}
function calculateMaxPrimaryAxisDistanceForRelativePosition(param1:Rectangle, param2:Rectangle, param3:String):Number
{
   var _loc4_:Number = NaN;
   switch(param3)
   {
      case "top":
         if(param1.bottom > param2.bottom || param1.y >= param2.bottom)
         {
            _loc4_ = param1.bottom - param2.y;
            if(_loc4_ > 0)
            {
               return _loc4_;
            }
         }
         break;
      case "right":
         if(param1.x < param2.x || param1.right <= param2.x)
         {
            _loc4_ = param2.right - param1.x;
            if(_loc4_ > 0)
            {
               return _loc4_;
            }
         }
         break;
      case "bottom":
         if(param1.y < param2.y || param1.bottom <= param2.y)
         {
            _loc4_ = param2.bottom - param1.y;
            if(_loc4_ > 0)
            {
               return _loc4_;
            }
         }
         break;
      case "left":
         if(param1.right > param2.right || param1.x >= param2.right)
         {
            _loc4_ = param1.right - param2.x;
            if(_loc4_ > 0)
            {
               return _loc4_;
            }
         }
   }
   return Infinity;
}
function calculateMinPrimaryAxisDistanceForRelativePosition(param1:Rectangle, param2:Rectangle, param3:String):Number
{
   var _loc4_:Number = NaN;
   switch(param3)
   {
      case "top":
         if(param1.bottom > param2.bottom || param1.y >= param2.bottom)
         {
            _loc4_ = param1.bottom - param2.bottom;
            if(_loc4_ > 0)
            {
               return _loc4_;
            }
         }
         break;
      case "right":
         if(param1.x < param2.x || param1.right <= param2.x)
         {
            _loc4_ = param2.x - param1.x;
            if(_loc4_ > 0)
            {
               return _loc4_;
            }
         }
         break;
      case "bottom":
         if(param1.y < param2.y || param1.bottom <= param2.y)
         {
            _loc4_ = param2.y - param1.y;
            if(_loc4_ > 0)
            {
               return _loc4_;
            }
         }
         break;
      case "left":
         if(param1.right > param2.right || param1.x >= param2.right)
         {
            _loc4_ = param1.right - param2.right;
            if(_loc4_ > 0)
            {
               return _loc4_;
            }
         }
   }
   return Infinity;
}
function itemsAreOnSameAxis(param1:Rectangle, param2:Rectangle, param3:String):Boolean
{
   if(param3 === "top" || param3 === "bottom")
   {
      return param1.x <= param2.right && param2.x <= param1.right;
   }
   return param1.y <= param2.bottom && param2.y <= param1.bottom;
}
