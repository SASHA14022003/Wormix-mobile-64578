package feathers.layout
{
   import feathers.core.IFeathersControl;
   import feathers.core.IMeasureDisplayObject;
   import feathers.core.IValidating;
   import flash.errors.IllegalOperationError;
   import flash.geom.Point;
   import starling.display.DisplayObject;
   import starling.events.EventDispatcher;
   import starling.utils.Pool;
   
   public class AnchorLayout extends EventDispatcher implements ILayout
   {
      
      protected static const CIRCULAR_REFERENCE_ERROR:String = "It is impossible to create this layout due to a circular reference in the AnchorLayoutData.";
      
      protected var _helperVector1:Vector.<DisplayObject> = new Vector.<DisplayObject>(0);
      
      protected var _helperVector2:Vector.<DisplayObject> = new Vector.<DisplayObject>(0);
      
      public function AnchorLayout()
      {
         super();
      }
      
      public function get requiresLayoutOnScroll() : Boolean
      {
         return false;
      }
      
      public function layout(param1:Vector.<DisplayObject>, param2:ViewPortBounds = null, param3:LayoutBoundsResult = null) : LayoutBoundsResult
      {
         var _loc6_:Point = null;
         var _loc9_:Number = param2 ? param2.x : 0;
         var _loc10_:Number = param2 ? param2.y : 0;
         var _loc5_:Number = param2 ? param2.minWidth : 0;
         var _loc7_:Number = param2 ? param2.minHeight : 0;
         var _loc16_:Number = param2 ? param2.maxWidth : Infinity;
         var _loc11_:Number = param2 ? param2.maxHeight : Infinity;
         var _loc8_:Number = param2 ? param2.explicitWidth : NaN;
         var _loc14_:Number = param2 ? param2.explicitHeight : NaN;
         var _loc12_:Number = _loc8_;
         var _loc15_:Number = _loc14_;
         var _loc4_:Boolean = _loc8_ !== _loc8_;
         var _loc13_:Boolean = _loc14_ !== _loc14_;
         if(_loc4_ || _loc13_)
         {
            this.validateItems(param1,_loc8_,_loc14_,_loc16_,_loc11_,true);
            _loc6_ = Pool.getPoint();
            this.measureViewPort(param1,_loc12_,_loc15_,_loc6_);
            if(_loc4_)
            {
               _loc12_ = Number(_loc6_.x);
               if(_loc12_ < _loc5_)
               {
                  _loc12_ = _loc5_;
               }
               else if(_loc12_ > _loc16_)
               {
                  _loc12_ = _loc16_;
               }
            }
            if(_loc13_)
            {
               _loc15_ = Number(_loc6_.y);
               if(_loc15_ < _loc7_)
               {
                  _loc15_ = _loc7_;
               }
               else if(_loc15_ > _loc11_)
               {
                  _loc15_ = _loc11_;
               }
            }
            Pool.putPoint(_loc6_);
         }
         else
         {
            this.validateItems(param1,_loc8_,_loc14_,_loc16_,_loc11_,false);
         }
         this.layoutWithBounds(param1,_loc9_,_loc10_,_loc12_,_loc15_);
         _loc6_ = Pool.getPoint();
         this.measureContent(param1,_loc12_,_loc15_,_loc6_);
         if(!param3)
         {
            param3 = new LayoutBoundsResult();
         }
         param3.contentWidth = _loc6_.x;
         param3.contentHeight = _loc6_.y;
         param3.viewPortWidth = _loc12_;
         param3.viewPortHeight = _loc15_;
         Pool.putPoint(_loc6_);
         return param3;
      }
      
      public function calculateNavigationDestination(param1:Vector.<DisplayObject>, param2:int, param3:uint, param4:LayoutBoundsResult) : int
      {
         return param2;
      }
      
      public function getNearestScrollPositionForIndex(param1:int, param2:Number, param3:Number, param4:Vector.<DisplayObject>, param5:Number, param6:Number, param7:Number, param8:Number, param9:Point = null) : Point
      {
         return this.getScrollPositionForIndex(param1,param4,param5,param6,param7,param8,param9);
      }
      
      public function getScrollPositionForIndex(param1:int, param2:Vector.<DisplayObject>, param3:Number, param4:Number, param5:Number, param6:Number, param7:Point = null) : Point
      {
         if(!param7)
         {
            param7 = new Point();
         }
         param7.x = 0;
         param7.y = 0;
         return param7;
      }
      
      protected function measureViewPort(param1:Vector.<DisplayObject>, param2:Number, param3:Number, param4:Point) : Point
      {
         var _loc6_:Number = NaN;
         this._helperVector1.length = 0;
         this._helperVector2.length = 0;
         param4.setTo(0,0);
         var _loc7_:Vector.<DisplayObject> = param1;
         var _loc8_:Vector.<DisplayObject> = this._helperVector1;
         this.measureVector(param1,_loc8_,param4);
         var _loc5_:Number = Number(_loc8_.length);
         while(_loc5_ > 0)
         {
            if(_loc8_ == this._helperVector1)
            {
               _loc7_ = this._helperVector1;
               _loc8_ = this._helperVector2;
            }
            else
            {
               _loc7_ = this._helperVector2;
               _loc8_ = this._helperVector1;
            }
            this.measureVector(_loc7_,_loc8_,param4);
            _loc6_ = _loc5_;
            _loc5_ = Number(_loc8_.length);
            if(_loc6_ == _loc5_)
            {
               this._helperVector1.length = 0;
               this._helperVector2.length = 0;
               throw new IllegalOperationError("It is impossible to create this layout due to a circular reference in the AnchorLayoutData.");
            }
         }
         this._helperVector1.length = 0;
         this._helperVector2.length = 0;
         return param4;
      }
      
      protected function measureVector(param1:Vector.<DisplayObject>, param2:Vector.<DisplayObject>, param3:Point = null) : Point
      {
         var _loc8_:int = 0;
         var _loc6_:DisplayObject = null;
         var _loc4_:AnchorLayoutData = null;
         var _loc7_:ILayoutDisplayObject = null;
         var _loc5_:Boolean = false;
         if(!param3)
         {
            param3 = new Point();
         }
         param2.length = 0;
         var _loc10_:int = int(param1.length);
         var _loc9_:int = 0;
         _loc8_ = 0;
         for(; _loc8_ < _loc10_; _loc8_++)
         {
            _loc6_ = param1[_loc8_];
            if(_loc6_ is ILayoutDisplayObject)
            {
               _loc7_ = ILayoutDisplayObject(_loc6_);
               if(!_loc7_.includeInLayout)
               {
                  continue;
               }
               _loc4_ = _loc7_.layoutData as AnchorLayoutData;
            }
            _loc5_ = !_loc4_ || this.isReadyForLayout(_loc4_,_loc8_,param1,param2);
            if(!_loc5_)
            {
               param2[_loc9_] = _loc6_;
               _loc9_++;
            }
            else
            {
               this.measureItem(_loc6_,param3);
            }
         }
         return param3;
      }
      
      protected function measureItem(param1:DisplayObject, param2:Point) : void
      {
         var _loc4_:ILayoutDisplayObject = null;
         var _loc3_:AnchorLayoutData = null;
         var _loc8_:Number = NaN;
         var _loc6_:Number = Number(param2.x);
         var _loc5_:Number = Number(param2.y);
         var _loc7_:Boolean = false;
         if(param1 is ILayoutDisplayObject)
         {
            _loc4_ = ILayoutDisplayObject(param1);
            _loc3_ = _loc4_.layoutData as AnchorLayoutData;
            if(_loc3_)
            {
               _loc8_ = this.measureItemHorizontally(_loc4_,_loc3_);
               if(_loc8_ > _loc6_)
               {
                  _loc6_ = _loc8_;
               }
               _loc8_ = this.measureItemVertically(_loc4_,_loc3_);
               if(_loc8_ > _loc5_)
               {
                  _loc5_ = _loc8_;
               }
               _loc7_ = true;
            }
         }
         if(!_loc7_)
         {
            _loc8_ = param1.x - param1.pivotX + param1.width;
            if(_loc8_ > _loc6_)
            {
               _loc6_ = _loc8_;
            }
            _loc8_ = param1.y - param1.pivotY + param1.height;
            if(_loc8_ > _loc5_)
            {
               _loc5_ = _loc8_;
            }
         }
         param2.x = _loc6_;
         param2.y = _loc5_;
      }
      
      protected function measureItemHorizontally(param1:ILayoutDisplayObject, param2:AnchorLayoutData) : Number
      {
         var _loc4_:Number = Number(param1.width);
         var _loc6_:DisplayObject = DisplayObject(param1);
         var _loc3_:Number = this.getLeftOffset(_loc6_);
         var _loc5_:Number = this.getRightOffset(_loc6_);
         return _loc4_ + _loc3_ + _loc5_;
      }
      
      protected function measureItemVertically(param1:ILayoutDisplayObject, param2:AnchorLayoutData) : Number
      {
         var _loc3_:Number = NaN;
         var _loc6_:Number = Number(param1.height);
         if(param2 && param1 is IFeathersControl)
         {
            _loc3_ = param2.percentHeight;
            this.doNothing();
            if(_loc3_ === _loc3_)
            {
               _loc6_ = Number(IFeathersControl(param1).minHeight);
            }
         }
         var _loc7_:DisplayObject = DisplayObject(param1);
         var _loc4_:Number = this.getTopOffset(_loc7_);
         var _loc5_:Number = this.getBottomOffset(_loc7_);
         return _loc6_ + _loc4_ + _loc5_;
      }
      
      protected function doNothing() : void
      {
      }
      
      protected function getTopOffset(param1:DisplayObject) : Number
      {
         var _loc5_:ILayoutDisplayObject = null;
         var _loc2_:AnchorLayoutData = null;
         var _loc12_:Number = NaN;
         var _loc8_:Boolean = false;
         var _loc4_:DisplayObject = null;
         var _loc6_:Number = NaN;
         var _loc9_:Boolean = false;
         var _loc10_:DisplayObject = null;
         var _loc3_:Number = NaN;
         var _loc13_:Boolean = false;
         var _loc11_:DisplayObject = null;
         var _loc7_:Number = NaN;
         if(param1 is ILayoutDisplayObject)
         {
            _loc5_ = ILayoutDisplayObject(param1);
            _loc2_ = _loc5_.layoutData as AnchorLayoutData;
            if(_loc2_)
            {
               _loc12_ = _loc2_.top;
               _loc8_ = _loc12_ === _loc12_;
               if(_loc8_)
               {
                  _loc4_ = _loc2_.topAnchorDisplayObject;
                  if(!_loc4_)
                  {
                     return _loc12_;
                  }
                  _loc12_ += _loc4_.height + this.getTopOffset(_loc4_);
               }
               else
               {
                  _loc12_ = 0;
               }
               _loc6_ = _loc2_.bottom;
               _loc9_ = _loc6_ === _loc6_;
               if(_loc9_)
               {
                  _loc10_ = _loc2_.bottomAnchorDisplayObject;
                  if(_loc10_)
                  {
                     _loc12_ = Number(Math.max(_loc12_,-_loc10_.height - _loc6_ + this.getTopOffset(_loc10_)));
                  }
               }
               _loc3_ = _loc2_.verticalCenter;
               _loc13_ = _loc3_ === _loc3_;
               if(_loc13_)
               {
                  _loc11_ = _loc2_.verticalCenterAnchorDisplayObject;
                  if(_loc11_)
                  {
                     _loc7_ = _loc3_ - Math.round((param1.height - _loc11_.height) / 2);
                     _loc12_ = Number(Math.max(_loc12_,_loc7_ + this.getTopOffset(_loc11_)));
                  }
                  else if(_loc3_ > 0)
                  {
                     return _loc3_ * 2;
                  }
               }
               return _loc12_;
            }
         }
         return 0;
      }
      
      protected function getRightOffset(param1:DisplayObject) : Number
      {
         var _loc3_:ILayoutDisplayObject = null;
         var _loc2_:AnchorLayoutData = null;
         var _loc4_:Number = NaN;
         var _loc6_:Boolean = false;
         var _loc13_:DisplayObject = null;
         var _loc9_:Number = NaN;
         var _loc11_:Boolean = false;
         var _loc10_:DisplayObject = null;
         var _loc5_:Number = NaN;
         var _loc12_:Boolean = false;
         var _loc8_:DisplayObject = null;
         var _loc7_:Number = NaN;
         if(param1 is ILayoutDisplayObject)
         {
            _loc3_ = ILayoutDisplayObject(param1);
            _loc2_ = _loc3_.layoutData as AnchorLayoutData;
            if(_loc2_)
            {
               _loc4_ = _loc2_.right;
               _loc6_ = _loc4_ === _loc4_;
               if(_loc6_)
               {
                  _loc13_ = _loc2_.rightAnchorDisplayObject;
                  if(!_loc13_)
                  {
                     return _loc4_;
                  }
                  _loc4_ += _loc13_.width + this.getRightOffset(_loc13_);
               }
               else
               {
                  _loc4_ = 0;
               }
               _loc9_ = _loc2_.left;
               _loc11_ = _loc9_ === _loc9_;
               if(_loc11_)
               {
                  _loc10_ = _loc2_.leftAnchorDisplayObject;
                  if(_loc10_)
                  {
                     _loc4_ = Number(Math.max(_loc4_,-_loc10_.width - _loc9_ + this.getRightOffset(_loc10_)));
                  }
               }
               _loc5_ = _loc2_.horizontalCenter;
               _loc12_ = _loc5_ === _loc5_;
               if(_loc12_)
               {
                  _loc8_ = _loc2_.horizontalCenterAnchorDisplayObject;
                  if(_loc8_)
                  {
                     _loc7_ = -_loc5_ - Math.round((param1.width - _loc8_.width) / 2);
                     _loc4_ = Number(Math.max(_loc4_,_loc7_ + this.getRightOffset(_loc8_)));
                  }
                  else if(_loc5_ < 0)
                  {
                     return -_loc5_ * 2;
                  }
               }
               return _loc4_;
            }
         }
         return 0;
      }
      
      protected function getBottomOffset(param1:DisplayObject) : Number
      {
         var _loc5_:ILayoutDisplayObject = null;
         var _loc2_:AnchorLayoutData = null;
         var _loc6_:Number = NaN;
         var _loc9_:Boolean = false;
         var _loc10_:DisplayObject = null;
         var _loc12_:Number = NaN;
         var _loc8_:Boolean = false;
         var _loc4_:DisplayObject = null;
         var _loc3_:Number = NaN;
         var _loc13_:Boolean = false;
         var _loc11_:DisplayObject = null;
         var _loc7_:Number = NaN;
         if(param1 is ILayoutDisplayObject)
         {
            _loc5_ = ILayoutDisplayObject(param1);
            _loc2_ = _loc5_.layoutData as AnchorLayoutData;
            if(_loc2_)
            {
               _loc6_ = _loc2_.bottom;
               _loc9_ = _loc6_ === _loc6_;
               if(_loc9_)
               {
                  _loc10_ = _loc2_.bottomAnchorDisplayObject;
                  if(!_loc10_)
                  {
                     return _loc6_;
                  }
                  _loc6_ += _loc10_.height + this.getBottomOffset(_loc10_);
               }
               else
               {
                  _loc6_ = 0;
               }
               _loc12_ = _loc2_.top;
               _loc8_ = _loc12_ === _loc12_;
               if(_loc8_)
               {
                  _loc4_ = _loc2_.topAnchorDisplayObject;
                  if(_loc4_)
                  {
                     _loc6_ = Number(Math.max(_loc6_,-_loc4_.height - _loc12_ + this.getBottomOffset(_loc4_)));
                  }
               }
               _loc3_ = _loc2_.verticalCenter;
               _loc13_ = _loc3_ === _loc3_;
               if(_loc13_)
               {
                  _loc11_ = _loc2_.verticalCenterAnchorDisplayObject;
                  if(_loc11_)
                  {
                     _loc7_ = -_loc3_ - Math.round((param1.height - _loc11_.height) / 2);
                     _loc6_ = Number(Math.max(_loc6_,_loc7_ + this.getBottomOffset(_loc11_)));
                  }
                  else if(_loc3_ < 0)
                  {
                     return -_loc3_ * 2;
                  }
               }
               return _loc6_;
            }
         }
         return 0;
      }
      
      protected function getLeftOffset(param1:DisplayObject) : Number
      {
         var _loc3_:ILayoutDisplayObject = null;
         var _loc2_:AnchorLayoutData = null;
         var _loc9_:Number = NaN;
         var _loc11_:Boolean = false;
         var _loc10_:DisplayObject = null;
         var _loc4_:Number = NaN;
         var _loc6_:Boolean = false;
         var _loc13_:DisplayObject = null;
         var _loc5_:Number = NaN;
         var _loc12_:Boolean = false;
         var _loc8_:DisplayObject = null;
         var _loc7_:Number = NaN;
         if(param1 is ILayoutDisplayObject)
         {
            _loc3_ = ILayoutDisplayObject(param1);
            _loc2_ = _loc3_.layoutData as AnchorLayoutData;
            if(_loc2_)
            {
               _loc9_ = _loc2_.left;
               _loc11_ = _loc9_ === _loc9_;
               if(_loc11_)
               {
                  _loc10_ = _loc2_.leftAnchorDisplayObject;
                  if(!_loc10_)
                  {
                     return _loc9_;
                  }
                  _loc9_ += _loc10_.width + this.getLeftOffset(_loc10_);
               }
               else
               {
                  _loc9_ = 0;
               }
               _loc4_ = _loc2_.right;
               _loc6_ = _loc4_ === _loc4_;
               if(_loc6_)
               {
                  _loc13_ = _loc2_.rightAnchorDisplayObject;
                  if(_loc13_)
                  {
                     _loc9_ = Number(Math.max(_loc9_,-_loc13_.width - _loc4_ + this.getLeftOffset(_loc13_)));
                  }
               }
               _loc5_ = _loc2_.horizontalCenter;
               _loc12_ = _loc5_ === _loc5_;
               if(_loc12_)
               {
                  _loc8_ = _loc2_.horizontalCenterAnchorDisplayObject;
                  if(_loc8_)
                  {
                     _loc7_ = _loc5_ - Math.round((param1.width - _loc8_.width) / 2);
                     _loc9_ = Number(Math.max(_loc9_,_loc7_ + this.getLeftOffset(_loc8_)));
                  }
                  else if(_loc5_ > 0)
                  {
                     return _loc5_ * 2;
                  }
               }
               return _loc9_;
            }
         }
         return 0;
      }
      
      protected function layoutWithBounds(param1:Vector.<DisplayObject>, param2:Number, param3:Number, param4:Number, param5:Number) : void
      {
         var _loc7_:Number = NaN;
         this._helperVector1.length = 0;
         this._helperVector2.length = 0;
         var _loc8_:Vector.<DisplayObject> = param1;
         var _loc9_:Vector.<DisplayObject> = this._helperVector1;
         this.layoutVector(param1,_loc9_,param2,param3,param4,param5);
         var _loc6_:Number = Number(_loc9_.length);
         while(_loc6_ > 0)
         {
            if(_loc9_ == this._helperVector1)
            {
               _loc8_ = this._helperVector1;
               _loc9_ = this._helperVector2;
            }
            else
            {
               _loc8_ = this._helperVector2;
               _loc9_ = this._helperVector1;
            }
            this.layoutVector(_loc8_,_loc9_,param2,param3,param4,param5);
            _loc7_ = _loc6_;
            _loc6_ = Number(_loc9_.length);
            if(_loc7_ == _loc6_)
            {
               this._helperVector1.length = 0;
               this._helperVector2.length = 0;
               throw new IllegalOperationError("It is impossible to create this layout due to a circular reference in the AnchorLayoutData.");
            }
         }
         this._helperVector1.length = 0;
         this._helperVector2.length = 0;
      }
      
      protected function layoutVector(param1:Vector.<DisplayObject>, param2:Vector.<DisplayObject>, param3:Number, param4:Number, param5:Number, param6:Number) : void
      {
         var _loc11_:int = 0;
         var _loc9_:DisplayObject = null;
         var _loc10_:ILayoutDisplayObject = null;
         var _loc7_:AnchorLayoutData = null;
         var _loc8_:Boolean = false;
         param2.length = 0;
         var _loc13_:int = int(param1.length);
         var _loc12_:int = 0;
         _loc11_ = 0;
         while(_loc11_ < _loc13_)
         {
            _loc9_ = param1[_loc11_];
            _loc10_ = _loc9_ as ILayoutDisplayObject;
            if(!(!_loc10_ || !_loc10_.includeInLayout))
            {
               _loc7_ = _loc10_.layoutData as AnchorLayoutData;
               if(_loc7_)
               {
                  _loc8_ = this.isReadyForLayout(_loc7_,_loc11_,param1,param2);
                  if(!_loc8_)
                  {
                     param2[_loc12_] = _loc9_;
                     _loc12_++;
                  }
                  else
                  {
                     this.positionHorizontally(_loc10_,_loc7_,param3,param4,param5,param6);
                     this.positionVertically(_loc10_,_loc7_,param3,param4,param5,param6);
                  }
               }
            }
            _loc11_++;
         }
      }
      
      protected function positionHorizontally(param1:ILayoutDisplayObject, param2:AnchorLayoutData, param3:Number, param4:Number, param5:Number, param6:Number) : void
      {
         var _loc19_:Number = NaN;
         var _loc8_:Number = NaN;
         var _loc23_:Number = NaN;
         var _loc17_:DisplayObject = null;
         var _loc21_:DisplayObject = null;
         var _loc7_:Number = NaN;
         var _loc13_:DisplayObject = null;
         var _loc22_:Number = NaN;
         var _loc15_:Number = NaN;
         var _loc16_:IFeathersControl = param1 as IFeathersControl;
         var _loc11_:Number = param2.percentWidth;
         if(_loc11_ === _loc11_)
         {
            if(_loc11_ < 0)
            {
               _loc11_ = 0;
            }
            else if(_loc11_ > 100)
            {
               _loc11_ = 100;
            }
            _loc19_ = _loc11_ * 0.01 * param5;
            if(_loc16_ !== null)
            {
               _loc8_ = Number(_loc16_.explicitMinWidth);
               _loc23_ = Number(_loc16_.explicitMaxWidth);
               if(_loc19_ < _loc8_)
               {
                  _loc19_ = _loc8_;
               }
               else if(_loc19_ > _loc23_)
               {
                  _loc19_ = _loc23_;
               }
            }
            if(_loc19_ > param5)
            {
               _loc19_ = param5;
            }
            if(_loc16_.explicitMaxWidth === _loc16_.explicitMaxWidth && _loc16_.explicitMaxWidth < _loc19_)
            {
               _loc19_ = Number(_loc16_.explicitMaxWidth);
            }
            param1.width = _loc19_;
         }
         var _loc14_:Number = param2.left;
         var _loc18_:Boolean = _loc14_ === _loc14_;
         if(_loc18_)
         {
            _loc17_ = param2.leftAnchorDisplayObject;
            if(_loc17_)
            {
               param1.x = param1.pivotX + _loc17_.x - _loc17_.pivotX + _loc17_.width + _loc14_;
            }
            else
            {
               param1.x = param1.pivotX + param3 + _loc14_;
            }
         }
         var _loc10_:Number = param2.horizontalCenter;
         var _loc20_:Boolean = _loc10_ === _loc10_;
         var _loc9_:Number = param2.right;
         var _loc12_:Boolean = _loc9_ === _loc9_;
         if(_loc12_)
         {
            _loc21_ = param2.rightAnchorDisplayObject;
            if(_loc18_)
            {
               _loc7_ = param5;
               if(_loc21_)
               {
                  _loc7_ = _loc21_.x - _loc21_.pivotX;
               }
               if(_loc17_)
               {
                  _loc7_ -= _loc17_.x - _loc17_.pivotX + _loc17_.width;
               }
               _loc19_ = _loc7_ - _loc9_ - _loc14_;
               if(_loc16_.explicitMaxWidth === _loc16_.explicitMaxWidth && _loc16_.explicitMaxWidth < _loc19_)
               {
                  _loc19_ = Number(_loc16_.explicitMaxWidth);
               }
               param1.width = _loc19_;
            }
            else if(_loc20_)
            {
               _loc13_ = param2.horizontalCenterAnchorDisplayObject;
               if(_loc13_)
               {
                  _loc22_ = _loc13_.x - _loc13_.pivotX + Math.round(_loc13_.width / 2) + _loc10_;
               }
               else
               {
                  _loc22_ = Math.round(param5 / 2) + _loc10_;
               }
               if(_loc21_)
               {
                  _loc15_ = _loc21_.x - _loc21_.pivotX - _loc9_;
               }
               else
               {
                  _loc15_ = param5 - _loc9_;
               }
               _loc19_ = 2 * (_loc15_ - _loc22_);
               if(_loc16_.explicitMaxWidth === _loc16_.explicitMaxWidth && _loc16_.explicitMaxWidth < _loc19_)
               {
                  _loc19_ = Number(_loc16_.explicitMaxWidth);
               }
               param1.width = _loc19_;
               param1.x = param1.pivotX + param5 - _loc9_ - param1.width;
            }
            else if(_loc21_)
            {
               param1.x = param1.pivotX + _loc21_.x - _loc21_.pivotX - param1.width - _loc9_;
            }
            else
            {
               param1.x = param1.pivotX + param3 + param5 - _loc9_ - param1.width;
            }
         }
         else if(_loc20_)
         {
            _loc13_ = param2.horizontalCenterAnchorDisplayObject;
            if(_loc13_)
            {
               _loc22_ = _loc13_.x - _loc13_.pivotX + Math.round(_loc13_.width / 2) + _loc10_;
            }
            else
            {
               _loc22_ = Math.round(param5 / 2) + _loc10_;
            }
            if(_loc18_)
            {
               _loc19_ = 2 * (_loc22_ - param1.x + param1.pivotX);
               if(_loc16_.explicitMaxWidth === _loc16_.explicitMaxWidth && _loc16_.explicitMaxWidth < _loc19_)
               {
                  _loc19_ = Number(_loc16_.explicitMaxWidth);
               }
               param1.width = _loc19_;
            }
            else
            {
               param1.x = param1.pivotX + _loc22_ - Math.round(param1.width / 2);
            }
         }
      }
      
      protected function positionVertically(param1:ILayoutDisplayObject, param2:AnchorLayoutData, param3:Number, param4:Number, param5:Number, param6:Number) : void
      {
         var _loc10_:Number = NaN;
         var _loc12_:Number = NaN;
         var _loc19_:Number = NaN;
         var _loc8_:DisplayObject = null;
         var _loc14_:DisplayObject = null;
         var _loc22_:Number = NaN;
         var _loc15_:DisplayObject = null;
         var _loc16_:Number = NaN;
         var _loc23_:Number = NaN;
         var _loc20_:IFeathersControl = param1 as IFeathersControl;
         var _loc17_:Number = param2.percentHeight;
         if(_loc17_ === _loc17_)
         {
            if(_loc17_ < 0)
            {
               _loc17_ = 0;
            }
            else if(_loc17_ > 100)
            {
               _loc17_ = 100;
            }
            _loc10_ = _loc17_ * 0.01 * param6;
            if(_loc20_ !== null)
            {
               _loc12_ = Number(_loc20_.explicitMinHeight);
               _loc19_ = Number(_loc20_.explicitMaxHeight);
               if(_loc10_ < _loc12_)
               {
                  _loc10_ = _loc12_;
               }
               else if(_loc10_ > _loc19_)
               {
                  _loc10_ = _loc19_;
               }
            }
            if(_loc10_ > param6)
            {
               _loc10_ = param6;
            }
            if(_loc20_.explicitMaxHeight === _loc20_.explicitMaxHeight && _loc20_.explicitMaxHeight < _loc10_)
            {
               _loc10_ = Number(_loc20_.explicitMaxHeight);
            }
            param1.height = _loc10_;
         }
         var _loc18_:Number = param2.top;
         var _loc11_:Boolean = _loc18_ === _loc18_;
         if(_loc11_)
         {
            _loc8_ = param2.topAnchorDisplayObject;
            if(_loc8_)
            {
               param1.y = param1.pivotY + _loc8_.y - _loc8_.pivotY + _loc8_.height + _loc18_;
            }
            else
            {
               param1.y = param1.pivotY + param4 + _loc18_;
            }
         }
         var _loc7_:Number = param2.verticalCenter;
         var _loc21_:Boolean = _loc7_ === _loc7_;
         var _loc9_:Number = param2.bottom;
         var _loc13_:Boolean = _loc9_ === _loc9_;
         if(_loc13_)
         {
            _loc14_ = param2.bottomAnchorDisplayObject;
            if(_loc11_)
            {
               _loc22_ = param6;
               if(_loc14_)
               {
                  _loc22_ = _loc14_.y - _loc14_.pivotY;
               }
               if(_loc8_)
               {
                  _loc22_ -= _loc8_.y - _loc8_.pivotY + _loc8_.height;
               }
               _loc10_ = _loc22_ - _loc9_ - _loc18_;
               if(_loc20_.explicitMaxHeight === _loc20_.explicitMaxHeight && _loc20_.explicitMaxHeight < _loc10_)
               {
                  _loc10_ = Number(_loc20_.explicitMaxHeight);
               }
               param1.height = _loc10_;
            }
            else if(_loc21_)
            {
               _loc15_ = param2.verticalCenterAnchorDisplayObject;
               if(_loc15_)
               {
                  _loc16_ = _loc15_.y - _loc15_.pivotY + Math.round(_loc15_.height / 2) + _loc7_;
               }
               else
               {
                  _loc16_ = Math.round(param6 / 2) + _loc7_;
               }
               if(_loc14_)
               {
                  _loc23_ = _loc14_.y - _loc14_.pivotY - _loc9_;
               }
               else
               {
                  _loc23_ = param6 - _loc9_;
               }
               _loc10_ = 2 * (_loc23_ - _loc16_);
               if(_loc20_.explicitMaxHeight === _loc20_.explicitMaxHeight && _loc20_.explicitMaxHeight < _loc10_)
               {
                  _loc10_ = Number(_loc20_.explicitMaxHeight);
               }
               param1.height = _loc10_;
               param1.y = param1.pivotY + param6 - _loc9_ - param1.height;
            }
            else if(_loc14_)
            {
               param1.y = param1.pivotY + _loc14_.y - _loc14_.pivotY - param1.height - _loc9_;
            }
            else
            {
               param1.y = param1.pivotY + param4 + param6 - _loc9_ - param1.height;
            }
         }
         else if(_loc21_)
         {
            _loc15_ = param2.verticalCenterAnchorDisplayObject;
            if(_loc15_)
            {
               _loc16_ = _loc15_.y - _loc15_.pivotY + Math.round(_loc15_.height / 2) + _loc7_;
            }
            else
            {
               _loc16_ = Math.round(param6 / 2) + _loc7_;
            }
            if(_loc11_)
            {
               _loc10_ = 2 * (_loc16_ - param1.y + param1.pivotY);
               if(_loc20_.explicitMaxHeight === _loc20_.explicitMaxHeight && _loc20_.explicitMaxHeight < _loc10_)
               {
                  _loc10_ = Number(_loc20_.explicitMaxHeight);
               }
               param1.height = _loc10_;
            }
            else
            {
               param1.y = param1.pivotY + _loc16_ - Math.round(param1.height / 2);
            }
         }
      }
      
      protected function measureContent(param1:Vector.<DisplayObject>, param2:Number, param3:Number, param4:Point = null) : Point
      {
         var _loc9_:int = 0;
         var _loc5_:DisplayObject = null;
         var _loc10_:Number = NaN;
         var _loc6_:Number = NaN;
         var _loc8_:Number = param2;
         var _loc7_:Number = param3;
         var _loc11_:int = int(param1.length);
         _loc9_ = 0;
         while(_loc9_ < _loc11_)
         {
            _loc5_ = param1[_loc9_];
            _loc10_ = _loc5_.x - _loc5_.pivotX + _loc5_.width;
            _loc6_ = _loc5_.y - _loc5_.pivotY + _loc5_.height;
            if(_loc10_ === _loc10_ && _loc10_ > _loc8_)
            {
               _loc8_ = _loc10_;
            }
            if(_loc6_ === _loc6_ && _loc6_ > _loc7_)
            {
               _loc7_ = _loc6_;
            }
            _loc9_++;
         }
         param4.x = _loc8_;
         param4.y = _loc7_;
         return param4;
      }
      
      protected function isReadyForLayout(param1:AnchorLayoutData, param2:int, param3:Vector.<DisplayObject>, param4:Vector.<DisplayObject>) : Boolean
      {
         var _loc10_:int = param2 + 1;
         var _loc9_:DisplayObject = param1.leftAnchorDisplayObject;
         if(_loc9_ && (param3.indexOf(_loc9_,_loc10_) >= _loc10_ || param4.indexOf(_loc9_) >= 0))
         {
            return false;
         }
         var _loc11_:DisplayObject = param1.rightAnchorDisplayObject;
         if(_loc11_ && (param3.indexOf(_loc11_,_loc10_) >= _loc10_ || param4.indexOf(_loc11_) >= 0))
         {
            return false;
         }
         var _loc5_:DisplayObject = param1.topAnchorDisplayObject;
         if(_loc5_ && (param3.indexOf(_loc5_,_loc10_) >= _loc10_ || param4.indexOf(_loc5_) >= 0))
         {
            return false;
         }
         var _loc6_:DisplayObject = param1.bottomAnchorDisplayObject;
         if(_loc6_ && (param3.indexOf(_loc6_,_loc10_) >= _loc10_ || param4.indexOf(_loc6_) >= 0))
         {
            return false;
         }
         var _loc7_:DisplayObject = param1.horizontalCenterAnchorDisplayObject;
         if(_loc7_ && (param3.indexOf(_loc7_,_loc10_) >= _loc10_ || param4.indexOf(_loc7_) >= 0))
         {
            return false;
         }
         var _loc8_:DisplayObject = param1.verticalCenterAnchorDisplayObject;
         if(_loc8_ && (param3.indexOf(_loc8_,_loc10_) >= _loc10_ || param4.indexOf(_loc8_) >= 0))
         {
            return false;
         }
         return true;
      }
      
      protected function isReferenced(param1:DisplayObject, param2:Vector.<DisplayObject>) : Boolean
      {
         var _loc4_:int = 0;
         var _loc5_:ILayoutDisplayObject = null;
         var _loc3_:AnchorLayoutData = null;
         var _loc6_:int = int(param2.length);
         _loc4_ = 0;
         while(_loc4_ < _loc6_)
         {
            _loc5_ = param2[_loc4_] as ILayoutDisplayObject;
            if(!(!_loc5_ || _loc5_ == param1))
            {
               _loc3_ = _loc5_.layoutData as AnchorLayoutData;
               if(_loc3_)
               {
                  if(_loc3_.leftAnchorDisplayObject == param1 || _loc3_.horizontalCenterAnchorDisplayObject == param1 || _loc3_.rightAnchorDisplayObject == param1 || _loc3_.topAnchorDisplayObject == param1 || _loc3_.verticalCenterAnchorDisplayObject == param1 || _loc3_.bottomAnchorDisplayObject == param1)
                  {
                     return true;
                  }
               }
            }
            _loc4_++;
         }
         return false;
      }
      
      protected function validateItems(param1:Vector.<DisplayObject>, param2:Number, param3:Number, param4:Number, param5:Number, param6:Boolean) : void
      {
         var _loc28_:int = 0;
         var _loc24_:DisplayObject = null;
         var _loc7_:ILayoutDisplayObject = null;
         var _loc22_:AnchorLayoutData = null;
         var _loc37_:Number = NaN;
         var _loc38_:Boolean = false;
         var _loc35_:DisplayObject = null;
         var _loc29_:Number = NaN;
         var _loc8_:DisplayObject = null;
         var _loc12_:Boolean = false;
         var _loc13_:Number = NaN;
         var _loc18_:Boolean = false;
         var _loc36_:IMeasureDisplayObject = null;
         var _loc20_:Number = NaN;
         var _loc11_:Number = NaN;
         var _loc21_:Boolean = false;
         var _loc15_:Number = NaN;
         var _loc27_:Boolean = false;
         var _loc30_:DisplayObject = null;
         var _loc26_:Number = NaN;
         var _loc33_:Boolean = false;
         var _loc9_:DisplayObject = null;
         var _loc16_:Number = NaN;
         var _loc31_:Boolean = false;
         var _loc10_:Number = NaN;
         var _loc23_:Number = NaN;
         var _loc17_:Boolean = false;
         var _loc25_:Boolean = param2 !== param2;
         var _loc19_:Boolean = param3 !== param3;
         var _loc14_:Number = param2;
         if(_loc25_ && param4 < Infinity)
         {
            _loc14_ = param4;
         }
         var _loc34_:Number = param3;
         if(_loc19_ && param5 < Infinity)
         {
            _loc34_ = param5;
         }
         var _loc32_:int = int(param1.length);
         _loc28_ = 0;
         for(; _loc28_ < _loc32_; _loc28_++)
         {
            _loc24_ = param1[_loc28_];
            if(_loc24_ is ILayoutDisplayObject)
            {
               _loc7_ = ILayoutDisplayObject(_loc24_);
               if(!_loc7_.includeInLayout)
               {
                  continue;
               }
               _loc22_ = _loc7_.layoutData as AnchorLayoutData;
               if(_loc22_ !== null)
               {
                  _loc37_ = _loc22_.left;
                  _loc38_ = _loc37_ === _loc37_;
                  _loc35_ = _loc22_.leftAnchorDisplayObject;
                  _loc29_ = _loc22_.right;
                  _loc8_ = _loc22_.rightAnchorDisplayObject;
                  _loc12_ = _loc29_ === _loc29_;
                  _loc13_ = _loc22_.percentWidth;
                  _loc18_ = _loc13_ === _loc13_;
                  _loc36_ = IMeasureDisplayObject(_loc24_);
                  if(_loc25_)
                  {
                     if(_loc38_ && _loc35_ === null && _loc12_ && _loc8_ === null)
                     {
                        _loc36_.width = NaN;
                        _loc36_.maxWidth = param4 - _loc37_ - _loc29_;
                     }
                     else if(_loc18_)
                     {
                        if(_loc13_ < 0)
                        {
                           _loc13_ = 0;
                        }
                        else if(_loc13_ > 100)
                        {
                           _loc13_ = 100;
                        }
                        _loc36_.width = NaN;
                        _loc36_.maxWidth = _loc13_ * 0.01 * param4;
                     }
                  }
                  else if(_loc38_ && _loc35_ === null && _loc12_ && _loc8_ === null)
                  {
                     _loc20_ = _loc14_ - _loc37_ - _loc29_;
                     if(_loc36_.explicitMaxWidth === _loc36_.explicitMaxWidth && _loc36_.explicitMaxWidth < _loc20_)
                     {
                        _loc20_ = _loc36_.explicitMaxWidth;
                     }
                     _loc24_.width = _loc20_;
                  }
                  else if(_loc18_)
                  {
                     if(_loc13_ < 0)
                     {
                        _loc13_ = 0;
                     }
                     else if(_loc13_ > 100)
                     {
                        _loc13_ = 100;
                     }
                     _loc20_ = _loc13_ * 0.01 * _loc14_;
                     if(_loc36_.explicitMaxWidth === _loc36_.explicitMaxWidth && _loc36_.explicitMaxWidth < _loc20_)
                     {
                        _loc20_ = _loc36_.explicitMaxWidth;
                     }
                     _loc24_.width = _loc20_;
                  }
                  _loc11_ = _loc22_.horizontalCenter;
                  _loc21_ = _loc11_ === _loc11_;
                  _loc15_ = _loc22_.top;
                  _loc27_ = _loc15_ === _loc15_;
                  _loc30_ = _loc22_.topAnchorDisplayObject;
                  _loc26_ = _loc22_.bottom;
                  _loc33_ = _loc26_ === _loc26_;
                  _loc9_ = _loc22_.bottomAnchorDisplayObject;
                  _loc16_ = _loc22_.percentHeight;
                  _loc31_ = _loc16_ === _loc16_;
                  if(!_loc19_)
                  {
                     if(_loc27_ && _loc30_ === null && _loc33_ && _loc9_ === null)
                     {
                        _loc10_ = _loc34_ - _loc15_ - _loc26_;
                        if(_loc36_.explicitMaxHeight === _loc36_.explicitMaxHeight && _loc36_.explicitMaxHeight < _loc10_)
                        {
                           _loc10_ = _loc36_.explicitMaxHeight;
                        }
                        _loc24_.height = _loc10_;
                     }
                     else if(_loc31_)
                     {
                        if(_loc16_ < 0)
                        {
                           _loc16_ = 0;
                        }
                        else if(_loc16_ > 100)
                        {
                           _loc16_ = 100;
                        }
                        _loc10_ = _loc16_ * 0.01 * _loc34_;
                        if(_loc36_.explicitMaxHeight === _loc36_.explicitMaxHeight && _loc36_.explicitMaxHeight < _loc10_)
                        {
                           _loc10_ = _loc36_.explicitMaxHeight;
                        }
                        _loc24_.height = _loc10_;
                     }
                  }
                  _loc23_ = _loc22_.verticalCenter;
                  _loc17_ = _loc23_ === _loc23_;
                  if(_loc12_ && !_loc38_ && !_loc21_ || _loc21_)
                  {
                     if(_loc24_ is IValidating)
                     {
                        IValidating(_loc24_).validate();
                     }
                     continue;
                  }
                  if(_loc33_ && !_loc27_ && !_loc17_ || _loc17_)
                  {
                     if(_loc24_ is IValidating)
                     {
                        IValidating(_loc24_).validate();
                     }
                     continue;
                  }
               }
            }
            if(param6 || this.isReferenced(_loc24_,param1))
            {
               if(_loc24_ is IValidating)
               {
                  IValidating(_loc24_).validate();
               }
            }
         }
      }
   }
}

