package feathers.events
{
   public class CollectionEventType
   {
      
      public static const RESET:String = "reset";
      
      public static const FILTER_CHANGE:String = "filterChange";
      
      public static const SORT_CHANGE:String = "sortChange";
      
      public static const ADD_ITEM:String = "addItem";
      
      public static const REMOVE_ITEM:String = "removeItem";
      
      public static const REPLACE_ITEM:String = "replaceItem";
      
      public static const UPDATE_ITEM:String = "updateItem";
      
      public static const UPDATE_ALL:String = "updateAll";
      
      public static const REMOVE_ALL:String = "removeAll";
      
      public function CollectionEventType()
      {
         super();
      }
   }
}

