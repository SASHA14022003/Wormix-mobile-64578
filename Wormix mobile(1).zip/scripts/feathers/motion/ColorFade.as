package feathers.motion
{
   import starling.display.DisplayObject;
   
   public class ColorFade
   {
      
      protected static const SCREEN_REQUIRED_ERROR:String = "Cannot transition if both old screen and new screen are null.";
      
      public function ColorFade()
      {
         super();
      }
      
      public static function createBlackFadeToBlackTransition(param1:Number = 0.75, param2:Object = "easeOut", param3:Object = null) : Function
      {
         return createBlackFadeTransition(param1,param2,param3);
      }
      
      public static function createBlackFadeTransition(param1:Number = 0.75, param2:Object = "easeOut", param3:Object = null) : Function
      {
         return createColorFadeTransition(0,param1,param2,param3);
      }
      
      public static function createWhiteFadeTransition(param1:Number = 0.75, param2:Object = "easeOut", param3:Object = null) : Function
      {
         return createColorFadeTransition(16777215,param1,param2,param3);
      }
      
      public static function createColorFadeTransition(param1:uint, param2:Number = 0.75, param3:Object = "easeOut", param4:Object = null) : Function
      {
         var color:uint = param1;
         var duration:Number = param2;
         var ease:Object = param3;
         var tweenProperties:Object = param4;
         return function(param1:DisplayObject, param2:DisplayObject, param3:Function):void
         {
            if(!param1 && !param2)
            {
               throw new ArgumentError("Cannot transition if both old screen and new screen are null.");
            }
            if(param2)
            {
               param2.alpha = 0;
               if(param1)
               {
                  param1.alpha = 1;
               }
               new ColorFadeTween(param2,param1,color,duration,ease,param3,tweenProperties);
            }
            else
            {
               param1.alpha = 1;
               new ColorFadeTween(param1,null,color,duration,ease,param3,tweenProperties);
            }
         };
      }
   }
}

import starling.animation.Tween;
import starling.core.Starling;
import starling.display.DisplayObject;
import starling.display.DisplayObjectContainer;
import starling.display.Quad;

class ColorFadeTween extends Tween
{
   
   private var _otherTarget:DisplayObject;
   
   private var _overlay:Quad;
   
   private var _onCompleteCallback:Function;
   
   public function ColorFadeTween(param1:DisplayObject, param2:DisplayObject, param3:uint, param4:Number, param5:Object, param6:Function, param7:Object)
   {
      super(param1,param4,param5);
      if(param1.alpha == 0)
      {
         this.fadeTo(1);
      }
      else
      {
         this.fadeTo(0);
      }
      if(param7)
      {
         for(var _loc8_ in param7)
         {
            this[_loc8_] = param7[_loc8_];
         }
      }
      if(param2)
      {
         this._otherTarget = param2;
         param1.visible = false;
      }
      this.onUpdate = this.updateOverlay;
      this._onCompleteCallback = param6;
      this.onComplete = this.cleanupTween;
      var _loc9_:DisplayObjectContainer = param1.parent;
      this._overlay = new Quad(1,1,param3);
      this._overlay.width = _loc9_.width;
      this._overlay.height = _loc9_.height;
      this._overlay.alpha = 0;
      this._overlay.touchable = false;
      _loc9_.addChild(this._overlay);
      Starling.juggler.add(this);
   }
   
   private function updateOverlay() : void
   {
      var _loc1_:Number = Number(this.progress);
      if(_loc1_ < 0.5)
      {
         this._overlay.alpha = _loc1_ * 2;
      }
      else
      {
         target.visible = true;
         if(this._otherTarget)
         {
            this._otherTarget.visible = false;
         }
         this._overlay.alpha = (1 - _loc1_) * 2;
      }
   }
   
   private function cleanupTween() : void
   {
      this._overlay.removeFromParent(true);
      this.target.visible = true;
      if(this._otherTarget)
      {
         this._otherTarget.visible = true;
      }
      if(this._onCompleteCallback !== null)
      {
         this._onCompleteCallback();
      }
   }
}
