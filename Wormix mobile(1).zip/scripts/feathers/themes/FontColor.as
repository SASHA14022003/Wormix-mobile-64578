package feathers.themes
{
   public class FontColor
   {
      
      public static const WHITE:uint = 16777215;
      
      public static const LIGHT_BROWN:uint = 9072988;
      
      public static const DARK_BROWN:uint = 5391158;
      
      public static const LIGHT_GRAY:uint = 8026746;
      
      public static const DARK_GRAY:uint = 3682094;
      
      public static const DARK_GREEN:uint = 5738752;
      
      public static const BRIGHT_GREEN:uint = 12517206;
      
      public static const RED:uint = 11730944;
      
      public static const BLUE:uint = 6525129;
      
      public static const LIGHT:uint = 16771235;
      
      public static const COLD_LIGHT:uint = 16113862;
      
      public static const ITEM_COLOR_NORMAL:uint = 8421504;
      
      public static const ITEM_COLOR_SUPERIOR:uint = 4827648;
      
      public static const ITEM_COLOR_AGGRESSIVE:uint = 690921;
      
      public static const ITEM_COLOR_DEFENSIVE:uint = 7289838;
      
      public static const ITEM_COLOR_VIOLENT:uint = 16751104;
      
      public static const ITEM_COLOR_EPIC:uint = 16729600;
      
      public static const ITEM_COLOR_LEGENDARY:uint = 13172736;
      
      public static const NUMERIC_STEPPER_DEFAULT:uint = 8089696;
      
      public static const TAB_DARK_SELECTED:uint = 7191039;
      
      public static const TAB_DARK_UNSELECTED:uint = 8886696;
      
      public static const TAB_SELECTED:uint = 16770186;
      
      public static const TAB_UNSELECTED:uint = 8886696;
      
      public function FontColor()
      {
         super();
      }
      
      public static function getColorCodeByStyleName(param1:String) : uint
      {
         if(param1.indexOf("darkbrown") != -1)
         {
            return 5391158;
         }
         if(param1.indexOf("lightbrown") != -1)
         {
            return 9072988;
         }
         if(param1.indexOf("darkgray") != -1)
         {
            return 3682094;
         }
         if(param1.indexOf("lightgray") != -1)
         {
            return 8026746;
         }
         if(param1.indexOf("darkgreen") != -1)
         {
            return 5738752;
         }
         if(param1.indexOf("red") != -1)
         {
            return 11730944;
         }
         if(param1.indexOf("blue") != -1)
         {
            return 6525129;
         }
         if(param1.indexOf("white") != -1)
         {
            return 16777215;
         }
         if(param1.indexOf("coldlight") != -1)
         {
            return 16113862;
         }
         if(param1.indexOf("brightgreen") != -1)
         {
            return 12517206;
         }
         if(param1.indexOf("dark") != -1)
         {
            return 8886696;
         }
         if(param1.indexOf("bright") != -1)
         {
            return 16770186;
         }
         trace("NO SIZE IN " + param1);
         return 16777215;
      }
   }
}

