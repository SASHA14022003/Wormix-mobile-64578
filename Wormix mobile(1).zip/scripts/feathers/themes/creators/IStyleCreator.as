package feathers.themes.creators
{
   public interface IStyleCreator
   {
      
      function initializeTextures() : void;
   }
}

