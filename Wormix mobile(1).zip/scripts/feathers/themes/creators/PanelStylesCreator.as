package feathers.themes.creators
{
   import feathers.controls.Button;
   import feathers.controls.Header;
   import feathers.controls.ImageLoader;
   import feathers.controls.LayoutGroup;
   import feathers.controls.Panel;
   import feathers.controls.text.TextInstanceCreator;
   import feathers.core.ITextRenderer;
   import feathers.layout.AnchorLayout;
   import feathers.layout.AnchorLayoutData;
   import feathers.layout.HorizontalLayout;
   import feathers.layout.HorizontalLayoutData;
   import flash.geom.Rectangle;
   import starling.display.DisplayObject;
   import starling.display.Image;
   import starling.display.Quad;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.textures.Texture;
   import starling.textures.TextureAtlas;
   
   public class PanelStylesCreator implements IStyleCreator
   {
      
      private var _atlas:TextureAtlas;
      
      private var backgroundTexture:Texture;
      
      private var backgroundTextureScaleRect:Rectangle;
      
      private var titleUnderlineTexture:Texture;
      
      private var titleUnderlineTextureScaleRect:Rectangle;
      
      private var subTabBackScaleRect:Rectangle;
      
      private var newPanelBackgroundTexture:Texture;
      
      private var newPanelHeaderBackgroundTexture:Texture;
      
      private var newPanelBackgroundTextureScaleRect:Rectangle;
      
      private var newPanelHeaderBackgroundTextureScaleRect:Rectangle;
      
      private var subTabBackTexture:Texture;
      
      public function PanelStylesCreator(param1:TextureAtlas)
      {
         super();
         _atlas = param1;
      }
      
      public function initializeTextures() : void
      {
         backgroundTexture = _atlas.getTexture("panel_back");
         backgroundTextureScaleRect = new Rectangle(14,14,1,1);
         titleUnderlineTexture = _atlas.getTexture("title_underline");
         titleUnderlineTextureScaleRect = new Rectangle(90,0,20);
         newPanelBackgroundTexture = _atlas.getTexture("panel_background");
         newPanelBackgroundTextureScaleRect = new Rectangle(6,6,4,4);
         newPanelHeaderBackgroundTexture = _atlas.getTexture("tab_new_down");
         newPanelHeaderBackgroundTextureScaleRect = new Rectangle(2,10,4,50);
         subTabBackScaleRect = new Rectangle(0,4,0,8);
         subTabBackTexture = _atlas.getTexture("sub_tab_back");
      }
      
      public function setNormalPanelStyles(param1:Panel) : void
      {
         var panel:Panel = param1;
         setNormalPanesBaseStyles(panel);
         panel.headerFactory = function():Header
         {
            var _loc1_:Header = new Header();
            _loc1_.backgroundSkin = new Sprite();
            return _loc1_;
         };
      }
      
      public function setNormalPanelWithTitleStyles(param1:Panel) : void
      {
         var panel:Panel = param1;
         setNormalPanesBaseStyles(panel);
         panel.headerFactory = function():Header
         {
            var headerBackground:LayoutGroup;
            var header:Header = new Header();
            var lineImage:ImageLoader = new ImageLoader();
            lineImage.source = titleUnderlineTexture;
            lineImage.scale9Grid = titleUnderlineTextureScaleRect;
            lineImage.layoutData = new AnchorLayoutData(NaN,75,0,75);
            headerBackground = new LayoutGroup();
            headerBackground.layout = new AnchorLayout();
            headerBackground.addChild(lineImage);
            header.backgroundSkin = headerBackground;
            header.titleFactory = function():ITextRenderer
            {
               return TextInstanceCreator.createTextRenderer(24,9072988,"center");
            };
            header.paddingTop = 15;
            header.paddingLeft = header.paddingRight = 75;
            header.wordWrap = true;
            return header;
         };
      }
      
      private function setNormalPanesBaseStyles(param1:Panel) : void
      {
         var _loc2_:Image = new Image(backgroundTexture);
         _loc2_.scale9Grid = backgroundTextureScaleRect;
         param1.backgroundSkin = _loc2_;
         param1.horizontalScrollPolicy = "off";
         param1.verticalScrollPolicy = "off";
      }
      
      public function setNewNormalPanelStyles(param1:Panel) : void
      {
         var _loc2_:Image = new Image(newPanelBackgroundTexture);
         _loc2_.scale9Grid = newPanelBackgroundTextureScaleRect;
         setNewPanelCommonStyles(param1,_loc2_);
      }
      
      public function setNewNormalPanel_Title_Styles(param1:Panel) : void
      {
         var panel:Panel = param1;
         var backSkin:Image = new Image(newPanelBackgroundTexture);
         backSkin.scale9Grid = newPanelBackgroundTextureScaleRect;
         setNewPanelCommonStyles(panel,backSkin,true);
         panel.headerFactory = function():Header
         {
            var header:Header = new Header();
            header.backgroundSkin = createNewHeaderBackground(false);
            header.titleFactory = function():ITextRenderer
            {
               return TextInstanceCreator.createFromStyleName("new_bright_big_center");
            };
            header.wordWrap = true;
            header.gap = 5;
            header.padding = 5;
            header.verticalAlign = "middle";
            header.titleAlign = "center";
            return header;
         };
      }
      
      public function setNewNormalPanel_Title_Close_Styles(param1:Panel) : void
      {
         var panel:Panel = param1;
         var backSkin:Image = new Image(newPanelBackgroundTexture);
         backSkin.scale9Grid = newPanelBackgroundTextureScaleRect;
         setNewPanelCommonStyles(panel,backSkin,true);
         panel.headerFactory = function():Header
         {
            var header:Header = new Header();
            var background:DisplayObject = createNewHeaderBackground(true);
            background.addEventListener("triggered",function(param1:Event):void
            {
               panel.dispatchEventWith("close");
            });
            header.backgroundSkin = background;
            header.titleFactory = function():ITextRenderer
            {
               return TextInstanceCreator.createFromStyleName("new_bright_big_center");
            };
            header.wordWrap = true;
            header.gap = 5;
            header.paddingTop = header.paddingBottom = 5;
            header.paddingLeft = header.paddingRight = 50;
            header.verticalAlign = "middle";
            header.titleAlign = "center";
            return header;
         };
      }
      
      private function createNewHeaderBackground(param1:Boolean) : DisplayObject
      {
         var centerPart:LayoutGroup;
         var closeBtn:Button;
         var addCloseButton:Boolean = param1;
         var background:LayoutGroup = new LayoutGroup();
         var layout:HorizontalLayout = new HorizontalLayout();
         layout.paddingLeft = 8;
         layout.paddingRight = 8;
         layout.paddingTop = 8;
         background.layout = layout;
         centerPart = new LayoutGroup();
         centerPart.backgroundSkin = new Quad(60,60,2041646);
         centerPart.layoutData = new HorizontalLayoutData(100);
         background.addChild(centerPart);
         if(addCloseButton)
         {
            closeBtn = new Button();
            closeBtn.styleName = "button_quad_close";
            centerPart.addChild(closeBtn);
            centerPart.layout = new AnchorLayout();
            closeBtn.layoutData = new AnchorLayoutData(-2,-3);
            closeBtn.addEventListener("triggered",function(param1:Event):void
            {
               background.dispatchEventWith("triggered");
            });
         }
         return background;
      }
      
      public function setNewEmptyPanelStyles(param1:Panel) : void
      {
         setNewPanelCommonStyles(param1,null);
         param1.padding = 0;
      }
      
      public function setNewPanelSubTabBarStyles(param1:Panel) : void
      {
         var _loc2_:Image = new Image(subTabBackTexture);
         _loc2_.scale9Grid = subTabBackScaleRect;
         setNewPanelCommonStyles(param1,_loc2_);
         param1.padding = 0;
      }
      
      public function setNewSubPanelDarkStyles(param1:Panel) : void
      {
         setNewPanelCommonStyles(param1,new Quad(16,16,1580837));
      }
      
      public function setNewSubPanelDarklessStyles(param1:Panel) : void
      {
         setNewPanelCommonStyles(param1,new Quad(16,16,2041646));
      }
      
      private function setNewPanelCommonStyles(param1:Panel, param2:DisplayObject, param3:Boolean = false) : void
      {
         var panel:Panel = param1;
         var backSkin:DisplayObject = param2;
         var hasHeader:Boolean = param3;
         panel.backgroundSkin = backSkin;
         panel.padding = 8;
         panel.paddingTop = 0;
         panel.horizontalScrollPolicy = "off";
         panel.verticalScrollPolicy = "off";
         if(hasHeader)
         {
            return;
         }
         panel.headerFactory = function():Header
         {
            var _loc1_:Header = new Header();
            _loc1_.width = _loc1_.height = 0;
            return _loc1_;
         };
      }
   }
}

