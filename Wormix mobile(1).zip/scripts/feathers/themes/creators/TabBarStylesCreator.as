package feathers.themes.creators
{
   import feathers.controls.TabBar;
   import feathers.controls.ToggleButton;
   import feathers.controls.text.TextFormatUtils;
   import feathers.controls.text.TextInstanceCreator;
   import feathers.core.ITextRenderer;
   import feathers.skins.ImageSkin;
   import flash.geom.Rectangle;
   import flash.text.TextFormat;
   import starling.events.Event;
   import starling.textures.Texture;
   import starling.textures.TextureAtlas;
   
   public class TabBarStylesCreator implements IStyleCreator
   {
      
      private var _atlas:TextureAtlas;
      
      private var _tabUpTexture:Texture;
      
      private var _tabDownTexture:Texture;
      
      private var _tabDisabledTexture:Texture;
      
      private var _tabNewUpTexture:Texture;
      
      private var _tabNewDownTexture:Texture;
      
      private var _tabNewDisabledTexture:Texture;
      
      private var _subTabNewDownTexture:Texture;
      
      private var _subTabNewUpTexture:Texture;
      
      private var _scale9Rect:Rectangle;
      
      private var _scale9RectNew:Rectangle;
      
      private var _subTabScale9RectNew:Rectangle;
      
      public function TabBarStylesCreator(param1:TextureAtlas)
      {
         super();
         _atlas = param1;
      }
      
      public function initializeTextures() : void
      {
         _tabUpTexture = _atlas.getTexture("tab_button_up");
         _tabDownTexture = _atlas.getTexture("tab_button_down");
         _tabDisabledTexture = _atlas.getTexture("tab_button_disabled");
         _tabNewUpTexture = _atlas.getTexture("tab_new_up");
         _tabNewDownTexture = _atlas.getTexture("tab_new_down");
         _tabNewDisabledTexture = _atlas.getTexture("tab_new_disabled");
         _subTabNewUpTexture = _atlas.getTexture("sub_tab_up");
         _subTabNewDownTexture = _atlas.getTexture("sub_tab_down");
         _scale9Rect = new Rectangle(5,10,1,0);
         _scale9RectNew = new Rectangle(2,20,4,20);
         _subTabScale9RectNew = new Rectangle(4,20,0,20);
      }
      
      public function setNormalTabBar(param1:TabBar) : void
      {
         var tabBar:TabBar = param1;
         tabBar.tabFactory = function():ToggleButton
         {
            var tf:TextFormat;
            var tab:ToggleButton = new ToggleButton();
            var skin:ImageSkin = new ImageSkin(_tabUpTexture);
            skin.selectedTexture = _tabDownTexture;
            skin.disabledTexture = _tabDisabledTexture;
            skin.scale9Grid = _scale9Rect;
            tab.defaultSkin = skin;
            tf = TextFormatUtils.createFlashTextFormat("WORMIX_NORMAL",18,9072988,"center");
            tab.labelFactory = function():ITextRenderer
            {
               return TextInstanceCreator.createTextRenderer(tf.size as int,tf.color as uint,tf.align);
            };
            tab.addEventListener("stageChange",function(param1:Event):void
            {
               var _loc2_:uint = tab.isSelected ? 5391158 : 9072988;
               tf.color = _loc2_;
               tab.defaultLabelProperties.textFormat = tf;
            });
            tab.padding = 5;
            tab.minWidth = 100;
            tab.maxWidth = 200;
            return tab;
         };
      }
      
      public function setNormalNewTabBar(param1:TabBar) : void
      {
         var tabBar:TabBar = param1;
         tabBar.tabFactory = function():ToggleButton
         {
            var tf:TextFormat;
            var tab:ToggleButton = new ToggleButton();
            var skin:ImageSkin = new ImageSkin(_tabNewUpTexture);
            skin.selectedTexture = _tabNewDownTexture;
            skin.disabledTexture = _tabNewDisabledTexture;
            skin.scale9Grid = _scale9RectNew;
            tab.defaultSkin = skin;
            tf = TextFormatUtils.createFlashTextFormat("WORMIX_NORMAL",18,8886696,"center");
            tab.labelFactory = function():ITextRenderer
            {
               return TextInstanceCreator.createTextRenderer(tf.size as int,tf.color as uint,tf.align);
            };
            tab.addEventListener("stageChange",function(param1:Event):void
            {
               var _loc2_:uint = tab.isSelected ? 7191039 : 8886696;
               tf.color = _loc2_;
               tab.defaultLabelProperties.textFormat = tf;
            });
            tab.padding = 5;
            tab.minWidth = 100;
            tab.maxWidth = 200;
            return tab;
         };
         tabBar.gap = 5;
      }
      
      public function setNewSubTabBar(param1:TabBar) : void
      {
         var tabBar:TabBar = param1;
         tabBar.tabFactory = function():ToggleButton
         {
            var tf:TextFormat;
            var tab:ToggleButton = new ToggleButton();
            var skin:ImageSkin = new ImageSkin(_subTabNewUpTexture);
            skin.selectedTexture = _subTabNewDownTexture;
            skin.disabledTexture = _tabNewDisabledTexture;
            skin.scale9Grid = _subTabScale9RectNew;
            tab.defaultSkin = skin;
            tf = TextFormatUtils.createFlashTextFormat("WORMIX_NORMAL",18,8886696,"center");
            tab.labelFactory = function():ITextRenderer
            {
               return TextInstanceCreator.createTextRenderer(tf.size as int,tf.color as uint,tf.align);
            };
            tab.addEventListener("stageChange",function(param1:Event):void
            {
               var _loc2_:uint = tab.isSelected ? 7191039 : 8886696;
               tf.color = _loc2_;
               tab.defaultLabelProperties.textFormat = tf;
            });
            tab.padding = 5;
            tab.minWidth = 100;
            tab.maxWidth = 200;
            return tab;
         };
         tabBar.gap = 5;
      }
   }
}

