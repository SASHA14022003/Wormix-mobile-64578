package feathers.themes.creators
{
   import feathers.controls.List;
   import starling.textures.TextureAtlas;
   
   public class ListStylesCreator implements IStyleCreator
   {
      
      private var _atlas:TextureAtlas;
      
      public function ListStylesCreator(param1:TextureAtlas)
      {
         super();
         _atlas = param1;
      }
      
      public function initializeTextures() : void
      {
      }
      
      public function setDefaultListStyles(param1:List) : void
      {
      }
   }
}

