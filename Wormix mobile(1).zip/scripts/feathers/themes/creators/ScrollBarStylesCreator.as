package feathers.themes.creators
{
   import feathers.controls.Button;
   import feathers.controls.SimpleScrollBar;
   import feathers.skins.ImageSkin;
   import flash.geom.Rectangle;
   import starling.textures.Texture;
   import starling.textures.TextureAtlas;
   
   public class ScrollBarStylesCreator implements IStyleCreator
   {
      
      private var _atlas:TextureAtlas;
      
      private var _thumbTexture:Texture;
      
      private var _scaleRect:Rectangle;
      
      public function ScrollBarStylesCreator(param1:TextureAtlas)
      {
         super();
         _atlas = param1;
      }
      
      public function initializeTextures() : void
      {
         _thumbTexture = _atlas.getTexture("scroll_thumb");
         _scaleRect = new Rectangle(3,3,2,2);
      }
      
      public function setSimpleNormalScrollBar(param1:SimpleScrollBar) : void
      {
         var scrollBar:SimpleScrollBar = param1;
         scrollBar.thumbFactory = function():Button
         {
            var _loc2_:ImageSkin = new ImageSkin(_thumbTexture);
            _loc2_.scale9Grid = _scaleRect;
            var _loc1_:Button = new Button();
            _loc1_.defaultSkin = _loc2_;
            _loc1_.width = 8;
            _loc1_.height = 8;
            _loc1_.styleName = "";
            return _loc1_;
         };
         scrollBar.width = 8;
         scrollBar.height = 8;
      }
   }
}

