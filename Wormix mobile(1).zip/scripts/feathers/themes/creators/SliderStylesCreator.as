package feathers.themes.creators
{
   import feathers.controls.Button;
   import feathers.controls.Slider;
   import starling.display.DisplayObject;
   import starling.display.Quad;
   import starling.textures.TextureAtlas;
   
   public class SliderStylesCreator implements IStyleCreator
   {
      
      private var _atlas:TextureAtlas;
      
      public function SliderStylesCreator(param1:TextureAtlas)
      {
         super();
         _atlas = param1;
      }
      
      public function initializeTextures() : void
      {
      }
      
      public function setNormalSliderStyles(param1:Slider) : void
      {
         var slider:Slider = param1;
         slider.maximumTrackFactory = function():Button
         {
            var _loc1_:Button = new Button();
            _loc1_.defaultSkin = new Quad(10,10,14863012);
            return _loc1_;
         };
         slider.minimumTrackFactory = function():DisplayObject
         {
            var _loc1_:Button = new Button();
            _loc1_.defaultSkin = new Quad(10,10,14863012);
            return _loc1_;
         };
         slider.thumbFactory = function():Button
         {
            var _loc1_:Button = new Button();
            _loc1_.styleName = "button_green";
            return _loc1_;
         };
      }
   }
}

