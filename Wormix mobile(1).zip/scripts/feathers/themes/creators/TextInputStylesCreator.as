package feathers.themes.creators
{
   import feathers.controls.TextInput;
   import feathers.controls.text.TextInstanceCreator;
   import feathers.core.ITextEditor;
   import feathers.core.ITextRenderer;
   import flash.geom.Rectangle;
   import starling.display.Image;
   import starling.textures.Texture;
   import starling.textures.TextureAtlas;
   
   public class TextInputStylesCreator implements IStyleCreator
   {
      
      private var _atlas:TextureAtlas;
      
      private var _textInputBackTexture:Texture;
      
      private var _textInputBackTextureRect:Rectangle;
      
      private var _textNewInputBackTexture:Texture;
      
      private var _textNewInputBackTextureRect:Rectangle;
      
      public function TextInputStylesCreator(param1:TextureAtlas)
      {
         super();
         _atlas = param1;
      }
      
      public function initializeTextures() : void
      {
         _textInputBackTexture = _atlas.getTexture("text_input_back");
         _textInputBackTextureRect = new Rectangle(4,18,5,24);
         _textNewInputBackTexture = _atlas.getTexture("text_input_background");
         _textNewInputBackTextureRect = new Rectangle(6,6,4,4);
      }
      
      public function setCommonInputStyles(param1:TextInput) : void
      {
         var backgroundSkin:Image;
         var input:TextInput = param1;
         input.isEditable = true;
         input.promptFactory = function():ITextRenderer
         {
            return TextInstanceCreator.createTextRenderer(18,5391158,"left");
         };
         input.textEditorFactory = function():ITextEditor
         {
            return TextInstanceCreator.createStageTextTextEditor(18,5391158,"left",false);
         };
         backgroundSkin = new Image(_textInputBackTexture);
         backgroundSkin.scale9Grid = _textInputBackTextureRect;
         input.backgroundSkin = backgroundSkin;
         input.verticalAlign = "top";
      }
      
      public function setCommonMultilineTextInputStyles(param1:TextInput) : void
      {
         var backgroundSkin:Image;
         var input:TextInput = param1;
         input.isEditable = true;
         input.promptFactory = function():ITextRenderer
         {
            return TextInstanceCreator.createTextRenderer(18,5391158,"left");
         };
         input.textEditorFactory = function():ITextEditor
         {
            return TextInstanceCreator.createStageTextTextEditor(18,5391158,"left",true);
         };
         backgroundSkin = new Image(_textInputBackTexture);
         backgroundSkin.scale9Grid = _textInputBackTextureRect;
         input.backgroundSkin = backgroundSkin;
         input.verticalAlign = "top";
      }
      
      public function setNewSingleLineInputStyles(param1:TextInput) : void
      {
         var input:TextInput = param1;
         input.isEditable = true;
         input.promptFactory = function():ITextRenderer
         {
            return TextInstanceCreator.createTextRenderer(18,8886696,"left");
         };
         input.textEditorFactory = function():ITextEditor
         {
            return TextInstanceCreator.createStageTextTextEditor(18,8886696,"left",false);
         };
         input.verticalAlign = "middle";
         setNewTextInputBaseStyles(input);
      }
      
      public function setNewMultiLineTextInputStyles(param1:TextInput) : void
      {
         var input:TextInput = param1;
         input.isEditable = true;
         input.promptFactory = function():ITextRenderer
         {
            return TextInstanceCreator.createTextRenderer(18,8886696,"left");
         };
         input.textEditorFactory = function():ITextEditor
         {
            return TextInstanceCreator.createStageTextTextEditor(18,8886696,"left",true);
         };
         input.verticalAlign = "top";
         setNewTextInputBaseStyles(input);
      }
      
      private function setNewTextInputBaseStyles(param1:TextInput) : void
      {
         param1.padding = 5;
         var _loc2_:Image = new Image(_textNewInputBackTexture);
         _loc2_.scale9Grid = _textNewInputBackTextureRect;
         param1.backgroundSkin = _loc2_;
      }
      
      public function setChatInputStyles(param1:TextInput) : void
      {
         var input:TextInput = param1;
         input.isEditable = true;
         input.promptFactory = function():ITextRenderer
         {
            return TextInstanceCreator.createTextRenderer(18,5391158,"left");
         };
         input.textEditorFactory = function():ITextEditor
         {
            return TextInstanceCreator.createTextFieldTextEditor(18,5391158,"left");
         };
         input.verticalAlign = "middle";
      }
   }
}

