package feathers.themes.creators
{
   import feathers.controls.Button;
   import feathers.controls.ToggleButton;
   import feathers.controls.text.TextInstanceCreator;
   import feathers.core.ITextRenderer;
   import feathers.skins.ImageSkin;
   import flash.geom.Rectangle;
   import starling.display.Image;
   import starling.events.Event;
   import starling.filters.ColorMatrixFilter;
   import starling.textures.Texture;
   import starling.textures.TextureAtlas;
   
   public class ButtonStylesCreator implements IStyleCreator
   {
      
      protected static const DEFAULT_BUTTON_SCALE9_GRID:Rectangle = new Rectangle(13,13,1,1);
      
      private var _atlas:TextureAtlas;
      
      protected var button_green_up_texture:Texture;
      
      protected var button_green_down_texture:Texture;
      
      protected var button_red_up_texture:Texture;
      
      protected var button_red_down_texture:Texture;
      
      protected var button_orange_up_texture:Texture;
      
      protected var button_orange_down_texture:Texture;
      
      protected var button_purple_up_texture:Texture;
      
      protected var button_purple_down_texture:Texture;
      
      protected var button_blue_up_texture:Texture;
      
      protected var button_blue_down_texture:Texture;
      
      protected var button_grey_up_texture:Texture;
      
      protected var button_close_up_texture:Texture;
      
      protected var button_close_down_texture:Texture;
      
      protected var button_round_green_up_texture:Texture;
      
      protected var button_round_green_down_texture:Texture;
      
      protected var button_round_yellow_up_texture:Texture;
      
      protected var button_round_yellow_down_texture:Texture;
      
      protected var button_round_yellow_disabled_texture:Texture;
      
      protected var button_new_green_up_texture:Texture;
      
      protected var button_new_green_down_texture:Texture;
      
      protected var button_new_blue_up_texture:Texture;
      
      protected var button_new_blue_down_texture:Texture;
      
      protected var button_new_red_up_texture:Texture;
      
      protected var button_new_red_down_texture:Texture;
      
      protected var button_new_disabled_texture:Texture;
      
      protected var button_quad_close_up_texture:Texture;
      
      protected var button_quad_close_down_texture:Texture;
      
      protected var button_quad_grey_up_texture:Texture;
      
      protected var button_quad_grey_down_texture:Texture;
      
      protected var arrow_left_up_texture:Texture;
      
      protected var arrow_left_down_texture:Texture;
      
      public function ButtonStylesCreator(param1:TextureAtlas)
      {
         super();
         _atlas = param1;
      }
      
      public function initializeTextures() : void
      {
         button_green_up_texture = _atlas.getTexture("button_green_up");
         button_green_down_texture = _atlas.getTexture("button_green_down");
         button_red_up_texture = _atlas.getTexture("button_red_up");
         button_red_down_texture = _atlas.getTexture("button_red_down");
         button_orange_up_texture = _atlas.getTexture("button_orange_up");
         button_orange_down_texture = _atlas.getTexture("button_orange_down");
         button_purple_up_texture = _atlas.getTexture("button_purple_up");
         button_purple_down_texture = _atlas.getTexture("button_purple_down");
         button_blue_up_texture = _atlas.getTexture("button_blue_up");
         button_blue_down_texture = _atlas.getTexture("button_blue_down");
         button_grey_up_texture = _atlas.getTexture("button_grey_up");
         button_close_up_texture = _atlas.getTexture("button_close_up");
         button_close_down_texture = _atlas.getTexture("button_close_down");
         button_round_green_up_texture = _atlas.getTexture("button_round_green_up");
         button_round_green_down_texture = _atlas.getTexture("button_round_green_down");
         button_round_yellow_up_texture = _atlas.getTexture("button_round_yellow_up");
         button_round_yellow_down_texture = _atlas.getTexture("button_round_yellow_down");
         button_round_yellow_disabled_texture = _atlas.getTexture("button_round_yellow_disabled");
         button_new_green_up_texture = _atlas.getTexture("button_new_green_up");
         button_new_green_down_texture = _atlas.getTexture("button_new_green_down");
         button_new_blue_up_texture = _atlas.getTexture("button_new_blue_up");
         button_new_blue_down_texture = _atlas.getTexture("button_new_blue_down");
         button_new_red_up_texture = _atlas.getTexture("button_new_red_up");
         button_new_red_down_texture = _atlas.getTexture("button_new_red_down");
         button_new_disabled_texture = _atlas.getTexture("button_new_disabled");
         button_quad_close_up_texture = _atlas.getTexture("button_quad_close_up");
         button_quad_close_down_texture = _atlas.getTexture("button_quad_close_down");
         button_quad_grey_up_texture = _atlas.getTexture("button_quad_grey_up");
         button_quad_grey_down_texture = _atlas.getTexture("button_quad_grey_down");
         arrow_left_up_texture = _atlas.getTexture("arrow_left_up");
         arrow_left_down_texture = _atlas.getTexture("arrow_left_down");
      }
      
      public function setBaseButtonStyles(param1:Button) : void
      {
         param1.padding = 5;
         param1.useHandCursor = true;
      }
      
      public function setGreenButtonStyles(param1:Button) : void
      {
         setCommonButtonStyles(param1,button_green_up_texture,button_green_down_texture,button_grey_up_texture);
      }
      
      public function setBlueButtonStyles(param1:Button) : void
      {
         setCommonButtonStyles(param1,button_blue_up_texture,button_blue_down_texture,button_grey_up_texture);
      }
      
      public function setRedButtonStyles(param1:Button) : void
      {
         setCommonButtonStyles(param1,button_red_up_texture,button_red_down_texture,button_grey_up_texture);
      }
      
      public function setOrangeButtonStyles(param1:Button) : void
      {
         setCommonButtonStyles(param1,button_orange_up_texture,button_orange_down_texture,button_grey_up_texture);
      }
      
      public function setPurpleButtonStyles(param1:Button) : void
      {
         setCommonButtonStyles(param1,button_purple_up_texture,button_purple_down_texture,button_grey_up_texture);
      }
      
      private function setCommonButtonStyles(param1:Button, param2:Texture, param3:Texture, param4:Texture) : void
      {
         var button:Button = param1;
         var upTexture:Texture = param2;
         var downTexture:Texture = param3;
         var disabledTexture:Texture = param4;
         var skin:ImageSkin = new ImageSkin(upTexture);
         skin.setTextureForState("down",downTexture);
         skin.setTextureForState("disabled",disabledTexture);
         if(button is ToggleButton)
         {
            skin.selectedTexture = upTexture;
            skin.setTextureForState("disabledAndSelected",disabledTexture);
         }
         skin.scale9Grid = DEFAULT_BUTTON_SCALE9_GRID;
         button.defaultSkin = skin;
         button.labelFactory = function():ITextRenderer
         {
            return TextInstanceCreator.createTextRenderer(24,16777215,"center");
         };
         button.minWidth = 40;
         button.minHeight = 40;
         setBaseButtonStyles(button);
      }
      
      public function setNewGreenButtonStyles(param1:Button) : void
      {
         setCommonNewButtonStyles(param1,button_new_green_up_texture,button_new_green_down_texture,button_new_disabled_texture);
      }
      
      public function setNewBlueButtonStyles(param1:Button) : void
      {
         setCommonNewButtonStyles(param1,button_new_blue_up_texture,button_new_blue_down_texture,button_new_disabled_texture);
      }
      
      public function setNewRedButtonStyles(param1:Button) : void
      {
         setCommonNewButtonStyles(param1,button_new_red_up_texture,button_new_red_down_texture,button_new_disabled_texture);
      }
      
      private function setCommonNewButtonStyles(param1:Button, param2:Texture, param3:Texture, param4:Texture) : void
      {
         var button:Button = param1;
         var upTexture:Texture = param2;
         var downTexture:Texture = param3;
         var disabledTexture:Texture = param4;
         var skin:ImageSkin = new ImageSkin(upTexture);
         skin.setTextureForState("down",downTexture);
         skin.setTextureForState("disabled",disabledTexture);
         if(button is ToggleButton)
         {
            skin.selectedTexture = upTexture;
            skin.setTextureForState("disabledAndSelected",disabledTexture);
         }
         skin.scale9Grid = DEFAULT_BUTTON_SCALE9_GRID;
         button.defaultSkin = skin;
         button.labelFactory = function():ITextRenderer
         {
            return TextInstanceCreator.createTextRenderer(18,16777215,"center");
         };
         button.labelOffsetY = -2;
         button.addEventListener("stageChange",function(param1:Event):void
         {
            if(button.currentState == "down")
            {
               button.labelOffsetY = 0;
               button.iconOffsetY = 0;
            }
            else
            {
               button.labelOffsetY = -2;
               button.iconOffsetY = -2;
            }
         });
         button.minWidth = 100;
         button.minHeight = 54;
         setBaseButtonStyles(button);
      }
      
      public function setCloseQuadButtonStyles(param1:Button) : void
      {
         setQuadButtonStyles(param1,button_quad_close_up_texture,button_quad_close_down_texture);
      }
      
      public function setGreyQuadButtonStyles(param1:Button) : void
      {
         setQuadButtonStyles(param1,button_quad_grey_up_texture,button_quad_grey_down_texture);
      }
      
      private function setQuadButtonStyles(param1:Button, param2:Texture, param3:Texture) : void
      {
         var button:Button = param1;
         var upTexture:Texture = param2;
         var downTexture:Texture = param3;
         var skin:ImageSkin = new ImageSkin(upTexture);
         skin.setTextureForState("down",downTexture);
         button.defaultSkin = skin;
         button.iconOffsetX = -2;
         button.iconOffsetY = -2;
         button.addEventListener("stageChange",function(param1:Event):void
         {
            if(button.currentState == "down")
            {
               button.iconOffsetY = 0;
            }
            else
            {
               button.iconOffsetY = -2;
            }
         });
         button.width = 40;
         button.height = 40;
         setBaseButtonStyles(button);
      }
      
      public function setCloseButtonStyles(param1:Button) : void
      {
         var _loc2_:ImageSkin = new ImageSkin(button_close_up_texture);
         _loc2_.setTextureForState("down",button_close_down_texture);
         param1.defaultSkin = _loc2_;
         param1.width = 60;
         param1.height = 60;
         setBaseButtonStyles(param1);
      }
      
      public function setBuyFuzyButtonStyles(param1:Button) : void
      {
         setBuyButtonStyles(param1,button_green_up_texture,button_green_down_texture,"icon_fuzy");
      }
      
      public function setBuyRubyButtonStyles(param1:Button) : void
      {
         setBuyButtonStyles(param1,button_blue_up_texture,button_blue_down_texture,"icon_ruby");
      }
      
      public function setBuyVipButtonStyles(param1:Button) : void
      {
         setBuyButtonStyles(param1,button_purple_up_texture,button_purple_down_texture,"crown");
      }
      
      public function setBuyNoAdsButtonStyles(param1:Button) : void
      {
         setBuyButtonStyles(param1,button_purple_up_texture,button_purple_down_texture,"icon_no_ads");
      }
      
      public function setShowAdsButtonStyles(param1:Button) : void
      {
         setBuyButtonStyles(param1,button_orange_up_texture,button_orange_down_texture,"icon_ads");
      }
      
      private function setBuyButtonStyles(param1:Button, param2:Texture, param3:Texture, param4:String) : void
      {
         var grayScaleFilter:ColorMatrixFilter;
         var iconTexture:Texture;
         var iconScale:Number;
         var defaultIconImage:Image;
         var disabledIconImage:Image;
         var button:Button = param1;
         var upTexture:Texture = param2;
         var downTexture:Texture = param3;
         var iconName:String = param4;
         var skin:ImageSkin = new ImageSkin(upTexture);
         skin.setTextureForState("down",downTexture);
         skin.setTextureForState("disabled",button_grey_up_texture);
         if(button is ToggleButton)
         {
            skin.selectedTexture = upTexture;
            skin.setTextureForState("disabledAndSelected",button_grey_up_texture);
         }
         skin.scale9Grid = DEFAULT_BUTTON_SCALE9_GRID;
         button.defaultSkin = skin;
         button.labelFactory = function():ITextRenderer
         {
            return TextInstanceCreator.createTextRenderer(24,16777215,"center");
         };
         grayScaleFilter = new ColorMatrixFilter();
         grayScaleFilter.adjustSaturation(-1);
         iconTexture = _atlas.getTexture(iconName);
         iconScale = 0.6;
         defaultIconImage = new Image(iconTexture);
         defaultIconImage.scale = iconScale;
         disabledIconImage = new Image(iconTexture);
         disabledIconImage.scale = iconScale;
         disabledIconImage.filter = grayScaleFilter;
         button.defaultIcon = defaultIconImage;
         button.disabledIcon = disabledIconImage;
         button.gap = 5;
         button.verticalAlign = "middle";
         button.labelOffsetY = -2;
         button.minWidth = 40;
         button.minHeight = 40;
         setBaseButtonStyles(button);
      }
      
      public function setGreenRoundButtonStyles(param1:Button) : void
      {
         setRoundButtonStyles(param1,button_round_green_up_texture,button_round_green_down_texture,button_round_green_up_texture);
      }
      
      public function setYellowRoundButtonStyles(param1:Button) : void
      {
         setRoundButtonStyles(param1,button_round_yellow_up_texture,button_round_yellow_down_texture,button_round_yellow_disabled_texture);
      }
      
      public function setYellowRoundArrowLeftButtonStyles(param1:Button) : void
      {
         setRoundButtonStyles(param1,button_round_yellow_up_texture,button_round_yellow_down_texture,button_round_yellow_disabled_texture);
         setRoundButtonArrows(param1,true);
      }
      
      public function setYellowRoundArrowRightButtonStyles(param1:Button) : void
      {
         setRoundButtonStyles(param1,button_round_yellow_up_texture,button_round_yellow_down_texture,button_round_yellow_disabled_texture);
         setRoundButtonArrows(param1,false);
      }
      
      private function setRoundButtonStyles(param1:Button, param2:Texture, param3:Texture, param4:Texture) : void
      {
         var _loc5_:ImageSkin = new ImageSkin(param2);
         _loc5_.setTextureForState("down",param3);
         _loc5_.setTextureForState("disabled",param4);
         param1.defaultSkin = _loc5_;
         param1.hasLabelTextRenderer = false;
         setBaseButtonStyles(param1);
      }
      
      private function setRoundButtonArrows(param1:Button, param2:Boolean) : void
      {
         var _loc3_:ImageSkin = new ImageSkin(arrow_left_up_texture);
         _loc3_.setTextureForState("down",arrow_left_down_texture);
         _loc3_.selectedTexture = arrow_left_down_texture;
         if(param2)
         {
            _loc3_.pivotX = arrow_left_down_texture.width * 0.1;
         }
         else
         {
            _loc3_.scaleX = -1;
            _loc3_.pivotX = arrow_left_down_texture.width * 1.1;
         }
         param1.defaultIcon = _loc3_;
      }
   }
}

