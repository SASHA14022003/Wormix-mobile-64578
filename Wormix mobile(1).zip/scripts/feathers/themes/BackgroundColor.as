package feathers.themes
{
   public class BackgroundColor
   {
      
      public static const PANEL_COLOR:uint = 2832454;
      
      public static const CONTENT_COLOR_DARK:uint = 1580837;
      
      public static const CONTENT_COLOR_DARKLESS:uint = 2041646;
      
      public static const CONTENT_COLOR_LIGHT:uint = 2041646;
      
      public function BackgroundColor()
      {
         super();
      }
   }
}

