package feathers.themes.styles
{
   public class AlternateScrollBarStyles
   {
      
      public static const SIMPLE_NORMAL:String = "simple-normal";
      
      public function AlternateScrollBarStyles()
      {
         super();
      }
   }
}

