package feathers.themes.styles
{
   public class AlternateNumericStepperStyles
   {
      
      public static const NORMAL:String = "numeric_stepper_normal";
      
      public static const BIG:String = "numeric_stepper_big";
      
      public function AlternateNumericStepperStyles()
      {
         super();
      }
   }
}

