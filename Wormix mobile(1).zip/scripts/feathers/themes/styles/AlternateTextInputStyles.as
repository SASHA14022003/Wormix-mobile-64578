package feathers.themes.styles
{
   public class AlternateTextInputStyles
   {
      
      public static const COMMON:String = "text_input_common";
      
      public static const COMMON_MULTILINE:String = "text_input_common_multiline";
      
      public static const SINGLE_LINE_NEW:String = "text_input_single_line_new";
      
      public static const MULTI_LINE_NEW:String = "text_input_multi_line_new";
      
      public static const CHAT:String = "text_input_chat";
      
      public function AlternateTextInputStyles()
      {
         super();
      }
   }
}

