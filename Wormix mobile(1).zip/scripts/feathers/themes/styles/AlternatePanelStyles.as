package feathers.themes.styles
{
   public class AlternatePanelStyles
   {
      
      public static const NORMAL:String = "normal";
      
      public static const NORMAL_WITH_TITLE:String = "normal_with_title";
      
      public static const NEW_PANEL_NORMAL:String = "new_panel_normal";
      
      public static const NEW_PANEL_NORMAL_TITLE:String = "new_panel_normal_title";
      
      public static const NEW_PANEL_NORMAL_TITLE_CLOSE:String = "new_panel_normal_title_close";
      
      public static const NEW_PANEL_EMPTY:String = "new_panel_empty";
      
      public static const NEW_PANEL_SUB_TAB_BAR:String = "new_panel_sub_tab_bar";
      
      public static const NEW_SUB_PANEL_DARK:String = "new_sub_panel_dark";
      
      public static const NEW_SUB_PANEL_DARKLESS:String = "new_sub_panel_light";
      
      public static const NEW_SUB_PANEL_LIGHT:String = "new_sub_panel_light";
      
      public function AlternatePanelStyles()
      {
         super();
      }
   }
}

