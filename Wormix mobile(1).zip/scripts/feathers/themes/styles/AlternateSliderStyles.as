package feathers.themes.styles
{
   public class AlternateSliderStyles
   {
      
      public static const NORMAL:String = "slider_normal";
      
      public function AlternateSliderStyles()
      {
         super();
      }
   }
}

