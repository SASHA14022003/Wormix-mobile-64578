package feathers.themes.styles
{
   public class AlternateTextStyles
   {
      
      public static const PROPERTY_LIGHT_HEADING:String = "PropertyLightHeading";
      
      public static const PROPERTY_LIGHT_TEXT:String = "PropertyLightText";
      
      public static const NORMAL_LIGHT_TEXT:String = "NormalLightText";
      
      public static const HINT_TITLE:String = "HintTitle";
      
      public static const DARKGRAY_SMALL_RIGHT:String = "darkgray_small_right";
      
      public static const LIGHT_GRAY_SMALL_LEFT:String = "lightgray_small_left";
      
      public static const LIGHT_GRAY_BIGGER_RIGHT:String = "lightgray_bigger_right";
      
      public static const LIGHT_BROWN_SMALL_LEFT:String = "lightbrown_small_left";
      
      public static const GREEN_SMALL_LEFT:String = "darkgreen_small_left";
      
      public static const LIGHT_BROWN_BIG_CENTER:String = "lightbrown_big_center";
      
      public static const LIGHT_BROWN_NORMAL_LEFT:String = "lightbrown_normal_left";
      
      public static const LIGHT_BROWN_NORMAL_CENTER:String = "lightbrown_normal_center";
      
      public static const DARK_BROWN_NORMAL_LEFT:String = "darkbrown_normal_left";
      
      public static const DARK_BROWN_NORMAL_BIGGER_LEFT:String = "darkbrown_bigger_left";
      
      public static const DARK_BROWN_MICRO_LEFT:String = "darkbrown_micro_left";
      
      public static const RED_NORMAL_LEFT:String = "red_normal_left";
      
      public static const BLUE_NORMAL_LEFT:String = "blue_normal_left";
      
      public static const BRIGHT_GREEN_SMALL_LEFT:String = "brightgreen_small_left";
      
      public static const LIGHT_BROWN_BIGGER_CENTER:String = "lightbrown_bigger_center";
      
      public static const LIGHT_BROWN_BIGGER_LEFT:String = "lightbrown_bigger_left";
      
      public static const COLD_LIGHT_BIG_LEFT:String = "coldlight_big_left";
      
      public static const COLD_LIGHT_TINY_LEFT:String = "coldlight_tiny_left";
      
      public static const COLD_LIGHT_SMALL_LEFT:String = "coldlight_small_left";
      
      public static const WHITE_GIANT_CENTER:String = "white_giant_center";
      
      public static const WHITE_NORMAL_CENTER:String = "white_normal_center";
      
      public static const BITMAP_DARK_BROWN_GIANT_LEFT:String = "bitmap_darkbrown_giant_left";
      
      public static const INPUT_LIGHT_BROWN_BIG_CENTER:String = "input_lightbrown_big_center";
      
      public static const BUTTON_LABEL_LARGE:String = "ButtonLabelLarge";
      
      public static const BUTTON_LABEL_BIGGER:String = "ButtonLabelBigger";
      
      public static const FIGHT_BUTTON_LABEL:String = "FightButtonLabel";
      
      public static const CHAT_SOCIAL_TOGGLE:String = "ChatSocialToggle";
      
      public static const ITEM_NAME_NORMAL:String = "ItemNameNormal";
      
      public static const ITEM_NAME_SUPERIOR:String = "ItemNameSuperior";
      
      public static const ITEM_NAME_AGGRESSIVE:String = "ItemNameAggressive";
      
      public static const ITEM_NAME_DEFENSIVE:String = "ItemNameDefensive";
      
      public static const ITEM_NAME_VIOLENT:String = "ItemNameViolent";
      
      public static const ITEM_NAME_EPIC:String = "ItemNameEpic";
      
      public static const ITEM_NAME_LEGENDARY:String = "ItemNameLegendary";
      
      public static const HINT_ACTION_LABEL:String = "HintActionLabel";
      
      public static const VIP_HINT_ACTION_LABEL:String = "VipHintActionLabel";
      
      public static const NUMERIC_STEPPER_BIG_INPUT:String = "numeric_stepper_big_input";
      
      public static const NUMERIC_STEPPER_NORMAL_INPUT:String = "numeric_stepper_normal_input";
      
      public static const NEW_DARK_BIG_CENTER:String = "new_dark_big_center";
      
      public static const NEW_DARK_BIG_LEFT:String = "new_dark_big_left";
      
      public static const NEW_DARK_BIG_RIGHT:String = "new_dark_big_right";
      
      public static const NEW_BRIGHT_BIG_CENTER:String = "new_bright_big_center";
      
      public static const NEW_BRIGHT_BIG_LEFT:String = "new_bright_big_left";
      
      public static const NEW_BRIGHT_BIG_RIGHT:String = "new_bright_big_right";
      
      public static const NEW_WHITE_BIG_CENTER:String = "new_white_big_center";
      
      public static const NEW_WHITE_BIG_LEFT:String = "new_white_big_left";
      
      public static const NEW_WHITE_BIG_RIGHT:String = "new_white_big_right";
      
      public static const NEW_DARK_NORMAL_CENTER:String = "new_dark_normal_center";
      
      public static const NEW_DARK_NORMAL_LEFT:String = "new_dark_normal_left";
      
      public static const NEW_DARK_NORMAL_RIGHT:String = "new_dark_normal_right";
      
      public static const NEW_BRIGHT_NORMAL_CENTER:String = "new_bright_normal_center";
      
      public static const NEW_BRIGHT_NORMAL_LEFT:String = "new_bright_normal_left";
      
      public static const NEW_BRIGHT_NORMAL_RIGHT:String = "new_bright_normal_right";
      
      public static const NEW_WHITE_NORMAL_CENTER:String = "new_white_normal_center";
      
      public static const NEW_WHITE_NORMAL_LEFT:String = "new_white_normal_left";
      
      public static const NEW_WHITE_NORMAL_RIGHT:String = "new_white_normal_right";
      
      public static const NEW_DARK_SMALL_CENTER:String = "new_dark_small_center";
      
      public static const NEW_DARK_SMALL_LEFT:String = "new_dark_small_left";
      
      public static const NEW_DARK_SMALL_RIGHT:String = "new_dark_small_right";
      
      public static const NEW_BRIGHT_SMALL_CENTER:String = "new_bright_small_center";
      
      public static const NEW_BRIGHT_SMALL_LEFT:String = "new_bright_small_left";
      
      public static const NEW_BRIGHT_SMALL_RIGHT:String = "new_bright_small_right";
      
      public static const NEW_WHITE_SMALL_CENTER:String = "new_white_small_center";
      
      public static const NEW_WHITE_SMALL_LEFT:String = "new_white_small_left";
      
      public static const NEW_WHITE_SMALL_RIGHT:String = "new_white_small_right";
      
      public function AlternateTextStyles()
      {
         super();
      }
   }
}

