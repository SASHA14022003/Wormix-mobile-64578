package feathers.themes.styles
{
   public class AlternateButtonsStyles
   {
      
      public static const BUTTON_GREEN:String = "button_green";
      
      public static const BUTTON_BLUE:String = "button_blue";
      
      public static const BUTTON_RED:String = "button_red";
      
      public static const BUTTON_ORANGE:String = "button_orange";
      
      public static const BUTTON_PURPLE:String = "button_purple";
      
      public static const BUTTON_CLOSE:String = "button_close";
      
      public static const BUTTON_NEW_GREEN:String = "button_new_green";
      
      public static const BUTTON_NEW_BLUE:String = "button_new_blue";
      
      public static const BUTTON_NEW_RED:String = "button_new_red";
      
      public static const BUTTON_NEW_ORANGE:String = "button_new_orange";
      
      public static const BUTTON_QUAD_CLOSE:String = "button_quad_close";
      
      public static const BUTTON_QUAD_GREY:String = "button_quad_grey";
      
      public static const BUTTON_ROUND_GREEN:String = "button_round_green";
      
      public static const BUTTON_ROUND_YELLOW:String = "button_round_yellow";
      
      public static const BUTTON_ROUND_YELLOW_ARROW_LEFT:String = "button_round_yellow_arrow_left";
      
      public static const BUTTON_ROUND_YELLOW_ARROW_RIGHT:String = "button_round_yellow_arrow_right";
      
      public static const BUTTON_BUY_FUZY:String = "button_buy_fuzy";
      
      public static const BUTTON_BUY_RUBY:String = "button_buy_ruby";
      
      public static const BUTTON_BUY_VIP:String = "button_buy_vip";
      
      public static const BUTTON_BUY_NO_ADS:String = "button_buy_no_ads";
      
      public static const BUTTON_SHOW_ADS:String = "button_show_ads";
      
      public function AlternateButtonsStyles()
      {
         super();
      }
   }
}

