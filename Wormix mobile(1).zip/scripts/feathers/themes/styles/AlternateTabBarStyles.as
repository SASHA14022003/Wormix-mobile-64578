package feathers.themes.styles
{
   public class AlternateTabBarStyles
   {
      
      public static const NORMAL:String = "tab_bar_normal";
      
      public static const NORMAL_NEW:String = "tab_bar_normal_new";
      
      public static const SUB_NEW:String = "tab_bar_sub_new";
      
      public function AlternateTabBarStyles()
      {
         super();
      }
   }
}

