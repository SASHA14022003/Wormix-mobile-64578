package feathers.themes
{
   public class FontSize
   {
      
      public static const GIANT:uint = 36;
      
      public static const LARGE:uint = 28;
      
      public static const BIG:uint = 24;
      
      public static const NORMAL_BIGGER:uint = 22;
      
      public static const NORMAL:uint = 18;
      
      public static const SMALL:uint = 16;
      
      public static const TINY:uint = 14;
      
      public static const MICRO:uint = 12;
      
      public function FontSize()
      {
         super();
      }
      
      public static function getSizeByStyleName(param1:String) : uint
      {
         if(param1.indexOf("micro") != -1)
         {
            return 12;
         }
         if(param1.indexOf("tiny") != -1)
         {
            return 14;
         }
         if(param1.indexOf("small") != -1)
         {
            return 16;
         }
         if(param1.indexOf("normal") != -1)
         {
            return 18;
         }
         if(param1.indexOf("bigger") != -1)
         {
            return 22;
         }
         if(param1.indexOf("big") != -1)
         {
            return 24;
         }
         if(param1.indexOf("large") != -1)
         {
            return 28;
         }
         if(param1.indexOf("giant") != -1)
         {
            return 36;
         }
         trace("NO SIZE IN " + param1);
         return 18;
      }
   }
}

