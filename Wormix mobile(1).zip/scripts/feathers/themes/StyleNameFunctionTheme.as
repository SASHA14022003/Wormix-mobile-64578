package feathers.themes
{
   import feathers.core.IFeathersControl;
   import feathers.skins.ConditionalStyleProvider;
   import feathers.skins.IStyleProvider;
   import feathers.skins.StyleNameFunctionStyleProvider;
   import feathers.skins.StyleProviderRegistry;
   import starling.core.Starling;
   import starling.events.EventDispatcher;
   
   public class StyleNameFunctionTheme extends EventDispatcher
   {
      
      protected static const GLOBAL_STYLE_PROVIDER_PROPERTY_NAME:String = "globalStyleProvider";
      
      protected var starling:Starling;
      
      protected var _registry:StyleProviderRegistry;
      
      protected var _conditionalRegistry:StyleProviderRegistry;
      
      public function StyleNameFunctionTheme()
      {
         super();
         if(this.starling === null)
         {
            this.starling = Starling.current;
         }
         this.createRegistry();
         this._conditionalRegistry = new StyleProviderRegistry(true,createConditionalStyleProvider);
      }
      
      public function dispose() : void
      {
         if(this._registry !== null)
         {
            this._registry.dispose();
            this._registry = null;
         }
         if(this._conditionalRegistry !== null)
         {
            this.disposeConditionalRegistry();
         }
      }
      
      public function getStyleProviderForClass(param1:Class) : StyleNameFunctionStyleProvider
      {
         var _loc4_:StyleNameFunctionStyleProvider = null;
         var _loc3_:IStyleProvider = IStyleProvider(param1["globalStyleProvider"]);
         var _loc2_:ConditionalStyleProvider = ConditionalStyleProvider(this._conditionalRegistry.getStyleProvider(param1));
         if(_loc2_.trueStyleProvider === null)
         {
            _loc4_ = StyleNameFunctionStyleProvider(this._registry.getStyleProvider(param1));
            _loc2_.trueStyleProvider = _loc4_;
            _loc2_.falseStyleProvider = _loc3_;
         }
         return StyleNameFunctionStyleProvider(_loc2_.trueStyleProvider);
      }
      
      protected function createRegistry() : void
      {
         this._registry = new StyleProviderRegistry(false);
      }
      
      protected function starlingConditional(param1:IFeathersControl) : Boolean
      {
         var _loc2_:Starling = param1.stage !== null ? param1.stage.starling : Starling.current;
         return _loc2_ === this.starling;
      }
      
      protected function createConditionalStyleProvider() : ConditionalStyleProvider
      {
         return new ConditionalStyleProvider(starlingConditional);
      }
      
      protected function disposeConditionalRegistry() : void
      {
         var _loc6_:int = 0;
         var _loc7_:Class = null;
         var _loc4_:IStyleProvider = null;
         var _loc5_:ConditionalStyleProvider = null;
         var _loc8_:ConditionalStyleProvider = null;
         var _loc9_:ConditionalStyleProvider = null;
         var _loc1_:IStyleProvider = null;
         var _loc3_:Vector.<Class> = this._conditionalRegistry.getRegisteredClasses();
         var _loc2_:int = int(_loc3_.length);
         _loc6_ = 0;
         while(_loc6_ < _loc2_)
         {
            _loc7_ = _loc3_[_loc6_];
            _loc4_ = IStyleProvider(_loc7_["globalStyleProvider"]);
            _loc5_ = ConditionalStyleProvider(this._conditionalRegistry.clearStyleProvider(_loc7_));
            _loc8_ = _loc4_ as ConditionalStyleProvider;
            _loc9_ = null;
            while(true)
            {
               if(_loc8_ === null)
               {
                  _loc5_.conditionalFunction = null;
                  _loc5_.trueStyleProvider = null;
                  break;
               }
               _loc1_ = _loc8_.falseStyleProvider;
               if(_loc8_ === _loc5_)
               {
                  if(_loc9_ !== null)
                  {
                     _loc9_.falseStyleProvider = _loc1_;
                     break;
                  }
                  _loc7_["globalStyleProvider"] = _loc1_;
                  break;
               }
               _loc9_ = _loc8_;
               _loc8_ = _loc1_ as ConditionalStyleProvider;
            }
            _loc6_++;
         }
         this._conditionalRegistry = null;
      }
   }
}

