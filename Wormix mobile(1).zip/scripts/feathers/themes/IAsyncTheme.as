package feathers.themes
{
   import feathers.core.IFeathersEventDispatcher;
   import starling.core.Starling;
   
   public interface IAsyncTheme extends IFeathersEventDispatcher
   {
      
      function isCompleteForStarling(param1:Starling) : Boolean;
   }
}

