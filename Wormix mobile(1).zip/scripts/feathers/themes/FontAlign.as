package feathers.themes
{
   public class FontAlign
   {
      
      public function FontAlign()
      {
         super();
      }
      
      public static function getAlignByStyleName(param1:String) : String
      {
         if(param1.indexOf("center") != -1)
         {
            return "center";
         }
         if(param1.indexOf("left") != -1)
         {
            return "left";
         }
         if(param1.indexOf("right") != -1)
         {
            return "right";
         }
         return "center";
      }
   }
}

