package feathers.themes
{
   public class FontName
   {
      
      public static const WORMIX_NORMAL:String = "WORMIX_NORMAL";
      
      public static const GROBOLD:String = "GROBOLD_NORMAL";
      
      public function FontName()
      {
         super();
      }
   }
}

