package feathers.themes
{
   import starling.core.Starling;
   import starling.utils.AssetManager;
   
   public class WormixMobileThemeWithAssetManager extends BaseWormixMobileTheme implements IAsyncTheme
   {
      
      private var _assetManager:AssetManager;
      
      private var _atlasName:String;
      
      public function WormixMobileThemeWithAssetManager(param1:AssetManager, param2:String)
      {
         _assetManager = param1;
         _atlasName = param2;
         super();
      }
      
      override protected function initialize() : void
      {
         atlas = _assetManager.getTextureAtlas(_atlasName);
         super.initialize();
      }
      
      public function isCompleteForStarling(param1:Starling) : Boolean
      {
         return atlas != null;
      }
   }
}

