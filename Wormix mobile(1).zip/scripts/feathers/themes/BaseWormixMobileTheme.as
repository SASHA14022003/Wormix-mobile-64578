package feathers.themes
{
   import feathers.controls.Button;
   import feathers.controls.Label;
   import feathers.controls.List;
   import feathers.controls.NumericStepper;
   import feathers.controls.Panel;
   import feathers.controls.ScrollBar;
   import feathers.controls.SimpleScrollBar;
   import feathers.controls.Slider;
   import feathers.controls.TabBar;
   import feathers.controls.TextInput;
   import feathers.controls.ToggleButton;
   import feathers.controls.text.TextFormatUtils;
   import feathers.controls.text.TextInstanceCreator;
   import feathers.core.ITextEditor;
   import feathers.core.ITextRenderer;
   import feathers.themes.creators.ButtonStylesCreator;
   import feathers.themes.creators.IStyleCreator;
   import feathers.themes.creators.ListStylesCreator;
   import feathers.themes.creators.PanelStylesCreator;
   import feathers.themes.creators.ScrollBarStylesCreator;
   import feathers.themes.creators.SliderStylesCreator;
   import feathers.themes.creators.TabBarStylesCreator;
   import feathers.themes.creators.TextInputStylesCreator;
   import flash.geom.Rectangle;
   import flash.text.Font;
   import flash.utils.Dictionary;
   import starling.display.Image;
   import starling.display.Quad;
   import starling.display.Sprite;
   import starling.textures.Texture;
   import starling.textures.TextureAtlas;
   
   public class BaseWormixMobileTheme extends StyleNameFunctionTheme
   {
      
      [Embed(source="../../../assets/fonts/SANSUS-WEBISSIMO-REGULAR.ttf",fontFamily="WORMIX_NORMAL",fontWeight="normal",fontStyle="normal",mimeType="application/x-font",embedAsCFF="false")]
      protected static const WORMIX_NORMAL_FONT:Class = §SANSUS-WEBISSIMO-REGULAR_ttf$07924987ec05298a965af8eff5719f311144879677§;
      
      private static var links:Array = [BackgroundColor];
      
      protected var atlas:TextureAtlas;
      
      protected var toolTipPanelTexture:Texture;
      
      protected var styleCreators:Dictionary;
      
      public function BaseWormixMobileTheme()
      {
         super();
         this.initialize();
      }
      
      public static function createTextRendererForStyle(param1:String) : ITextRenderer
      {
         var _loc2_:uint = FontSize.getSizeByStyleName(param1);
         var _loc3_:uint = FontColor.getColorCodeByStyleName(param1);
         var _loc4_:String = FontAlign.getAlignByStyleName(param1);
         if(param1.indexOf("bitmap") == -1)
         {
            return TextInstanceCreator.createTextRenderer(_loc2_,_loc3_,_loc4_);
         }
         return TextInstanceCreator.createBitmapFontTextRenderer(_loc2_,_loc3_,_loc4_);
      }
      
      override public function dispose() : void
      {
         super.dispose();
      }
      
      protected function initialize() : void
      {
         styleCreators = new Dictionary();
         styleCreators[TextInput] = new TextInputStylesCreator(atlas);
         styleCreators[Button] = new ButtonStylesCreator(atlas);
         styleCreators[Slider] = new SliderStylesCreator(atlas);
         styleCreators[Panel] = new PanelStylesCreator(atlas);
         styleCreators[TabBar] = new TabBarStylesCreator(atlas);
         styleCreators[List] = new ListStylesCreator(atlas);
         styleCreators[ScrollBar] = new ScrollBarStylesCreator(atlas);
         this.initializeTextures();
         this.initializeFonts();
         this.initializeStyleProviders();
      }
      
      protected function initializeTextures() : void
      {
         for each(var _loc1_ in styleCreators)
         {
            _loc1_.initializeTextures();
         }
         toolTipPanelTexture = this.atlas.getTexture("WeaponHint_panel");
      }
      
      protected function initializeFonts() : void
      {
         Font.registerFont(WORMIX_NORMAL_FONT);
      }
      
      protected function initializeStyleProviders() : void
      {
         initLabelsStyles();
         initInputFields();
         initButtons();
         initNumericSteppers();
         initSliders();
         initPanels();
         initTabBars();
         initList();
         initScrollBar();
      }
      
      private function initLabelsStyles() : void
      {
         this.getStyleProviderForClass(Label).setFunctionForStyleName("NormalLightText",this.setNormalLightTextLabelStyles);
         this.getStyleProviderForClass(Label).setFunctionForStyleName("HintTitle",this.setHintTitleStyles);
         initLabelAutoStylingTypes(["darkgray_small_right","lightgray_small_left","lightgray_bigger_right","lightbrown_small_left","lightbrown_normal_left","lightbrown_normal_center","lightbrown_bigger_left","lightbrown_bigger_center","lightbrown_big_center","darkbrown_normal_left","darkbrown_bigger_left","darkbrown_micro_left","coldlight_big_left","coldlight_tiny_left","coldlight_small_left","darkgreen_small_left","red_normal_left","blue_normal_left","brightgreen_small_left","white_normal_center","white_giant_center","bitmap_darkbrown_giant_left","new_dark_big_center","new_dark_big_left","new_dark_big_right","new_bright_big_center","new_bright_big_left","new_bright_big_right","new_white_big_center","new_white_big_left","new_white_big_right","new_dark_normal_center","new_dark_normal_left","new_dark_normal_right","new_bright_normal_center","new_bright_normal_left","new_bright_normal_right","new_white_normal_center","new_white_normal_left","new_white_normal_right","new_dark_small_center","new_dark_small_left"
         ,"new_dark_small_right","new_bright_small_center","new_bright_small_left","new_bright_small_right","new_white_small_center","new_white_small_left","new_white_small_right"]);
         this.getStyleProviderForClass(Label).setFunctionForStyleName("ButtonLabelLarge",this.setButtonLabelLargeStyles);
         this.getStyleProviderForClass(Label).setFunctionForStyleName("ButtonLabelBigger",this.setButtonBigLargeStyles);
         this.getStyleProviderForClass(Label).setFunctionForStyleName("FightButtonLabel",this.setFightButtonLabelStyles);
         this.getStyleProviderForClass(Label).setFunctionForStyleName("ItemNameNormal",this.setNormalItemNameStyles);
         this.getStyleProviderForClass(Label).setFunctionForStyleName("ItemNameSuperior",this.setSuperiorItemNameStyles);
         this.getStyleProviderForClass(Label).setFunctionForStyleName("ItemNameAggressive",this.setAggressiveItemNameStyles);
         this.getStyleProviderForClass(Label).setFunctionForStyleName("ItemNameDefensive",this.setDefenciveItemNameStyles);
         this.getStyleProviderForClass(Label).setFunctionForStyleName("ItemNameViolent",this.setViolentItemNameStyles);
         this.getStyleProviderForClass(Label).setFunctionForStyleName("ItemNameEpic",this.setEpicItemNameStyles);
         this.getStyleProviderForClass(Label).setFunctionForStyleName("ItemNameLegendary",this.setLegendaryItemNameStyles);
         this.getStyleProviderForClass(Label).setFunctionForStyleName("feathers-tool-tip",this.setToolTipLabelStyles);
      }
      
      private function initLabelAutoStylingTypes(param1:Array) : void
      {
         for each(var _loc2_ in param1)
         {
            this.getStyleProviderForClass(Label).setFunctionForStyleName(_loc2_,this.setStylesByStyleName);
         }
      }
      
      private function initInputFields() : void
      {
         var _loc1_:TextInputStylesCreator = styleCreators[TextInput] as TextInputStylesCreator;
         this.getStyleProviderForClass(TextInput).defaultStyleFunction = setInputStyles;
         this.getStyleProviderForClass(TextInput).setFunctionForStyleName("input_lightbrown_big_center",this.setInputStyleByStyleName);
         this.getStyleProviderForClass(TextInput).setFunctionForStyleName("numeric_stepper_big_input",this.setBigStepperInputStyles);
         this.getStyleProviderForClass(TextInput).setFunctionForStyleName("numeric_stepper_normal_input",this.setNormalStepperInputStyles);
         this.getStyleProviderForClass(TextInput).setFunctionForStyleName("text_input_common",_loc1_.setCommonInputStyles);
         this.getStyleProviderForClass(TextInput).setFunctionForStyleName("text_input_common_multiline",_loc1_.setCommonMultilineTextInputStyles);
         this.getStyleProviderForClass(TextInput).setFunctionForStyleName("text_input_single_line_new",_loc1_.setNewSingleLineInputStyles);
         this.getStyleProviderForClass(TextInput).setFunctionForStyleName("text_input_multi_line_new",_loc1_.setNewMultiLineTextInputStyles);
         this.getStyleProviderForClass(TextInput).setFunctionForStyleName("text_input_chat",_loc1_.setChatInputStyles);
      }
      
      private function initButtons() : void
      {
         var _loc1_:ButtonStylesCreator = styleCreators[Button] as ButtonStylesCreator;
         this.getStyleProviderForClass(Button).defaultStyleFunction = _loc1_.setBaseButtonStyles;
         this.getStyleProviderForClass(ToggleButton).setFunctionForStyleName("ChatSocialToggle",this.setChatSocialToggleButtonStyles);
         this.getStyleProviderForClass(Button).setFunctionForStyleName("HintActionLabel",this.setHintActionButtonStyles);
         this.getStyleProviderForClass(Button).setFunctionForStyleName("VipHintActionLabel",this.setVipHintActionButtonStyles);
         this.getStyleProviderForClass(Button).setFunctionForStyleName("button_green",_loc1_.setGreenButtonStyles);
         this.getStyleProviderForClass(Button).setFunctionForStyleName("button_blue",_loc1_.setBlueButtonStyles);
         this.getStyleProviderForClass(Button).setFunctionForStyleName("button_red",_loc1_.setRedButtonStyles);
         this.getStyleProviderForClass(Button).setFunctionForStyleName("button_orange",_loc1_.setOrangeButtonStyles);
         this.getStyleProviderForClass(Button).setFunctionForStyleName("button_purple",_loc1_.setPurpleButtonStyles);
         this.getStyleProviderForClass(Button).setFunctionForStyleName("button_close",_loc1_.setCloseButtonStyles);
         this.getStyleProviderForClass(Button).setFunctionForStyleName("button_new_green",_loc1_.setNewGreenButtonStyles);
         this.getStyleProviderForClass(Button).setFunctionForStyleName("button_new_blue",_loc1_.setNewBlueButtonStyles);
         this.getStyleProviderForClass(Button).setFunctionForStyleName("button_new_red",_loc1_.setNewRedButtonStyles);
         this.getStyleProviderForClass(Button).setFunctionForStyleName("button_quad_close",_loc1_.setCloseQuadButtonStyles);
         this.getStyleProviderForClass(Button).setFunctionForStyleName("button_quad_grey",_loc1_.setGreyQuadButtonStyles);
         this.getStyleProviderForClass(Button).setFunctionForStyleName("button_round_green",_loc1_.setGreenRoundButtonStyles);
         this.getStyleProviderForClass(Button).setFunctionForStyleName("button_round_yellow",_loc1_.setYellowRoundButtonStyles);
         this.getStyleProviderForClass(Button).setFunctionForStyleName("button_round_yellow_arrow_left",_loc1_.setYellowRoundArrowLeftButtonStyles);
         this.getStyleProviderForClass(Button).setFunctionForStyleName("button_round_yellow_arrow_right",_loc1_.setYellowRoundArrowRightButtonStyles);
         this.getStyleProviderForClass(Button).setFunctionForStyleName("button_buy_fuzy",_loc1_.setBuyFuzyButtonStyles);
         this.getStyleProviderForClass(Button).setFunctionForStyleName("button_buy_ruby",_loc1_.setBuyRubyButtonStyles);
         this.getStyleProviderForClass(Button).setFunctionForStyleName("button_buy_vip",_loc1_.setBuyVipButtonStyles);
         this.getStyleProviderForClass(Button).setFunctionForStyleName("button_buy_no_ads",_loc1_.setBuyNoAdsButtonStyles);
         this.getStyleProviderForClass(Button).setFunctionForStyleName("button_show_ads",_loc1_.setShowAdsButtonStyles);
      }
      
      private function initNumericSteppers() : void
      {
         this.getStyleProviderForClass(NumericStepper).defaultStyleFunction = setNormalNumericStepperStyle;
         this.getStyleProviderForClass(NumericStepper).setFunctionForStyleName("numeric_stepper_normal",this.setNormalNumericStepperStyle);
         this.getStyleProviderForClass(NumericStepper).setFunctionForStyleName("numeric_stepper_big",this.setBigNumericStepperStyle);
      }
      
      private function initSliders() : void
      {
         var _loc1_:SliderStylesCreator = styleCreators[Slider] as SliderStylesCreator;
         this.getStyleProviderForClass(Slider).setFunctionForStyleName("slider_normal",_loc1_.setNormalSliderStyles);
      }
      
      private function initPanels() : void
      {
         var _loc1_:PanelStylesCreator = styleCreators[Panel] as PanelStylesCreator;
         this.getStyleProviderForClass(Panel).setFunctionForStyleName("normal",_loc1_.setNormalPanelStyles);
         this.getStyleProviderForClass(Panel).setFunctionForStyleName("normal_with_title",_loc1_.setNormalPanelWithTitleStyles);
         this.getStyleProviderForClass(Panel).setFunctionForStyleName("new_panel_normal",_loc1_.setNewNormalPanelStyles);
         this.getStyleProviderForClass(Panel).setFunctionForStyleName("new_panel_normal_title",_loc1_.setNewNormalPanel_Title_Styles);
         this.getStyleProviderForClass(Panel).setFunctionForStyleName("new_panel_normal_title_close",_loc1_.setNewNormalPanel_Title_Close_Styles);
         this.getStyleProviderForClass(Panel).setFunctionForStyleName("new_panel_empty",_loc1_.setNewEmptyPanelStyles);
         this.getStyleProviderForClass(Panel).setFunctionForStyleName("new_panel_sub_tab_bar",_loc1_.setNewPanelSubTabBarStyles);
         this.getStyleProviderForClass(Panel).setFunctionForStyleName("new_sub_panel_dark",_loc1_.setNewSubPanelDarkStyles);
         this.getStyleProviderForClass(Panel).setFunctionForStyleName("new_sub_panel_light",_loc1_.setNewSubPanelDarklessStyles);
      }
      
      private function initTabBars() : void
      {
         var _loc1_:TabBarStylesCreator = styleCreators[TabBar] as TabBarStylesCreator;
         this.getStyleProviderForClass(TabBar).setFunctionForStyleName("tab_bar_normal",_loc1_.setNormalTabBar);
         this.getStyleProviderForClass(TabBar).setFunctionForStyleName("tab_bar_normal_new",_loc1_.setNormalNewTabBar);
         this.getStyleProviderForClass(TabBar).setFunctionForStyleName("tab_bar_sub_new",_loc1_.setNewSubTabBar);
      }
      
      private function initList() : void
      {
         var _loc1_:ListStylesCreator = styleCreators[List] as ListStylesCreator;
         this.getStyleProviderForClass(List).defaultStyleFunction = _loc1_.setDefaultListStyles;
      }
      
      private function initScrollBar() : void
      {
         var _loc1_:ScrollBarStylesCreator = styleCreators[ScrollBar] as ScrollBarStylesCreator;
         this.getStyleProviderForClass(SimpleScrollBar).setFunctionForStyleName("simple-normal",_loc1_.setSimpleNormalScrollBar);
      }
      
      protected function setNormalLightTextLabelStyles(param1:Label) : void
      {
         var label:Label = param1;
         label.textRendererFactory = function():ITextRenderer
         {
            return TextInstanceCreator.createTextRenderer(18,16771235,"left");
         };
      }
      
      protected function setHintTitleStyles(param1:Label) : void
      {
         var label:Label = param1;
         label.textRendererFactory = function():ITextRenderer
         {
            return TextInstanceCreator.createTextRenderer(16,5391158,"center");
         };
      }
      
      protected function setToolTipLabelStyles(param1:Label) : void
      {
         var backgroundSkin:Image;
         var label:Label = param1;
         label.textRendererFactory = function():ITextRenderer
         {
            return TextInstanceCreator.createTextRenderer(16,9072988,"center");
         };
         backgroundSkin = new Image(toolTipPanelTexture);
         backgroundSkin.scale9Grid = new Rectangle(5,5,1,1);
         label.backgroundSkin = backgroundSkin;
         label.padding = 10;
      }
      
      protected function setNormalItemNameStyles(param1:Label) : void
      {
         var label:Label = param1;
         label.textRendererFactory = function():ITextRenderer
         {
            return TextInstanceCreator.createTextRenderer(18,8421504,"center");
         };
      }
      
      protected function setSuperiorItemNameStyles(param1:Label) : void
      {
         var label:Label = param1;
         label.textRendererFactory = function():ITextRenderer
         {
            return TextInstanceCreator.createTextRenderer(18,4827648,"center");
         };
      }
      
      protected function setAggressiveItemNameStyles(param1:Label) : void
      {
         var label:Label = param1;
         label.textRendererFactory = function():ITextRenderer
         {
            return TextInstanceCreator.createTextRenderer(18,690921,"center");
         };
      }
      
      protected function setDefenciveItemNameStyles(param1:Label) : void
      {
         var label:Label = param1;
         label.textRendererFactory = function():ITextRenderer
         {
            return TextInstanceCreator.createTextRenderer(18,7289838,"center");
         };
      }
      
      protected function setViolentItemNameStyles(param1:Label) : void
      {
         var label:Label = param1;
         label.textRendererFactory = function():ITextRenderer
         {
            return TextInstanceCreator.createTextRenderer(18,16751104,"center");
         };
      }
      
      protected function setEpicItemNameStyles(param1:Label) : void
      {
         var label:Label = param1;
         label.textRendererFactory = function():ITextRenderer
         {
            return TextInstanceCreator.createTextRenderer(18,16729600,"center");
         };
      }
      
      protected function setLegendaryItemNameStyles(param1:Label) : void
      {
         var label:Label = param1;
         label.textRendererFactory = function():ITextRenderer
         {
            return TextInstanceCreator.createTextRenderer(18,13172736,"center");
         };
      }
      
      protected function setButtonLabelLargeStyles(param1:Label) : void
      {
         var label:Label = param1;
         label.textRendererFactory = function():ITextRenderer
         {
            return TextInstanceCreator.createTextRenderer(28,16777215,"center");
         };
      }
      
      protected function setButtonBigLargeStyles(param1:Label) : void
      {
         var label:Label = param1;
         label.textRendererFactory = function():ITextRenderer
         {
            return TextInstanceCreator.createTextRenderer(22,16777215,"center");
         };
      }
      
      protected function setFightButtonLabelStyles(param1:Label) : void
      {
         var label:Label = param1;
         label.textRendererFactory = function():ITextRenderer
         {
            return TextInstanceCreator.createTextRenderer(44,16777215,"center");
         };
      }
      
      protected function setStylesByStyleName(param1:Label) : void
      {
         var label:Label = param1;
         label.textRendererFactory = function():ITextRenderer
         {
            return createTextRendererForStyle(label.styleName);
         };
      }
      
      protected function setInputStyles(param1:TextInput) : void
      {
         var input:TextInput = param1;
         setDefaultInputStyles(input);
         input.textEditorFactory = function():ITextEditor
         {
            return TextInstanceCreator.createTextFieldTextEditor(24,5391158,"left");
         };
      }
      
      protected function setBigStepperInputStyles(param1:TextInput) : void
      {
         var input:TextInput = param1;
         input.isEditable = true;
         input.textEditorFactory = function():ITextEditor
         {
            return TextInstanceCreator.createTextFieldTextEditor(24,8089696,"center");
         };
         input.promptFactory = function():ITextRenderer
         {
            return TextInstanceCreator.createTextRenderer(24,8089696,"center");
         };
         input.maxChars = 2;
         input.restrict = "0-9";
      }
      
      protected function setNormalStepperInputStyles(param1:TextInput) : void
      {
         var input:TextInput = param1;
         input.isEditable = true;
         input.textEditorFactory = function():ITextEditor
         {
            return TextInstanceCreator.createTextFieldTextEditor(24,8089696,"center");
         };
         input.promptFactory = function():ITextRenderer
         {
            return TextInstanceCreator.createTextRenderer(22,8089696,"center");
         };
         input.maxChars = 2;
         input.restrict = "0-9";
      }
      
      protected function setInputStyleByStyleName(param1:TextInput) : void
      {
         var input:TextInput = param1;
         input.isEditable = true;
         input.promptFactory = function():ITextRenderer
         {
            return TextInstanceCreator.createTextRenderer(FontSize.getSizeByStyleName(input.styleName) / 2,FontColor.getColorCodeByStyleName(input.styleName),FontAlign.getAlignByStyleName(input.styleName));
         };
         input.textEditorFactory = function():ITextEditor
         {
            return TextInstanceCreator.createTextFieldTextEditor(FontSize.getSizeByStyleName(input.styleName),FontColor.getColorCodeByStyleName(input.styleName),FontAlign.getAlignByStyleName(input.styleName));
         };
      }
      
      protected function setDefaultInputStyles(param1:TextInput) : void
      {
         var input:TextInput = param1;
         input.isEditable = true;
         input.promptFactory = function():ITextRenderer
         {
            var _loc1_:ITextRenderer = TextInstanceCreator.createTextRenderer(18,5391158,"left");
            _loc1_.height = 56;
            return _loc1_;
         };
      }
      
      protected function setChatSocialToggleButtonStyles(param1:ToggleButton) : void
      {
         var toggleBtn:ToggleButton = param1;
         toggleBtn.labelFactory = function():ITextRenderer
         {
            return TextInstanceCreator.createTextRenderer(20,8743764,"center");
         };
         toggleBtn.disabledFontStyles = TextFormatUtils.createStarlingTextFormat("WORMIX_NORMAL",20,16711680,"center");
         toggleBtn.padding = 10;
      }
      
      protected function setHintActionButtonStyles(param1:Button) : void
      {
         var button:Button = param1;
         setAbstractHintActionButtonStyles(button);
         button.labelFactory = function():ITextRenderer
         {
            return TextInstanceCreator.createTextRenderer(18,5935565,"left");
         };
      }
      
      protected function setVipHintActionButtonStyles(param1:Button) : void
      {
         var button:Button = param1;
         setAbstractHintActionButtonStyles(button);
         button.labelFactory = function():ITextRenderer
         {
            return TextInstanceCreator.createTextRenderer(18,10573104,"left");
         };
      }
      
      protected function setAbstractHintActionButtonStyles(param1:Button) : void
      {
         param1.iconPosition = "left";
         param1.horizontalAlign = "left";
         param1.gap = 5;
         param1.paddingLeft = 5;
         param1.scaleWhenDown = 0.9;
      }
      
      public function setNormalNumericStepperStyle(param1:NumericStepper) : void
      {
         setDefaultNumericStepperStyle(param1);
         setIconFactories(param1,10);
         param1.customTextInputStyleName = "numeric_stepper_normal_input";
      }
      
      public function setBigNumericStepperStyle(param1:NumericStepper) : void
      {
         setDefaultNumericStepperStyle(param1);
         setIconFactories(param1,16);
         param1.customTextInputStyleName = "numeric_stepper_big_input";
      }
      
      private function setDefaultNumericStepperStyle(param1:NumericStepper) : void
      {
         param1.minimum = 1;
         param1.maximum = 99;
         param1.value = 1;
         param1.step = 1;
      }
      
      private function setIconFactories(param1:NumericStepper, param2:Number) : void
      {
         var stepper:NumericStepper = param1;
         var size:Number = param2;
         stepper.incrementButtonFactory = (function():*
         {
            var createPlusButton:Function;
            return createPlusButton = function():Button
            {
               var _loc1_:Button = new Button();
               _loc1_.styleName = "button_green";
               _loc1_.defaultIcon = makePlusIcon(size);
               return _loc1_;
            };
         })();
         stepper.decrementButtonFactory = (function():*
         {
            var createMinusButton:Function;
            return createMinusButton = function():Button
            {
               var _loc1_:Button = new Button();
               _loc1_.styleName = "button_green";
               _loc1_.defaultIcon = makeMinusIcon(size);
               return _loc1_;
            };
         })();
      }
      
      private function makeMinusIcon(param1:Number) : Sprite
      {
         var _loc3_:Sprite = new Sprite();
         _loc3_.addChild(new Image(Texture.empty(param1 * 4,param1 * 4)));
         var _loc2_:Quad = new Quad(param1,param1 / 3,16777215);
         _loc2_.x = (_loc3_.width - _loc2_.width) * 0.5;
         _loc2_.y = (_loc3_.height - _loc2_.height) * 0.5;
         _loc3_.addChild(_loc2_);
         return _loc3_;
      }
      
      private function makePlusIcon(param1:Number) : Sprite
      {
         var _loc3_:Sprite = makeMinusIcon(param1);
         var _loc2_:Quad = new Quad(param1 / 3,param1,16777215);
         _loc2_.x = (_loc3_.width - _loc2_.width) * 0.5;
         _loc2_.y = (_loc3_.height - _loc2_.height) * 0.5;
         _loc3_.addChild(_loc2_);
         return _loc3_;
      }
   }
}

