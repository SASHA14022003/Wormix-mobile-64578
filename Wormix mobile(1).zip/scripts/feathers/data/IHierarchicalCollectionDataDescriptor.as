package feathers.data
{
   public interface IHierarchicalCollectionDataDescriptor
   {
      
      function isBranch(param1:Object) : Boolean;
      
      function getLength(param1:Object, ... rest) : int;
      
      function getLengthAtLocation(param1:Object, param2:Vector.<int> = null) : int;
      
      function getItemAt(param1:Object, param2:int, ... rest) : Object;
      
      function getItemAtLocation(param1:Object, param2:Vector.<int>) : Object;
      
      function setItemAt(param1:Object, param2:Object, param3:int, ... rest) : void;
      
      function setItemAtLocation(param1:Object, param2:Object, param3:Vector.<int>) : void;
      
      function addItemAt(param1:Object, param2:Object, param3:int, ... rest) : void;
      
      function addItemAtLocation(param1:Object, param2:Object, param3:Vector.<int>) : void;
      
      function removeItemAt(param1:Object, param2:int, ... rest) : Object;
      
      function removeItemAtLocation(param1:Object, param2:Vector.<int>) : Object;
      
      function removeAll(param1:Object) : void;
      
      function getItemLocation(param1:Object, param2:Object, param3:Vector.<int> = null, ... rest) : Vector.<int>;
   }
}

