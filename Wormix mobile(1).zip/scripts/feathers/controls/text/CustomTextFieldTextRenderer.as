package feathers.controls.text
{
   import starling.core.Starling;
   import starling.events.Event;
   
   public class CustomTextFieldTextRenderer extends TextFieldTextRenderer
   {
      
      private static const removeHTMLRegExp:RegExp = /<[^>]*>/gi;
      
      private static const removeEmbedFontRegExp:RegExp = /([ a-zA-Z0-9а-яА-ЯёЁ .,'"\/#!?$%\^&\*;:{}=+\-_`~()\[\]<>\n\t])/g;
      
      public function CustomTextFieldTextRenderer()
      {
         super();
         _updateSnapshotOnScaleChange = true;
      }
      
      override public function set text(param1:String) : void
      {
         var _loc3_:String = null;
         var _loc2_:Boolean = false;
         if(param1)
         {
            _loc3_ = param1;
            _loc3_ = _loc3_.replace(removeHTMLRegExp,"");
            _loc3_ = _loc3_.replace(removeEmbedFontRegExp,"");
            _loc2_ = _loc3_.length == 0;
            embedFonts = _loc2_;
            if(_textFormat)
            {
               _textFormat.bold = !_loc2_;
            }
         }
         super.text = param1;
      }
      
      override protected function calculateSnapshotDimensions() : void
      {
         var _loc1_:Starling = this.stage !== null ? this.stage.starling : Starling.current;
         var _loc2_:Number = _loc1_.contentScaleFactor;
         this.textField.scaleX = _loc2_;
         this.textField.scaleY = _loc2_;
         super.calculateSnapshotDimensions();
      }
      
      override protected function feathersControl_addedToStageHandler(param1:Event) : void
      {
         if(this.stage)
         {
            super.feathersControl_addedToStageHandler(param1);
         }
      }
   }
}

