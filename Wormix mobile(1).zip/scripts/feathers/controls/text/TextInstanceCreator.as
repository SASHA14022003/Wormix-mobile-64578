package feathers.controls.text
{
   import feathers.core.ITextRenderer;
   import feathers.themes.FontAlign;
   import feathers.themes.FontColor;
   import feathers.themes.FontSize;
   
   public class TextInstanceCreator
   {
      
      public function TextInstanceCreator()
      {
         super();
      }
      
      public static function createTextRenderer(param1:uint, param2:uint, param3:String) : TextFieldTextRenderer
      {
         var _loc4_:TextFieldTextRenderer = new CustomTextFieldTextRenderer();
         _loc4_.textFormat = TextFormatUtils.createFlashTextFormat("WORMIX_NORMAL",param1,param2,param3);
         return _loc4_;
      }
      
      public static function createBitmapFontTextRenderer(param1:uint, param2:uint, param3:String) : BitmapFontTextRenderer
      {
         var _loc4_:BitmapFontTextRenderer = new BitmapFontTextRenderer();
         _loc4_.textFormat = TextFormatUtils.createBitmapFontTextFormat(param1,param2,param3);
         return _loc4_;
      }
      
      public static function createTextFieldTextEditor(param1:uint, param2:uint, param3:String) : TextFieldTextEditor
      {
         var _loc4_:TextFieldTextEditor = new CustomTextFieldTextEditor();
         _loc4_.textFormat = TextFormatUtils.createFlashTextFormat("WORMIX_NORMAL",param1,param2,param3);
         _loc4_.useGutter = true;
         return _loc4_;
      }
      
      public static function createStageTextTextEditor(param1:uint, param2:uint, param3:String, param4:Boolean) : StageTextTextEditor
      {
         var _loc5_:StageTextTextEditor = new StageTextTextEditor();
         _loc5_.fontFamily = "WORMIX_NORMAL";
         _loc5_.fontSize = param1;
         _loc5_.color = param2;
         _loc5_.textAlign = param3;
         _loc5_.multiline = param4;
         return _loc5_;
      }
      
      public static function createFromStyleName(param1:String) : ITextRenderer
      {
         var _loc2_:uint = FontSize.getSizeByStyleName(param1);
         var _loc3_:uint = FontColor.getColorCodeByStyleName(param1);
         var _loc4_:String = FontAlign.getAlignByStyleName(param1);
         var _loc5_:Boolean = param1.indexOf("bitmap") != -1;
         if(_loc5_)
         {
            return createBitmapFontTextRenderer(_loc2_,_loc3_,_loc4_);
         }
         return createTextRenderer(_loc2_,_loc3_,_loc4_);
      }
   }
}

