package feathers.controls.text
{
   import feathers.text.BitmapFontTextFormat;
   import flash.text.TextFormat;
   import starling.text.TextFormat;
   
   public class TextFormatUtils
   {
      
      public function TextFormatUtils()
      {
         super();
      }
      
      public static function createFlashTextFormat(param1:String, param2:uint, param3:uint, param4:String) : flash.text.TextFormat
      {
         var _loc5_:flash.text.TextFormat = new flash.text.TextFormat(param1,param2,param3);
         _loc5_.align = param4;
         return _loc5_;
      }
      
      public static function createStarlingTextFormat(param1:String, param2:uint, param3:uint, param4:String) : starling.text.TextFormat
      {
         return new starling.text.TextFormat(param1,param2,param3,param4,"center");
      }
      
      public static function createBitmapFontTextFormat(param1:uint, param2:uint, param3:String) : BitmapFontTextFormat
      {
         return new BitmapFontTextFormat("GROBOLD_NORMAL",param1,param2,param3);
      }
   }
}

