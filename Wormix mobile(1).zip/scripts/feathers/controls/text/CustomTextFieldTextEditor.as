package feathers.controls.text
{
   public class CustomTextFieldTextEditor extends TextFieldTextEditor
   {
      
      public function CustomTextFieldTextEditor()
      {
         super();
      }
      
      override protected function draw() : void
      {
         var _loc1_:RegExp = null;
         if(isInvalid("data"))
         {
            _loc1_ = /^[a-zA-Z0-9а-яА-Я.,\/#!$%\^&\*;:{}=+\-_`~()\n\\p\\b]/;
            embedFonts = _loc1_.test(text);
            _textFormat.bold = !_embedFonts;
         }
         super.draw();
      }
   }
}

