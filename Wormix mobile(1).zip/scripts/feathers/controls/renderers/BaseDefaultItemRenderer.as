package feathers.controls.renderers
{
   import feathers.controls.ImageLoader;
   import feathers.controls.Scroller;
   import feathers.controls.ToggleButton;
   import feathers.core.FeathersControl;
   import feathers.core.IFeathersControl;
   import feathers.core.IFocusContainer;
   import feathers.core.IMeasureDisplayObject;
   import feathers.core.IStateObserver;
   import feathers.core.ITextRenderer;
   import feathers.core.IValidating;
   import feathers.core.PropertyProxy;
   import feathers.text.FontStylesSet;
   import feathers.utils.skins.resetFluidChildDimensionsForMeasurement;
   import feathers.utils.touch.DelayedDownTouchToState;
   import flash.geom.Point;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   import starling.events.Touch;
   import starling.events.TouchEvent;
   import starling.text.TextFormat;
   
   public class BaseDefaultItemRenderer extends ToggleButton implements IFocusContainer
   {
      
      public static const ALTERNATE_STYLE_NAME_DRILL_DOWN:String = "feathers-drill-down-item-renderer";
      
      public static const ALTERNATE_STYLE_NAME_CHECK:String = "feathers-check-item-renderer";
      
      public static const DEFAULT_CHILD_STYLE_NAME_LABEL:String = "feathers-item-renderer-label";
      
      public static const DEFAULT_CHILD_STYLE_NAME_ICON_LABEL:String = "feathers-item-renderer-icon-label";
      
      public static const DEFAULT_CHILD_STYLE_NAME_ICON_LOADER:String = "feathers-item-renderer-icon-loader";
      
      public static const DEFAULT_CHILD_STYLE_NAME_ACCESSORY_LABEL:String = "feathers-item-renderer-accessory-label";
      
      public static const DEFAULT_CHILD_STYLE_NAME_ACCESSORY_LOADER:String = "feathers-item-renderer-accessory-loader";
      
      public static const STATE_UP:String = "up";
      
      public static const STATE_DOWN:String = "down";
      
      public static const STATE_HOVER:String = "hover";
      
      public static const STATE_DISABLED:String = "disabled";
      
      public static const STATE_UP_AND_SELECTED:String = "upAndSelected";
      
      public static const STATE_DOWN_AND_SELECTED:String = "downAndSelected";
      
      public static const STATE_HOVER_AND_SELECTED:String = "hoverAndSelected";
      
      public static const STATE_DISABLED_AND_SELECTED:String = "disabledAndSelected";
      
      public static const ICON_POSITION_TOP:String = "top";
      
      public static const ICON_POSITION_RIGHT:String = "right";
      
      public static const ICON_POSITION_BOTTOM:String = "bottom";
      
      public static const ICON_POSITION_LEFT:String = "left";
      
      public static const ICON_POSITION_MANUAL:String = "manual";
      
      public static const ICON_POSITION_LEFT_BASELINE:String = "leftBaseline";
      
      public static const ICON_POSITION_RIGHT_BASELINE:String = "rightBaseline";
      
      public static const HORIZONTAL_ALIGN_LEFT:String = "left";
      
      public static const HORIZONTAL_ALIGN_CENTER:String = "center";
      
      public static const HORIZONTAL_ALIGN_RIGHT:String = "right";
      
      public static const VERTICAL_ALIGN_TOP:String = "top";
      
      public static const VERTICAL_ALIGN_MIDDLE:String = "middle";
      
      public static const VERTICAL_ALIGN_BOTTOM:String = "bottom";
      
      public static const ACCESSORY_POSITION_TOP:String = "top";
      
      public static const ACCESSORY_POSITION_RIGHT:String = "right";
      
      public static const ACCESSORY_POSITION_BOTTOM:String = "bottom";
      
      public static const ACCESSORY_POSITION_LEFT:String = "left";
      
      public static const ACCESSORY_POSITION_MANUAL:String = "manual";
      
      public static const LAYOUT_ORDER_LABEL_ACCESSORY_ICON:String = "labelAccessoryIcon";
      
      public static const LAYOUT_ORDER_LABEL_ICON_ACCESSORY:String = "labelIconAccessory";
      
      private static const HELPER_POINT:Point = new Point();
      
      protected var iconLabelStyleName:String = "feathers-item-renderer-icon-label";
      
      protected var iconLoaderStyleName:String = "feathers-item-renderer-icon-loader";
      
      protected var accessoryLabelStyleName:String = "feathers-item-renderer-accessory-label";
      
      protected var accessoryLoaderStyleName:String = "feathers-item-renderer-accessory-loader";
      
      protected var _isChildFocusEnabled:Boolean = true;
      
      protected var skinLoader:ImageLoader;
      
      protected var iconLoader:ImageLoader;
      
      protected var iconLabel:ITextRenderer;
      
      protected var accessoryLoader:ImageLoader;
      
      protected var accessoryLabel:ITextRenderer;
      
      protected var currentAccessory:DisplayObject;
      
      protected var _skinIsFromItem:Boolean = false;
      
      protected var _iconIsFromItem:Boolean = false;
      
      protected var _accessoryIsFromItem:Boolean = false;
      
      protected var _data:Object;
      
      protected var _owner:Scroller;
      
      protected var _factoryID:String;
      
      protected var _useStateDelayTimer:Boolean = true;
      
      protected var isSelectableWithoutToggle:Boolean = true;
      
      protected var _itemHasLabel:Boolean = true;
      
      protected var _itemHasIcon:Boolean = true;
      
      protected var _itemHasAccessory:Boolean = true;
      
      protected var _itemHasSkin:Boolean = false;
      
      protected var _itemHasSelectable:Boolean = false;
      
      protected var _itemHasEnabled:Boolean = false;
      
      protected var _accessoryPosition:String = "right";
      
      protected var _layoutOrder:String = "labelIconAccessory";
      
      protected var _accessoryOffsetX:Number = 0;
      
      protected var _accessoryOffsetY:Number = 0;
      
      protected var _accessoryGap:Number = NaN;
      
      protected var _minAccessoryGap:Number = NaN;
      
      protected var _defaultAccessory:DisplayObject;
      
      protected var _stateToAccessory:Object = {};
      
      protected var _stateToAccessoryFunction:Function;
      
      protected var accessoryTouchPointID:int = -1;
      
      protected var _stopScrollingOnAccessoryTouch:Boolean = true;
      
      protected var _isSelectableOnAccessoryTouch:Boolean = false;
      
      protected var _delayTextureCreationOnScroll:Boolean = false;
      
      protected var _labelField:String = "label";
      
      protected var _labelFunction:Function;
      
      protected var _iconField:String = "icon";
      
      protected var _iconFunction:Function;
      
      protected var _iconSourceField:String = "iconSource";
      
      protected var _iconSourceFunction:Function;
      
      protected var _iconLabelField:String = "iconLabel";
      
      protected var _iconLabelFunction:Function;
      
      protected var _customIconLoaderStyleName:String;
      
      protected var _customIconLabelStyleName:String;
      
      protected var _accessoryField:String = "accessory";
      
      protected var _accessoryFunction:Function;
      
      protected var _accessorySourceField:String = "accessorySource";
      
      protected var _accessorySourceFunction:Function;
      
      protected var _accessoryLabelField:String = "accessoryLabel";
      
      protected var _accessoryLabelFunction:Function;
      
      protected var _customAccessoryLabelStyleName:String;
      
      protected var _customAccessoryLoaderStyleName:String;
      
      protected var _skinField:String = "skin";
      
      protected var _skinFunction:Function;
      
      protected var _skinSourceField:String = "skinSource";
      
      protected var _skinSourceFunction:Function;
      
      protected var _selectableField:String = "selectable";
      
      protected var _selectableFunction:Function;
      
      protected var _enabledField:String = "enabled";
      
      protected var _enabledFunction:Function;
      
      protected var _explicitIsToggle:Boolean = false;
      
      protected var _explicitIsEnabled:Boolean;
      
      protected var _iconLoaderFactory:Function = defaultLoaderFactory;
      
      protected var _iconLabelFontStylesSet:FontStylesSet;
      
      protected var _iconLabelFactory:Function;
      
      protected var _iconLabelProperties:PropertyProxy;
      
      protected var _accessoryLoaderFactory:Function = defaultLoaderFactory;
      
      protected var _accessoryLabelFontStylesSet:FontStylesSet;
      
      protected var _accessoryLabelFactory:Function;
      
      protected var _accessoryLabelProperties:PropertyProxy;
      
      protected var _skinLoaderFactory:Function = defaultLoaderFactory;
      
      protected var _ignoreAccessoryResizes:Boolean = false;
      
      protected var _topOffset:Number = 0;
      
      protected var _rightOffset:Number = 0;
      
      protected var _bottomOffset:Number = 0;
      
      protected var _leftOffset:Number = 0;
      
      public function BaseDefaultItemRenderer()
      {
         super();
         if(this._iconLabelFontStylesSet === null)
         {
            this._iconLabelFontStylesSet = new FontStylesSet();
            this._iconLabelFontStylesSet.addEventListener("change",fontStyles_changeHandler);
         }
         if(this._accessoryLabelFontStylesSet === null)
         {
            this._accessoryLabelFontStylesSet = new FontStylesSet();
            this._accessoryLabelFontStylesSet.addEventListener("change",fontStyles_changeHandler);
         }
         this._explicitIsEnabled = this._isEnabled;
         this.labelStyleName = "feathers-item-renderer-label";
         this.isFocusEnabled = false;
         this.isQuickHitAreaEnabled = false;
         this.addEventListener("removedFromStage",itemRenderer_removedFromStageHandler);
      }
      
      protected static function defaultLoaderFactory() : ImageLoader
      {
         return new ImageLoader();
      }
      
      public function get isChildFocusEnabled() : Boolean
      {
         return this._isEnabled && this._isChildFocusEnabled;
      }
      
      public function set isChildFocusEnabled(param1:Boolean) : void
      {
         this._isChildFocusEnabled = param1;
      }
      
      override public function set defaultIcon(param1:DisplayObject) : void
      {
         if(this.processStyleRestriction(arguments.callee))
         {
            if(param1 !== null)
            {
               param1.dispose();
            }
            return;
         }
         if(this._defaultIcon === param1)
         {
            return;
         }
         this.replaceIcon(null);
         this._iconIsFromItem = false;
         super.defaultIcon = param1;
      }
      
      override public function set defaultSkin(param1:DisplayObject) : void
      {
         if(this.processStyleRestriction(arguments.callee))
         {
            if(param1 !== null)
            {
               param1.dispose();
            }
            return;
         }
         if(this._defaultSkin === param1)
         {
            return;
         }
         this.replaceSkin(null);
         this._skinIsFromItem = false;
         super.defaultSkin = param1;
      }
      
      public function get data() : Object
      {
         return this._data;
      }
      
      public function set data(param1:Object) : void
      {
         if(this._data === param1)
         {
            return;
         }
         this._data = param1;
         this.invalidate("data");
      }
      
      public function get factoryID() : String
      {
         return this._factoryID;
      }
      
      public function set factoryID(param1:String) : void
      {
         this._factoryID = param1;
      }
      
      public function get useStateDelayTimer() : Boolean
      {
         return this._useStateDelayTimer;
      }
      
      public function set useStateDelayTimer(param1:Boolean) : void
      {
         if(this.processStyleRestriction(arguments.callee))
         {
            return;
         }
         this._useStateDelayTimer = param1;
      }
      
      public function get itemHasLabel() : Boolean
      {
         return this._itemHasLabel;
      }
      
      public function set itemHasLabel(param1:Boolean) : void
      {
         if(this._itemHasLabel == param1)
         {
            return;
         }
         this._itemHasLabel = param1;
         this.invalidate("data");
      }
      
      public function get itemHasIcon() : Boolean
      {
         return this._itemHasIcon;
      }
      
      public function set itemHasIcon(param1:Boolean) : void
      {
         if(this._itemHasIcon == param1)
         {
            return;
         }
         this._itemHasIcon = param1;
         this.invalidate("data");
      }
      
      public function get itemHasAccessory() : Boolean
      {
         return this._itemHasAccessory;
      }
      
      public function set itemHasAccessory(param1:Boolean) : void
      {
         if(this._itemHasAccessory == param1)
         {
            return;
         }
         this._itemHasAccessory = param1;
         this.invalidate("data");
      }
      
      public function get itemHasSkin() : Boolean
      {
         return this._itemHasSkin;
      }
      
      public function set itemHasSkin(param1:Boolean) : void
      {
         if(this._itemHasSkin == param1)
         {
            return;
         }
         this._itemHasSkin = param1;
         this.invalidate("data");
      }
      
      public function get itemHasSelectable() : Boolean
      {
         return this._itemHasSelectable;
      }
      
      public function set itemHasSelectable(param1:Boolean) : void
      {
         if(this._itemHasSelectable == param1)
         {
            return;
         }
         this._itemHasSelectable = param1;
         this.invalidate("data");
      }
      
      public function get itemHasEnabled() : Boolean
      {
         return this._itemHasEnabled;
      }
      
      public function set itemHasEnabled(param1:Boolean) : void
      {
         if(this._itemHasEnabled == param1)
         {
            return;
         }
         this._itemHasEnabled = param1;
         this.invalidate("data");
      }
      
      public function get accessoryPosition() : String
      {
         return this._accessoryPosition;
      }
      
      public function set accessoryPosition(param1:String) : void
      {
         if(this.processStyleRestriction(arguments.callee))
         {
            return;
         }
         if(this._accessoryPosition === param1)
         {
            return;
         }
         this._accessoryPosition = param1;
         this.invalidate("styles");
      }
      
      public function get layoutOrder() : String
      {
         return this._layoutOrder;
      }
      
      public function set layoutOrder(param1:String) : void
      {
         if(this.processStyleRestriction(arguments.callee))
         {
            return;
         }
         if(this._layoutOrder === param1)
         {
            return;
         }
         this._layoutOrder = param1;
         this.invalidate("styles");
      }
      
      public function get accessoryOffsetX() : Number
      {
         return this._accessoryOffsetX;
      }
      
      public function set accessoryOffsetX(param1:Number) : void
      {
         if(this.processStyleRestriction(arguments.callee))
         {
            return;
         }
         if(this._accessoryOffsetX === param1)
         {
            return;
         }
         this._accessoryOffsetX = param1;
         this.invalidate("styles");
      }
      
      public function get accessoryOffsetY() : Number
      {
         return this._accessoryOffsetY;
      }
      
      public function set accessoryOffsetY(param1:Number) : void
      {
         if(this.processStyleRestriction(arguments.callee))
         {
            return;
         }
         if(this._accessoryOffsetY === param1)
         {
            return;
         }
         this._accessoryOffsetY = param1;
         this.invalidate("styles");
      }
      
      public function get accessoryGap() : Number
      {
         return this._accessoryGap;
      }
      
      public function set accessoryGap(param1:Number) : void
      {
         if(this.processStyleRestriction(arguments.callee))
         {
            return;
         }
         if(this._accessoryGap === param1)
         {
            return;
         }
         this._accessoryGap = param1;
         this.invalidate("styles");
      }
      
      public function get minAccessoryGap() : Number
      {
         return this._minAccessoryGap;
      }
      
      public function set minAccessoryGap(param1:Number) : void
      {
         if(this.processStyleRestriction(arguments.callee))
         {
            return;
         }
         if(this._minAccessoryGap === param1)
         {
            return;
         }
         this._minAccessoryGap = param1;
         this.invalidate("styles");
      }
      
      public function get defaultAccessory() : DisplayObject
      {
         return this._defaultAccessory;
      }
      
      public function set defaultAccessory(param1:DisplayObject) : void
      {
         if(this._defaultAccessory === param1)
         {
            return;
         }
         this.replaceAccessory(null);
         this._accessoryIsFromItem = false;
         this._defaultAccessory = param1;
         this.invalidate("styles");
      }
      
      public function get stateToAccessoryFunction() : Function
      {
         return this._stateToAccessoryFunction;
      }
      
      public function set stateToAccessoryFunction(param1:Function) : void
      {
         if(this._stateToAccessoryFunction == param1)
         {
            return;
         }
         this._stateToAccessoryFunction = param1;
         this.invalidate("styles");
      }
      
      public function get stopScrollingOnAccessoryTouch() : Boolean
      {
         return this._stopScrollingOnAccessoryTouch;
      }
      
      public function set stopScrollingOnAccessoryTouch(param1:Boolean) : void
      {
         this._stopScrollingOnAccessoryTouch = param1;
      }
      
      public function get isSelectableOnAccessoryTouch() : Boolean
      {
         return this._isSelectableOnAccessoryTouch;
      }
      
      public function set isSelectableOnAccessoryTouch(param1:Boolean) : void
      {
         this._isSelectableOnAccessoryTouch = param1;
      }
      
      public function get delayTextureCreationOnScroll() : Boolean
      {
         return this._delayTextureCreationOnScroll;
      }
      
      public function set delayTextureCreationOnScroll(param1:Boolean) : void
      {
         this._delayTextureCreationOnScroll = param1;
      }
      
      public function get labelField() : String
      {
         return this._labelField;
      }
      
      public function set labelField(param1:String) : void
      {
         if(this._labelField == param1)
         {
            return;
         }
         this._labelField = param1;
         this.invalidate("data");
      }
      
      public function get labelFunction() : Function
      {
         return this._labelFunction;
      }
      
      public function set labelFunction(param1:Function) : void
      {
         if(this._labelFunction == param1)
         {
            return;
         }
         this._labelFunction = param1;
         this.invalidate("data");
      }
      
      public function get iconField() : String
      {
         return this._iconField;
      }
      
      public function set iconField(param1:String) : void
      {
         if(this._iconField == param1)
         {
            return;
         }
         this._iconField = param1;
         this.invalidate("data");
      }
      
      public function get iconFunction() : Function
      {
         return this._iconFunction;
      }
      
      public function set iconFunction(param1:Function) : void
      {
         if(this._iconFunction == param1)
         {
            return;
         }
         this._iconFunction = param1;
         this.invalidate("data");
      }
      
      public function get iconSourceField() : String
      {
         return this._iconSourceField;
      }
      
      public function set iconSourceField(param1:String) : void
      {
         if(this._iconSourceField == param1)
         {
            return;
         }
         this._iconSourceField = param1;
         this.invalidate("data");
      }
      
      public function get iconSourceFunction() : Function
      {
         return this._iconSourceFunction;
      }
      
      public function set iconSourceFunction(param1:Function) : void
      {
         if(this._iconSourceFunction == param1)
         {
            return;
         }
         this._iconSourceFunction = param1;
         this.invalidate("data");
      }
      
      public function get iconLabelField() : String
      {
         return this._iconLabelField;
      }
      
      public function set iconLabelField(param1:String) : void
      {
         if(this._iconLabelField == param1)
         {
            return;
         }
         this._iconLabelField = param1;
         this.invalidate("data");
      }
      
      public function get iconLabelFunction() : Function
      {
         return this._iconLabelFunction;
      }
      
      public function set iconLabelFunction(param1:Function) : void
      {
         if(this._iconLabelFunction == param1)
         {
            return;
         }
         this._iconLabelFunction = param1;
         this.invalidate("data");
      }
      
      public function get customIconLoaderStyleName() : String
      {
         return this._customIconLoaderStyleName;
      }
      
      public function set customIconLoaderStyleName(param1:String) : void
      {
         if(this.processStyleRestriction(arguments.callee))
         {
            return;
         }
         if(this._customIconLoaderStyleName === param1)
         {
            return;
         }
         this._customIconLoaderStyleName = param1;
         this.invalidate("data");
      }
      
      public function get customIconLabelStyleName() : String
      {
         return this._customIconLabelStyleName;
      }
      
      public function set customIconLabelStyleName(param1:String) : void
      {
         if(this.processStyleRestriction(arguments.callee))
         {
            return;
         }
         if(this._customIconLabelStyleName === param1)
         {
            return;
         }
         this._customIconLabelStyleName = param1;
         this.invalidate("textRenderer");
      }
      
      public function get accessoryField() : String
      {
         return this._accessoryField;
      }
      
      public function set accessoryField(param1:String) : void
      {
         if(this._accessoryField == param1)
         {
            return;
         }
         this._accessoryField = param1;
         this.invalidate("data");
      }
      
      public function get accessoryFunction() : Function
      {
         return this._accessoryFunction;
      }
      
      public function set accessoryFunction(param1:Function) : void
      {
         if(this._accessoryFunction == param1)
         {
            return;
         }
         this._accessoryFunction = param1;
         this.invalidate("data");
      }
      
      public function get accessorySourceField() : String
      {
         return this._accessorySourceField;
      }
      
      public function set accessorySourceField(param1:String) : void
      {
         if(this._accessorySourceField == param1)
         {
            return;
         }
         this._accessorySourceField = param1;
         this.invalidate("data");
      }
      
      public function get accessorySourceFunction() : Function
      {
         return this._accessorySourceFunction;
      }
      
      public function set accessorySourceFunction(param1:Function) : void
      {
         if(this._accessorySourceFunction == param1)
         {
            return;
         }
         this._accessorySourceFunction = param1;
         this.invalidate("data");
      }
      
      public function get accessoryLabelField() : String
      {
         return this._accessoryLabelField;
      }
      
      public function set accessoryLabelField(param1:String) : void
      {
         if(this._accessoryLabelField == param1)
         {
            return;
         }
         this._accessoryLabelField = param1;
         this.invalidate("data");
      }
      
      public function get accessoryLabelFunction() : Function
      {
         return this._accessoryLabelFunction;
      }
      
      public function set accessoryLabelFunction(param1:Function) : void
      {
         if(this._accessoryLabelFunction == param1)
         {
            return;
         }
         this._accessoryLabelFunction = param1;
         this.invalidate("data");
      }
      
      public function get customAccessoryLabelStyleName() : String
      {
         return this._customAccessoryLabelStyleName;
      }
      
      public function set customAccessoryLabelStyleName(param1:String) : void
      {
         if(this.processStyleRestriction(arguments.callee))
         {
            return;
         }
         if(this._customAccessoryLabelStyleName === param1)
         {
            return;
         }
         this._customAccessoryLabelStyleName = param1;
         this.invalidate("textRenderer");
      }
      
      public function get customAccessoryLoaderStyleName() : String
      {
         return this._customAccessoryLoaderStyleName;
      }
      
      public function set customAccessoryLoaderStyleName(param1:String) : void
      {
         if(this.processStyleRestriction(arguments.callee))
         {
            return;
         }
         if(this._customAccessoryLoaderStyleName === param1)
         {
            return;
         }
         this._customAccessoryLoaderStyleName = param1;
         this.invalidate("data");
      }
      
      public function get skinField() : String
      {
         return this._skinField;
      }
      
      public function set skinField(param1:String) : void
      {
         if(this._skinField == param1)
         {
            return;
         }
         this._skinField = param1;
         this.invalidate("data");
      }
      
      public function get skinFunction() : Function
      {
         return this._skinFunction;
      }
      
      public function set skinFunction(param1:Function) : void
      {
         if(this._skinFunction == param1)
         {
            return;
         }
         this._skinFunction = param1;
         this.invalidate("data");
      }
      
      public function get skinSourceField() : String
      {
         return this._skinSourceField;
      }
      
      public function set skinSourceField(param1:String) : void
      {
         if(this._skinSourceField == param1)
         {
            return;
         }
         this._skinSourceField = param1;
         this.invalidate("data");
      }
      
      public function get skinSourceFunction() : Function
      {
         return this._skinSourceFunction;
      }
      
      public function set skinSourceFunction(param1:Function) : void
      {
         if(this._skinSourceFunction == param1)
         {
            return;
         }
         this._skinSourceFunction = param1;
         this.invalidate("data");
      }
      
      public function get selectableField() : String
      {
         return this._selectableField;
      }
      
      public function set selectableField(param1:String) : void
      {
         if(this._selectableField == param1)
         {
            return;
         }
         this._selectableField = param1;
         this.invalidate("data");
      }
      
      public function get selectableFunction() : Function
      {
         return this._selectableFunction;
      }
      
      public function set selectableFunction(param1:Function) : void
      {
         if(this._selectableFunction == param1)
         {
            return;
         }
         this._selectableFunction = param1;
         this.invalidate("data");
      }
      
      public function get enabledField() : String
      {
         return this._enabledField;
      }
      
      public function set enabledField(param1:String) : void
      {
         if(this._enabledField == param1)
         {
            return;
         }
         this._enabledField = param1;
         this.invalidate("data");
      }
      
      public function get enabledFunction() : Function
      {
         return this._enabledFunction;
      }
      
      public function set enabledFunction(param1:Function) : void
      {
         if(this._enabledFunction == param1)
         {
            return;
         }
         this._enabledFunction = param1;
         this.invalidate("data");
      }
      
      override public function set isToggle(param1:Boolean) : void
      {
         if(this._explicitIsToggle == param1)
         {
            return;
         }
         super.isToggle = param1;
         this._explicitIsToggle = param1;
         this.invalidate("data");
      }
      
      override public function set isEnabled(param1:Boolean) : void
      {
         if(this._explicitIsEnabled == param1)
         {
            return;
         }
         this._explicitIsEnabled = param1;
         super.isEnabled = param1;
         this.invalidate("data");
      }
      
      public function get iconLoaderFactory() : Function
      {
         return this._iconLoaderFactory;
      }
      
      public function set iconLoaderFactory(param1:Function) : void
      {
         if(this._iconLoaderFactory == param1)
         {
            return;
         }
         this._iconLoaderFactory = param1;
         this._iconIsFromItem = false;
         this.replaceIcon(null);
         this.invalidate("data");
      }
      
      public function get iconLabelFontStyles() : TextFormat
      {
         return this._iconLabelFontStylesSet.format;
      }
      
      public function set iconLabelFontStyles(param1:TextFormat) : void
      {
         if(this.processStyleRestriction(arguments.callee))
         {
            return;
         }
         this._iconLabelFontStylesSet.format = param1;
      }
      
      public function get iconLabelDisabledFontStyles() : TextFormat
      {
         return this._iconLabelFontStylesSet.disabledFormat;
      }
      
      public function set iconLabelDisabledFontStyles(param1:TextFormat) : void
      {
         if(this.processStyleRestriction(arguments.callee))
         {
            return;
         }
         this._iconLabelFontStylesSet.disabledFormat = param1;
      }
      
      public function get iconLabelSelectedFontStyles() : TextFormat
      {
         return this._iconLabelFontStylesSet.selectedFormat;
      }
      
      public function set iconLabelSelectedFontStyles(param1:TextFormat) : void
      {
         if(this.processStyleRestriction(arguments.callee))
         {
            return;
         }
         this._iconLabelFontStylesSet.selectedFormat = param1;
      }
      
      public function get iconLabelFactory() : Function
      {
         return this._iconLabelFactory;
      }
      
      public function set iconLabelFactory(param1:Function) : void
      {
         if(this._iconLabelFactory == param1)
         {
            return;
         }
         this._iconLabelFactory = param1;
         this._iconIsFromItem = false;
         this.replaceIcon(null);
         this.invalidate("data");
      }
      
      public function get iconLabelProperties() : Object
      {
         if(!this._iconLabelProperties)
         {
            this._iconLabelProperties = new PropertyProxy(childProperties_onChange);
         }
         return this._iconLabelProperties;
      }
      
      public function set iconLabelProperties(param1:Object) : void
      {
         var _loc2_:PropertyProxy = null;
         if(this._iconLabelProperties == param1)
         {
            return;
         }
         if(!param1)
         {
            param1 = new PropertyProxy();
         }
         if(!(param1 is PropertyProxy))
         {
            _loc2_ = new PropertyProxy();
            for(var _loc3_ in param1)
            {
               _loc2_[_loc3_] = param1[_loc3_];
            }
            param1 = _loc2_;
         }
         if(this._iconLabelProperties)
         {
            this._iconLabelProperties.removeOnChangeCallback(childProperties_onChange);
         }
         this._iconLabelProperties = PropertyProxy(param1);
         if(this._iconLabelProperties)
         {
            this._iconLabelProperties.addOnChangeCallback(childProperties_onChange);
         }
         this.invalidate("styles");
      }
      
      public function get accessoryLoaderFactory() : Function
      {
         return this._accessoryLoaderFactory;
      }
      
      public function set accessoryLoaderFactory(param1:Function) : void
      {
         if(this._accessoryLoaderFactory == param1)
         {
            return;
         }
         this._accessoryLoaderFactory = param1;
         this._accessoryIsFromItem = false;
         this.replaceAccessory(null);
         this.invalidate("data");
      }
      
      public function get accessoryLabelFontStyles() : TextFormat
      {
         return this._accessoryLabelFontStylesSet.format;
      }
      
      public function set accessoryLabelFontStyles(param1:TextFormat) : void
      {
         if(this.processStyleRestriction(arguments.callee))
         {
            return;
         }
         this._accessoryLabelFontStylesSet.format = param1;
      }
      
      public function get accessoryLabelDisabledFontStyles() : TextFormat
      {
         return this._accessoryLabelFontStylesSet.disabledFormat;
      }
      
      public function set accessoryLabelDisabledFontStyles(param1:TextFormat) : void
      {
         if(this.processStyleRestriction(arguments.callee))
         {
            return;
         }
         this._accessoryLabelFontStylesSet.disabledFormat = param1;
      }
      
      public function get accessoryLabelSelectedFontStyles() : TextFormat
      {
         return this._accessoryLabelFontStylesSet.selectedFormat;
      }
      
      public function set accessoryLabelSelectedFontStyles(param1:TextFormat) : void
      {
         if(this.processStyleRestriction(arguments.callee))
         {
            return;
         }
         this._accessoryLabelFontStylesSet.selectedFormat = param1;
      }
      
      public function get accessoryLabelFactory() : Function
      {
         return this._accessoryLabelFactory;
      }
      
      public function set accessoryLabelFactory(param1:Function) : void
      {
         if(this._accessoryLabelFactory == param1)
         {
            return;
         }
         this._accessoryLabelFactory = param1;
         this._accessoryIsFromItem = false;
         this.replaceAccessory(null);
         this.invalidate("data");
      }
      
      public function get accessoryLabelProperties() : Object
      {
         if(!this._accessoryLabelProperties)
         {
            this._accessoryLabelProperties = new PropertyProxy(childProperties_onChange);
         }
         return this._accessoryLabelProperties;
      }
      
      public function set accessoryLabelProperties(param1:Object) : void
      {
         var _loc2_:PropertyProxy = null;
         if(this._accessoryLabelProperties == param1)
         {
            return;
         }
         if(!param1)
         {
            param1 = new PropertyProxy();
         }
         if(!(param1 is PropertyProxy))
         {
            _loc2_ = new PropertyProxy();
            for(var _loc3_ in param1)
            {
               _loc2_[_loc3_] = param1[_loc3_];
            }
            param1 = _loc2_;
         }
         if(this._accessoryLabelProperties)
         {
            this._accessoryLabelProperties.removeOnChangeCallback(childProperties_onChange);
         }
         this._accessoryLabelProperties = PropertyProxy(param1);
         if(this._accessoryLabelProperties)
         {
            this._accessoryLabelProperties.addOnChangeCallback(childProperties_onChange);
         }
         this.invalidate("styles");
      }
      
      public function get skinLoaderFactory() : Function
      {
         return this._skinLoaderFactory;
      }
      
      public function set skinLoaderFactory(param1:Function) : void
      {
         if(this._skinLoaderFactory == param1)
         {
            return;
         }
         this._skinLoaderFactory = param1;
         this._skinIsFromItem = false;
         this.replaceSkin(null);
         this.invalidate("data");
      }
      
      override public function dispose() : void
      {
         if(this._iconIsFromItem)
         {
            this.replaceIcon(null);
         }
         if(this._accessoryIsFromItem)
         {
            this.replaceAccessory(null);
         }
         if(this._skinIsFromItem)
         {
            this.replaceSkin(null);
         }
         if(this._iconLabelFontStylesSet !== null)
         {
            this._iconLabelFontStylesSet.dispose();
            this._iconLabelFontStylesSet = null;
         }
         if(this._accessoryLabelFontStylesSet !== null)
         {
            this._accessoryLabelFontStylesSet.dispose();
            this._accessoryLabelFontStylesSet = null;
         }
         super.dispose();
      }
      
      public function itemToLabel(param1:Object) : String
      {
         var _loc3_:Object = null;
         var _loc2_:IGroupedListItemRenderer = null;
         if(this._labelFunction !== null)
         {
            if(this is IListItemRenderer && this._labelFunction.length === 2)
            {
               _loc3_ = this._labelFunction(param1,IListItemRenderer(this).index);
            }
            else if(this is IGroupedListItemRenderer && this._labelFunction.length === 3)
            {
               _loc2_ = IGroupedListItemRenderer(this);
               _loc3_ = this._labelFunction(param1,_loc2_.groupIndex,_loc2_.itemIndex);
            }
            else
            {
               _loc3_ = this._labelFunction(param1);
            }
            if(_loc3_ is String)
            {
               return _loc3_ as String;
            }
            if(_loc3_ !== null)
            {
               return _loc3_.toString();
            }
         }
         else if(this._labelField !== null && param1 !== null && Boolean(param1.hasOwnProperty(this._labelField)))
         {
            _loc3_ = param1[this._labelField];
            if(_loc3_ is String)
            {
               return _loc3_ as String;
            }
            if(_loc3_ !== null)
            {
               return _loc3_.toString();
            }
         }
         else
         {
            if(param1 is String)
            {
               return param1 as String;
            }
            if(param1 !== null)
            {
               return param1.toString();
            }
         }
         return null;
      }
      
      protected function itemToIcon(param1:Object) : DisplayObject
      {
         var _loc3_:Object = null;
         var _loc2_:IGroupedListItemRenderer = null;
         var _loc4_:Object = null;
         if(this._iconSourceFunction !== null)
         {
            if(this is IListItemRenderer && this._iconSourceFunction.length === 2)
            {
               _loc3_ = this._iconSourceFunction(param1,IListItemRenderer(this).index);
            }
            else if(this is IGroupedListItemRenderer && this._iconSourceFunction.length === 3)
            {
               _loc2_ = IGroupedListItemRenderer(this);
               _loc3_ = this._iconSourceFunction(param1,_loc2_.groupIndex,_loc2_.itemIndex);
            }
            else
            {
               _loc3_ = this._iconSourceFunction(param1);
            }
            this.refreshIconSource(_loc3_);
            return this.iconLoader;
         }
         if(this._iconSourceField !== null && param1 !== null && Boolean(param1.hasOwnProperty(this._iconSourceField)))
         {
            _loc3_ = param1[this._iconSourceField];
            this.refreshIconSource(_loc3_);
            return this.iconLoader;
         }
         if(this._iconLabelFunction !== null)
         {
            if(this is IListItemRenderer && this._iconLabelFunction.length === 2)
            {
               _loc4_ = this._iconLabelFunction(param1,IListItemRenderer(this).index);
            }
            else if(this is IGroupedListItemRenderer && this._iconLabelFunction.length === 3)
            {
               _loc2_ = IGroupedListItemRenderer(this);
               _loc4_ = this._iconLabelFunction(param1,_loc2_.groupIndex,_loc2_.itemIndex);
            }
            else
            {
               _loc4_ = this._iconLabelFunction(param1);
            }
            if(_loc4_ is String)
            {
               this.refreshIconLabel(_loc4_ as String);
            }
            else
            {
               this.refreshIconLabel(_loc4_.toString());
            }
            return DisplayObject(this.iconLabel);
         }
         if(this._iconLabelField !== null && param1 !== null && Boolean(param1.hasOwnProperty(this._iconLabelField)))
         {
            _loc4_ = param1[this._iconLabelField];
            if(_loc4_ is String)
            {
               this.refreshIconLabel(_loc4_ as String);
            }
            else
            {
               this.refreshIconLabel(_loc4_.toString());
            }
            return DisplayObject(this.iconLabel);
         }
         if(this._iconFunction !== null)
         {
            if(this is IListItemRenderer && this._iconFunction.length === 2)
            {
               return this._iconFunction(param1,IListItemRenderer(this).index) as DisplayObject;
            }
            if(this is IGroupedListItemRenderer && this._iconFunction.length === 3)
            {
               _loc2_ = IGroupedListItemRenderer(this);
               return this._iconFunction(param1,_loc2_.groupIndex,_loc2_.itemIndex) as DisplayObject;
            }
            return this._iconFunction(param1) as DisplayObject;
         }
         if(this._iconField !== null && param1 !== null && Boolean(param1.hasOwnProperty(this._iconField)))
         {
            return param1[this._iconField] as DisplayObject;
         }
         return null;
      }
      
      protected function itemToAccessory(param1:Object) : DisplayObject
      {
         var _loc3_:Object = null;
         var _loc2_:IGroupedListItemRenderer = null;
         var _loc4_:Object = null;
         if(this._accessorySourceFunction !== null)
         {
            if(this is IListItemRenderer && this._accessorySourceFunction.length === 2)
            {
               _loc3_ = this._accessorySourceFunction(param1,IListItemRenderer(this).index);
            }
            else if(this is IGroupedListItemRenderer && this._accessorySourceFunction.length === 3)
            {
               _loc2_ = IGroupedListItemRenderer(this);
               _loc3_ = this._accessorySourceFunction(param1,_loc2_.groupIndex,_loc2_.itemIndex);
            }
            else
            {
               _loc3_ = this._accessorySourceFunction(param1);
            }
            this.refreshAccessorySource(_loc3_);
            return this.accessoryLoader;
         }
         if(this._accessorySourceField !== null && param1 !== null && Boolean(param1.hasOwnProperty(this._accessorySourceField)))
         {
            _loc3_ = param1[this._accessorySourceField];
            this.refreshAccessorySource(_loc3_);
            return this.accessoryLoader;
         }
         if(this._accessoryLabelFunction !== null)
         {
            if(this is IListItemRenderer && this._accessoryLabelFunction.length === 2)
            {
               _loc4_ = this._accessoryLabelFunction(param1,IListItemRenderer(this).index);
            }
            else if(this is IGroupedListItemRenderer && this._accessoryLabelFunction.length === 3)
            {
               _loc2_ = IGroupedListItemRenderer(this);
               _loc4_ = this._accessoryLabelFunction(param1,_loc2_.groupIndex,_loc2_.itemIndex);
            }
            else
            {
               _loc4_ = this._accessoryLabelFunction(param1);
            }
            if(_loc4_ is String)
            {
               this.refreshAccessoryLabel(_loc4_ as String);
            }
            else
            {
               this.refreshAccessoryLabel(_loc4_.toString());
            }
            return DisplayObject(this.accessoryLabel);
         }
         if(this._accessoryLabelField !== null && param1 !== null && Boolean(param1.hasOwnProperty(this._accessoryLabelField)))
         {
            _loc4_ = param1[this._accessoryLabelField];
            if(_loc4_ is String)
            {
               this.refreshAccessoryLabel(_loc4_ as String);
            }
            else
            {
               this.refreshAccessoryLabel(_loc4_.toString());
            }
            return DisplayObject(this.accessoryLabel);
         }
         if(this._accessoryFunction !== null)
         {
            if(this is IListItemRenderer && this._accessoryFunction.length === 2)
            {
               return this._accessoryFunction(param1,IListItemRenderer(this).index) as DisplayObject;
            }
            if(this is IGroupedListItemRenderer && this._accessoryFunction.length === 3)
            {
               _loc2_ = IGroupedListItemRenderer(this);
               return this._accessoryFunction(param1,_loc2_.groupIndex,_loc2_.itemIndex) as DisplayObject;
            }
            return this._accessoryFunction(param1) as DisplayObject;
         }
         if(this._accessoryField !== null && param1 !== null && Boolean(param1.hasOwnProperty(this._accessoryField)))
         {
            return param1[this._accessoryField] as DisplayObject;
         }
         return null;
      }
      
      protected function itemToSkin(param1:Object) : DisplayObject
      {
         var _loc3_:Object = null;
         var _loc2_:IGroupedListItemRenderer = null;
         if(this._skinSourceFunction !== null)
         {
            if(this is IListItemRenderer && this._skinSourceFunction.length === 2)
            {
               _loc3_ = this._skinSourceFunction(param1,IListItemRenderer(this).index);
            }
            else if(this is IGroupedListItemRenderer && this._skinSourceFunction.length === 3)
            {
               _loc2_ = IGroupedListItemRenderer(this);
               _loc3_ = this._skinSourceFunction(param1,_loc2_.groupIndex,_loc2_.itemIndex);
            }
            else
            {
               _loc3_ = this._skinSourceFunction(param1);
            }
            this.refreshSkinSource(_loc3_);
            return this.skinLoader;
         }
         if(this._skinSourceField !== null && param1 !== null && Boolean(param1.hasOwnProperty(this._skinSourceField)))
         {
            _loc3_ = param1[this._skinSourceField];
            this.refreshSkinSource(_loc3_);
            return this.skinLoader;
         }
         if(this._skinFunction !== null)
         {
            if(this is IListItemRenderer && this._skinFunction.length === 2)
            {
               return this._skinFunction(param1,IListItemRenderer(this).index) as DisplayObject;
            }
            if(this is IGroupedListItemRenderer && this._skinFunction.length === 3)
            {
               _loc2_ = IGroupedListItemRenderer(this);
               return this._skinFunction(param1,_loc2_.groupIndex,_loc2_.itemIndex) as DisplayObject;
            }
            return this._skinFunction(param1) as DisplayObject;
         }
         if(this._skinField !== null && param1 !== null && Boolean(param1.hasOwnProperty(this._skinField)))
         {
            return param1[this._skinField] as DisplayObject;
         }
         return null;
      }
      
      protected function itemToSelectable(param1:Object) : Boolean
      {
         var _loc2_:IGroupedListItemRenderer = null;
         if(this._selectableFunction !== null)
         {
            if(this is IListItemRenderer && this._selectableFunction.length === 2)
            {
               return this._selectableFunction(param1,IListItemRenderer(this).index) as Boolean;
            }
            if(this is IGroupedListItemRenderer && this._selectableFunction.length === 3)
            {
               _loc2_ = IGroupedListItemRenderer(this);
               return this._selectableFunction(param1,_loc2_.groupIndex,_loc2_.itemIndex) as Boolean;
            }
            return this._selectableFunction(param1) as Boolean;
         }
         if(this._selectableField !== null && param1 !== null && Boolean(param1.hasOwnProperty(this._selectableField)))
         {
            return param1[this._selectableField] as Boolean;
         }
         return true;
      }
      
      protected function itemToEnabled(param1:Object) : Boolean
      {
         var _loc2_:IGroupedListItemRenderer = null;
         if(this._enabledFunction !== null)
         {
            if(this is IListItemRenderer && this._enabledFunction.length === 2)
            {
               return this._enabledFunction(param1,IListItemRenderer(this).index) as Boolean;
            }
            if(this is IGroupedListItemRenderer && this._enabledFunction.length === 3)
            {
               _loc2_ = IGroupedListItemRenderer(this);
               return this._enabledFunction(param1,_loc2_.groupIndex,_loc2_.itemIndex) as Boolean;
            }
            return this._enabledFunction(param1) as Boolean;
         }
         if(this._enabledField !== null && param1 !== null && Boolean(param1.hasOwnProperty(this._enabledField)))
         {
            return param1[this._enabledField] as Boolean;
         }
         return true;
      }
      
      public function getIconLabelFontStylesForState(param1:String) : TextFormat
      {
         if(this._iconLabelFontStylesSet === null)
         {
            return null;
         }
         return this._iconLabelFontStylesSet.getFormatForState(param1);
      }
      
      public function setIconLabelFontStylesForState(param1:String, param2:TextFormat) : void
      {
         this._iconLabelFontStylesSet.setFormatForState(param1,param2);
      }
      
      public function getAccessoryLabelFontStylesForState(param1:String) : TextFormat
      {
         if(this._accessoryLabelFontStylesSet === null)
         {
            return null;
         }
         return this._accessoryLabelFontStylesSet.getFormatForState(param1);
      }
      
      public function setAccessoryLabelFontStylesForState(param1:String, param2:TextFormat) : void
      {
         this._accessoryLabelFontStylesSet.setFormatForState(param1,param2);
      }
      
      public function getAccessoryForState(param1:String) : DisplayObject
      {
         return this._stateToAccessory[param1] as DisplayObject;
      }
      
      public function setAccessoryForState(param1:String, param2:DisplayObject) : void
      {
         if(param2 !== null)
         {
            this._stateToAccessory[param1] = param2;
         }
         else
         {
            delete this._stateToAccessory[param1];
         }
         this.invalidate("styles");
      }
      
      override protected function initialize() : void
      {
         if(this.touchToState === null && this._useStateDelayTimer)
         {
            this.touchToState = new DelayedDownTouchToState(this,this.changeState);
         }
         super.initialize();
         this.tapToTrigger.customHitTest = this.hitTestWithAccessory;
         this.tapToSelect.customHitTest = this.hitTestWithAccessory;
         this.longPress.customHitTest = this.hitTestWithAccessory;
         this.touchToState.customHitTest = this.hitTestWithAccessory;
      }
      
      override protected function draw() : void
      {
         var _loc1_:Boolean = this.isInvalid("state");
         var _loc2_:Boolean = this.isInvalid("data");
         var _loc3_:Boolean = this.isInvalid("styles");
         if(_loc2_)
         {
            this.commitData();
         }
         if(_loc1_ || _loc2_ || _loc3_)
         {
            this.refreshAccessory();
         }
         this.refreshOffsets();
         super.draw();
      }
      
      override protected function autoSizeIfNeeded() : Boolean
      {
         var _loc4_:Boolean = this._explicitWidth !== this._explicitWidth;
         var _loc9_:Boolean = this._explicitHeight !== this._explicitHeight;
         var _loc5_:Boolean = this._explicitMinWidth !== this._explicitMinWidth;
         var _loc11_:Boolean = this._explicitMinHeight !== this._explicitMinHeight;
         if(!_loc4_ && !_loc9_ && !_loc5_ && !_loc11_)
         {
            return false;
         }
         var _loc8_:Boolean = this._ignoreAccessoryResizes;
         this._ignoreAccessoryResizes = true;
         var _loc1_:ITextRenderer = null;
         if(this._label !== null && this.labelTextRenderer !== null)
         {
            _loc1_ = this.labelTextRenderer;
            this.refreshLabelTextRendererDimensions(true);
            this.labelTextRenderer.measureText(HELPER_POINT);
         }
         if(this.currentIcon is IValidating)
         {
            IValidating(this.currentIcon).validate();
         }
         if(this.currentAccessory is IValidating)
         {
            IValidating(this.currentAccessory).validate();
         }
         resetFluidChildDimensionsForMeasurement(this.currentSkin,this._explicitWidth,this._explicitHeight,this._explicitMinWidth,this._explicitMinHeight,this._explicitMaxWidth,this._explicitMaxHeight,this._explicitSkinWidth,this._explicitSkinHeight,this._explicitSkinMinWidth,this._explicitSkinMinHeight,this._explicitSkinMaxWidth,this._explicitSkinMaxHeight);
         var _loc10_:IMeasureDisplayObject = this.currentSkin as IMeasureDisplayObject;
         var _loc3_:Number = this._explicitWidth;
         if(_loc4_)
         {
            if(_loc1_ !== null)
            {
               _loc3_ = Number(HELPER_POINT.x);
            }
            else
            {
               _loc3_ = 0;
            }
            if(this._layoutOrder === "labelAccessoryIcon")
            {
               _loc3_ = this.addAccessoryWidth(_loc3_);
               _loc3_ = this.addIconWidth(_loc3_);
            }
            else
            {
               _loc3_ = this.addIconWidth(_loc3_);
               _loc3_ = this.addAccessoryWidth(_loc3_);
            }
            _loc3_ += this._leftOffset + this._rightOffset;
            if(this.currentSkin !== null && this.currentSkin.width > _loc3_)
            {
               _loc3_ = this.currentSkin.width;
            }
         }
         var _loc6_:Number = this._explicitHeight;
         if(_loc9_)
         {
            if(_loc1_ !== null)
            {
               _loc6_ = Number(HELPER_POINT.y);
            }
            else
            {
               _loc6_ = 0;
            }
            if(this._layoutOrder === "labelAccessoryIcon")
            {
               _loc6_ = this.addAccessoryHeight(_loc6_);
               _loc6_ = this.addIconHeight(_loc6_);
            }
            else
            {
               _loc6_ = this.addIconHeight(_loc6_);
               _loc6_ = this.addAccessoryHeight(_loc6_);
            }
            _loc6_ += this._topOffset + this._bottomOffset;
            if(this.currentSkin !== null && this.currentSkin.height > _loc6_)
            {
               _loc6_ = this.currentSkin.height;
            }
         }
         var _loc2_:Number = this._explicitMinWidth;
         if(_loc5_)
         {
            if(_loc1_ !== null)
            {
               _loc2_ = Number(HELPER_POINT.x);
            }
            else
            {
               _loc2_ = 0;
            }
            if(this._layoutOrder === "labelAccessoryIcon")
            {
               _loc2_ = this.addAccessoryWidth(_loc2_);
               _loc2_ = this.addIconWidth(_loc2_);
            }
            else
            {
               _loc2_ = this.addIconWidth(_loc2_);
               _loc2_ = this.addAccessoryWidth(_loc2_);
            }
            _loc2_ += this._leftOffset + this._rightOffset;
            if(this.currentSkin !== null)
            {
               if(_loc10_ !== null)
               {
                  if(_loc10_.minWidth > _loc2_)
                  {
                     _loc2_ = _loc10_.minWidth;
                  }
               }
               else if(this._explicitSkinMinWidth > _loc2_)
               {
                  _loc2_ = this._explicitSkinMinWidth;
               }
            }
         }
         var _loc7_:Number = this._explicitMinHeight;
         if(_loc11_)
         {
            if(_loc1_ !== null)
            {
               _loc7_ = Number(HELPER_POINT.y);
            }
            else
            {
               _loc7_ = 0;
            }
            if(this._layoutOrder === "labelAccessoryIcon")
            {
               _loc7_ = this.addAccessoryHeight(_loc7_);
               _loc7_ = this.addIconHeight(_loc7_);
            }
            else
            {
               _loc7_ = this.addIconHeight(_loc7_);
               _loc7_ = this.addAccessoryHeight(_loc7_);
            }
            _loc7_ += this._topOffset + this._bottomOffset;
            if(this.currentSkin !== null)
            {
               if(_loc10_ !== null)
               {
                  if(_loc10_.minHeight > _loc7_)
                  {
                     _loc7_ = _loc10_.minHeight;
                  }
               }
               else if(this._explicitSkinMinHeight > _loc7_)
               {
                  _loc7_ = this._explicitSkinMinHeight;
               }
            }
         }
         this._ignoreAccessoryResizes = _loc8_;
         return this.saveMeasurements(_loc3_,_loc6_,_loc2_,_loc7_);
      }
      
      override protected function changeState(param1:String) : void
      {
         if(this._isEnabled && !this._isToggle && (!this.isSelectableWithoutToggle || this._itemHasSelectable && !this.itemToSelectable(this._data)))
         {
            param1 = "up";
         }
         super.changeState(param1);
      }
      
      protected function addIconWidth(param1:Number) : Number
      {
         var _loc4_:Number = NaN;
         if(!this.currentIcon)
         {
            return param1;
         }
         var _loc3_:Number = this.currentIcon.width;
         if(_loc3_ !== _loc3_)
         {
            return param1;
         }
         var _loc2_:Boolean = param1 === param1;
         if(!_loc2_)
         {
            param1 = 0;
         }
         if(this._iconPosition == "left" || this._iconPosition == "leftBaseline" || this._iconPosition == "right" || this._iconPosition == "rightBaseline")
         {
            if(_loc2_)
            {
               _loc4_ = this._gap;
               if(this._gap == Infinity)
               {
                  _loc4_ = this._minGap;
               }
               param1 += _loc4_;
            }
            param1 += _loc3_;
         }
         else if(_loc3_ > param1)
         {
            param1 = _loc3_;
         }
         return param1;
      }
      
      protected function addAccessoryWidth(param1:Number) : Number
      {
         var _loc4_:Number = NaN;
         if(!this.currentAccessory)
         {
            return param1;
         }
         var _loc3_:Number = this.currentAccessory.width;
         if(_loc3_ !== _loc3_)
         {
            return param1;
         }
         var _loc2_:Boolean = param1 === param1;
         if(!_loc2_)
         {
            param1 = 0;
         }
         if(this._accessoryPosition == "left" || this._accessoryPosition == "right")
         {
            if(_loc2_)
            {
               _loc4_ = this._accessoryGap;
               if(this._accessoryGap !== this._accessoryGap)
               {
                  _loc4_ = this._gap;
               }
               if(_loc4_ == Infinity)
               {
                  if(this._minAccessoryGap !== this._minAccessoryGap)
                  {
                     _loc4_ = this._minGap;
                  }
                  else
                  {
                     _loc4_ = this._minAccessoryGap;
                  }
               }
               param1 += _loc4_;
            }
            param1 += _loc3_;
         }
         else if(_loc3_ > param1)
         {
            param1 = _loc3_;
         }
         return param1;
      }
      
      protected function addIconHeight(param1:Number) : Number
      {
         var _loc4_:Number = NaN;
         if(this.currentIcon === null)
         {
            return param1;
         }
         var _loc3_:Number = this.currentIcon.height;
         if(_loc3_ !== _loc3_)
         {
            return param1;
         }
         var _loc2_:Boolean = param1 === param1;
         if(!_loc2_)
         {
            param1 = 0;
         }
         if(this._iconPosition === "top" || this._iconPosition === "bottom")
         {
            if(_loc2_)
            {
               _loc4_ = this._gap;
               if(this._gap === Infinity)
               {
                  _loc4_ = this._minGap;
               }
               param1 += _loc4_;
            }
            param1 += _loc3_;
         }
         else if(_loc3_ > param1)
         {
            param1 = _loc3_;
         }
         return param1;
      }
      
      protected function addAccessoryHeight(param1:Number) : Number
      {
         var _loc3_:Number = NaN;
         if(this.currentAccessory === null)
         {
            return param1;
         }
         var _loc4_:Number = this.currentAccessory.height;
         if(_loc4_ !== _loc4_)
         {
            return param1;
         }
         var _loc2_:Boolean = param1 === param1;
         if(!_loc2_)
         {
            param1 = 0;
         }
         if(this._accessoryPosition === "top" || this._accessoryPosition === "bottom")
         {
            if(_loc2_)
            {
               _loc3_ = this._accessoryGap;
               if(this._accessoryGap !== this._accessoryGap)
               {
                  _loc3_ = this._gap;
               }
               if(_loc3_ === Infinity)
               {
                  if(this._minAccessoryGap !== this._minAccessoryGap)
                  {
                     _loc3_ = this._minGap;
                  }
                  else
                  {
                     _loc3_ = this._minAccessoryGap;
                  }
               }
               param1 += _loc3_;
            }
            param1 += _loc4_;
         }
         else if(_loc4_ > param1)
         {
            param1 = _loc4_;
         }
         return param1;
      }
      
      protected function getDataToRender() : Object
      {
         return this._data;
      }
      
      protected function commitData() : void
      {
         var _loc2_:DisplayObject = null;
         var _loc4_:DisplayObject = null;
         var _loc3_:DisplayObject = null;
         var _loc1_:Object = this.getDataToRender();
         if(_loc1_ !== null)
         {
            if(this._itemHasLabel)
            {
               this._label = this.itemToLabel(_loc1_);
            }
            if(this._itemHasSkin)
            {
               _loc2_ = this.itemToSkin(_loc1_);
               this._skinIsFromItem = _loc2_ != null;
               this.replaceSkin(_loc2_);
            }
            else if(this._skinIsFromItem)
            {
               this._skinIsFromItem = false;
               this.replaceSkin(null);
            }
            if(this._itemHasIcon)
            {
               _loc4_ = this.itemToIcon(_loc1_);
               this._iconIsFromItem = _loc4_ != null;
               this.replaceIcon(_loc4_);
            }
            else if(this._iconIsFromItem)
            {
               this._iconIsFromItem = false;
               this.replaceIcon(null);
            }
            if(this._itemHasAccessory)
            {
               _loc3_ = this.itemToAccessory(_loc1_);
               this._accessoryIsFromItem = _loc3_ != null;
               this.replaceAccessory(_loc3_);
            }
            else if(this._accessoryIsFromItem)
            {
               this._accessoryIsFromItem = false;
               this.replaceAccessory(null);
            }
            if(this._itemHasSelectable)
            {
               this._isToggle = this._explicitIsToggle && this.itemToSelectable(_loc1_);
            }
            else
            {
               this._isToggle = this._explicitIsToggle;
            }
            if(this._itemHasEnabled)
            {
               this.refreshIsEnabled(this._explicitIsEnabled && this.itemToEnabled(_loc1_));
            }
            else
            {
               this.refreshIsEnabled(this._explicitIsEnabled);
            }
         }
         else
         {
            if(this._itemHasLabel)
            {
               this._label = "";
            }
            if(this._itemHasIcon || this._iconIsFromItem)
            {
               this._iconIsFromItem = false;
               this.replaceIcon(null);
            }
            if(this._itemHasSkin || this._skinIsFromItem)
            {
               this._skinIsFromItem = false;
               this.replaceSkin(null);
            }
            if(this._itemHasAccessory || this._accessoryIsFromItem)
            {
               this._accessoryIsFromItem = false;
               this.replaceAccessory(null);
            }
            if(this._itemHasSelectable)
            {
               this._isToggle = this._explicitIsToggle;
            }
            if(this._itemHasEnabled)
            {
               this.refreshIsEnabled(this._explicitIsEnabled);
            }
         }
      }
      
      protected function refreshIsEnabled(param1:Boolean) : void
      {
         if(this._isEnabled == param1)
         {
            return;
         }
         this._isEnabled = param1;
         if(this._isEnabled)
         {
            if(this._currentState == "disabled")
            {
               this._currentState = "up";
            }
            this.touchable = true;
         }
         else
         {
            this._currentState = "disabled";
            this.touchable = false;
         }
         this.setInvalidationFlag("state");
         this.dispatchEventWith("stageChange");
      }
      
      protected function replaceIcon(param1:DisplayObject) : void
      {
         if(this.iconLoader && this.iconLoader != param1)
         {
            this.iconLoader.removeEventListener("complete",loader_completeOrErrorHandler);
            this.iconLoader.removeEventListener("error",loader_completeOrErrorHandler);
            this.iconLoader.dispose();
            this.iconLoader = null;
         }
         if(this.iconLabel && this.iconLabel != param1)
         {
            this.iconLabel.dispose();
            this.iconLabel = null;
         }
         if(this._itemHasIcon && this.currentIcon && this.currentIcon != param1 && this.currentIcon.parent == this)
         {
            this.currentIcon.removeFromParent(false);
            this.currentIcon = null;
         }
         if(this._defaultIcon !== param1)
         {
            this._defaultIcon = param1;
            this._stateToIconFunction = null;
            this.setInvalidationFlag("styles");
         }
         if(this.iconLoader !== null)
         {
            this.iconLoader.delayTextureCreation = this._delayTextureCreationOnScroll && this._owner !== null && this._owner.isScrolling;
         }
      }
      
      protected function replaceAccessory(param1:DisplayObject) : void
      {
         if(this.accessoryLoader && this.accessoryLoader != param1)
         {
            this.accessoryLoader.removeEventListener("complete",loader_completeOrErrorHandler);
            this.accessoryLoader.removeEventListener("error",loader_completeOrErrorHandler);
            this.accessoryLoader.dispose();
            this.accessoryLoader = null;
         }
         if(this.accessoryLabel && this.accessoryLabel != param1)
         {
            this.accessoryLabel.dispose();
            this.accessoryLabel = null;
         }
         if(this._itemHasAccessory && this.currentAccessory && this.currentAccessory != param1 && this.currentAccessory.parent == this)
         {
            this.currentAccessory.removeFromParent(false);
            this.currentAccessory = null;
         }
         if(this._defaultAccessory !== param1)
         {
            this._defaultAccessory = param1;
            this._stateToAccessoryFunction = null;
            this.setInvalidationFlag("styles");
         }
         if(this.accessoryLoader !== null)
         {
            this.accessoryLoader.delayTextureCreation = this._delayTextureCreationOnScroll && this._owner !== null && this._owner.isScrolling;
         }
      }
      
      protected function replaceSkin(param1:DisplayObject) : void
      {
         if(this.skinLoader && this.skinLoader != param1)
         {
            this.skinLoader.removeEventListener("complete",loader_completeOrErrorHandler);
            this.skinLoader.removeEventListener("error",loader_completeOrErrorHandler);
            this.skinLoader.dispose();
            this.skinLoader = null;
         }
         if(this._itemHasSkin && this.currentSkin && this.currentSkin != param1 && this.currentSkin.parent == this)
         {
            this.currentSkin.removeFromParent(false);
            this.currentSkin = null;
         }
         if(this._defaultSkin !== param1)
         {
            this._defaultSkin = param1;
            this._stateToSkinFunction = null;
            this.setInvalidationFlag("styles");
         }
         if(this.skinLoader !== null)
         {
            this.skinLoader.delayTextureCreation = this._delayTextureCreationOnScroll && this._owner !== null && this._owner.isScrolling;
         }
      }
      
      override protected function refreshIcon() : void
      {
         var _loc1_:DisplayObject = null;
         var _loc3_:Object = null;
         super.refreshIcon();
         if(this.iconLabel !== null)
         {
            this.iconLabel.fontStyles = this._iconLabelFontStylesSet;
            _loc1_ = DisplayObject(this.iconLabel);
            for(var _loc2_ in this._iconLabelProperties)
            {
               _loc3_ = this._iconLabelProperties[_loc2_];
               _loc1_[_loc2_] = _loc3_;
            }
         }
      }
      
      protected function refreshAccessory() : void
      {
         var _loc1_:DisplayObject = null;
         var _loc4_:Object = null;
         var _loc3_:DisplayObject = this.currentAccessory;
         this.currentAccessory = this.getCurrentAccessory();
         if(this.currentAccessory is IFeathersControl)
         {
            IFeathersControl(this.currentAccessory).isEnabled = this._isEnabled;
         }
         if(this.currentAccessory != _loc3_)
         {
            if(_loc3_)
            {
               if(_loc3_ is IStateObserver)
               {
                  IStateObserver(_loc3_).stateContext = null;
               }
               if(_loc3_ is IFeathersControl)
               {
                  IFeathersControl(_loc3_).removeEventListener("resize",accessory_resizeHandler);
                  IFeathersControl(_loc3_).removeEventListener("touch",accessory_touchHandler);
               }
               this.removeChild(_loc3_,false);
            }
            if(this.currentAccessory)
            {
               if(this.currentAccessory is IStateObserver)
               {
                  IStateObserver(this.currentAccessory).stateContext = this;
               }
               this.addChild(this.currentAccessory);
               if(this.currentAccessory is IFeathersControl)
               {
                  IFeathersControl(this.currentAccessory).addEventListener("resize",accessory_resizeHandler);
                  IFeathersControl(this.currentAccessory).addEventListener("touch",accessory_touchHandler);
               }
            }
         }
         if(this.accessoryLabel !== null)
         {
            this.accessoryLabel.fontStyles = this._accessoryLabelFontStylesSet;
            _loc1_ = DisplayObject(this.accessoryLabel);
            for(var _loc2_ in this._accessoryLabelProperties)
            {
               _loc4_ = this._accessoryLabelProperties[_loc2_];
               _loc1_[_loc2_] = _loc4_;
            }
         }
      }
      
      protected function getCurrentAccessory() : DisplayObject
      {
         if(this._stateToAccessoryFunction !== null)
         {
            return DisplayObject(this._stateToAccessoryFunction(this,this._currentState,this.currentAccessory));
         }
         var _loc1_:DisplayObject = this._stateToAccessory[this.currentState] as DisplayObject;
         if(_loc1_ !== null)
         {
            return _loc1_;
         }
         return this._defaultAccessory;
      }
      
      protected function refreshIconSource(param1:Object) : void
      {
         var _loc2_:String = null;
         if(!this.iconLoader)
         {
            this.iconLoader = this._iconLoaderFactory();
            this.iconLoader.addEventListener("complete",loader_completeOrErrorHandler);
            this.iconLoader.addEventListener("ioError",loader_completeOrErrorHandler);
            this.iconLoader.addEventListener("securityError",loader_completeOrErrorHandler);
            _loc2_ = this._customIconLoaderStyleName ?? this.iconLoaderStyleName;
            this.iconLoader.styleNameList.add(_loc2_);
         }
         this.iconLoader.source = param1;
      }
      
      protected function refreshIconLabel(param1:String) : void
      {
         var _loc2_:Function = null;
         var _loc3_:String = null;
         if(this.iconLabel === null)
         {
            _loc2_ = this._iconLabelFactory ?? FeathersControl.defaultTextRendererFactory;
            this.iconLabel = ITextRenderer(_loc2_());
            if(this.iconLabel is IStateObserver)
            {
               IStateObserver(this.iconLabel).stateContext = this;
            }
            _loc3_ = this._customIconLabelStyleName ?? this.iconLabelStyleName;
            this.iconLabel.styleNameList.add(_loc3_);
         }
         this.iconLabel.text = param1;
      }
      
      protected function refreshAccessorySource(param1:Object) : void
      {
         var _loc2_:String = null;
         if(!this.accessoryLoader)
         {
            this.accessoryLoader = this._accessoryLoaderFactory();
            this.accessoryLoader.addEventListener("complete",loader_completeOrErrorHandler);
            this.accessoryLoader.addEventListener("ioError",loader_completeOrErrorHandler);
            this.accessoryLoader.addEventListener("securityError",loader_completeOrErrorHandler);
            _loc2_ = this._customAccessoryLoaderStyleName ?? this.accessoryLoaderStyleName;
            this.accessoryLoader.styleNameList.add(_loc2_);
         }
         this.accessoryLoader.source = param1;
      }
      
      protected function refreshAccessoryLabel(param1:String) : void
      {
         var _loc2_:Function = null;
         var _loc3_:String = null;
         if(this.accessoryLabel === null)
         {
            _loc2_ = this._accessoryLabelFactory ?? FeathersControl.defaultTextRendererFactory;
            this.accessoryLabel = ITextRenderer(_loc2_());
            if(this.accessoryLabel is IStateObserver)
            {
               IStateObserver(this.accessoryLabel).stateContext = this;
            }
            _loc3_ = this._customAccessoryLabelStyleName ?? this.accessoryLabelStyleName;
            this.accessoryLabel.styleNameList.add(_loc3_);
         }
         this.accessoryLabel.text = param1;
      }
      
      protected function refreshSkinSource(param1:Object) : void
      {
         if(!this.skinLoader)
         {
            this.skinLoader = this._skinLoaderFactory();
            this.skinLoader.addEventListener("complete",loader_completeOrErrorHandler);
            this.skinLoader.addEventListener("error",loader_completeOrErrorHandler);
         }
         this.skinLoader.source = param1;
      }
      
      override protected function layoutContent() : void
      {
         var _loc7_:String = null;
         var _loc5_:Boolean = this._ignoreAccessoryResizes;
         this._ignoreAccessoryResizes = true;
         var _loc6_:Boolean = this._ignoreIconResizes;
         this._ignoreIconResizes = true;
         this.refreshLabelTextRendererDimensions(false);
         var _loc1_:DisplayObject = null;
         if(this._label !== null && this.labelTextRenderer !== null)
         {
            _loc1_ = DisplayObject(this.labelTextRenderer);
         }
         var _loc2_:Boolean = this.currentIcon && this._iconPosition != "manual";
         var _loc3_:Boolean = this.currentAccessory && this._accessoryPosition != "manual";
         var _loc4_:Number = this._accessoryGap;
         if(_loc4_ !== _loc4_)
         {
            _loc4_ = this._gap;
         }
         if(_loc1_ && _loc2_ && _loc3_)
         {
            this.positionSingleChild(_loc1_);
            if(this._layoutOrder == "labelAccessoryIcon")
            {
               this.positionRelativeToOthers(this.currentAccessory,_loc1_,null,this._accessoryPosition,_loc4_,null,0);
               _loc7_ = this._iconPosition;
               if(_loc7_ == "leftBaseline")
               {
                  _loc7_ = "left";
               }
               else if(_loc7_ == "rightBaseline")
               {
                  _loc7_ = "right";
               }
               this.positionRelativeToOthers(this.currentIcon,_loc1_,this.currentAccessory,_loc7_,this._gap,this._accessoryPosition,_loc4_);
            }
            else
            {
               this.positionLabelAndIcon();
               this.positionRelativeToOthers(this.currentAccessory,_loc1_,this.currentIcon,this._accessoryPosition,_loc4_,this._iconPosition,this._gap);
            }
         }
         else if(_loc1_)
         {
            this.positionSingleChild(_loc1_);
            if(_loc2_)
            {
               this.positionLabelAndIcon();
            }
            else if(_loc3_)
            {
               this.positionRelativeToOthers(this.currentAccessory,_loc1_,null,this._accessoryPosition,_loc4_,null,0);
            }
         }
         else if(_loc2_)
         {
            this.positionSingleChild(this.currentIcon);
            if(_loc3_)
            {
               this.positionRelativeToOthers(this.currentAccessory,this.currentIcon,null,this._accessoryPosition,_loc4_,null,0);
            }
         }
         else if(_loc3_)
         {
            this.positionSingleChild(this.currentAccessory);
         }
         if(this.currentAccessory)
         {
            if(!_loc3_)
            {
               this.currentAccessory.x = this._leftOffset;
               this.currentAccessory.y = this._topOffset;
            }
            this.currentAccessory.x += this._accessoryOffsetX;
            this.currentAccessory.y += this._accessoryOffsetY;
         }
         if(this.currentIcon)
         {
            if(!_loc2_)
            {
               this.currentIcon.x = this._leftOffset;
               this.currentIcon.y = this._topOffset;
            }
            this.currentIcon.x += this._iconOffsetX;
            this.currentIcon.y += this._iconOffsetY;
         }
         if(_loc1_)
         {
            this.labelTextRenderer.x += this._labelOffsetX;
            this.labelTextRenderer.y += this._labelOffsetY;
         }
         this._ignoreIconResizes = _loc6_;
         this._ignoreAccessoryResizes = _loc5_;
      }
      
      protected function refreshOffsets() : void
      {
         this._topOffset = this._paddingTop;
         this._rightOffset = this._paddingRight;
         this._bottomOffset = this._paddingBottom;
         this._leftOffset = this._paddingLeft;
      }
      
      override protected function refreshLabelTextRendererDimensions(param1:Boolean) : void
      {
         var _loc2_:Boolean = false;
         var _loc12_:Boolean = false;
         var _loc5_:Boolean = this._ignoreIconResizes;
         this._ignoreIconResizes = true;
         var _loc3_:Number = this.actualWidth;
         if(param1)
         {
            _loc3_ = this._explicitWidth;
            if(_loc3_ !== _loc3_)
            {
               _loc3_ = this._explicitMaxWidth;
            }
         }
         _loc3_ -= this._leftOffset + this._rightOffset;
         var _loc8_:Number = this.actualHeight;
         if(param1)
         {
            _loc8_ = this._explicitHeight;
            if(_loc8_ !== _loc8_)
            {
               _loc8_ = this._explicitMaxHeight;
            }
         }
         _loc8_ -= this._topOffset + this._bottomOffset;
         var _loc9_:Number = this._gap;
         if(_loc9_ == Infinity)
         {
            _loc9_ = this._minGap;
         }
         var _loc7_:Number = this._accessoryGap;
         if(_loc7_ !== _loc7_)
         {
            _loc7_ = this._gap;
         }
         if(_loc7_ == Infinity)
         {
            _loc7_ = this._minAccessoryGap;
            if(_loc7_ !== _loc7_)
            {
               _loc7_ = this._minGap;
            }
         }
         var _loc10_:Boolean = this.currentIcon && (this._iconPosition == "left" || this._iconPosition == "leftBaseline" || this._iconPosition == "right" || this._iconPosition == "rightBaseline");
         var _loc6_:Boolean = this.currentIcon && (this._iconPosition == "top" || this._iconPosition == "bottom");
         var _loc11_:Boolean = this.currentAccessory && (this._accessoryPosition == "left" || this._accessoryPosition == "right");
         var _loc4_:Boolean = this.currentAccessory && (this._accessoryPosition == "top" || this._accessoryPosition == "bottom");
         if(this.accessoryLabel)
         {
            _loc2_ = _loc10_ && (_loc11_ || this._layoutOrder === "labelAccessoryIcon");
            if(this.iconLabel)
            {
               this.iconLabel.maxWidth = _loc3_ - _loc9_;
               if(this.iconLabel.maxWidth < 0)
               {
                  this.iconLabel.maxWidth = 0;
               }
            }
            if(this.currentIcon is IValidating)
            {
               IValidating(this.currentIcon).validate();
            }
            if(_loc2_)
            {
               _loc3_ -= this.currentIcon.width + _loc9_;
            }
            if(_loc3_ < 0)
            {
               _loc3_ = 0;
            }
            this.accessoryLabel.maxWidth = _loc3_;
            this.accessoryLabel.maxHeight = _loc8_;
            if(_loc10_ && this.currentIcon && !_loc2_)
            {
               _loc3_ -= this.currentIcon.width + _loc9_;
            }
            if(this.currentAccessory is IValidating)
            {
               IValidating(this.currentAccessory).validate();
            }
            if(_loc11_)
            {
               _loc3_ -= this.currentAccessory.width + _loc7_;
            }
            if(_loc4_)
            {
               _loc8_ -= this.currentAccessory.height + _loc7_;
            }
         }
         else if(this.iconLabel)
         {
            _loc12_ = _loc11_ && (_loc10_ || this._layoutOrder === "labelIconAccessory");
            if(this.currentAccessory is IValidating)
            {
               IValidating(this.currentAccessory).validate();
            }
            if(_loc12_)
            {
               _loc3_ -= _loc7_ + this.currentAccessory.width;
            }
            if(_loc3_ < 0)
            {
               _loc3_ = 0;
            }
            this.iconLabel.maxWidth = _loc3_;
            this.iconLabel.maxHeight = _loc8_;
            if(_loc11_ && this.currentAccessory && !_loc12_)
            {
               _loc3_ -= _loc7_ + this.currentAccessory.width;
            }
            if(this.currentIcon is IValidating)
            {
               IValidating(this.currentIcon).validate();
            }
            if(_loc10_)
            {
               _loc3_ -= this.currentIcon.width + _loc9_;
            }
            if(_loc6_)
            {
               _loc8_ -= this.currentIcon.height + _loc9_;
            }
         }
         else
         {
            if(this.currentIcon is IValidating)
            {
               IValidating(this.currentIcon).validate();
            }
            if(_loc10_)
            {
               _loc3_ -= _loc9_ + this.currentIcon.width;
            }
            if(_loc6_)
            {
               _loc8_ -= _loc9_ + this.currentIcon.height;
            }
            if(this.currentAccessory is IValidating)
            {
               IValidating(this.currentAccessory).validate();
            }
            if(_loc11_)
            {
               _loc3_ -= _loc7_ + this.currentAccessory.width;
            }
            if(_loc4_)
            {
               _loc8_ -= _loc7_ + this.currentAccessory.height;
            }
         }
         if(_loc3_ < 0)
         {
            _loc3_ = 0;
         }
         if(_loc8_ < 0)
         {
            _loc8_ = 0;
         }
         if(_loc3_ > this._explicitLabelMaxWidth)
         {
            _loc3_ = this._explicitLabelMaxWidth;
         }
         if(_loc8_ > this._explicitLabelMaxHeight)
         {
            _loc8_ = this._explicitLabelMaxHeight;
         }
         if(this.labelTextRenderer !== null)
         {
            this.labelTextRenderer.width = this._explicitLabelWidth;
            this.labelTextRenderer.height = this._explicitLabelHeight;
            this.labelTextRenderer.minWidth = this._explicitLabelMinWidth;
            this.labelTextRenderer.minHeight = this._explicitLabelMinHeight;
            this.labelTextRenderer.maxWidth = _loc3_;
            this.labelTextRenderer.maxHeight = _loc8_;
            this.labelTextRenderer.validate();
            if(!param1)
            {
               _loc3_ = Number(this.labelTextRenderer.width);
               _loc8_ = Number(this.labelTextRenderer.height);
               this.labelTextRenderer.width = _loc3_;
               this.labelTextRenderer.height = _loc8_;
               this.labelTextRenderer.minWidth = _loc3_;
               this.labelTextRenderer.minHeight = _loc8_;
            }
         }
         this._ignoreIconResizes = _loc5_;
      }
      
      override protected function positionSingleChild(param1:DisplayObject) : void
      {
         if(this._horizontalAlign === "left")
         {
            param1.x = this._leftOffset;
         }
         else if(this._horizontalAlign === "right")
         {
            param1.x = this.actualWidth - this._rightOffset - param1.width;
         }
         else
         {
            param1.x = this._leftOffset + Math.round((this.actualWidth - this._leftOffset - this._rightOffset - param1.width) / 2);
         }
         if(this._verticalAlign === "top")
         {
            param1.y = this._topOffset;
         }
         else if(this._verticalAlign === "bottom")
         {
            param1.y = this.actualHeight - this._bottomOffset - param1.height;
         }
         else
         {
            param1.y = this._topOffset + Math.round((this.actualHeight - this._topOffset - this._bottomOffset - param1.height) / 2);
         }
      }
      
      protected function positionRelativeToOthers(param1:DisplayObject, param2:DisplayObject, param3:DisplayObject, param4:String, param5:Number, param6:String, param7:Number) : void
      {
         var _loc14_:Number = NaN;
         var _loc11_:Number = NaN;
         var _loc10_:Number = NaN;
         var _loc9_:Number = NaN;
         var _loc19_:Number = param2.x;
         if(param3 !== null && param3.x < _loc19_)
         {
            _loc19_ = param3.x;
         }
         var _loc18_:Number = param2.y;
         if(param3 !== null && param3.y < _loc18_)
         {
            _loc18_ = param3.y;
         }
         var _loc8_:Number = param2.width;
         if(param3 !== null)
         {
            _loc8_ = param2.x + param2.width;
            _loc14_ = param3.x + param3.width;
            if(_loc14_ > _loc8_)
            {
               _loc8_ = _loc14_;
            }
            _loc8_ -= _loc19_;
         }
         var _loc15_:Number = param2.height;
         if(param3 !== null)
         {
            _loc15_ = param2.y + param2.height;
            _loc11_ = param3.y + param3.height;
            if(_loc11_ > _loc15_)
            {
               _loc15_ = _loc11_;
            }
            _loc15_ -= _loc18_;
         }
         var _loc17_:Number = _loc19_;
         var _loc16_:Number = _loc18_;
         if(param4 == "top")
         {
            if(param5 == Infinity)
            {
               param1.y = this._topOffset;
               _loc16_ = this.actualHeight - this._bottomOffset - _loc15_;
            }
            else
            {
               if(this._verticalAlign == "top")
               {
                  _loc16_ += param1.height + param5;
               }
               else if(this._verticalAlign == "middle")
               {
                  _loc16_ += Math.round((param1.height + param5) / 2);
               }
               if(param3 != null)
               {
                  _loc10_ = this._topOffset + param1.height + param5;
                  if(_loc10_ > _loc16_)
                  {
                     _loc16_ = _loc10_;
                  }
               }
               param1.y = _loc16_ - param1.height - param5;
            }
         }
         else if(param4 == "right")
         {
            if(param5 == Infinity)
            {
               _loc17_ = this._leftOffset;
               param1.x = this.actualWidth - this._rightOffset - param1.width;
            }
            else
            {
               if(this._horizontalAlign == "right")
               {
                  _loc17_ -= param1.width + param5;
               }
               else if(this._horizontalAlign == "center")
               {
                  _loc17_ -= Math.round((param1.width + param5) / 2);
               }
               if(param3 !== null)
               {
                  _loc9_ = this.actualWidth - this._rightOffset - param1.width - _loc8_ - param5;
                  if(_loc9_ < _loc17_)
                  {
                     _loc17_ = _loc9_;
                  }
               }
               param1.x = _loc17_ + _loc8_ + param5;
            }
         }
         else if(param4 == "bottom")
         {
            if(param5 == Infinity)
            {
               _loc16_ = this._topOffset;
               param1.y = this.actualHeight - this._bottomOffset - param1.height;
            }
            else
            {
               if(this._verticalAlign == "bottom")
               {
                  _loc16_ -= param1.height + param5;
               }
               else if(this._verticalAlign == "middle")
               {
                  _loc16_ -= Math.round((param1.height + param5) / 2);
               }
               if(param3 !== null)
               {
                  _loc10_ = this.actualHeight - this._bottomOffset - param1.height - _loc15_ - param5;
                  if(_loc10_ < _loc16_)
                  {
                     _loc16_ = _loc10_;
                  }
               }
               param1.y = _loc16_ + _loc15_ + param5;
            }
         }
         else if(param4 == "left")
         {
            if(param5 == Infinity)
            {
               param1.x = this._leftOffset;
               _loc17_ = this.actualWidth - this._rightOffset - _loc8_;
            }
            else
            {
               if(this._horizontalAlign == "left")
               {
                  _loc17_ += param5 + param1.width;
               }
               else if(this._horizontalAlign == "center")
               {
                  _loc17_ += Math.round((param5 + param1.width) / 2);
               }
               if(param3 !== null)
               {
                  _loc9_ = this._leftOffset + param1.width + param5;
                  if(_loc9_ > _loc17_)
                  {
                     _loc17_ = _loc9_;
                  }
               }
               param1.x = _loc17_ - param5 - param1.width;
            }
         }
         var _loc12_:Number = _loc17_ - _loc19_;
         var _loc13_:Number = _loc16_ - _loc18_;
         if(!param3 || param7 != Infinity || !(param4 == "top" && param6 == "top" || param4 == "right" && param6 == "right" || param4 == "bottom" && param6 == "bottom" || param4 == "left" && param6 == "left"))
         {
            param2.x += _loc12_;
            param2.y += _loc13_;
         }
         if(param3)
         {
            if(param7 != Infinity || !(param4 == "left" && param6 == "right" || param4 == "right" && param6 == "left" || param4 == "top" && param6 == "bottom" || param4 == "bottom" && param6 == "top"))
            {
               param3.x += _loc12_;
               param3.y += _loc13_;
            }
            if(param5 == Infinity && param7 == Infinity)
            {
               if(param4 == "right" && param6 == "left")
               {
                  param2.x = param3.x + Math.round((param1.x - param3.x + param3.width - param2.width) / 2);
               }
               else if(param4 == "left" && param6 == "right")
               {
                  param2.x = param1.x + Math.round((param3.x - param1.x + param1.width - param2.width) / 2);
               }
               else if(param4 == "right" && param6 == "right")
               {
                  param3.x = param2.x + Math.round((param1.x - param2.x + param2.width - param3.width) / 2);
               }
               else if(param4 == "left" && param6 == "left")
               {
                  param3.x = param1.x + Math.round((param2.x - param1.x + param1.width - param3.width) / 2);
               }
               else if(param4 == "bottom" && param6 == "top")
               {
                  param2.y = param3.y + Math.round((param1.y - param3.y + param3.height - param2.height) / 2);
               }
               else if(param4 == "top" && param6 == "bottom")
               {
                  param2.y = param1.y + Math.round((param3.y - param1.y + param1.height - param2.height) / 2);
               }
               else if(param4 == "bottom" && param6 == "bottom")
               {
                  param3.y = param2.y + Math.round((param1.y - param2.y + param2.height - param3.height) / 2);
               }
               else if(param4 == "top" && param6 == "top")
               {
                  param3.y = param1.y + Math.round((param2.y - param1.y + param1.height - param3.height) / 2);
               }
            }
         }
         if(param4 == "left" || param4 == "right")
         {
            if(this._verticalAlign == "top")
            {
               param1.y = this._topOffset;
            }
            else if(this._verticalAlign == "bottom")
            {
               param1.y = this.actualHeight - this._bottomOffset - param1.height;
            }
            else
            {
               param1.y = this._topOffset + Math.round((this.actualHeight - this._topOffset - this._bottomOffset - param1.height) / 2);
            }
         }
         else if(param4 == "top" || param4 == "bottom")
         {
            if(this._horizontalAlign == "left")
            {
               param1.x = this._leftOffset;
            }
            else if(this._horizontalAlign == "right")
            {
               param1.x = this.actualWidth - this._rightOffset - param1.width;
            }
            else
            {
               param1.x = this._leftOffset + Math.round((this.actualWidth - this._leftOffset - this._rightOffset - param1.width) / 2);
            }
         }
      }
      
      override protected function refreshSelectionEvents() : void
      {
         var _loc1_:Boolean = this._isEnabled && (this._isToggle || this.isSelectableWithoutToggle);
         if(this._itemHasSelectable)
         {
            if(_loc1_)
            {
               _loc1_ = this.itemToSelectable(this._data);
            }
         }
         if(this.accessoryTouchPointID >= 0)
         {
            if(_loc1_)
            {
               _loc1_ = this._isSelectableOnAccessoryTouch;
            }
         }
         this.tapToSelect.isEnabled = _loc1_;
         this.tapToSelect.tapToDeselect = this._isToggle;
         this.keyToSelect.isEnabled = false;
      }
      
      protected function hitTestWithAccessory(param1:Point) : Boolean
      {
         var _loc2_:DisplayObjectContainer = null;
         if(this._isQuickHitAreaEnabled || this._isSelectableOnAccessoryTouch || this.currentAccessory === null || this.currentAccessory === this.accessoryLabel || this.currentAccessory === this.accessoryLoader)
         {
            return true;
         }
         if(this.currentAccessory is DisplayObjectContainer)
         {
            _loc2_ = DisplayObjectContainer(this.currentAccessory);
            return !_loc2_.contains(this.hitTest(param1));
         }
         return this.hitTest(param1) !== this.currentAccessory;
      }
      
      protected function owner_scrollStartHandler(param1:Event) : void
      {
         if(this._delayTextureCreationOnScroll)
         {
            if(this.accessoryLoader)
            {
               this.accessoryLoader.delayTextureCreation = true;
            }
            if(this.iconLoader)
            {
               this.iconLoader.delayTextureCreation = true;
            }
         }
         if(this.accessoryTouchPointID >= 0)
         {
            this._owner.stopScrolling();
         }
      }
      
      protected function owner_scrollCompleteHandler(param1:Event) : void
      {
         if(this._delayTextureCreationOnScroll)
         {
            if(this.accessoryLoader)
            {
               this.accessoryLoader.delayTextureCreation = false;
            }
            if(this.iconLoader)
            {
               this.iconLoader.delayTextureCreation = false;
            }
         }
      }
      
      protected function itemRenderer_removedFromStageHandler(param1:Event) : void
      {
         this.accessoryTouchPointID = -1;
      }
      
      protected function accessory_touchHandler(param1:TouchEvent) : void
      {
         var _loc2_:Touch = null;
         if(!this._isEnabled)
         {
            this.accessoryTouchPointID = -1;
            return;
         }
         if(!this._stopScrollingOnAccessoryTouch || this.currentAccessory === this.accessoryLabel || this.currentAccessory === this.accessoryLoader)
         {
            return;
         }
         if(this.accessoryTouchPointID >= 0)
         {
            _loc2_ = param1.getTouch(this.currentAccessory,"ended",this.accessoryTouchPointID);
            if(!_loc2_)
            {
               return;
            }
            this.accessoryTouchPointID = -1;
            this.refreshSelectionEvents();
         }
         else
         {
            _loc2_ = param1.getTouch(this.currentAccessory,"began");
            if(!_loc2_)
            {
               return;
            }
            this.accessoryTouchPointID = _loc2_.id;
            this.refreshSelectionEvents();
         }
      }
      
      protected function accessory_resizeHandler(param1:Event) : void
      {
         if(this._ignoreAccessoryResizes)
         {
            return;
         }
         this.invalidate("size");
      }
      
      protected function loader_completeOrErrorHandler(param1:Event) : void
      {
         this.invalidate("size");
      }
   }
}

