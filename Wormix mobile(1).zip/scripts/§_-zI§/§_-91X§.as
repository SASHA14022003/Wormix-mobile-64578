package §_-zI§
{
   import §_-82l§.§_-A2Y§;
   import §_-B1y§.§_-F1P§;
   import §_-YF§.§_-N3§;
   import §_-m2s§.§_-R11§;
   import §_-o14§.*;
   import com.amanitadesign.steam.SteamConstants;
   import com.amanitadesign.steam.SteamEvent;
   import feathers.controls.ScreenNavigator;
   import feathers.controls.ScreenNavigatorItem;
   import flash.utils.ByteArray;
   import ru.pragmatix.flox.social.utils.id.GetAuthKeyEvent;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.clans.chat.NotInClanChatScreen;
   import ru.pragmatix.wormix.gui.menu.clans.chat.§_-D2t§;
   import ru.pragmatix.wormix.messages.clans.structures.ClanAuditActionTO;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.utils.StringUtil;
   import ru.pragmatix.wormix.utils.§_-g20§;
   
   public class §_-91X§
   {
      
      §§push(§§findproperty(§_-K2C§));
      
      public static const §_-K2C§:Vector.<int> = new <int>[CREATE,§_-O2N§,§_-9w§,§_-m1N§,§_-E1c§,§_-QI§,§_-S2v§,§_-aq§,§_-q1B§,§_-hP§,§_-Y2n§,§_-I2s§,§_-DC§,§_-j5§,§_-Wc§,§_-41W§,§_-Kg§];
      
      private static const CREATE:uint = 1;
      
      private static const §_-O2N§:uint = 2;
      
      private static const §_-9w§:uint = 3;
      
      private static const §_-m1N§:uint = 4;
      
      private static const §_-E1c§:uint = 5;
      
      private static const §_-QI§:uint = 6;
      
      private static const §_-S2v§:uint = 7;
      
      private static const §_-aq§:uint = 8;
      
      private static const §_-q1B§:uint = 9;
      
      private static const §_-hP§:uint = 10;
      
      private static const §_-Y2n§:uint = 11;
      
      private static const §_-I2s§:uint = 12;
      
      private static const §_-DC§:uint = 14;
      
      private static const §_-j5§:uint = 15;
      
      private static const §_-Wc§:uint = 16;
      
      private static const §_-41W§:uint = 17;
      
      private static const §_-Kg§:uint = 18;
      
      public function §_-91X§()
      {
         super();
      }
      
      public static function §_-K3t§(param1:ClanAuditActionTO) : String
      {
         var publisher:String = null;
         var medals:String = null;
         var action:ClanAuditActionTO = param1;
         var addPublisher:Function = function(param1:String):String
         {
            return param1.slice(0,param1.length - 1) + " (" + publisher + ").";
         };
         publisher = getName(action.publisherId);
         var member:String = getName(action.memberId);
         var text:String = "";
         var rubies:String = "";
         var _loc3_:int = action.action;
         switch(_loc3_)
         {
            case CREATE:
               §§push(0);
               break;
            case §_-O2N§:
               §§push(1);
               break;
            case §_-9w§:
               §§push(2);
               break;
            case §_-m1N§:
               §§push(3);
               break;
            case §_-E1c§:
               §§push(4);
               break;
            case §_-QI§:
               §§push(5);
               break;
            case §_-S2v§:
               §§push(6);
               break;
            case §_-aq§:
               §§push(7);
               break;
            case §_-q1B§:
               §§push(8);
               break;
            case §_-hP§:
               §§push(9);
               break;
            case §_-Y2n§:
               §§push(10);
               break;
            case §_-I2s§:
               §§push(11);
               break;
            case §_-DC§:
               §§push(12);
               break;
            case §_-j5§:
               §§push(13);
               break;
            case §_-Wc§:
               §§push(14);
               break;
            default:
               switch(_loc3_)
               {
                  case §_-41W§:
                     §§push(15);
                     break;
                  case §_-Kg§:
                     §§push(16);
                     break;
                  default:
                     §§push(17);
               }
         }
         switch(§§pop())
         {
            case 0:
               text = §_-F1P§.format(§_-s2a§.§_-K3t§(§_-s2a§.CLAN_CREATED),{"name":publisher});
               break;
            case 1:
               text = §_-F1P§.format(§_-s2a§.§_-K3t§(§_-s2a§.CLAN_DELETED),{"name":publisher});
               break;
            case 2:
               text = §_-F1P§.format(§_-s2a§.§_-K3t§(§_-s2a§.MEMBER_JOINED_CLAN),{"name":publisher});
               break;
            case 3:
               text = §_-F1P§.format(§_-s2a§.§_-K3t§(§_-s2a§.MEMBER_WAS_EXPELLED),{
                  "name":member,
                  "subject":publisher
               });
               break;
            case 4:
               text = §_-F1P§.format(§_-s2a§.§_-K3t§(§_-s2a§.MEMBER_LEFT_CLAN),{"name":publisher});
               break;
            case 5:
               text = addPublisher(action.param == §_-X1q§.§_-O2V§ ? §_-F1P§.format(§_-s2a§.§_-K3t§(§_-s2a§.LEADER_SWITCHED_WITH_OFFICER),{"name":member}) : §_-F1P§.format(§_-s2a§.§_-K3t§(§_-s2a§.LEADER_PROMOTE_RANK_MEMBER),{
                  "name":member,
                  "rank":§_-s2a§.§_-K3t§(§_-s2a§.RANK_OFFICER_ACCUSITIVE)
               }));
               break;
            case 6:
               text = addPublisher(§_-F1P§.format(§_-s2a§.§_-K3t§(§_-s2a§.LEADER_LOWER_RANK_MEMBER),{
                  "name":member,
                  "rank":§_-s2a§.§_-K3t§(§_-s2a§.RANK_SOLDIER_ACCUSITIVE)
               }));
               break;
            case 7:
               text = §_-F1P§.format(§_-s2a§.§_-K3t§(§_-s2a§.CLAN_HAS_NEW_CAPACITY),{"name":publisher});
               break;
            case 8:
               text = §_-F1P§.format(§_-s2a§.§_-K3t§(§_-s2a§.CLAN_HAS_NEW_NAME),{"name":publisher});
               break;
            case 9:
               text = §_-F1P§.format(§_-s2a§.§_-K3t§(§_-s2a§.CLAN_HAS_NEW_DESCRIPTION),{"name":publisher});
               break;
            case 10:
               text = addPublisher(§_-F1P§.format(§_-s2a§.§_-K3t§(§_-s2a§.CLAN_HAS_NEW_EMBLEM),{"name":publisher}));
               break;
            case 11:
               text = addPublisher(§_-F1P§.format(action.param == 0 ? §_-s2a§.§_-K3t§(§_-s2a§.CLAN_EXIT_HAS_OPENED) : §_-s2a§.§_-K3t§(§_-s2a§.CLAN_EXIT_HAS_CLOSED)));
               break;
            case 12:
               rubies = §_-X1j§.§_-82T§.getPluralForm(int(action.param),§_-s2a§.RUBY_PLURALS);
               text = §_-F1P§.format(§_-s2a§.§_-K3t§(§_-s2a§.DONATE_CLAN_MEMBER),{
                  "name":publisher,
                  "count":action.param,
                  "rubies":rubies
               });
               break;
            case 13:
               rubies = §_-X1j§.§_-82T§.getPluralForm(int(action.param),§_-s2a§.RUBY_PLURALS);
               text = addPublisher(§_-F1P§.format(§_-s2a§.§_-K3t§(§_-s2a§.CHANGE_MEDAL_PRICE_CLAN),{
                  "count":action.param,
                  "rubies":rubies
               }));
               break;
            case 14:
               medals = §_-X1j§.§_-82T§.getPluralForm(int(action.param),§_-s2a§.MEDAL_PLURALS);
               text = §_-F1P§.format(§_-s2a§.§_-K3t§(§_-s2a§.EXCHANGE_MEDALS_CLAN_MEMBER),{
                  "name":publisher,
                  "count":action.param,
                  "medals":medals
               });
               break;
            case 15:
               text = §_-F1P§.format(action.param == 0 ? §_-s2a§.§_-K3t§(§_-s2a§.OFFICER_WAS_EXPEL_PERMISSION_OFF) : §_-s2a§.§_-K3t§(§_-s2a§.OFFICER_WAS_EXPEL_PERMISSION_ON),{
                  "name":member,
                  "subject":publisher
               });
               break;
            case 16:
               text = §_-F1P§.format(action.param == 0 ? §_-s2a§.§_-K3t§(§_-s2a§.MEMBER_WAS_UNMUTED) : §_-s2a§.§_-K3t§(§_-s2a§.MEMBER_WAS_MUTED),{
                  "name":member,
                  "subject":publisher
               });
         }
         return text;
      }
      
      private static function getName(param1:int) : String
      {
         var _loc2_:UserProfile = null;
         if(param1 == 0)
         {
            return "";
         }
         _loc2_ = §_-N3§.§_-g1D§(param1);
         return §_-s2a§.§_-K3t§(§_-s2a§.CLAN_CAPTION_PLAYER) + " " + (_loc2_ ? _loc2_.getCharName() : StringUtil.§_-43t§);
      }
   }
}

