package §_-zI§
{
   import §_-C3f§.§_-yG§;
   import §_-CF§.§_-E19§;
   import §_-CF§.§_-x2t§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   
   public class §_-92Q§
   {
      
      §§push(§§findproperty(§_-61k§));
      var _temp_2:* = new <§_-92Q§>[new §_-92Q§(null,10,2),new §_-92Q§(new §_-yG§(§_-E19§.§_-51D§,new §_-x2t§(0,50),§_-s2a§.EXPAND_CLAN_CONFIRMATION),15,3),new §_-92Q§(new §_-yG§(§_-E19§.§_-51D§,new §_-x2t§(0,100),§_-s2a§.EXPAND_CLAN_CONFIRMATION),20,4)];
      var _temp_3:* = new <§_-92Q§>[new §_-92Q§(null,10,2),new §_-92Q§(new §_-yG§(§_-E19§.§_-51D§,new §_-x2t§(0,50),§_-s2a§.EXPAND_CLAN_CONFIRMATION),15,3),new §_-92Q§(new §_-yG§(§_-E19§.§_-51D§,new §_-x2t§(0,100),§_-s2a§.EXPAND_CLAN_CONFIRMATION),20,4)];
      
      private static const §_-61k§:Vector.<§_-92Q§> = new <§_-92Q§>[new §_-92Q§(null,10,2),new §_-92Q§(new §_-yG§(§_-E19§.§_-51D§,new §_-x2t§(0,50),§_-s2a§.EXPAND_CLAN_CONFIRMATION),15,3),new §_-92Q§(new §_-yG§(§_-E19§.§_-51D§,new §_-x2t§(0,100),§_-s2a§.EXPAND_CLAN_CONFIRMATION),20,4)];
      
      private static const §_-03X§:int = §_-61k§.length;
      
      public var priceInfo:§_-yG§;
      
      public var capacity:int;
      
      public var §_-52X§:int;
      
      public function §_-92Q§(param1:§_-yG§, param2:int, param3:int)
      {
         super();
         this.priceInfo = param1;
         this.capacity = param2;
         this.§_-52X§ = param3;
      }
      
      public static function getLevel(param1:int) : §_-92Q§
      {
         var _loc2_:int = param1 - 1;
         if(_loc2_ < §_-61k§.length)
         {
            return §_-61k§[_loc2_];
         }
         return null;
      }
      
      public static function §_-KT§(param1:int) : §_-92Q§
      {
         if(param1 > §_-03X§)
         {
            return null;
         }
         var _loc2_:int = param1 - 1;
         if(_loc2_ < §_-61k§.length)
         {
            return §_-61k§[_loc2_];
         }
         return null;
      }
   }
}

