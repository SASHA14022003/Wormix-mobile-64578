package §_-zI§
{
   import §_-62§.§_-G1p§;
   import §_-62§.§_-W1r§;
   import §_-A2U§.§_-A23§;
   import §_-j1w§.§_-L1x§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.ClanMessages;
   import ru.pragmatix.wormix.messages.clans.structures.ClanChatMessageTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanMemberTO;
   import ru.pragmatix.wormix.utils.StringUtil;
   import ru.pragmatix.wormix.utils.§_-6A§;
   
   public class §_-U1A§
   {
      
      public function §_-U1A§()
      {
         super();
      }
      
      public static function §_-g1N§(param1:ClanChatMessageTO) : String
      {
         var _loc9_:ClanMemberTO = null;
         var _loc10_:String = null;
         var _loc11_:int = 0;
         var _loc12_:§_-W1r§ = null;
         var _loc13_:String = null;
         var _loc2_:String = §_-wx§(param1.publisherName,§_-8D§.§_-ss§);
         var _loc3_:String = §_-wx§(param1.memberName,§_-8D§.§_-ss§);
         var _loc4_:RegExp = /</g;
         var _loc5_:RegExp = />/g;
         _loc2_ = _loc2_.replace(_loc4_,"&lt;");
         _loc2_ = _loc2_.replace(_loc5_,"&gt;");
         _loc3_ = _loc3_.replace(_loc4_,"&lt;");
         _loc3_ = _loc3_.replace(_loc5_,"&gt;");
         var _loc6_:String = "";
         var _loc7_:String = "";
         var _loc8_:String = "";
         var _loc14_:int = param1.actionCode;
         switch(_loc14_)
         {
            case ClanMessages.LOGIN_JOIN_REQUEST:
               §§push(0);
               break;
            case ClanMessages.QUIT_CLAN_REQUEST:
               §§push(1);
               break;
            case ClanMessages.RENAME_CLAN_REQUEST:
               §§push(2);
               break;
            case ClanMessages.CHANGE_CLAN_DESCRIPTION_REQUEST:
               §§push(3);
               break;
            case ClanMessages.INCREASE_LEVEL_CLAN_REQUEST:
               §§push(4);
               break;
            case ClanMessages.CHANGE_CLAN_EMBLEM_REQUEST:
               §§push(5);
               break;
            case ClanMessages.PROMOTE_IN_RANK_REQUEST:
               §§push(6);
               break;
            case ClanMessages.LOWER_IN_RANK_REQUEST:
               §§push(7);
               break;
            case ClanMessages.EXPEL_FROM_CLAN_REQUEST:
               §§push(8);
               break;
            case ClanMessages.CHANGE_CLAN_CLOSE_EXIT_REQUEST:
               §§push(9);
               break;
            case ClanMessages.DONATE_REQUEST:
               §§push(10);
               break;
            case ClanMessages.CHANGE_CLAN_MEDAL_PRICE_REQUEST:
               §§push(11);
               break;
            case ClanMessages.CASH_MEDALS_REQUEST:
               §§push(12);
               break;
            case ClanMessages.GLADIATOR_FINISH_EVENT:
               §§push(13);
               break;
            case ClanMessages.SET_EXPEL_PERMIT_REQUEST:
               §§push(14);
               break;
            default:
               switch(_loc14_)
               {
                  case ClanMessages.SET_MUTE_MODE_REQUEST:
                     §§push(15);
                     break;
                  case ClanMessages.CRAFT_LEGENDARY_EVENT:
                     §§push(16);
                     break;
                  default:
                     §§push(17);
               }
         }
         switch(§§pop())
         {
            case 0:
               _loc6_ = StringUtil.format(§_-s2a§.MEMBER_JOINED_CLAN,{"name":_loc2_});
               break;
            case 1:
               _loc6_ = StringUtil.format(§_-s2a§.MEMBER_LEFT_CLAN,{"name":_loc2_});
               break;
            case 2:
               _loc6_ = StringUtil.format(§_-s2a§.CLAN_HAS_NEW_NAME,{"name":_loc2_});
               break;
            case 3:
               _loc6_ = StringUtil.format(§_-s2a§.CLAN_HAS_NEW_DESCRIPTION,{"name":_loc2_});
               break;
            case 4:
               _loc6_ = StringUtil.format(§_-s2a§.CLAN_HAS_NEW_CAPACITY,{"name":_loc2_});
               break;
            case 5:
               _loc6_ = §_-s2a§.§_-K3t§(§_-s2a§.CLAN_HAS_NEW_EMBLEM);
               break;
            case 6:
               _loc9_ = §_-6A§.§_-k1a§(param1.memberProfileId);
               _loc6_ = (Boolean(_loc9_)) && _loc9_.rank == §_-X1q§.§_-O2V§ ? StringUtil.format(§_-s2a§.LEADER_SWITCHED_WITH_OFFICER,{"name":_loc3_}) : StringUtil.format(§_-s2a§.LEADER_PROMOTE_RANK_MEMBER,{
                  "name":_loc3_,
                  "rank":§_-s2a§.§_-K3t§(§_-s2a§.RANK_OFFICER_ACCUSITIVE)
               });
               break;
            case 7:
               _loc6_ = StringUtil.format(§_-s2a§.LEADER_LOWER_RANK_MEMBER,{
                  "name":_loc3_,
                  "rank":§_-s2a§.§_-K3t§(§_-s2a§.RANK_SOLDIER_ACCUSITIVE)
               });
               break;
            case 8:
               _loc6_ = StringUtil.format(§_-s2a§.MEMBER_WAS_EXPELLED,{
                  "name":_loc3_,
                  "subject":_loc2_
               });
               break;
            case 9:
               _loc6_ = §_-A23§.userClan.isExitClosed ? §_-s2a§.§_-K3t§(§_-s2a§.CLAN_EXIT_HAS_CLOSED) : §_-s2a§.§_-K3t§(§_-s2a§.CLAN_EXIT_HAS_OPENED);
               break;
            case 10:
               _loc8_ = §_-X1j§.§_-82T§.getPluralForm(int(param1.params),§_-s2a§.RUBY_PLURALS);
               _loc6_ = StringUtil.format(§_-s2a§.DONATE_CLAN_MEMBER,{
                  "name":_loc2_,
                  "count":param1.params,
                  "rubies":_loc8_
               });
               break;
            case 11:
               _loc8_ = §_-X1j§.§_-82T§.getPluralForm(int(param1.params),§_-s2a§.RUBY_PLURALS);
               _loc6_ = StringUtil.format(§_-s2a§.CHANGE_MEDAL_PRICE_CLAN,{
                  "count":param1.params,
                  "rubies":_loc8_
               });
               break;
            case 12:
               _loc10_ = §_-X1j§.§_-82T§.getPluralForm(int(param1.params),§_-s2a§.MEDAL_PLURALS);
               _loc6_ = StringUtil.format(§_-s2a§.EXCHANGE_MEDALS_CLAN_MEMBER,{
                  "name":_loc2_,
                  "count":param1.params,
                  "medals":_loc10_
               });
               break;
            case 13:
               _loc6_ = StringUtil.format(§_-s2a§.MEMBER_GLADIATOR_COMPLETE_MESSAGE,{
                  "name":_loc2_,
                  "count":param1.params
               });
               break;
            case 14:
               _loc7_ = param1.params == "true" ? §_-s2a§.OFFICER_WAS_EXPEL_PERMISSION_ON : §_-s2a§.OFFICER_WAS_EXPEL_PERMISSION_OFF;
               _loc6_ = StringUtil.§_-CN§(StringUtil.format(_loc7_,{
                  "name":_loc3_,
                  "subject":_loc2_
               }),§_-8D§.§_-Fi§);
               break;
            case 15:
               _loc7_ = param1.params == "true" ? §_-s2a§.MEMBER_WAS_MUTED : §_-s2a§.MEMBER_WAS_UNMUTED;
               _loc6_ = StringUtil.§_-CN§(StringUtil.format(_loc7_,{
                  "name":_loc3_,
                  "subject":_loc2_
               }),§_-8D§.§_-Fi§);
               break;
            case 16:
               _loc11_ = int(int(param1.params));
               _loc12_ = §_-G1p§.§_-d0§(_loc11_,§_-L1x§.§_-AU§.§_-wz§());
               _loc13_ = _loc12_.getName();
               _loc6_ = StringUtil.format(§_-s2a§.MEMBER_CRAFT_LEGENDARY_MESSAGE,{
                  "name":_loc2_,
                  "item":_loc13_
               });
               break;
            default:
               _loc6_ += §_-s2a§.§_-K3t§(§_-s2a§.§_-hC§) + " actionCode=" + param1.actionCode + " params=" + param1.params;
         }
         return _loc6_;
      }
      
      public static function §_-FA§(param1:ClanChatMessageTO) : String
      {
         var _loc3_:String = null;
         var _loc7_:String = null;
         var _loc8_:String = null;
         var _loc9_:int = 0;
         var _loc10_:§_-W1r§ = null;
         var _loc11_:String = null;
         var _loc2_:String = §_-wx§(§_-6A§.§_-b2w§(param1.publisherProfileId,30));
         _loc3_ = §_-wx§(§_-6A§.§_-b2w§(param1.memberProfileId,30));
         var _loc4_:String = "";
         var _loc5_:String = "";
         var _loc6_:String = "";
         var _loc12_:int = param1.actionCode;
         switch(_loc12_)
         {
            case ClanMessages.POST_TO_CHAT_REQUEST:
               §§push(0);
               break;
            case ClanMessages.LOGIN_JOIN_REQUEST:
               §§push(1);
               break;
            case ClanMessages.QUIT_CLAN_REQUEST:
               §§push(2);
               break;
            case ClanMessages.RENAME_CLAN_REQUEST:
               §§push(3);
               break;
            case ClanMessages.CHANGE_CLAN_DESCRIPTION_REQUEST:
               §§push(4);
               break;
            case ClanMessages.INCREASE_LEVEL_CLAN_REQUEST:
               §§push(5);
               break;
            case ClanMessages.CHANGE_CLAN_EMBLEM_REQUEST:
               §§push(6);
               break;
            case ClanMessages.PROMOTE_IN_RANK_REQUEST:
               §§push(7);
               break;
            case ClanMessages.LOWER_IN_RANK_REQUEST:
               §§push(8);
               break;
            case ClanMessages.EXPEL_FROM_CLAN_REQUEST:
               §§push(9);
               break;
            case ClanMessages.CHANGE_CLAN_CLOSE_EXIT_REQUEST:
               §§push(10);
               break;
            case ClanMessages.DONATE_REQUEST:
               §§push(11);
               break;
            case ClanMessages.CHANGE_CLAN_MEDAL_PRICE_REQUEST:
               §§push(12);
               break;
            case ClanMessages.CASH_MEDALS_REQUEST:
               §§push(13);
               break;
            case ClanMessages.GLADIATOR_FINISH_EVENT:
               §§push(14);
               break;
            case ClanMessages.SET_EXPEL_PERMIT_REQUEST:
               §§push(15);
               break;
            default:
               switch(_loc12_)
               {
                  case ClanMessages.SET_MUTE_MODE_REQUEST:
                     §§push(16);
                     break;
                  case ClanMessages.CRAFT_LEGENDARY_EVENT:
                     §§push(17);
                     break;
                  default:
                     §§push(18);
               }
         }
         switch(§§pop())
         {
            case 0:
               _loc4_ = StringUtil.§_-CN§(_loc2_ + ": ","#696969") + StringUtil.§_-CN§(param1.params,"#9A9A9A");
               break;
            case 1:
               _loc4_ = StringUtil.§_-CN§(StringUtil.format(§_-s2a§.MEMBER_JOINED_CLAN,{"name":_loc2_}),§_-8D§.§_-Fi§);
               break;
            case 2:
               _loc4_ = StringUtil.§_-CN§(StringUtil.format(§_-s2a§.MEMBER_LEFT_CLAN,{"name":_loc2_}),§_-8D§.§_-Fi§);
               break;
            case 3:
               _loc4_ = StringUtil.§_-CN§(StringUtil.format(§_-s2a§.CLAN_HAS_NEW_NAME,{"newName":§_-A23§.userClan.name}),§_-8D§.§_-Fi§);
               break;
            case 4:
               _loc4_ = StringUtil.§_-CN§(§_-s2a§.CLAN_HAS_NEW_DESCRIPTION,§_-8D§.§_-Fi§);
               break;
            case 5:
               _loc4_ = StringUtil.§_-CN§(StringUtil.format(§_-s2a§.CLAN_HAS_NEW_CAPACITY,{"name":_loc2_}),§_-8D§.§_-Fi§);
               break;
            case 6:
               _loc4_ = StringUtil.§_-CN§(§_-s2a§.CLAN_HAS_NEW_EMBLEM,§_-8D§.§_-Fi§);
               break;
            case 7:
               _loc7_ = §_-6A§.§_-k1a§(param1.memberProfileId).rank == §_-X1q§.§_-O2V§ ? StringUtil.format(§_-s2a§.LEADER_SWITCHED_WITH_OFFICER,{"name":_loc3_}) : StringUtil.format(§_-s2a§.LEADER_PROMOTE_RANK_MEMBER,{
                  "name":_loc3_,
                  "rank":§_-s2a§.§_-K3t§(§_-s2a§.RANK_OFFICER_ACCUSITIVE)
               });
               _loc4_ = StringUtil.§_-CN§(_loc7_,§_-8D§.§_-Fi§);
               break;
            case 8:
               _loc4_ = StringUtil.§_-CN§(StringUtil.format(§_-s2a§.LEADER_LOWER_RANK_MEMBER,{
                  "name":_loc3_,
                  "rank":§_-s2a§.§_-K3t§(§_-s2a§.RANK_SOLDIER_ACCUSITIVE)
               }),§_-8D§.§_-Fi§);
               break;
            case 9:
               _loc4_ = StringUtil.§_-CN§(StringUtil.format(§_-s2a§.MEMBER_WAS_EXPELLED,{
                  "name":_loc3_,
                  "subject":_loc2_
               }),§_-8D§.§_-Fi§);
               break;
            case 10:
               break;
            case 11:
               _loc6_ = §_-X1j§.§_-82T§.getPluralForm(int(param1.params),§_-s2a§.RUBY_PLURALS);
               _loc4_ = StringUtil.format(§_-s2a§.DONATE_CLAN_MEMBER,{
                  "name":_loc2_,
                  "count":param1.params,
                  "rubies":_loc6_
               });
               break;
            case 12:
               _loc6_ = §_-X1j§.§_-82T§.getPluralForm(int(param1.params),§_-s2a§.RUBY_PLURALS);
               _loc4_ = StringUtil.format(§_-s2a§.CHANGE_MEDAL_PRICE_CLAN,{
                  "count":param1.params,
                  "rubies":_loc6_
               });
               break;
            case 13:
               _loc8_ = §_-X1j§.§_-82T§.getPluralForm(int(param1.params),§_-s2a§.MEDAL_PLURALS);
               _loc4_ = StringUtil.format(§_-s2a§.EXCHANGE_MEDALS_CLAN_MEMBER,{
                  "name":_loc2_,
                  "count":param1.params,
                  "medals":_loc8_
               });
               break;
            case 14:
               _loc4_ = StringUtil.format(§_-s2a§.MEMBER_GLADIATOR_COMPLETE_MESSAGE,{
                  "name":_loc2_,
                  "count":param1.params
               });
               break;
            case 15:
               _loc5_ = param1.params == "true" ? §_-s2a§.OFFICER_WAS_EXPEL_PERMISSION_ON : §_-s2a§.OFFICER_WAS_EXPEL_PERMISSION_OFF;
               _loc4_ = StringUtil.§_-CN§(StringUtil.format(_loc5_,{
                  "name":_loc3_,
                  "subject":_loc2_
               }),§_-8D§.§_-Fi§);
               break;
            case 16:
               _loc5_ = param1.params == "true" ? §_-s2a§.MEMBER_WAS_MUTED : §_-s2a§.MEMBER_WAS_UNMUTED;
               _loc4_ = StringUtil.§_-CN§(StringUtil.format(_loc5_,{
                  "name":_loc3_,
                  "subject":_loc2_
               }),§_-8D§.§_-Fi§);
               break;
            case 17:
               _loc9_ = int(int(param1.params));
               _loc10_ = §_-G1p§.§_-d0§(_loc9_,§_-L1x§.§_-AU§.§_-wz§());
               _loc11_ = _loc10_.getName();
               _loc4_ = StringUtil.format(§_-s2a§.MEMBER_CRAFT_LEGENDARY_MESSAGE,{
                  "name":_loc2_,
                  "item":_loc11_
               });
               break;
            default:
               _loc4_ += StringUtil.§_-CN§(§_-s2a§.§_-hC§ + " actionCode=" + param1.actionCode + " params=" + param1.params,§_-8D§.§_-Fi§);
         }
         return _loc4_;
      }
      
      public static function §_-wx§(param1:String, param2:int = -1) : String
      {
         var _loc3_:String = null;
         if(param2 == -1)
         {
            param2 = int(§_-8D§.§_-1C§);
         }
         if(!param1)
         {
            return StringUtil.§_-43t§;
         }
         if(param1.length < param2)
         {
            return param1;
         }
         _loc3_ = param1.split(" ")[0];
         return _loc3_.length < §_-8D§.§_-1C§ ? _loc3_ : _loc3_.substr(0,§_-8D§.§_-1C§ - 1) + "...";
      }
   }
}

