package §_-zI§
{
   import ru.pragmatix.wormix.model.user.UserProfile;
   
   public interface §_-sI§
   {
      
      function §_-Qn§() : String;
      
      function get clanNameLengthMin() : int;
      
      function get clanNameLengthMax() : int;
      
      function §_-g1F§(param1:String) : Boolean;
      
      function get clanDescriptionLengthMax() : int;
      
      function get clanEmblemFiguresCount() : int;
      
      function get clanEmblemBacksCount() : int;
      
      function get medalRatingChangeValue() : int;
      
      function get medalPriceMin() : int;
      
      function get medalPriceMax() : int;
      
      function get medalDetermination() : int;
      
      function get clanNewsMessageLengthMax() : int;
      
      function get minimalRatingForTop() : int;
      
      function get topPlaces() : int;
      
      function get promoteToLeaderLevel() : int;
      
      function get promoteToLeaderRating() : int;
      
      function get createClanMinLevel() : int;
      
      function get createClanMinRating() : int;
      
      function §_-83S§(param1:UserProfile) : Boolean;
   }
}

