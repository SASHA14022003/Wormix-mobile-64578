package §_-zI§
{
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import starling.animation.Tween;
   import starling.core.Starling;
   
   public class §_-F3q§ implements §_-sI§
   {
      
      private static var instance:§_-sI§;
      
      private static const §_-11R§:uint = 3;
      
      private static const §_-11W§:uint = 18;
      
      private static const §_-31K§:uint = 250;
      
      private static const §_-E2k§:uint = 250;
      
      private static const §_-p1H§:uint = 30;
      
      private static const §_-rZ§:uint = 12;
      
      private static const §_-H3l§:uint = 1000;
      
      private static const §_-R14§:uint = 1;
      
      private static const §_-k15§:uint = 3;
      
      private static const §_-G2p§:uint = 20;
      
      private static const §_-82S§:uint = 7;
      
      private static const §_-N2P§:uint = 200;
      
      public static const §_-I1S§:uint = 7;
      
      public static const §_-O1O§:uint = 200;
      
      private static const §_-VP§:uint = 5000;
      
      private static const §_-01E§:uint = 50;
      
      public function §_-F3q§()
      {
         super();
      }
      
      public static function getInstance() : §_-sI§
      {
         if(instance == null)
         {
            instance = new §_-F3q§();
         }
         return instance;
      }
      
      public function §_-Qn§() : String
      {
         switch(§_-X1j§.socialController.getType())
         {
            case SocialType.STEAM:
               return null;
            default:
               return null;
         }
      }
      
      public function get clanNameLengthMin() : int
      {
         return §_-11R§;
      }
      
      public function get clanNameLengthMax() : int
      {
         return §_-11W§;
      }
      
      public function §_-g1F§(param1:String) : Boolean
      {
         var _loc2_:int = param1 ? int(param1.length) : 0;
         return _loc2_ >= §_-11R§ && _loc2_ <= §_-11W§;
      }
      
      public function get clanDescriptionLengthMax() : int
      {
         return §_-31K§;
      }
      
      public function get clanEmblemFiguresCount() : int
      {
         return §_-p1H§;
      }
      
      public function get clanEmblemBacksCount() : int
      {
         return §_-rZ§;
      }
      
      public function get medalRatingChangeValue() : int
      {
         return §_-H3l§;
      }
      
      public function get medalPriceMin() : int
      {
         return §_-R14§;
      }
      
      public function get medalPriceMax() : int
      {
         return §_-k15§;
      }
      
      public function get medalDetermination() : int
      {
         return §_-G2p§;
      }
      
      public function get promoteToLeaderLevel() : int
      {
         return §_-82S§;
      }
      
      public function get promoteToLeaderRating() : int
      {
         return §_-N2P§;
      }
      
      public function get clanNewsMessageLengthMax() : int
      {
         return §_-E2k§;
      }
      
      public function get createClanMinLevel() : int
      {
         return §_-I1S§;
      }
      
      public function get createClanMinRating() : int
      {
         return §_-O1O§;
      }
      
      public function §_-83S§(param1:UserProfile) : Boolean
      {
         if(param1)
         {
            return param1.getLevel() >= §_-I1S§ && param1.§_-Zp§() >= §_-O1O§;
         }
         return false;
      }
      
      public function get minimalRatingForTop() : int
      {
         return §_-VP§;
      }
      
      public function get topPlaces() : int
      {
         return §_-01E§;
      }
   }
}

