package §_-zI§
{
   import §_-A1K§.§_-TA§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   
   public class §_-A1s§
   {
      
      §§push(§§findproperty(§_-Jv§));
      var _temp_4:* = new <§_-A1s§>[new §_-A1s§(1,200,6,6),new §_-A1s§(2,210,8,8,5),new §_-A1s§(3,220,8,8,5,6),new §_-A1s§(4,230,8,8,5,6,5),new §_-A1s§(5,240,10,10,5,6,5)];
      
      private static const §_-Jv§:Vector.<§_-A1s§> = new <§_-A1s§>[new §_-A1s§(1,200,6,6),new §_-A1s§(2,210,8,8,5),new §_-A1s§(3,220,8,8,5,6),new §_-A1s§(4,230,8,8,5,6,5),new §_-A1s§(5,240,10,10,5,6,5)];
      
      public var id:§_-TA§;
      
      public var §_-91Q§:§_-TA§;
      
      public var §_-d1E§:§_-TA§;
      
      public var §_-T1O§:§_-TA§;
      
      public var §_-22w§:§_-TA§;
      
      public var speedBonus:§_-TA§;
      
      public var §_-61m§:§_-TA§;
      
      public function §_-A1s§(param1:uint, param2:uint, param3:int, param4:int, param5:int = 0, param6:int = 0, param7:int = 0)
      {
         super();
         this.id = new §_-TA§(param1);
         this.§_-91Q§ = new §_-TA§(param2);
         this.§_-d1E§ = new §_-TA§(param3);
         this.§_-T1O§ = new §_-TA§(param4);
         this.§_-22w§ = new §_-TA§(param5);
         this.speedBonus = new §_-TA§(param6);
         this.§_-61m§ = new §_-TA§(param7);
      }
      
      public static function valueOf(param1:uint) : §_-A1s§
      {
         return param1 > 0 && param1 <= §_-Jv§.length ? §_-Jv§[param1 - 1] : null;
      }
      
      public function get name() : String
      {
         return §_-s2a§.§_-K3t§("BANNER_NAME_" + this.id.value.toString());
      }
      
      public function get description() : String
      {
         return §_-s2a§.§_-K3t§("BANNER_DESCRIPTION_" + this.id.value.toString());
      }
      
      public function §_-b24§() : Boolean
      {
         return this.speedBonus.value > 0 || this.§_-61m§.value > 0;
      }
   }
}

