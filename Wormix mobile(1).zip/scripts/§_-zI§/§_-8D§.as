package §_-zI§
{
   import §_-C3f§.§_-yG§;
   import §_-CF§.§_-E19§;
   import §_-CF§.§_-x2t§;
   import flash.text.TextField;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.utils.StringUtil;
   
   public class §_-8D§
   {
      
      public static const §_-2l§:uint = 5;
      
      public static const §_-v3§:uint = 4;
      
      public static const §_-93T§:Array = ["ClanShaft1","ClanShaft2","ClanShaft3","ClanShaft4","ClanShaft5"];
      
      public static const §_-21Q§:String = "ClanFlagColor";
      
      public static const §_-OM§:Array = [{
         "max":50,
         "min":11,
         "tier":1
      },{
         "max":10,
         "min":4,
         "tier":2
      },{
         "place":3,
         "tier":3
      },{
         "place":2,
         "tier":4
      },{
         "place":1,
         "tier":5
      }];
      
      public static const §_-L1L§:§_-yG§ = new §_-yG§(§_-E19§.§_-i2d§,new §_-x2t§(3000),§_-s2a§.CREATE_CLAN_CONFIRMATION);
      
      public static const §_-k2N§:§_-yG§ = new §_-yG§(§_-E19§.§_-51D§,new §_-x2t§(0,5),§_-s2a§.CHANGE_CLAN_NAME_CONFIRMATION);
      
      public static const §_-hP§:§_-yG§ = new §_-yG§(§_-E19§.§_-51D§,new §_-x2t§(0,5),§_-s2a§.CHANGE_CLAN_DESCRIPTION_CONFIRMATION);
      
      public static const §_-K2G§:§_-yG§ = new §_-yG§(§_-E19§.§_-51D§,new §_-x2t§(0,5),§_-s2a§.CHANGE_CLAN_EMBLEM_CONFIRMATION);
      
      private static const §_-83R§:§_-yG§ = new §_-yG§(§_-E19§.§_-51D§,new §_-x2t§(0,1),"",true);
      
      public static const §_-x1F§:int = 1000;
      
      public static const §_-n2I§:uint = 30;
      
      public static const §_-Z1k§:uint = 4;
      
      public static const §_-R14§:uint = 1;
      
      public static const §_-k15§:uint = 3;
      
      public static const §_-H3l§:uint = 1000;
      
      public static const §_-G2p§:uint = 20;
      
      public static const §_-32O§:uint = 3;
      
      public static const §_-ss§:uint = 16;
      
      public static const §_-D36§:uint = 250;
      
      public static const §_-F3V§:uint = 50;
      
      public static const §_-i20§:uint = 100;
      
      public static const §_-K1k§:String = "0-9";
      
      public static const §_-W2N§:RegExp = new RegExp(/[^0-9]/);
      
      public static const §_-Fi§:String = "#CCCC00";
      
      public static const §_-4G§:String = "#64AEFF";
      
      public static const §_-1C§:uint = 36;
      
      public function §_-8D§()
      {
         super();
      }
      
      public static function §_-G2e§(param1:int) : §_-yG§
      {
         §_-83R§.price.realPrice = param1;
         §_-83R§.message = StringUtil.format(§_-s2a§.DONATE_CLAN_CONFIRMATION,{
            "count":param1,
            "rubies":§_-X1j§.§_-82T§.getPluralForm(param1,§_-s2a§.RUBY_PLURALS)
         });
         return §_-83R§;
      }
      
      public static function §_-72N§() : String
      {
         var _loc1_:SocialType = §_-X1j§.socialController.getType();
         switch(0)
         {
         }
         return "A-Z a-z А-Я ё Ё а-я 0-9";
      }
      
      public static function §_-Z2N§(param1:TextField, param2:int, param3:Boolean = false) : void
      {
         switch(param2)
         {
            case §_-X1q§.§_-O2V§:
               param1.textColor = param3 ? 9568040 : 5151488;
               break;
            case §_-X1q§.OFFICER:
               param1.textColor = param3 ? 13235094 : 7651350;
         }
      }
   }
}

