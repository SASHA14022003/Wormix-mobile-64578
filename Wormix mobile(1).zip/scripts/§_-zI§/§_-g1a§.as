package §_-zI§
{
   import feathers.controls.ImageLoader;
   import starling.display.DisplayObject;
   
   public class §_-g1a§
   {
      
      public static const §_-8Z§:uint = 30;
      
      §§push(§§findproperty(§_-W1Q§));
      var _temp_11:* = new <uint>[15198183,16746540,16769887,14811136,12319316,7471104,6430976,10024703,2112000,16766748,5211647,2105376];
      
      public static const §_-W1Q§:Vector.<uint> = new <uint>[15198183,16746540,16769887,14811136,12319316,7471104,6430976,10024703,2112000,16766748,5211647,2105376];
      
      public static const §_-B2w§:Vector.<String> = §_-T13§();
      
      public static const §_-PZ§:Array = [§_-s2i§(1,12),§_-s2i§(2,12),§_-s2i§(3,12),§_-s2i§(4,12),§_-s2i§(5,12),§_-s2i§(6,12),§_-s2i§(7,12),§_-s2i§(8,12),§_-s2i§(9,12),§_-s2i§(10,12),§_-s2i§(11,12),§_-s2i§(12,12)];
      
      public function §_-g1a§()
      {
         super();
      }
      
      private static function §_-T13§() : Vector.<String>
      {
         var _loc1_:Vector.<String> = new Vector.<String>();
         var _loc2_:uint = 1;
         while(_loc2_ <= §_-8Z§)
         {
            _loc1_.push("ClanIcon" + _loc2_);
            _loc2_++;
         }
         return _loc1_;
      }
      
      private static function §_-s2i§(param1:uint, param2:uint) : Vector.<String>
      {
         var _loc3_:Vector.<String> = new Vector.<String>();
         var _loc4_:uint = 1;
         while(_loc4_ <= param2)
         {
            _loc3_.push("ClanTemplate" + param1 + "Kind" + _loc4_);
            _loc4_++;
         }
         return _loc3_;
      }
   }
}

