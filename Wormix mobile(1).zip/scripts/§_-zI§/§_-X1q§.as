package §_-zI§
{
   public class §_-X1q§
   {
      
      public static const §_-O2V§:int = 1;
      
      public static const OFFICER:int = 2;
      
      public static const §_-CM§:int = 3;
      
      public static const §_-E2R§:Vector.<String> = new <String>["ClanRankIcon1","ClanRankIcon2","ClanRankIcon3"];
      
      public function §_-X1q§()
      {
         super();
      }
   }
}

