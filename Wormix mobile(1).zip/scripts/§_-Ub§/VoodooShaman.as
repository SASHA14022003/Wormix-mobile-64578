package §_-Ub§
{
   import §_-12W§.§_-221§;
   import §_-21p§.§_-4w§;
   import §_-2U§.*;
   import §_-31N§.§_-Yy§;
   import §_-31W§.AchievRoomPanel;
   import §_-62§.§_-L1r§;
   import §_-63U§.SafetyArea;
   import §_-91B§.§_-QK§;
   import §_-91B§.§_-z2l§;
   import §_-931§.§_-02O§;
   import §_-937§.§_-BO§;
   import §_-A1K§.§_-6L§;
   import §_-A1K§.§_-TA§;
   import §_-A1K§.§_-U11§;
   import §_-Af§.§_-d1B§;
   import §_-B1y§.*;
   import §_-CF§.§_-E19§;
   import §_-CF§.§_-x2t§;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-J31§.§_-R1h§;
   import §_-J31§.§_-e2J§;
   import §_-J3L§.§_-K2i§;
   import §_-L1H§.§_-C3e§;
   import §_-L1H§.§_-b2K§;
   import §_-N8§.§_-2C§;
   import §_-N8§.§_-o2w§;
   import §_-TF§.§_-q1j§;
   import §_-Tm§.§_-RF§;
   import §_-Vg§.ClanEditView;
   import §_-Y1Q§.§_-aG§;
   import §_-Y1Q§.§_-tc§;
   import §_-Y1b§.§_-OP§;
   import §_-Z1K§.§_-q24§;
   import §_-Z1w§.§_-s1x§;
   import §_-aM§.*;
   import §_-b1F§.§_-v2Q§;
   import §_-b1R§.§_-C3P§;
   import §_-k13§.§_-j23§;
   import §_-l1g§.§_-L3Q§;
   import §_-rM§.§_-61j§;
   import §_-s20§.§_-J2g§;
   import §_-w2i§.§_-Ia§;
   import §_-z1g§.§_-5c§;
   import §_-zI§.§_-F3q§;
   import com.distriqt.extension.inappbilling.InAppBilling;
   import com.greensock.*;
   import com.greensock.loading.LoaderMax;
   import com.greensock.plugins.*;
   import com.hurlant.crypto.tls.§_-Tx§;
   import com.hurlant.crypto.tls.§_-a2D§;
   import com.hurlant.math.*;
   import config.§_-vR§;
   import feathers.controls.Button;
   import feathers.controls.List;
   import feathers.controls.text.BitmapFontTextRenderer;
   import feathers.core.FeathersControl;
   import feathers.core.ITextRenderer;
   import feathers.data.ListCollection;
   import feathers.layout.AnchorLayoutData;
   import feathers.text.BitmapFontTextFormat;
   import flash.events.Event;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.flox.social.utils.storage.EncryptedLocalStorageCookie;
   import ru.pragmatix.wormix.controller.*;
   import ru.pragmatix.wormix.fonts.BitmapFonts;
   import ru.pragmatix.wormix.game.ai.§_-A1l§;
   import ru.pragmatix.wormix.game.ai.§_-de§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.request.login.LoginClanBase;
   import ru.pragmatix.wormix.messages.client.PumpReactionRate;
   import ru.pragmatix.wormix.messages.structures.EndBattleStructure;
   import ru.pragmatix.wormix.messages.structures.WeaponStructure;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.pvp.messages.ex.BattleCreationFailure;
   import ru.pragmatix.wormix.pvp.messages.ex.CallToBattle;
   import ru.pragmatix.wormix.pvp.messages.server.BattleLoginError;
   import ru.pragmatix.wormix.serialization.SerializationUtils;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.weapons.ammo.LightningBullet;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Image;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.filters.ColorMatrixFilter;
   import starling.utils.Align;
   import starling.utils.Pool;
   import starling.utils.ScaleMode;
   
   use namespace bi_internal;
   
   public class VoodooShaman extends §_-d1B§
   {
      
      private static const §_-x2E§:int = 2;
      
      private var boss:§_-01J§;
      
      private var §_-h2R§:int = 0;
      
      public function VoodooShaman()
      {
         super(59);
      }
      
      override protected function §_-IB§() : void
      {
         §_-6D§ = new <§_-P1N§>[new §_-I26§()];
      }
      
      override protected function §_-C2E§() : void
      {
         super.§_-C2E§();
         §_-32L§ = [[map.§_-FV§[4],map.§_-FV§[1],map.§_-FV§[2],map.§_-FV§[3]],[map.§_-FV§[0]],[map.§_-FV§[6],map.§_-FV§[7],map.§_-FV§[5]]];
      }
      
      override protected function §_-03f§(param1:uint) : void
      {
         super.§_-03f§(param1);
         if(!currentUnit.squad.isAi())
         {
            ++this.§_-h2R§;
         }
      }
      
      override protected function §_-K2o§(param1:uint) : void
      {
         var _loc2_:§_-e2J§ = null;
         super.§_-K2o§(param1);
         if(!currentUnit.squad.isAi() && this.§_-h2R§ == §_-x2E§)
         {
            _loc2_ = §_-A6§(§_-s1x§.SHAMAN_KILL_IN_TWO_TURNS);
            if(_loc2_.available)
            {
               _loc2_.§_-j2F§();
               §_-wJ§(_loc2_);
            }
         }
      }
      
      override public function §_-e2d§() : void
      {
         super.§_-e2d§();
         this.boss = §_-336§[0].getUnits()[0];
         this.boss.addEventListener(§_-L3Q§.DISPOSED,this.§_-zV§);
      }
      
      private function §_-zV§(param1:starling.events.Event) : void
      {
         var _loc2_:§_-e2J§ = §_-A6§(§_-s1x§.§_-P1E§);
         if(§_-X1j§.§_-12n§.gameMaster.§_-b2W§(this.boss).length == 0 && _loc2_.available)
         {
            _loc2_.§_-h2j§ = true;
            §_-o2e§(_loc2_);
         }
         else if(_loc2_.available)
         {
            _loc2_.§_-j2F§();
            §_-wJ§(_loc2_);
         }
         _loc2_ = §_-A6§(§_-s1x§.SHAMAN_KILL_IN_TWO_TURNS);
         if(this.§_-h2R§ <= §_-x2E§ && _loc2_.available)
         {
            _loc2_.§_-h2j§ = true;
            §_-o2e§(_loc2_);
         }
      }
      
      override protected function §_-d1Y§(param1:§_-R1h§) : void
      {
         var _loc2_:§_-e2J§ = null;
         if(param1.code == §_-I26§.§_-EU§)
         {
            _loc2_ = §_-A6§(§_-s1x§.§_-w29§);
            if(_loc2_.available)
            {
               _loc2_.§_-h2j§ = true;
               §_-o2e§(_loc2_);
            }
         }
         else if(param1.code == §_-I26§.§_-zs§)
         {
            _loc2_ = §_-A6§(§_-s1x§.§_-w29§);
            if(!_loc2_.closed)
            {
               _loc2_.§_-j2F§();
               §_-wJ§(_loc2_);
            }
         }
      }
      
      override public function clear() : void
      {
         super.clear();
         this.boss.removeEventListener(§_-L3Q§.DISPOSED,this.§_-zV§);
      }
   }
}

