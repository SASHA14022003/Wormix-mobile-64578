package §_-Ub§
{
   import §_-12W§.*;
   import §_-2U§.*;
   import §_-62§.§_-W1r§;
   import §_-62§.§_-zF§;
   import §_-73I§.§_-q15§;
   import §_-79§.*;
   import §_-91A§.§_-sH§;
   import §_-A1K§.§_-TA§;
   import §_-Af§.§_-d1B§;
   import §_-B1y§.§_-bs§;
   import §_-Cl§.*;
   import §_-DJ§.§_-fH§;
   import §_-F2Q§.GestureEvent;
   import §_-F39§.§_-i1i§;
   import §_-G16§.*;
   import §_-G2H§.*;
   import §_-H2g§.§_-di§;
   import §_-J31§.§_-R1h§;
   import §_-J31§.§_-e2J§;
   import §_-Ly§.§_-81L§;
   import §_-TF§.§_-q1j§;
   import §_-Ta§.*;
   import §_-Z1w§.§_-s1x§;
   import §_-ZP§.§_-H1H§;
   import §_-ZP§.§_-w1J§;
   import §_-aM§.*;
   import §_-fo§.§_-21L§;
   import §_-j2R§.§_-73G§;
   import §_-l1K§.§_-m2§;
   import §_-l1g§.§_-L3Q§;
   import §_-r1C§.§_-h2B§;
   import com.distriqt.extension.inappbilling.Purchase;
   import com.hurlant.util.der.*;
   import feathers.controls.TabBar;
   import feathers.data.ListCollection;
   import feathers.events.FeathersEventType;
   import feathers.layout.VerticalLayout;
   import flash.events.Event;
   import flash.events.IEventDispatcher;
   import flash.net.SharedObject;
   import flash.net.URLRequest;
   import flash.net.navigateToURL;
   import flash.utils.*;
   import org.as3commons.zip.*;
   import ru.pragmatix.flox.social.model.PaymentOption;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.response.PromoteRankInClanResponse;
   import ru.pragmatix.wormix.messages.structures.AdvertisingPurchaseStructure;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.§_-6A§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.weapons.Weapon;
   import ru.pragmatix.wormix.weapons.ammo.GuardingBot;
   import ru.pragmatix.wormix.weapons.ammo.LightningBullet;
   import starling.display.DisplayObject;
   import starling.display.Image;
   import starling.events.Event;
   import starling.textures.Texture;
   
   public class WindMaster extends §_-d1B§
   {
      
      private static const §_-82L§:int = 9;
      
      private static const §_-B1V§:int = 7;
      
      private var boss:§_-01J§;
      
      private var §_-F13§:int = 0;
      
      public function WindMaster()
      {
         super(26);
      }
      
      override protected function §_-IB§() : void
      {
         §_-6D§ = new <§_-P1N§>[new §_-C1e§()];
         §_-C1e§(script).setMap(map);
      }
      
      override protected function §_-C2E§() : void
      {
         super.§_-C2E§();
         §_-32L§ = [[map.§_-FV§[0],map.§_-FV§[1],map.§_-FV§[2],map.§_-FV§[3]],[map.§_-FV§[4],map.§_-FV§[5]],[map.§_-FV§[6],map.§_-FV§[7],map.§_-42I§[0]]];
      }
      
      override protected function §_-p13§() : void
      {
         var _loc1_:§_-e2J§ = §_-A6§(§_-s1x§.WIND_MASTER_DONT_DROWN_ENEMIES);
         if(Boolean(_loc1_) && _loc1_.available)
         {
            §_-o2x§();
         }
      }
      
      override public function §_-e2d§() : void
      {
         super.§_-e2d§();
         this.boss = §_-336§[0].getUnits()[0];
         this.boss.addEventListener(§_-L3Q§.DISPOSED,this.§_-zV§);
      }
      
      override protected function §_-K2o§(param1:uint) : void
      {
         var _loc2_:§_-e2J§ = null;
         super.§_-K2o§(param1);
         if(!currentUnit.squad.isAi())
         {
            ++this.§_-F13§;
            _loc2_ = §_-A6§(§_-s1x§.WIND_MASTER_DROWN_GUARDIANS);
            if(Boolean(this.§_-F13§ == §_-B1V§) && Boolean(_loc2_) && _loc2_.available)
            {
               _loc2_.§_-j2F§();
               §_-wJ§(_loc2_);
            }
         }
      }
      
      private function §_-zV§(param1:starling.events.Event) : void
      {
         var _loc2_:§_-e2J§ = §_-A6§(§_-s1x§.WIND_MASTER_KILL_LAST);
         if(Boolean(_loc2_) && Boolean(_loc2_.available) && §_-X1j§.§_-12n§.gameMaster.§_-b2W§(this.boss).length == 0)
         {
            _loc2_.§_-h2j§ = true;
            §_-o2e§(_loc2_);
         }
         else if(Boolean(_loc2_) && _loc2_.available)
         {
            _loc2_.§_-j2F§();
            §_-wJ§(_loc2_);
         }
      }
      
      override protected function §_-d1Y§(param1:§_-R1h§) : void
      {
         var _loc2_:§_-e2J§ = null;
         if(param1.code == §_-s1x§.WIND_MASTER_DONT_DROWN_ENEMIES)
         {
            _loc2_ = §_-A6§(§_-s1x§.WIND_MASTER_DONT_DROWN_ENEMIES);
            if(Boolean(_loc2_) && _loc2_.available)
            {
               _loc2_.§_-j2F§();
               §_-wJ§(_loc2_);
            }
         }
         else if(param1.code == §_-s1x§.WIND_MASTER_DROWN_GUARDIANS)
         {
            _loc2_ = §_-A6§(§_-s1x§.WIND_MASTER_DROWN_GUARDIANS);
            if(Boolean(_loc2_) && _loc2_.available)
            {
               §_-T27§(_loc2_,§_-82L§);
            }
         }
      }
      
      override protected function §_-Te§(param1:starling.events.Event) : void
      {
         var _loc2_:Boolean = false;
         var _loc3_:§_-e2J§ = null;
         if(param1.data.source is LightningBullet)
         {
            _loc2_ = LightningBullet(param1.data.source).getSource() is GuardingBot;
            _loc3_ = §_-A6§(§_-s1x§.WIND_MASTER_DROWN_GUARDIANS);
            if(Boolean(_loc2_) && Boolean(_loc3_) && _loc3_.available)
            {
               _loc3_.§_-j2F§();
               §_-wJ§(_loc3_);
               §_-43n§();
            }
         }
      }
      
      override protected function §_-e1m§() : void
      {
         var _loc1_:§_-e2J§ = §_-A6§(§_-s1x§.WIND_MASTER_DONT_DROWN_ENEMIES);
         if(_loc1_)
         {
            §_-A6§(§_-s1x§.WIND_MASTER_DONT_DROWN_ENEMIES).§_-Z2M§();
         }
      }
   }
}

