package §_-Ub§
{
   import §_-21p§.§_-4w§;
   import §_-5P§.*;
   import §_-62§.§_-G1p§;
   import §_-A1K§.§_-6L§;
   import §_-A1K§.§_-TA§;
   import §_-A1K§.§_-U11§;
   import §_-Af§.§_-d1B§;
   import §_-Bv§.§_-G3P§;
   import §_-Cl§.*;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-J2l§;
   import §_-F39§.§_-a2W§;
   import §_-J31§.§_-R1h§;
   import §_-J31§.§_-e2J§;
   import §_-Ly§.§_-81L§;
   import §_-Tm§.Action;
   import §_-Tm§.§_-K1I§;
   import §_-Tm§.§_-RF§;
   import §_-U1i§.§_-J1§;
   import §_-Vu§.MD5;
   import §_-Y1b§.§_-OP§;
   import §_-Z1K§.§_-q24§;
   import §_-Z1w§.§_-s1x§;
   import §_-aM§.IllusionistScript;
   import §_-aM§.§_-P1N§;
   import §_-hv§.*;
   import §_-j22§.§_-5g§;
   import §_-l1K§.§_-m2§;
   import §_-l1g§.§_-L3Q§;
   import §_-n1w§.*;
   import §_-nE§.SelectCraftWeaponScreen;
   import §_-r1C§.§_-h2B§;
   import §_-s20§.§_-J2g§;
   import §_-u13§.MD2;
   import §_-u13§.MD5;
   import §_-u13§.SHA1;
   import §_-u13§.§_-F3§;
   import com.greensock.*;
   import com.greensock.core.*;
   import com.hurlant.util.der.Sequence;
   import com.hurlant.util.der.§_-cz§;
   import com.hurlant.util.der.§_-l1b§;
   import config.§_-vR§;
   import feathers.controls.ImageLoader;
   import flash.display.DisplayObject;
   import flash.display.Shape;
   import flash.events.TimerEvent;
   import flash.utils.ByteArray;
   import flash.utils.Dictionary;
   import flash.utils.IDataOutput;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.shop.*;
   import ru.pragmatix.wormix.messages.client.MobileLogin;
   import ru.pragmatix.wormix.model.items.craft.CraftedEquipFamily;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.*;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.pvp.messages.ex.CreateBattleRequest;
   import ru.pragmatix.wormix.serialization.SerializationUtils;
   import ru.pragmatix.wormix.weapons.Weapon;
   import ru.pragmatix.wormix.weapons.ammo.type.blocker.HealBlocker;
   import starling.events.Event;
   import starling.textures.Texture;
   
   public class §_-W1E§ extends §_-d1B§
   {
      
      public static const §_-813§:§_-TA§ = new §_-TA§(5);
      
      public function §_-W1E§()
      {
         super(60);
      }
      
      override protected function §_-IB§() : void
      {
         §_-6D§ = new <§_-P1N§>[new IllusionistScript()];
      }
      
      override protected function §_-C2E§() : void
      {
         super.§_-C2E§();
         §_-32L§ = [[map.§_-FV§[1],map.§_-FV§[2],map.§_-FV§[3],map.§_-FV§[4]],[map.§_-FV§[0]]];
      }
      
      override protected function §_-d1Y§(param1:§_-R1h§) : void
      {
         var _loc2_:§_-e2J§ = null;
         if(param1.code == §_-s1x§.ILLUSIONIST_DROWN_FIVE_TIMES)
         {
            _loc2_ = §_-A6§(§_-s1x§.ILLUSIONIST_DROWN_FIVE_TIMES);
            if(_loc2_.available)
            {
               §_-T27§(_loc2_,§_-813§.value);
            }
         }
         else if(param1.code == §_-s1x§.§_-930§)
         {
            _loc2_ = §_-A6§(§_-s1x§.§_-930§);
            if(_loc2_.available)
            {
               _loc2_.§_-j2F§();
               §_-wJ§(_loc2_);
            }
         }
         else if(param1.code == §_-s1x§.§_-5w§)
         {
            _loc2_ = §_-A6§(§_-s1x§.§_-5w§);
            if(_loc2_.available)
            {
               _loc2_.§_-j2F§();
               §_-wJ§(_loc2_);
            }
         }
      }
      
      override protected function §_-e1m§() : void
      {
         §_-A6§(§_-s1x§.§_-930§).§_-Z2M§();
         §_-A6§(§_-s1x§.§_-5w§).§_-Z2M§();
      }
   }
}

