package §_-Ub§
{
   import §_-12W§.*;
   import §_-12a§.§_-6p§;
   import §_-43V§.*;
   import §_-52V§.§_-R9§;
   import §_-62§.*;
   import §_-63U§.§_-NV§;
   import §_-73I§.§_-q15§;
   import §_-9§.§_-52A§;
   import §_-9e§.§_-73e§;
   import §_-9e§.§_-8O§;
   import §_-9e§.§_-A18§;
   import §_-A1K§.§_-TA§;
   import §_-Af§.§_-d1B§;
   import §_-B1y§.§_-bs§;
   import §_-C3f§.§_-yG§;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-J2l§;
   import §_-F39§.§_-D14§;
   import §_-G16§.*;
   import §_-H2g§.§_-di§;
   import §_-J31§.§_-R1h§;
   import §_-J31§.§_-e2J§;
   import §_-Ly§.§_-81L§;
   import §_-T1t§.§_-u19§;
   import §_-TF§.§_-q1j§;
   import §_-U1i§.§_-O2i§;
   import §_-Y1O§.§_-V23§;
   import §_-Y1b§.§_-OP§;
   import §_-Z1K§.§_-A2n§;
   import §_-Z1L§.§_-A2V§;
   import §_-Z1L§.§_-H1K§;
   import §_-Z1w§.§_-s1x§;
   import §_-aM§.*;
   import §_-b1F§.§_-v2Q§;
   import §_-bI§.*;
   import §_-g2r§.§_-03A§;
   import §_-hO§.§_-v24§;
   import §_-k1u§.§_-H2M§;
   import §_-k1u§.§_-Oi§;
   import §_-l1g§.§_-L3Q§;
   import §_-l2r§.§_-K1t§;
   import §_-nE§.SelectCraftWeaponScreen;
   import §_-nE§.§_-p16§;
   import §_-q26§.*;
   import §_-r1C§.§_-h2B§;
   import §_-rM§.§_-61j§;
   import §_-sQ§.§_-H3D§;
   import §_-v2t§.§_-43O§;
   import §_-x2Q§.§_-dU§;
   import §_-z1g§.§_-4l§;
   import §_-z1g§.§_-522§;
   import §_-zI§.§_-X1q§;
   import com.amanitadesign.steam.FriendConstants;
   import com.hurlant.crypto.tls.§_-21v§;
   import com.hurlant.util.der.*;
   import dragonBones.animation.WorldClock;
   import feathers.controls.ScrollPolicy;
   import feathers.data.VectorCollection;
   import feathers.events.FeathersEventType;
   import feathers.layout.VerticalLayout;
   import flash.events.Event;
   import flash.events.StatusEvent;
   import flash.geom.Point;
   import flash.text.TextField;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import flash.utils.getTimer;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.flox.social.controller.steam.*;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.*;
   import ru.pragmatix.wormix.gui.menu.clans.chat.*;
   import ru.pragmatix.wormix.messages.clans.request.DeleteClanRequest;
   import ru.pragmatix.wormix.messages.clans.request.login.LoginClanBase;
   import ru.pragmatix.wormix.messages.clans.request.login.LoginCreateClanRequest;
   import ru.pragmatix.wormix.messages.clans.request.login.LoginJoinClanRequest;
   import ru.pragmatix.wormix.messages.clans.response.DeleteClanResponse;
   import ru.pragmatix.wormix.messages.clans.response.LoginClanEnterAccount;
   import ru.pragmatix.wormix.messages.clans.response.LoginClanErrorResponse;
   import ru.pragmatix.wormix.messages.client.Login;
   import ru.pragmatix.wormix.messages.structures.HeroicMissionStructure;
   import ru.pragmatix.wormix.messages.structures.RatingProfileStructure;
   import ru.pragmatix.wormix.messages.structures.ReconnectToSimpleBattleResultStructure;
   import ru.pragmatix.wormix.model.bonus.§_-x2M§;
   import ru.pragmatix.wormix.model.items.craft.§_-IE§;
   import ru.pragmatix.wormix.model.items.craft.§_-Y2u§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-8K§;
   import ru.pragmatix.wormix.serialization.client.*;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.utils.§_-72u§;
   import ru.pragmatix.wormix.utils.§_-c1S§;
   import ru.pragmatix.wormix.weapons.ammo.type.RopeHook;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Image;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.textures.Texture;
   import starling.utils.Pool;
   import starling.utils.SystemUtil;
   
   public class Vikings extends §_-d1B§
   {
      
      public static const §_-X2r§:§_-TA§ = new §_-TA§(3);
      
      public function Vikings()
      {
         super(61);
      }
      
      override protected function §_-IB§() : void
      {
         §_-6D§ = new <§_-P1N§>[new §_-3B§()];
      }
      
      override protected function §_-C2E§() : void
      {
         super.§_-C2E§();
         §_-32L§ = [[map.§_-FV§[3],map.§_-FV§[6],map.§_-FV§[0],map.§_-FV§[2]],[map.§_-FV§[4]],[map.§_-FV§[5]],[map.§_-FV§[1]]];
      }
      
      override protected function §_-p13§() : void
      {
         §_-TZ§.addListener(script,§_-L3Q§.§_-Qw§,this.§_-Jc§);
         §_-o2x§();
      }
      
      override protected function §_-K2o§(param1:uint) : void
      {
         var _loc3_:§_-V23§ = null;
         var _loc4_:§_-e2J§ = null;
         super.§_-K2o§(param1);
         var _loc2_:int = 0;
         for each(_loc3_ in §_-336§)
         {
            _loc2_ += _loc3_.§_-Z2G§();
         }
         _loc4_ = §_-A6§(§_-s1x§.VIKINGS_KILL_TWO_IN_TURN);
         if(_loc4_.available)
         {
            if(_loc2_ <= 1)
            {
               _loc4_.§_-j2F§();
               §_-wJ§(_loc4_);
            }
            else
            {
               _loc4_.count = 0;
            }
         }
      }
      
      override protected function §_-d1Y§(param1:§_-R1h§) : void
      {
         var _loc2_:§_-e2J§ = null;
         if(param1.code == §_-s1x§.VIKINGS_DROWN_ALL)
         {
            _loc2_ = §_-A6§(§_-s1x§.VIKINGS_DROWN_ALL);
            if(_loc2_.available)
            {
               §_-T27§(_loc2_,§_-X2r§.value);
            }
            this.§_-v2x§();
         }
      }
      
      private function §_-Jc§(param1:starling.events.Event) : void
      {
         var _loc2_:§_-e2J§ = null;
         if(param1.data.victim.disposed)
         {
            _loc2_ = §_-A6§(§_-s1x§.VIKINGS_DROWN_ALL);
            if(_loc2_.available)
            {
               _loc2_.§_-j2F§();
               §_-wJ§(_loc2_);
            }
            this.§_-v2x§();
         }
      }
      
      private function §_-v2x§() : void
      {
         var _loc1_:§_-e2J§ = §_-A6§(§_-s1x§.VIKINGS_KILL_TWO_IN_TURN);
         if(_loc1_.available)
         {
            §_-T27§(_loc1_,§_-X2r§.value - 1);
         }
      }
      
      override protected function §_-Te§(param1:starling.events.Event) : void
      {
         var _loc2_:§_-e2J§ = §_-A6§(§_-s1x§.VIKINGS_WIN_WITH_FULL_HP);
         if(param1.data.power > 0 && _loc2_.available)
         {
            _loc2_.§_-j2F§();
            §_-wJ§(_loc2_);
         }
      }
      
      override protected function §_-e1m§() : void
      {
         §_-A6§(§_-s1x§.VIKINGS_WIN_WITH_FULL_HP).§_-Z2M§();
      }
      
      override public function §_-H1J§() : §_-73e§
      {
         var _loc1_:§_-73e§ = super.§_-H1J§();
         _loc1_.online = false;
         _loc1_.backpackEnabled = true;
         _loc1_.§_-v17§ = false;
         _loc1_.§_-f2m§ = false;
         _loc1_.§_-724§ = false;
         _loc1_.§_-z2U§ = false;
         _loc1_.§_-nA§ = false;
         _loc1_.achievements = §_-N1V§.settings.§_-l9§();
         _loc1_.water = §_-A18§.§_-J24§;
         _loc1_.timer = new §_-8O§(40,4,4,5,5,30);
         _loc1_.§_-32V§ = false;
         _loc1_.§_-b2i§ = §_-43O§.§_-i1N§;
         return _loc1_;
      }
   }
}

