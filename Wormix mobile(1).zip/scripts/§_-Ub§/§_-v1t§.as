package §_-Ub§
{
   import §_-31W§.*;
   import §_-51W§.§_-SN§;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-L1r§;
   import §_-62§.§_-O2H§;
   import §_-62§.§_-W1r§;
   import §_-62§.§_-gr§;
   import §_-73I§.§_-Y1l§;
   import §_-9e§.§_-73e§;
   import §_-9e§.§_-8O§;
   import §_-9e§.§_-A18§;
   import §_-A1K§.§_-6L§;
   import §_-A1K§.§_-TA§;
   import §_-A1K§.§_-U11§;
   import §_-Af§.§_-d1B§;
   import §_-CF§.§_-E19§;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-Es§;
   import §_-DJ§.§_-J2l§;
   import §_-H2g§.§_-di§;
   import §_-J31§.§_-R1h§;
   import §_-J31§.§_-e2J§;
   import §_-J3b§.*;
   import §_-L1H§.§_-C3e§;
   import §_-Nq§.*;
   import §_-R2I§.§_-u2V§;
   import §_-TF§.§_-q1j§;
   import §_-U1i§.§_-J1§;
   import §_-W§.§_-z2Q§;
   import §_-YF§.§_-q2v§;
   import §_-Z1w§.§_-s1x§;
   import §_-ZP§.§_-b23§;
   import §_-a19§.*;
   import §_-aM§.§_-325§;
   import §_-aM§.§_-P1N§;
   import §_-j22§.§_-5g§;
   import §_-k2s§.§_-8c§;
   import §_-k2s§.§_-C3A§;
   import §_-k2s§.§_-fG§;
   import §_-l1g§.§_-L3Q§;
   import §_-rM§.§_-61j§;
   import §_-s20§.§_-J2g§;
   import §_-u13§.*;
   import §_-u2J§.§_-T1K§;
   import §_-v2t§.§_-43O§;
   import §_-z1g§.§_-82X§;
   import com.distriqt.extension.inappbilling.InAppBilling;
   import com.distriqt.extension.inappbilling.InAppBillingAvailability;
   import com.distriqt.extension.inappbilling.events.AvailabilityEvent;
   import com.distriqt.extension.pushnotifications.events.RegistrationEvent;
   import com.greensock.*;
   import com.greensock.core.*;
   import com.greensock.events.LoaderEvent;
   import com.greensock.loading.*;
   import com.greensock.loading.core.LoaderCore;
   import com.hurlant.math.BigInteger;
   import com.hurlant.math.bi_internal;
   import com.hurlant.util.*;
   import dragonBones.animation.WorldClock;
   import feathers.controls.ScrollPolicy;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import feathers.core.ITextRenderer;
   import feathers.data.ArrayCollection;
   import feathers.data.ListCollection;
   import feathers.layout.AnchorLayoutData;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.HorizontalLayout;
   import feathers.layout.RelativePosition;
   import feathers.layout.TiledRowsLayout;
   import feathers.layout.VerticalAlign;
   import feathers.layout.VerticalLayout;
   import flash.display.DisplayObject;
   import flash.display.DisplayObjectContainer;
   import flash.display.Shape;
   import flash.events.*;
   import flash.geom.Point;
   import flash.geom.Rectangle;
   import flash.utils.ByteArray;
   import flash.utils.Dictionary;
   import flash.utils.IDataInput;
   import flash.utils.IDataOutput;
   import ru.pragmatix.flox.serialization.§_-616§;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.flox.social.controller.mobile.*;
   import ru.pragmatix.flox.social.utils.id.UserIdType;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fonts.BitmapFonts;
   import ru.pragmatix.wormix.fx.EffectType;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.house.*;
   import ru.pragmatix.wormix.messages.clans.response.SetMuteModeResponse;
   import ru.pragmatix.wormix.messages.clans.structures.ClanChatMessageTO;
   import ru.pragmatix.wormix.messages.client.RefundPvpBattleLoss;
   import ru.pragmatix.wormix.messages.client.RepeatPvpBattleAward;
   import ru.pragmatix.wormix.messages.client.WipeProfile;
   import ru.pragmatix.wormix.messages.server.BuyVipResult;
   import ru.pragmatix.wormix.messages.structures.PreCalculatedPoints;
   import ru.pragmatix.wormix.messages.structures.RentedItemsStructure;
   import ru.pragmatix.wormix.messages.structures.SelectStuffResultStructure;
   import ru.pragmatix.wormix.model.§_-4V§;
   import ru.pragmatix.wormix.model.items.craft.*;
   import ru.pragmatix.wormix.model.rewards.§_-qU§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.physics.HitTest;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.utils.§_-2t§;
   import ru.pragmatix.wormix.utils.§_-R2g§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.utils.§_-k1h§;
   import ru.pragmatix.wormix.weapons.ammo.JumpingMine;
   import ru.pragmatix.wormix.weapons.ammo.LightningBullet;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Image;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.utils.Color;
   import starling.utils.Pool;
   import starling.utils.RectangleUtil;
   import starling.utils.ScaleMode;
   
   use namespace bi_internal;
   
   public class §_-v1t§ extends §_-d1B§
   {
      
      private static const §_-Fv§:int = 3;
      
      private var boss:§_-01J§;
      
      private var §_-a2K§:Vector.<§_-01J§>;
      
      public function §_-v1t§()
      {
         super(62);
      }
      
      override protected function §_-IB§() : void
      {
         §_-6D§ = new <§_-P1N§>[new §_-325§()];
      }
      
      override protected function §_-C2E§() : void
      {
         super.§_-C2E§();
         §_-32L§ = [[map.§_-FV§[0],map.§_-FV§[1],map.§_-FV§[2],map.§_-42I§[1]],[Pool.getPoint(map.§_-FV§[4].x - 310,map.§_-FV§[4].y - 500)],[map.§_-FV§[5],map.§_-FV§[7],map.§_-FV§[3]]];
      }
      
      override public function §_-e2d§() : void
      {
         super.§_-e2d§();
         this.boss = §_-336§[0].getUnits()[0];
         this.boss.addEventListener(§_-L3Q§.DISPOSED,this.§_-zV§);
      }
      
      override protected function §_-03f§(param1:uint) : void
      {
         var _loc3_:§_-01J§ = null;
         super.§_-03f§(param1);
         var _loc2_:§_-e2J§ = §_-A6§(§_-s1x§.PIRATE_DONT_SINK);
         if(_loc2_.available && param1 == 1)
         {
            this.§_-a2K§ = new Vector.<§_-01J§>();
            for each(_loc3_ in §_-X1j§.§_-12n§.gameMaster.§_-83I§(this.boss))
            {
               this.§_-a2K§.push(_loc3_);
               _loc3_.buffs.place(new §_-z2Q§());
               _loc3_.addEventListener(§_-R1h§.NAME,this.§_-V1g§);
            }
         }
      }
      
      private function §_-V1g§(param1:Event) : void
      {
         var _loc3_:§_-01J§ = null;
         var _loc2_:§_-e2J§ = §_-A6§(§_-s1x§.PIRATE_DONT_SINK);
         if(_loc2_.available)
         {
            _loc2_.§_-j2F§();
            §_-wJ§(_loc2_);
         }
         for each(_loc3_ in this.§_-a2K§)
         {
            _loc3_.buffs.§_-e1z§(§_-z2Q§.NAME);
            _loc3_.removeEventListener(§_-R1h§.NAME,this.§_-V1g§);
         }
         this.§_-a2K§ = null;
      }
      
      override protected function §_-p13§() : void
      {
         §_-TZ§.addListener(script,§_-L3Q§.§_-Qw§,this.§_-61a§,§_-4V§.§_-CO§);
      }
      
      private function §_-zV§(param1:Event) : void
      {
         var _loc2_:§_-e2J§ = §_-A6§(§_-s1x§.PIRATE_KILL_LAST);
         if(_loc2_.available && §_-X1j§.§_-12n§.gameMaster.§_-b2W§(this.boss).length == 0)
         {
            _loc2_.§_-h2j§ = true;
            §_-o2e§(_loc2_);
         }
         else if(_loc2_.available)
         {
            _loc2_.§_-j2F§();
            §_-wJ§(_loc2_);
         }
      }
      
      override protected function §_-d1Y§(param1:§_-R1h§) : void
      {
         var _loc2_:§_-e2J§ = null;
         if(param1.code == §_-s1x§.PIRATE_DROWN_SUPPORTS)
         {
            _loc2_ = §_-A6§(§_-s1x§.PIRATE_DROWN_SUPPORTS);
            if(_loc2_.available)
            {
               §_-T27§(_loc2_,§_-Fv§);
            }
         }
      }
      
      private function §_-61a§(param1:Event) : void
      {
         var _loc2_:§_-e2J§ = null;
         if(param1.data.victim.disposed)
         {
            _loc2_ = §_-A6§(§_-s1x§.PIRATE_DROWN_SUPPORTS);
            if(_loc2_.available)
            {
               _loc2_.§_-j2F§();
               §_-wJ§(_loc2_);
            }
         }
      }
      
      override protected function §_-e1m§() : void
      {
         §_-A6§(§_-s1x§.PIRATE_DONT_SINK).§_-Z2M§();
      }
      
      override public function clear() : void
      {
         var _loc1_:§_-01J§ = null;
         super.clear();
         this.boss.removeEventListener(§_-L3Q§.DISPOSED,this.§_-zV§);
         if(this.§_-a2K§)
         {
            for each(_loc1_ in this.§_-a2K§)
            {
               _loc1_.removeEventListener(§_-R1h§.NAME,this.§_-V1g§);
            }
            this.§_-a2K§ = null;
         }
      }
      
      override public function §_-H1J§() : §_-73e§
      {
         var _loc1_:§_-73e§ = super.§_-H1J§();
         _loc1_.online = false;
         _loc1_.backpackEnabled = true;
         _loc1_.§_-v17§ = false;
         _loc1_.§_-f2m§ = false;
         _loc1_.§_-724§ = false;
         _loc1_.§_-z2U§ = false;
         _loc1_.§_-nA§ = false;
         _loc1_.achievements = §_-N1V§.settings.§_-l9§();
         _loc1_.water = new §_-A18§(20,3,30);
         _loc1_.timer = §_-8O§.DEFAULT;
         _loc1_.§_-b2i§ = §_-43O§.§_-i1N§;
         _loc1_.§_-32V§ = false;
         return _loc1_;
      }
   }
}

