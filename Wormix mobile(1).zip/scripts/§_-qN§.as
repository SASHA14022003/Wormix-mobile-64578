package
{
   import §_-62§.*;
   import §_-A1K§.§_-TA§;
   import §_-C2t§.§_-92W§;
   import §_-L1H§.§_-C3e§;
   import §_-Y1O§.§_-V23§;
   import §_-Z1K§.§_-q24§;
   import §_-aM§.*;
   import §_-fo§.§_-hH§;
   import §_-l1g§.§_-L3Q§;
   import config.§_-vR§;
   import flash.geom.ColorTransform;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.game.ai.§_-A1l§;
   import ru.pragmatix.wormix.game.ai.§_-de§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.utils.*;
   import starling.events.Event;
   
   public class §_-qN§
   {
      
      public static const §_-L2b§:Object = {
         "useFakeHardwareAddress":"",
         "socialType":"mobile",
         "secretKey":"s0PaWHUokZZMlhtKVyj3S1n5BruorNmk",
         "facebookAppId":§_-vR§.facebookAppId,
         "FacebookApplicationLinkURL":§_-vR§.facebookAppLinkURL,
         "vkAppId":§_-vR§.vkAppId,
         "vkAppLink":§_-vR§.§_-j2§,
         "appDownloadLink":§_-vR§.appDownloadLink,
         "clubLink":§_-vR§.clubLink,
         "platform":§_-vR§.§_-I1d§,
         "facebookAppAccessToken":""
      };
      
      public function §_-qN§()
      {
         super();
      }
   }
}

