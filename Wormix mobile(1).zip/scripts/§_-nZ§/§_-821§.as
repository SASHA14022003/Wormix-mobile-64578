package §_-nZ§
{
   import §_-L1H§.§_-b2K§;
   import §_-RE§.§_-52p§;
   import §_-Ty§.§_-1R§;
   import §_-Ty§.§_-71n§;
   import §_-Ty§.§_-Jb§;
   import §_-Ty§.§_-M1h§;
   import §_-Ty§.§_-Z2E§;
   import §_-Y1O§.*;
   import §_-Z1K§.§_-q24§;
   import §_-c2O§.§_-03I§;
   import §_-n1w§.*;
   import §_-o14§.§_-Dd§;
   import com.distriqt.extension.inappbilling.Purchase;
   import com.distriqt.extension.inappbilling.events.PurchaseEvent;
   import flash.geom.Point;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-E2w§;
   import ru.pragmatix.wormix.objects.Waypoint;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.weapons.*;
   import starling.display.DisplayObject;
   import starling.utils.Pool;
   
   public class §_-821§ extends §_-E2w§ implements §_-03I§
   {
      
      private var §_-k2H§:Vector.<§_-1R§>;
      
      private var unavailableBossInfo:§_-71n§;
      
      private var lockedBossInfo:§_-Jb§;
      
      private var availableBossInfo:§_-Z2E§;
      
      private var §_-Vn§:§_-M1h§;
      
      public function §_-821§(param1:DisplayObject = null)
      {
         var _loc2_:DisplayObject = null;
         this.§_-k2H§ = new Vector.<§_-1R§>(0);
         super(param1);
         param1.touchable = true;
         _loc2_ = getChildByName("unavailableBossInfo");
         this.unavailableBossInfo = new §_-71n§(_loc2_);
         this.§_-k2H§.push(this.unavailableBossInfo);
         _loc2_ = getChildByName("lockedBossInfo");
         this.lockedBossInfo = new §_-Jb§(_loc2_);
         this.§_-k2H§.push(this.lockedBossInfo);
         _loc2_ = getChildByName("availableBossInfo");
         this.availableBossInfo = new §_-Z2E§(_loc2_);
         this.§_-k2H§.push(this.availableBossInfo);
         _loc2_ = getChildByName("completedBossInfo");
         this.§_-Vn§ = new §_-M1h§(_loc2_);
         this.§_-k2H§.push(this.§_-Vn§);
      }
      
      public function §_-42T§(param1:Object) : void
      {
         this.§_-7B§();
         this.availableBossInfo.§_-c1v§(true);
         this.availableBossInfo.§_-X2n§(param1 as §_-52p§);
      }
      
      public function §_-x2i§(param1:Object) : void
      {
         this.§_-7B§();
         this.§_-Vn§.§_-c1v§(true);
         this.§_-Vn§.§_-X2n§(param1 as §_-52p§);
      }
      
      public function §_-23j§(param1:Object) : void
      {
         this.§_-7B§();
         this.availableBossInfo.§_-c1v§(true);
         this.availableBossInfo.§_-X2n§(param1 as §_-52p§);
      }
      
      public function §_-t1i§(param1:Object) : void
      {
         this.§_-7B§();
         this.lockedBossInfo.§_-c1v§(true);
         this.lockedBossInfo.§_-X2n§(param1 as §_-52p§);
      }
      
      public function §_-511§(param1:Object) : void
      {
         this.§_-7B§();
         this.unavailableBossInfo.§_-c1v§(true);
         this.unavailableBossInfo.§_-X2n§(param1 as §_-52p§);
      }
      
      private function §_-7B§() : void
      {
         var _loc1_:§_-1R§ = null;
         for each(_loc1_ in this.§_-k2H§)
         {
            _loc1_.§_-c1v§(false);
         }
      }
      
      override public function dispose() : void
      {
         var _loc1_:* = 0;
         this.unavailableBossInfo = null;
         this.lockedBossInfo = null;
         this.availableBossInfo = null;
         this.§_-Vn§ = null;
         if(this.§_-k2H§)
         {
            _loc1_ = int(this.§_-k2H§.length);
            while(_loc1_--)
            {
               this.§_-k2H§[_loc1_].dispose();
            }
            this.§_-k2H§ = null;
         }
         super.dispose();
      }
   }
}

