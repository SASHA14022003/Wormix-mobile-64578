package §_-nZ§
{
   import §_-21p§.§_-4w§;
   import §_-L2F§.§_-D2p§;
   import §_-RE§.§_-D3v§;
   import §_-RE§.§_-r2q§;
   import §_-x2Q§.§_-dU§;
   import feathers.controls.ScrollPolicy;
   import feathers.data.VectorCollection;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.clans.chat.*;
   
   public class §_-6z§
   {
      
      public static const §_-v1N§:String = "is locked";
      
      public static const AVAILABLE:String = "is available";
      
      public static const UNAVAILABLE:String = "is unavailable";
      
      public static const COMPLETED:String = "is completed";
      
      public static const §_-D1p§:String = "is completed today";
      
      public function §_-6z§()
      {
         super();
      }
      
      public static function §_-l2I§(param1:§_-D2p§) : String
      {
         var _loc2_:§_-D3v§ = §_-r2q§.§_-r9§(param1.getId());
         var _loc3_:int = _loc2_.§_-rm§;
         if(_loc3_ < 0)
         {
            _loc3_ = 0;
         }
         var _loc4_:int = param1.getId();
         if(Application.userProfile.getLevel() < param1.§_-eH§())
         {
            return UNAVAILABLE;
         }
         if(_loc4_ <= _loc3_)
         {
            return COMPLETED;
         }
         if((_loc4_ == _loc3_ + 1 || _loc4_ == _loc2_.getOffset() + 1) && §_-X1j§.§_-A24§.§_-X2A§())
         {
            return AVAILABLE;
         }
         if(!§_-X1j§.§_-A24§.§_-X2A§())
         {
            return §_-D1p§;
         }
         if(_loc4_ > _loc3_)
         {
            return §_-v1N§;
         }
         return §_-v1N§;
      }
   }
}

