package §_-nZ§
{
   import §_-L1H§.§_-C3e§;
   import §_-L2F§.§_-D2p§;
   import §_-Ty§.§_-83N§;
   import §_-Ty§.§_-K3a§;
   import §_-Ty§.§_-U2T§;
   import §_-Ty§.§_-n1U§;
   import §_-Ty§.§_-o1U§;
   import §_-Y1O§.*;
   import §_-bI§.*;
   import §_-c2O§.§_-03I§;
   import §_-l1K§.*;
   import §_-zI§.§_-X1q§;
   import flash.text.TextField;
   import ru.pragmatix.wormix.gui.§_-E2w§;
   import ru.pragmatix.wormix.messages.structures.RatingProfileStructure;
   import ru.pragmatix.wormix.model.user.§_-r1d§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.physics.Force;
   import ru.pragmatix.wormix.utils.§_-c1S§;
   import ru.pragmatix.wormix.weapons.ammo.type.grenade.cluster.ShellBurst;
   import starling.display.DisplayObject;
   
   public class §_-41f§ extends §_-E2w§ implements §_-03I§
   {
      
      private var §_-k2H§:Vector.<§_-K3a§>;
      
      private var unavailableBossInfo:§_-n1U§;
      
      private var lockedBossInfo:§_-o1U§;
      
      private var availableBossInfo:§_-83N§;
      
      private var §_-Vn§:§_-U2T§;
      
      private var §_-V1W§:§_-K3a§;
      
      public function §_-41f§(param1:DisplayObject = null)
      {
         var _loc2_:DisplayObject = null;
         var _loc3_:§_-K3a§ = null;
         this.§_-k2H§ = new Vector.<§_-K3a§>(0);
         super(param1);
         param1.touchable = true;
         _loc2_ = getChildByName("unavailableBossInfo");
         this.unavailableBossInfo = new §_-n1U§(_loc2_);
         this.§_-k2H§.push(this.unavailableBossInfo);
         _loc2_ = getChildByName("lockedBossInfo");
         this.lockedBossInfo = new §_-o1U§(_loc2_);
         this.§_-k2H§.push(this.lockedBossInfo);
         _loc2_ = getChildByName("availableBossInfo");
         this.availableBossInfo = new §_-83N§(_loc2_);
         this.§_-k2H§.push(this.availableBossInfo);
         _loc2_ = getChildByName("completedBossInfo");
         this.§_-Vn§ = new §_-U2T§(_loc2_);
         this.§_-k2H§.push(this.§_-Vn§);
         for each(_loc3_ in this.§_-k2H§)
         {
            _loc3_.getContainer().removeFromParent();
         }
      }
      
      public function §_-42T§(param1:Object) : void
      {
         this.§_-o2U§(this.availableBossInfo,param1);
      }
      
      public function §_-x2i§(param1:Object) : void
      {
         this.§_-o2U§(this.§_-Vn§,param1);
      }
      
      public function §_-23j§(param1:Object) : void
      {
         this.§_-o2U§(this.availableBossInfo,param1);
      }
      
      public function §_-t1i§(param1:Object) : void
      {
         this.§_-o2U§(this.lockedBossInfo,param1);
      }
      
      public function §_-511§(param1:Object) : void
      {
         this.§_-o2U§(this.unavailableBossInfo,param1);
      }
      
      private function §_-o2U§(param1:§_-K3a§, param2:Object) : void
      {
         if(param1 != this.§_-V1W§)
         {
            if(this.§_-V1W§)
            {
               this.§_-V1W§.getContainer().removeFromParent();
            }
            this.§_-V1W§ = param1;
            addChild(this.§_-V1W§);
         }
         this.§_-V1W§.§_-X2n§(param2 as §_-D2p§);
      }
      
      override public function dispose() : void
      {
         var _loc1_:* = 0;
         this.unavailableBossInfo = null;
         this.lockedBossInfo = null;
         this.availableBossInfo = null;
         this.§_-Vn§ = null;
         if(this.§_-k2H§)
         {
            _loc1_ = int(this.§_-k2H§.length);
            while(_loc1_--)
            {
               this.§_-k2H§[_loc1_].dispose();
            }
            this.§_-k2H§ = null;
         }
         super.dispose();
      }
   }
}

