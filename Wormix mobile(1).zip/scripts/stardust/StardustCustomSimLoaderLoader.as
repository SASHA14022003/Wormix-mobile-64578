package stardust
{
   import com.funkypandagame.stardustplayer.ISimLoader;
   import com.funkypandagame.stardustplayer.SDEConstants;
   import com.funkypandagame.stardustplayer.emitter.EmitterBuilder;
   import com.funkypandagame.stardustplayer.emitter.EmitterValueObject;
   import com.funkypandagame.stardustplayer.project.ProjectValueObject;
   import com.funkypandagame.stardustplayer.sequenceLoader.ISequenceLoader;
   import com.funkypandagame.stardustplayer.sequenceLoader.LoadByteArrayJob;
   import com.funkypandagame.stardustplayer.sequenceLoader.SequenceLoader;
   import flash.events.Event;
   import flash.events.EventDispatcher;
   import flash.utils.ByteArray;
   import idv.cjcat.stardustextended.Stardust;
   import idv.cjcat.stardustextended.actions.Action;
   import idv.cjcat.stardustextended.actions.Spawn;
   import idv.cjcat.stardustextended.emitters.Emitter;
   import idv.cjcat.stardustextended.handlers.starling.StarlingHandler;
   import org.as3commons.zip.§_-Lr§;
   import starling.textures.SubTexture;
   import starling.textures.Texture;
   import starling.utils.AssetManager;
   
   public class StardustCustomSimLoaderLoader extends EventDispatcher implements ISimLoader
   {
      
      public static const DESCRIPTOR_FILENAME:String = "descriptor.json";
      
      private const sequenceLoader:ISequenceLoader = new SequenceLoader();
      
      protected var projectLoaded:Boolean = false;
      
      protected var loadedZip:§_-Lr§;
      
      protected var descriptorJSON:Object;
      
      protected var rawEmitterDatas:Vector.<RawEmitterData> = new Vector.<RawEmitterData>();
      
      private var assetManager:AssetManager;
      
      private var name:String;
      
      public function StardustCustomSimLoaderLoader(param1:String, param2:AssetManager)
      {
         super();
         this.name = param1;
         this.assetManager = param2;
      }
      
      private static function getTextureName(param1:String, param2:EmitterValueObject) : String
      {
         return param1 + "_" + param2.id.toString() + "_";
      }
      
      public function loadSim(param1:ByteArray) : void
      {
         var _loc4_:String = null;
         var _loc5_:String = null;
         var _loc6_:ByteArray = null;
         var _loc7_:RawEmitterData = null;
         this.projectLoaded = false;
         this.sequenceLoader.clearAllJobs();
         this.loadedZip = new §_-Lr§();
         this.loadedZip.loadBytes(param1);
         this.descriptorJSON = JSON.parse(this.loadedZip.§_-if§(DESCRIPTOR_FILENAME).§_-83v§());
         if(this.descriptorJSON == null)
         {
            throw new Error(DESCRIPTOR_FILENAME + " not found.");
         }
         if(parseFloat(this.descriptorJSON.version) < Stardust.VERSION)
         {
         }
         var _loc2_:int = 0;
         while(_loc2_ < this.loadedZip.getFileCount())
         {
            _loc4_ = this.loadedZip.§_-k20§(_loc2_).filename;
            if(SDEConstants.isEmitterXMLName(_loc4_))
            {
               _loc5_ = SDEConstants.getEmitterID(_loc4_);
               _loc6_ = this.loadedZip.§_-if§(_loc4_).content;
               _loc7_ = new RawEmitterData();
               _loc7_.emitterID = _loc5_;
               _loc7_.emitterXML = new XML(_loc6_.readUTFBytes(_loc6_.length));
               this.rawEmitterDatas.push(_loc7_);
            }
            _loc2_++;
         }
         var _loc3_:LoadByteArrayJob = this.sequenceLoader.getCompletedJobs().pop();
         this.loadedZip = null;
         this.sequenceLoader.clearAllJobs();
         this.projectLoaded = true;
         dispatchEvent(new Event(Event.COMPLETE));
      }
      
      public function createProjectInstance() : ProjectValueObject
      {
         var _loc2_:RawEmitterData = null;
         var _loc3_:Emitter = null;
         var _loc4_:Emitter = null;
         var _loc5_:EmitterValueObject = null;
         var _loc6_:Vector.<SubTexture> = null;
         var _loc7_:Vector.<Texture> = null;
         var _loc8_:uint = 0;
         var _loc9_:int = 0;
         var _loc10_:Action = null;
         var _loc11_:Spawn = null;
         var _loc12_:EmitterValueObject = null;
         if(!this.projectLoaded)
         {
            throw new Error("ERROR: Project is not loaded, call loadSim(), and then wait for the Event.COMPLETE event.");
         }
         var _loc1_:ProjectValueObject = new ProjectValueObject(parseFloat(this.descriptorJSON.version));
         for each(_loc2_ in this.rawEmitterDatas)
         {
            _loc4_ = EmitterBuilder.buildEmitter(_loc2_.emitterXML,_loc2_.emitterID);
            _loc4_.name = _loc2_.emitterID;
            _loc5_ = new EmitterValueObject(_loc4_);
            _loc1_.emitters[_loc2_.emitterID] = _loc5_;
            _loc6_ = new Vector.<SubTexture>();
            _loc7_ = this.assetManager.getTextures(getTextureName(this.name,_loc5_));
            _loc8_ = uint(_loc7_.length);
            _loc9_ = 0;
            while(_loc9_ < _loc8_)
            {
               _loc6_.push(_loc7_[_loc9_]);
               _loc9_++;
            }
            StarlingHandler(_loc5_.emitter.particleHandler).setTextures(_loc6_);
         }
         for each(_loc3_ in _loc1_.emittersArr)
         {
            for each(_loc10_ in _loc3_.actions)
            {
               if(_loc10_ is Spawn && Boolean(Spawn(_loc10_).spawnerEmitterId))
               {
                  _loc11_ = Spawn(_loc10_);
                  for each(_loc12_ in _loc1_.emitters)
                  {
                     if(_loc11_.spawnerEmitterId == _loc12_.id)
                     {
                        _loc11_.spawnerEmitter = _loc12_.emitter;
                     }
                  }
               }
            }
         }
         return _loc1_;
      }
      
      public function dispose() : void
      {
         this.sequenceLoader.clearAllJobs();
         this.projectLoaded = false;
         this.descriptorJSON = null;
         this.rawEmitterDatas = null;
      }
   }
}

class RawEmitterData
{
   
   public var emitterID:String;
   
   public var emitterXML:XML;
   
   public function RawEmitterData()
   {
      super();
   }
}
