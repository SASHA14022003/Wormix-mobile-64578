package stardust
{
   import stardust.player.ICustomSimPlayer;
   import starling.core.Starling;
   import starling.events.EnterFrameEvent;
   
   public class StardustSimPlayersManager
   {
      
      private var simPlayers:Vector.<ICustomSimPlayer>;
      
      private var simPlayersCount:int;
      
      public function StardustSimPlayersManager()
      {
         super();
         this.simPlayers = new Vector.<ICustomSimPlayer>(0);
         this.simPlayersCount = 0;
      }
      
      public function dispose() : void
      {
         this.simPlayers = null;
         Starling.current.stage.removeEventListener(EnterFrameEvent.ENTER_FRAME,this.onEnterFrame);
      }
      
      public function addSimPlayer(param1:ICustomSimPlayer) : void
      {
         this.simPlayers.push(param1);
         if(this.simPlayersCount++ == 0)
         {
            Starling.current.stage.addEventListener(EnterFrameEvent.ENTER_FRAME,this.onEnterFrame);
         }
      }
      
      public function removeSimPlayer(param1:ICustomSimPlayer) : void
      {
         var _loc2_:int = int(this.simPlayers.indexOf(param1));
         if(_loc2_ > -1)
         {
            this.simPlayers.removeAt(_loc2_);
            if(--this.simPlayersCount == 0)
            {
               Starling.current.stage.removeEventListener(EnterFrameEvent.ENTER_FRAME,this.onEnterFrame);
            }
         }
      }
      
      private function onEnterFrame(param1:EnterFrameEvent) : void
      {
         var _loc2_:* = this.simPlayersCount;
         while(_loc2_--)
         {
            this.simPlayers[_loc2_].stepSimulation(param1.passedTime);
         }
      }
   }
}

