package stardust.player
{
   import §_-G16§.§_-K2m§;
   import com.funkypandagame.stardustplayer.project.ProjectValueObject;
   import idv.cjcat.stardustextended.emitters.Emitter;
   import idv.cjcat.stardustextended.handlers.starling.StarlingHandler;
   import starling.display.DisplayObjectContainer;
   import starling.events.EventDispatcher;
   
   public class AbstractSimPlayer extends EventDispatcher implements ICustomSimPlayer
   {
      
      protected var _project:ProjectValueObject;
      
      protected var _renderTarget:DisplayObjectContainer;
      
      protected var _active:Boolean;
      
      protected var _emittersVec:Vector.<Emitter>;
      
      protected var _playerPoolLink:§_-K2m§;
      
      protected var _lifeTime:Number;
      
      protected var _maxLifetime:Number = 0;
      
      public function AbstractSimPlayer()
      {
         super();
      }
      
      public function dispose() : void
      {
         this._project = null;
         this._renderTarget = null;
         this._emittersVec = null;
         this._playerPoolLink = null;
      }
      
      public function setProject(param1:ProjectValueObject) : void
      {
         if(param1 == null)
         {
         }
         this._project = param1;
         this._active = true;
         this.setupSimulation();
      }
      
      public function setRenderTarget(param1:DisplayObjectContainer) : void
      {
         if(param1 == null)
         {
         }
         this._renderTarget = param1;
         this.setupSimulation();
      }
      
      protected function setupSimulation() : void
      {
         if(this._renderTarget == null || this._project == null)
         {
            return;
         }
         this.setupSimulationInternal();
      }
      
      protected function setupSimulationInternal() : void
      {
         var _loc1_:Emitter = null;
         this._lifeTime = 0;
         this._emittersVec = this._project.emittersArr;
         var _loc2_:* = int(this._emittersVec.length);
         while(_loc2_--)
         {
            _loc1_ = this._emittersVec[_loc2_];
            _loc1_.active = true;
            StarlingHandler(_loc1_.particleHandler).container = this._renderTarget as DisplayObjectContainer;
         }
      }
      
      public function getProject() : ProjectValueObject
      {
         return this._project;
      }
      
      public function stepSimulation(param1:Number) : void
      {
         if(this._maxLifetime > 0)
         {
            if(this._lifeTime < this._maxLifetime)
            {
               this._lifeTime += param1;
            }
            else if(this._active)
            {
               this.deactivate();
            }
         }
      }
      
      public function activate() : void
      {
         this._active = true;
      }
      
      public function deactivate() : void
      {
         var _loc1_:Emitter = null;
         this._active = false;
         for each(_loc1_ in this._project.emittersArr)
         {
            if(_loc1_)
            {
               _loc1_.active = false;
            }
         }
      }
      
      public function get playerPoolLink() : §_-K2m§
      {
         return this._playerPoolLink;
      }
      
      public function set playerPoolLink(param1:§_-K2m§) : void
      {
         this._playerPoolLink = param1;
      }
      
      public function setPosition(param1:int, param2:int) : void
      {
      }
      
      public function get maxLifetime() : Number
      {
         return this._maxLifetime;
      }
      
      public function set maxLifetime(param1:Number) : void
      {
         this._maxLifetime = param1;
      }
      
      public function get emittersVec() : Vector.<Emitter>
      {
         return this._emittersVec;
      }
   }
}

