package stardust.player
{
   import idv.cjcat.stardustextended.emitters.Emitter;
   import idv.cjcat.stardustextended.initializers.PositionAnimated;
   import idv.cjcat.stardustextended.zones.Zone;
   import starling.events.Event;
   
   public class StationarySimPlayer extends AbstractSimPlayer implements ICustomSimPlayer
   {
      
      public function StationarySimPlayer()
      {
         super();
      }
      
      override public function stepSimulation(param1:Number) : void
      {
         if(_project == null || _renderTarget == null)
         {
            throw new Error("The simulation and its render target must be set.");
         }
         super.stepSimulation(param1);
         var _loc2_:* = int(_emittersVec.length);
         while(_loc2_--)
         {
            _emittersVec[_loc2_].step(param1);
         }
         if(!_active && _project.numberOfParticles == 0)
         {
            dispatchEventWith(Event.COMPLETE);
         }
      }
      
      override public function setPosition(param1:int, param2:int) : void
      {
         var _loc3_:Emitter = null;
         var _loc4_:PositionAnimated = null;
         var _loc5_:Zone = null;
         if(_project == null || _renderTarget == null)
         {
            throw new Error("The simulation and its render target must be set.");
         }
         var _loc6_:* = int(_emittersVec.length);
         var _loc7_:* = 0;
         var _loc8_:* = 0;
         while(_loc6_--)
         {
            _loc3_ = _emittersVec[_loc6_];
            _loc7_ = int(_loc3_.initializers.length);
            while(_loc7_--)
            {
               _loc4_ = _loc3_.initializers[_loc7_] as PositionAnimated;
               if(_loc4_)
               {
                  _loc8_ = int(_loc4_.zones.length);
                  while(_loc8_--)
                  {
                     _loc5_ = _loc4_.zones[_loc8_];
                     _loc5_.setPosition(param1,param2);
                  }
               }
            }
         }
      }
   }
}

