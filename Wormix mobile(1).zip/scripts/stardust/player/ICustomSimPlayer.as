package stardust.player
{
   public interface ICustomSimPlayer
   {
      
      function setPosition(param1:int, param2:int) : void;
      
      function stepSimulation(param1:Number) : void;
      
      function activate() : void;
      
      function deactivate() : void;
   }
}

