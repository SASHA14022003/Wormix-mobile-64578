package stardust.player
{
   import idv.cjcat.stardustextended.emitters.Emitter;
   import idv.cjcat.stardustextended.initializers.PositionAnimated;
   import idv.cjcat.stardustextended.zones.Zone;
   import starling.events.Event;
   
   public class MovableSimPlayer extends AbstractSimPlayer
   {
      
      private var x:int = 0;
      
      private var y:int = 0;
      
      private var zones:Vector.<Zone>;
      
      private var zonesCount:int;
      
      private var emittersCount:int;
      
      public function MovableSimPlayer()
      {
         super();
      }
      
      override protected function setupSimulationInternal() : void
      {
         var _loc1_:Emitter = null;
         var _loc2_:PositionAnimated = null;
         super.setupSimulationInternal();
         this.zones = new Vector.<Zone>(0);
         var _loc3_:* = int(_emittersVec.length);
         var _loc4_:* = 0;
         var _loc5_:* = 0;
         while(_loc3_--)
         {
            _loc1_ = _emittersVec[_loc3_];
            _loc4_ = int(_loc1_.initializers.length);
            while(_loc4_--)
            {
               _loc2_ = _loc1_.initializers[_loc4_] as PositionAnimated;
               if(_loc2_)
               {
                  _loc5_ = int(_loc2_.zones.length);
                  while(_loc5_--)
                  {
                     this.zones.push(_loc2_.zones[_loc5_]);
                  }
               }
            }
         }
         this.zonesCount = this.zones.length;
         this.emittersCount = _emittersVec.length;
      }
      
      override public function stepSimulation(param1:Number) : void
      {
         if(_project == null || _renderTarget == null)
         {
            throw new Error("The simulation and its render target must be set.");
         }
         super.stepSimulation(param1);
         var _loc2_:* = this.emittersCount;
         while(_loc2_--)
         {
            _emittersVec[_loc2_].step(param1);
         }
         _loc2_ = int(this.zones.length);
         while(_loc2_--)
         {
            this.zones[_loc2_].setPosition(this.x,this.y);
         }
         if(!_active && _project.numberOfParticles == 0)
         {
            dispatchEventWith(Event.COMPLETE);
         }
      }
      
      override public function setPosition(param1:int, param2:int) : void
      {
         this.x = param1;
         this.y = param2;
      }
   }
}

