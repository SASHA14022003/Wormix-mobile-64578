package §_-J3b§
{
   import §_-A1K§.§_-TA§;
   import §_-A2U§.§_-A23§;
   import §_-DJ§.§_-fH§;
   import §_-L1H§.§_-C3e§;
   import §_-Y1O§.§_-yA§;
   import §_-j1w§.§_-B2i§;
   import §_-k1u§.§_-2m§;
   import §_-k1u§.§_-52D§;
   import §_-k1u§.§_-F3H§;
   import §_-k1u§.§_-H2M§;
   import §_-k1u§.§_-Vr§;
   import §_-k1u§.§_-by§;
   import §_-r1C§.§_-h2B§;
   import flash.utils.Dictionary;
   import flash.utils.IDataOutput;
   import ru.pragmatix.flox.gui.controls.MessageBox;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.ClanServiceResult;
   import ru.pragmatix.wormix.messages.clans.response.treasury.DonateClanResponse;
   import ru.pragmatix.wormix.messages.clans.structures.ClanMemberTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.rewards.§_-d2F§;
   import ru.pragmatix.wormix.model.user.*;
   import ru.pragmatix.wormix.utils.§_-6A§;
   
   public class §_-A1M§ extends PresentBonusPanel
   {
      
      public function §_-A1M§(param1:§_-d2F§)
      {
         super(param1);
      }
      
      override public function hide() : void
      {
         super.hide();
         if(§_-X1j§.§_-p1c§.§_-ba§())
         {
            §_-X1j§.§_-p1c§.§_-F3K§();
         }
      }
   }
}

