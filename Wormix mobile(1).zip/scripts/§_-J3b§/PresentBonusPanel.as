package §_-J3b§
{
   import §_-51W§.§_-SN§;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-L1r§;
   import §_-62§.§_-O2H§;
   import §_-62§.§_-W1r§;
   import §_-62§.§_-gr§;
   import §_-73I§.§_-Y1l§;
   import §_-CF§.§_-E19§;
   import §_-DJ§.§_-73y§;
   import §_-DJ§.§_-Es§;
   import §_-L1H§.§_-C3e§;
   import §_-Nq§.§_-G1J§;
   import §_-Nq§.§_-Ow§;
   import §_-Nq§.§_-s1O§;
   import §_-Nq§.§_-uh§;
   import §_-j22§.§_-5g§;
   import §_-k2s§.§_-8c§;
   import §_-k2s§.§_-C3A§;
   import §_-k2s§.§_-fG§;
   import §_-u2J§.§_-T1K§;
   import §_-zI§.*;
   import feathers.controls.ScrollPolicy;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import feathers.data.ArrayCollection;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.HorizontalLayout;
   import feathers.layout.TiledRowsLayout;
   import feathers.layout.VerticalAlign;
   import feathers.layout.VerticalLayout;
   import flash.utils.ByteArray;
   import flash.utils.IDataOutput;
   import ru.pragmatix.wormix.controller.§_-J2d§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.server.ArenaLocked;
   import ru.pragmatix.wormix.model.items.craft.§_-Y2u§;
   import ru.pragmatix.wormix.model.rewards.§_-d2F§;
   import ru.pragmatix.wormix.model.rewards.§_-qU§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.utils.§_-2t§;
   import ru.pragmatix.wormix.weapons.ammo.AirCatAmmo;
   import ru.pragmatix.wormix.weapons.ammo.DamageType;
   import starling.events.Event;
   
   public class PresentBonusPanel extends §_-73y§
   {
      
      private var §_-32d§:§_-d2F§;
      
      private var binder:Binder = new Binder();
      
      public function PresentBonusPanel(param1:§_-d2F§)
      {
         Application.uiBuilder.create(Application.assetManager.getObject("bonus_panel"),true,this.binder);
         this.§_-32d§ = param1;
         super(this.binder._panel);
         this.destroyOnRemove = true;
      }
      
      override protected function §_-O2y§() : void
      {
         super.§_-O2y§();
         §_-rP§.name = "_content.buttons.okBtn";
         §_-rP§.stringId = §_-s2a§.BUTTON_OK;
         §_-PQ§ = "closeBtn";
      }
      
      override protected function §_-q2a§() : void
      {
         var itemsListLayout:TiledRowsLayout;
         var weaponRendererFactory:Function;
         var equipRendererFactory:Function;
         var reagentRendererFactory:Function;
         var arrayCollection:ArrayCollection;
         var isVisibleDecor:Boolean;
         var count:int = 0;
         var id:int = 0;
         var strId:String = null;
         var moneyListLayout:HorizontalLayout = null;
         var bonusRendererFactory:Function = null;
         var awards:ArrayCollection = null;
         var equipRecord:§_-W1r§ = null;
         var itemRecord:§_-L1r§ = null;
         var copyRec:§_-L1r§ = null;
         var weaponRecord:§_-O2H§ = null;
         var reagentItem:§_-W1r§ = null;
         var reagentRec:§_-gr§ = null;
         super.§_-q2a§();
         (this.binder._content.layout as VerticalLayout).paddingBottom = 20;
         this.binder._title.text = this.§_-32d§.§_-52h§;
         this.binder._description.text = this.§_-32d§.bonusMessage;
         itemsListLayout = new TiledRowsLayout();
         itemsListLayout.gap = 0;
         itemsListLayout.verticalAlign = VerticalAlign.TOP;
         itemsListLayout.horizontalAlign = HorizontalAlign.CENTER;
         itemsListLayout.useSquareTiles = false;
         this.binder._itemsList.layout = itemsListLayout;
         this.binder._itemsList.horizontalScrollPolicy = ScrollPolicy.OFF;
         this.binder._itemsList.verticalScrollPolicy = ScrollPolicy.OFF;
         this.binder._itemsList.itemRendererType = §_-G1J§;
         weaponRendererFactory = function():DefaultListItemRenderer
         {
            return new §_-G1J§();
         };
         equipRendererFactory = function():DefaultListItemRenderer
         {
            return new §_-Ow§();
         };
         reagentRendererFactory = function():DefaultListItemRenderer
         {
            return new §_-uh§();
         };
         this.binder._itemsList.setItemRendererFactoryWithID("record-weapon",weaponRendererFactory);
         this.binder._itemsList.setItemRendererFactoryWithID("record-equip",equipRendererFactory);
         this.binder._itemsList.setItemRendererFactoryWithID("record-reagent",reagentRendererFactory);
         this.binder._itemsList.factoryIDFunction = function(param1:Object, param2:int):String
         {
            var _loc3_:§_-W1r§ = null;
            var _loc4_:§_-8c§ = null;
            if(param1.item is §_-W1r§)
            {
               _loc3_ = param1.item as §_-W1r§;
               if(_loc3_ is §_-O2H§)
               {
                  return "record-weapon";
               }
               if(_loc3_ is §_-L1r§)
               {
                  return "record-equip";
               }
               if(_loc3_ is §_-gr§)
               {
                  return "record-reagent";
               }
            }
            else if(param1.item is §_-8c§)
            {
               _loc4_ = param1.item as §_-8c§;
            }
            return "";
         };
         arrayCollection = new ArrayCollection();
         for(strId in this.§_-32d§.items)
         {
            id = int(int(strId));
            equipRecord = §_-G1p§.§_-d0§(id,Application.userProfile.§_-P2e§());
            if(equipRecord is §_-L1r§)
            {
               count = int(this.§_-32d§.items[id]);
               if(count > 0)
               {
                  itemRecord = equipRecord as §_-L1r§;
                  copyRec = §_-2t§.§_-91M§(itemRecord,count);
                  arrayCollection.push({
                     "item":copyRec,
                     "count":copyRec.§_-n2k§()
                  });
               }
               else
               {
                  arrayCollection.push({"item":equipRecord});
               }
            }
         }
         for(strId in this.§_-32d§.items)
         {
            id = int(int(strId));
            weaponRecord = §_-G1p§.§_-I4§(id);
            if(weaponRecord)
            {
               count = int(this.§_-32d§.items[id]);
               arrayCollection.push({
                  "item":weaponRecord,
                  "count":count
               });
            }
         }
         for(strId in this.§_-32d§.reagents)
         {
            id = int(int(strId));
            reagentItem = §_-Y2u§.§_-k14§(id);
            if(reagentItem)
            {
               reagentRec = new §_-gr§();
               reagentItem.copyTo(reagentRec);
               count = int(this.§_-32d§.reagents[id]);
               arrayCollection.push({
                  "item":reagentRec,
                  "count":count
               });
            }
         }
         this.binder._itemsList.dataProvider = arrayCollection;
         moneyListLayout = new HorizontalLayout();
         moneyListLayout.gap = 5;
         moneyListLayout.horizontalAlign = HorizontalAlign.CENTER;
         moneyListLayout.verticalAlign = VerticalAlign.MIDDLE;
         moneyListLayout.hasVariableItemDimensions = true;
         bonusRendererFactory = function():DefaultListItemRenderer
         {
            return new §_-s1O§();
         };
         this.binder._awardsList.layout = moneyListLayout;
         this.binder._awardsList.itemRendererFactory = bonusRendererFactory;
         awards = new ArrayCollection();
         if(this.§_-32d§.realMoney > 0)
         {
            awards.push({
               "bonusType":§_-E19§.§_-51D§,
               "icon":"icon_ruby",
               "bg":"HolidayBonusPanel_star",
               "bgColor":16760690,
               "count":this.§_-32d§.realMoney
            });
         }
         if(this.§_-32d§.money > 0)
         {
            awards.push({
               "bonusType":§_-E19§.§_-i2d§,
               "icon":"icon_fuzy",
               "bg":"HolidayBonusPanel_star",
               "bgColor":11262790,
               "count":this.§_-32d§.money
            });
         }
         if(this.§_-32d§.reaction > 0)
         {
            awards.push({
               "rewardItem":new §_-fG§(this.§_-32d§.reaction),
               "icon":"ReactionIcon",
               "bg":"HolidayBonusPanel_star",
               "bgColor":8706264,
               "count":this.§_-32d§.reaction
            });
         }
         if(this.§_-32d§.exp > 0)
         {
            awards.push({
               "icon":"ExperienceIcon",
               "count":this.§_-32d§.exp
            });
         }
         if(this.§_-32d§.bonusExp > 0)
         {
            awards.push({
               "icon":"bounusExpIcon",
               "count":this.§_-32d§.bonusExp
            });
         }
         if(this.§_-32d§.battlesCount > 0)
         {
            awards.push({
               "rewardItem":new §_-C3A§(this.§_-32d§.battlesCount,§_-SN§.§_-C39§),
               "bonusType":§_-E19§.§_-qt§,
               "icon":§_-SN§.§_-C39§.iconName,
               "bg":"HolidayBonusPanel_star",
               "bgColor":5554687,
               "count":this.§_-32d§.battlesCount
            });
         }
         if(this.§_-32d§.§_-u28§ > 0)
         {
            awards.push({
               "rewardItem":new §_-C3A§(this.§_-32d§.§_-u28§,§_-SN§.§_-21i§),
               "bonusType":§_-E19§.§_-qt§,
               "icon":§_-SN§.§_-21i§.iconName,
               "bg":"HolidayBonusPanel_star",
               "bgColor":5554687,
               "count":this.§_-32d§.§_-u28§
            });
         }
         if(this.§_-32d§.§_-R2R§ > 0)
         {
            awards.push({
               "rewardItem":new §_-C3A§(this.§_-32d§.§_-R2R§,§_-SN§.§_-X1D§),
               "bonusType":§_-E19§.§_-qt§,
               "icon":§_-SN§.§_-X1D§.iconName,
               "bg":"HolidayBonusPanel_star",
               "bgColor":5554687,
               "count":this.§_-32d§.§_-R2R§
            });
         }
         this.binder._awardsList.dataProvider = awards;
         if(awards.length)
         {
            this.binder._awardsList.parent.swapChildren(this.binder._awardsList,this.binder._itemsList);
         }
         isVisibleDecor = this.§_-32d§.type == §_-qU§.§_-q12§;
         this.binder._decorHeader.visible = isVisibleDecor;
         this.binder._decorStar3.visible = isVisibleDecor;
         this.binder._decorStar4.visible = isVisibleDecor;
      }
      
      override public function hide() : void
      {
         super.hide();
         if(this.§_-32d§.type == §_-qU§.§_-q12§)
         {
            if(§_-X1j§.§_-p1c§.§_-c1Y§())
            {
               §_-X1j§.§_-p1c§.§_-Bl§();
            }
         }
      }
      
      override public function dispose() : void
      {
         super.dispose();
      }
   }
}

import feathers.controls.Label;
import feathers.controls.LayoutGroup;
import feathers.controls.List;
import starling.display.Image;

class Binder
{
   
   public var _panel:LayoutGroup;
   
   public var _content:LayoutGroup;
   
   public var _decorStar3:Image;
   
   public var _decorStar4:Image;
   
   public var _decorHeader:LayoutGroup;
   
   public var _itemsList:List;
   
   public var _awardsList:List;
   
   public var _title:Label;
   
   public var _description:Label;
   
   public function Binder()
   {
      super();
   }
}
