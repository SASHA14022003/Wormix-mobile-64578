package §_-u2J§
{
   import §_-5Y§.§_-Ma§;
   import §_-CF§.§_-E19§;
   import §_-CR§.§_-02k§;
   import §_-DJ§.§_-J2l§;
   import §_-G2H§.*;
   import §_-K35§.§_-S18§;
   import §_-Ta§.*;
   import §_-Z1K§.§_-q24§;
   import §_-k1u§.§_-F3H§;
   import §_-k1u§.§_-Oi§;
   import §_-r1C§.§_-h2B§;
   import feathers.controls.LayoutGroup;
   import ru.pragmatix.flox.social.model.PaymentOption;
   import ru.pragmatix.wormix.controller.§_-I3A§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.weapons.ammo.AtomBomb;
   import starling.events.Event;
   
   public class §_-T1K§
   {
      
      public static const §_-H1X§:String = "SlideMove";
      
      public static const CHANGE_BALANCE:String = "CHANGE_BALANCE";
      
      public static const ACCEPT_BATTLE_OFFER:String = "ACCEPT_BATTLE_OFFER";
      
      public static const DECLINE_BATTLE_OFFER:String = "DECLINE_BATTLE_OFFER";
      
      public static const CANCEL_BATTLE_REQUEST:String = "CANCEL_BATTLE_REQUEST";
      
      public static const SHOW_HINT:String = "SHOW_HINT";
      
      public static const UNIT_INFO_VISIBILITY_CHANGED:String = "UNIT_INFO_VISIBILITY_CHANGED";
      
      public static const TOGGLE_STICKERS:String = "TOGGLE_STICKERS";
      
      public static const TEAM_MEMBER_TYPE_CHANGED:String = "TEAM_MEMBER_TYPE_CHANGED";
      
      public static const BUY_TRIGGERED:String = "BUY_TRIGGERED";
      
      public static const PAGE_CHANGED:String = "PAGE_CHANGED";
      
      public static const ITEM_SELECTED:String = "ITEM_SELECTED";
      
      public function §_-T1K§()
      {
         super();
      }
   }
}

