package §_-u2J§
{
   import §_-P2i§.§_-G3J§;
   import §_-Tm§.§_-RF§;
   import §_-jF§.*;
   import §_-w2i§.§_-Ia§;
   import feathers.controls.List;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import flash.geom.Point;
   import ru.pragmatix.wormix.controls.Command;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.Meteor;
   import ru.pragmatix.wormix.weapons.interfaces.§_-O1c§;
   import starling.animation.Tween;
   import starling.core.Starling;
   import starling.display.Image;
   import starling.events.Touch;
   import starling.events.TouchEvent;
   import starling.events.TouchPhase;
   
   public class §_-A0§
   {
      
      public static const PROGRESS:String = "loading_progress";
      
      public function §_-A0§()
      {
         super();
      }
   }
}

