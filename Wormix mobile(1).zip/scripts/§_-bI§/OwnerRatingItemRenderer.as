package §_-bI§
{
   import feathers.controls.List;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import ru.pragmatix.wormix.messages.server.GetRatingResult;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.utils.§_-c1S§;
   import starling.utils.ScaleMode;
   
   public class OwnerRatingItemRenderer extends DefaultListItemRenderer
   {
      
      protected static const §_-32o§:String = "player_rating_item_renderer";
      
      protected var binder:Binder;
      
      public function OwnerRatingItemRenderer()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         itemHasLabel = false;
         itemHasIcon = false;
         itemHasAccessory = false;
         isQuickHitAreaEnabled = true;
         this.binder = new Binder();
         var _loc1_:Object = Application.assetManager.getObject(§_-32o§);
         Application.uiBuilder.create(_loc1_,true,this.binder);
         defaultAccessory = this.binder._container;
         this.binder._posDeltaIcon.maintainAspectRatio = true;
         this.binder._posDeltaIcon.scaleMode = ScaleMode.SHOW_ALL;
      }
      
      override protected function commitData() : void
      {
         var _loc1_:UserProfile = null;
         var _loc2_:GetRatingResult = null;
         if(Boolean(_data) && Boolean(_data.owner))
         {
            _loc1_ = _data.owner as UserProfile;
            _loc2_ = _data.result as GetRatingResult;
            this.binder._name.text = _loc1_.getCharName();
            this.binder._ratingValue.text = _loc2_.rating.toString();
            §_-c1S§.§_-MU§(_loc2_.place,this.binder._posValue,null);
            §_-c1S§.§_-62q§(_loc2_.place,_loc2_.oldPlace,this.binder._posDeltaValue,20,this.binder._posDeltaIcon,false);
         }
         else
         {
            this.binder._name.text = "";
            this.binder._ratingValue.text = "";
            this.binder._posValue.text = "";
            this.binder._posDeltaValue.text = "";
            this.binder._posDeltaIcon.source = "";
         }
      }
      
      override protected function draw() : void
      {
         super.draw();
         if(isInvalid(INVALIDATION_FLAG_SIZE) && Boolean(_owner))
         {
            this.binder._container.width = _owner.width;
         }
      }
      
      override public function set owner(param1:List) : void
      {
         super.owner = param1;
         invalidate(INVALIDATION_FLAG_SIZE);
      }
   }
}

import feathers.controls.ImageLoader;
import feathers.controls.Label;
import feathers.controls.LayoutGroup;

class Binder
{
   
   public var _container:LayoutGroup;
   
   public var _posDeltaIcon:ImageLoader;
   
   public var _posValue:Label;
   
   public var _posDeltaValue:Label;
   
   public var _name:Label;
   
   public var _ratingValue:Label;
   
   public function Binder()
   {
      super();
   }
}
