package §_-bI§
{
   import §_-Vg§.§_-M11§;
   import feathers.controls.List;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.utils.§_-c1S§;
   import starling.utils.ScaleMode;
   
   public class ClanRatingItemRenderer extends DefaultListItemRenderer
   {
      
      private static const §_-32o§:String = "clan_rating_item_renderer";
      
      private var binder:Binder;
      
      private var clanEmblem:§_-M11§;
      
      public function ClanRatingItemRenderer()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         itemHasLabel = false;
         itemHasIcon = false;
         itemHasAccessory = false;
         isQuickHitAreaEnabled = true;
         this.binder = new Binder();
         var _loc1_:Object = Application.assetManager.getObject(§_-32o§);
         Application.uiBuilder.create(_loc1_,true,this.binder);
         defaultAccessory = this.binder._container;
         this.binder._posDeltaIcon.maintainAspectRatio = true;
         this.binder._posDeltaIcon.scaleMode = ScaleMode.SHOW_ALL;
         this.clanEmblem = new §_-M11§();
         this.clanEmblem.size = this.binder._emblem.height;
         this.binder._emblem.addChild(this.clanEmblem);
         height = 50;
      }
      
      override protected function commitData() : void
      {
         var _loc1_:ClanTO = _data ? _data.clan as ClanTO : null;
         var _loc2_:int = _data ? int(_data.oldPlace) : 0;
         if(_loc1_)
         {
            this.binder._name.text = _loc1_.name;
            this.binder._ratingValue.text = _loc1_.seasonRating.toString();
            this.binder._capacity.text = _loc1_.getCapacityWithSize();
            this.clanEmblem.§_-6B§ = _loc1_.emblem;
            §_-c1S§.§_-MU§(_loc1_.topPlace,this.binder._posValue,null);
            §_-c1S§.§_-62q§(_loc1_.topPlace,_loc2_,this.binder._posDeltaValue,20,this.binder._posDeltaIcon,false);
         }
         else
         {
            this.binder._name.text = "";
            this.binder._ratingValue.text = "";
            this.binder._capacity.text = "";
            this.clanEmblem.§_-6B§ = null;
            this.binder._posValue.text = "";
            this.binder._posDeltaValue.text = "";
            this.binder._posDeltaIcon.source = "";
         }
      }
      
      override protected function draw() : void
      {
         super.draw();
         if(isInvalid(INVALIDATION_FLAG_SIZE) && Boolean(_owner))
         {
            this.binder._container.width = _owner.width;
         }
      }
      
      override public function set owner(param1:List) : void
      {
         super.owner = param1;
         invalidate(INVALIDATION_FLAG_SIZE);
      }
   }
}

import feathers.controls.ImageLoader;
import feathers.controls.Label;
import feathers.controls.LayoutGroup;
import starling.display.Image;

class Binder
{
   
   public var _container:LayoutGroup;
   
   public var _emblem:LayoutGroup;
   
   public var _posDeltaIcon:ImageLoader;
   
   public var _posValue:Label;
   
   public var _posDeltaValue:Label;
   
   public var _name:Label;
   
   public var _capacity:Label;
   
   public var _ratingValue:Label;
   
   public var _ratingIcon:Image;
   
   public function Binder()
   {
      super();
   }
}
