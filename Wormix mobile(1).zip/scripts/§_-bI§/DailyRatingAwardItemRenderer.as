package §_-bI§
{
   import §_-533§.§_-c2b§;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-zF§;
   import §_-TF§.§_-Z1U§;
   import §_-TF§.§_-q1j§;
   import §_-TF§.§_-y2n§;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import feathers.layout.RelativePosition;
   import ru.pragmatix.wormix.gui.menu.§_-3m§;
   import starling.display.DisplayObject;
   import starling.utils.AssetManager;
   import starling.utils.ScaleMode;
   
   public class DailyRatingAwardItemRenderer extends DefaultListItemRenderer implements §_-Z1U§
   {
      
      private static const §_-32o§:String = "top_award_item_renderer";
      
      private static const §_-13m§:String = "TopAwardCell_gold";
      
      private static const §_-R2r§:String = "TopAwardCell_silver";
      
      private static const §_-71Y§:String = "TopAwardCell_bronse";
      
      private var itemIcon:§_-3m§;
      
      private var binder:Binder;
      
      public function DailyRatingAwardItemRenderer()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         itemHasIcon = false;
         itemHasLabel = false;
         itemHasAccessory = false;
         isQuickHitAreaEnabled = true;
         this.binder = new Binder();
         var _loc1_:Object = Application.assetManager.getObject(§_-32o§);
         Application.uiBuilder.create(_loc1_,true,this.binder);
         this.binder._back.maintainAspectRatio = true;
         this.binder._back.scaleMode = ScaleMode.SHOW_ALL;
         this.itemIcon = new §_-3m§(this.binder._iconContainer);
         defaultAccessory = this.binder._container;
         §_-q1j§.register(this);
      }
      
      override public function dispose() : void
      {
         super.dispose();
         §_-q1j§.remove(this);
      }
      
      override protected function commitData() : void
      {
         var _loc2_:AssetManager = null;
         var _loc3_:§_-zF§ = null;
         var _loc1_:§_-c2b§ = _data as §_-c2b§;
         if(_loc1_)
         {
            _loc2_ = Application.assetManager;
            if(_index == 0)
            {
               this.binder._back.source = _loc2_.getTexture(§_-13m§);
            }
            else if(_index == 1)
            {
               this.binder._back.source = _loc2_.getTexture(§_-R2r§);
            }
            else if(_index == 2)
            {
               this.binder._back.source = _loc2_.getTexture(§_-71Y§);
            }
            else
            {
               this.binder._back.source = "";
            }
            if(_loc1_.§_-D2R§ == 0)
            {
               this.binder._label.text = _loc1_.§_-S2f§.toString();
            }
            else
            {
               this.binder._label.text = _loc1_.§_-S2f§.toString() + "-" + _loc1_.§_-D2R§.toString();
            }
            _loc3_ = §_-G1p§.§_-12J§(_loc1_.itemId,Application.userProfile.§_-P2e§());
            this.itemIcon.setItem(_loc3_);
         }
         else
         {
            this.binder._back.source = "";
            this.binder._label.text = "";
         }
      }
      
      public function getOrigin() : DisplayObject
      {
         return this;
      }
      
      public function §_-8I§() : DisplayObject
      {
         return §_-y2n§.§_-i1N§.§_-8N§(this.itemIcon.getItem());
      }
      
      public function §_-52e§() : Object
      {
         return new <String>[RelativePosition.BOTTOM,RelativePosition.RIGHT,RelativePosition.LEFT];
      }
   }
}

import feathers.controls.ImageLoader;
import feathers.controls.Label;
import feathers.controls.LayoutGroup;

class Binder
{
   
   public var _container:LayoutGroup;
   
   public var _iconContainer:LayoutGroup;
   
   public var _back:ImageLoader;
   
   public var _label:Label;
   
   public function Binder()
   {
      super();
   }
}
