package §_-Jd§
{
   import §_-21p§.§_-4w§;
   import §_-j2R§.§_-E1u§;
   import §_-j2R§.§_-v1l§;
   
   public class BonusBuff extends BonusStat
   {
      
      public static const NAME:String = "BonusBuff";
      
      protected var §_-sX§:§_-v1l§;
      
      public function BonusBuff()
      {
         super(NAME);
      }
      
      override public function add(param1:§_-4w§) : void
      {
         super.add(param1);
         if(count.value == 1)
         {
            activate(param1);
            owner.buffs.place(this.§_-sX§);
         }
         else if(this.§_-sX§ is §_-E1u§)
         {
            §_-E1u§(this.§_-sX§).setValue(getValue());
         }
      }
      
      override public function remove(param1:§_-4w§) : void
      {
         super.remove(param1);
         if(count.value == 0 || owner.disposed)
         {
            this.deactivate(param1);
         }
         else
         {
            owner.buffs.getBuff(this.§_-sX§.getName()).§_-W1g§(-param1.getValue());
         }
      }
      
      override protected function deactivate(param1:§_-4w§) : void
      {
         owner.buffs.§_-e1z§(this.§_-sX§.getName());
      }
   }
}

