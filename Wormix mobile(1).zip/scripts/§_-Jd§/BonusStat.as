package §_-Jd§
{
   import §_-21p§.§_-4w§;
   import §_-A1K§.§_-TA§;
   
   public class BonusStat extends §_-11K§
   {
      
      public static const NAME:String = "BonusStat";
      
      protected var §_-B1H§:§_-TA§ = new §_-TA§(0);
      
      public function BonusStat(param1:String = "BonusStat")
      {
         super(param1);
      }
      
      override public function add(param1:§_-4w§) : void
      {
         super.add(param1);
         this.§_-B1H§.value += param1.getValue();
      }
      
      override public function remove(param1:§_-4w§) : void
      {
         super.remove(param1);
         this.§_-B1H§.value -= param1.getValue();
      }
      
      public function getValue() : int
      {
         return this.§_-B1H§.value;
      }
   }
}

