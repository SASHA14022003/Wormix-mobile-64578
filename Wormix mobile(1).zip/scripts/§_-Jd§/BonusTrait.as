package §_-Jd§
{
   import §_-21p§.§_-4w§;
   import §_-Y1O§.*;
   import ru.pragmatix.wormix.objects.§_-01J§;
   
   public class BonusTrait extends §_-11K§
   {
      
      public static const NAME:String = "BonusTrait";
      
      public function BonusTrait()
      {
         super(NAME);
      }
      
      override public function add(param1:§_-4w§) : void
      {
         super.add(param1);
         if(count.value == 1)
         {
            activate(param1);
         }
      }
      
      override public function remove(param1:§_-4w§) : void
      {
         super.remove(param1);
         if(count.value == 0)
         {
            deactivate(param1);
         }
      }
   }
}

