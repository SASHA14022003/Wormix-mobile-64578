package §_-Jd§
{
   import ru.pragmatix.wormix.objects.§_-01J§;
   
   public interface §_-g2F§
   {
      
      function applyOnUnit(param1:§_-01J§) : void;
   }
}

