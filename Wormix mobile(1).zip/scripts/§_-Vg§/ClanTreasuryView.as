package §_-Vg§
{
   import §_-A2U§.§_-A23§;
   import §_-x2Q§.§_-dU§;
   import §_-zI§.§_-8D§;
   import §_-zI§.§_-X1q§;
   import §_-zI§.§_-sI§;
   import feathers.controls.text.TextFormatUtils;
   import feathers.layout.AnchorLayout;
   import feathers.layout.VerticalAlign;
   import feathers.themes.FontColor;
   import feathers.themes.FontName;
   import feathers.themes.FontSize;
   import flash.text.TextFormatAlign;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.structures.ClanMemberTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.utils.StringUtil;
   import ru.pragmatix.wormix.utils.§_-6A§;
   import starling.events.Event;
   
   public class ClanTreasuryView extends §_-03W§
   {
      
      public static const §_-f29§:String = "donation";
      
      public static const §_-Y1I§:String = "medals-change";
      
      public static const §_-V2o§:String = "medal-cost-change";
      
      private var binder:Binder;
      
      private var §_-Hi§:int = 0;
      
      private var §_-c2h§:§_-sI§;
      
      private var §_-93m§:ClanTO;
      
      private var §_-z2g§:UserProfile;
      
      public function ClanTreasuryView()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         this.layout = new AnchorLayout();
         this.binder = new Binder();
         var _loc1_:Object = Application.assetManager.getObject("clan_treasury_view");
         Application.uiBuilder.create(_loc1_,true,this.binder);
         addChild(this.binder._container);
         this.binder._medalPriceInput.restrict = "0-3";
         this.binder._medalPriceInput.maxChars = 1;
         this.binder._medalPriceInput.verticalAlign = VerticalAlign.MIDDLE;
         this.binder._medalPriceInput.paddingRight = 5;
         this.binder._medalPriceInput.promptProperties.textFormat = TextFormatUtils.createFlashTextFormat(FontName.WORMIX_NORMAL,FontSize.BIG,FontColor.TAB_UNSELECTED,TextFormatAlign.RIGHT);
         this.binder._medalPriceInput.textEditorProperties.textAlign = TextFormatAlign.RIGHT;
         this.binder._medalPriceInput.textEditorProperties.color = FontColor.TAB_UNSELECTED;
         this.binder._clanDonationButtton.addEventListener(Event.TRIGGERED,this.§_-V11§);
         this.binder._medalPriceSaveButtton.addEventListener(Event.TRIGGERED,this.§_-D34§);
         this.binder._medalChangeButton.addEventListener(Event.TRIGGERED,this.§_-v1Y§);
         this.binder._medalPriceInput.addEventListener(Event.CHANGE,this.§_-n0§);
         this.binder._treasuryValue.text = "";
         this.binder._medalsValue.text = "";
         this.binder._nextMedalValue.text = "";
      }
      
      override public function dispose() : void
      {
         super.dispose();
         this.binder._clanDonationButtton.removeEventListener(Event.TRIGGERED,this.§_-V11§);
         this.binder._medalPriceSaveButtton.removeEventListener(Event.TRIGGERED,this.§_-D34§);
         this.binder._medalChangeButton.removeEventListener(Event.TRIGGERED,this.§_-v1Y§);
         this.binder._medalPriceInput.removeEventListener(Event.CHANGE,this.§_-n0§);
      }
      
      private function §_-V11§(param1:Event) : void
      {
         dispatchEventWith(§_-f29§);
      }
      
      private function §_-D34§(param1:Event) : void
      {
         dispatchEventWith(§_-V2o§,false,int(this.binder._medalPriceInput.text));
      }
      
      private function §_-v1Y§(param1:Event) : void
      {
         dispatchEventWith(§_-Y1I§,false,this.§_-Hi§);
      }
      
      public function setData(param1:ClanTO, param2:UserProfile, param3:§_-sI§) : void
      {
         this.§_-93m§ = param1;
         this.§_-z2g§ = param2;
         this.§_-c2h§ = param3;
         invalidate(INVALIDATION_FLAG_DATA);
      }
      
      override protected function draw() : void
      {
         var _loc1_:ClanMemberTO = null;
         var _loc2_:int = 0;
         var _loc3_:Boolean = false;
         var _loc4_:int = 0;
         var _loc5_:Boolean = false;
         var _loc6_:int = 0;
         var _loc7_:uint = 0;
         var _loc8_:int = 0;
         var _loc9_:Boolean = false;
         var _loc10_:int = 0;
         var _loc11_:String = null;
         var _loc12_:int = 0;
         var _loc13_:Boolean = false;
         var _loc14_:int = 0;
         var _loc15_:Boolean = false;
         if(this.§_-93m§)
         {
            if(isInvalid(INVALIDATION_FLAG_DATA))
            {
               _loc1_ = §_-6A§.§_-62r§(this.§_-z2g§,this.§_-93m§);
               _loc2_ = _loc1_.seasonRating - _loc1_.cashedMedals * this.§_-c2h§.medalRatingChangeValue;
               _loc3_ = this.§_-z2g§.§_-ia§() && this.§_-z2g§.clanMember.clanId == this.§_-93m§.id;
               _loc4_ = this.§_-z2g§.clanMember.rank;
               _loc5_ = _loc3_ && _loc4_ == §_-X1q§.§_-O2V§;
               _loc6_ = _loc2_ < 0 ? _loc2_ : 0;
               _loc2_ = _loc2_ > 0 ? _loc2_ : 0;
               _loc7_ = _loc2_ / this.§_-c2h§.medalRatingChangeValue;
               _loc8_ = _loc2_ - _loc7_ * this.§_-c2h§.medalRatingChangeValue;
               this.binder._medalsValue.text = this.§_-93m§.cashedMedals.toString();
               this.binder._nextMedalValue.text = int(_loc8_) + " / " + int(this.§_-c2h§.medalRatingChangeValue - _loc6_);
               this.binder._medalPriceInput.text = this.§_-93m§.medalPrice.toString();
               this.binder._treasuryValue.text = this.§_-93m§.treasury.toString();
               _loc9_ = _loc5_ && this.§_-93m§.medalPrice < this.§_-c2h§.medalPriceMax;
               this.binder._medalPriceInput.isEditable = _loc9_;
               this.binder._medalPriceInput.isSelectable = _loc9_;
               _loc10_ = this.§_-93m§.medalPrice * _loc7_;
               _loc10_ = _loc10_ > this.§_-93m§.treasury ? this.§_-93m§.treasury : _loc10_;
               this.§_-Hi§ = this.§_-93m§.medalPrice > 0 ? int(_loc10_ / this.§_-93m§.medalPrice) : 0;
               this.binder._medalsValue.text = this.§_-Hi§ > 0 ? String(this.§_-Hi§) + (this.§_-Hi§ < _loc7_ ? " (" + String(_loc7_) + ")" : "") : String(_loc7_);
               this.binder._medalChangeButton.isEnabled = this.§_-Hi§ > 0;
               invalidate(§_-dU§.§_-h26§);
               invalidate(§_-dU§.§_-i1t§);
            }
            if(isInvalid(§_-dU§.§_-i1t§))
            {
               _loc11_ = this.binder._medalPriceInput.text;
               _loc12_ = int(int(_loc11_));
               _loc13_ = _loc12_ > this.§_-93m§.medalPrice && _loc12_ <= this.§_-c2h§.medalPriceMax;
               _loc14_ = _loc12_ * this.§_-c2h§.medalDetermination;
               _loc15_ = §_-A23§.userClan.treasury >= _loc14_;
               this.binder._medalPriceSaveButtton.isEnabled = _loc13_ && _loc15_;
            }
         }
         if(isInvalid(§_-dU§.§_-h26§))
         {
            this.binder._treasuryLabel.text = §_-s2a§.§_-K3t§("CLAN_TREASURY_LABEL") + ":";
            this.binder._treasuryInfoTip1.text = StringUtil.format("CLAN_TREASURY_PAY_NOTIFY_BONUS",{"value":§_-8D§.§_-n2I§});
            this.binder._treasuryInfoTip2.text = StringUtil.format("CLAN_TREASURY_PAY_NOTIFY_FIRE",{"value":§_-8D§.§_-n2I§});
            this.binder._medalsLabel.text = §_-s2a§.§_-K3t§("MEDAL_COLLECT_LABEL");
            this.binder._madalInfoTip.text = StringUtil.format("MEDAL_COLLECT_NOTIFY",{"count":§_-8D§.§_-H3l§});
            this.binder._nextMedalLabel.text = §_-s2a§.§_-K3t§("MEDAL_RATE_NEXT_LABEL");
            this.binder._medalPriceLabel.text = §_-s2a§.§_-K3t§("MEDAL_COST_LABEL");
            this.binder._medalPriceInfoTip1.text = StringUtil.format("MEDAL_COST_NOTIFY",{
               "min":§_-8D§.§_-R14§,
               "max":§_-8D§.§_-k15§,
               "count":§_-8D§.§_-G2p§
            });
            this.binder._clanDonationButtton.label = §_-s2a§.§_-K3t§("CLAN_TREASURY_PAY_BTN");
            this.binder._medalChangeButton.label = §_-s2a§.§_-K3t§("CLAN_EXCHANGE_MEDAL_FOR");
            this.binder._medalPriceSaveButtton.label = §_-s2a§.§_-K3t§(§_-s2a§.BUTTON_SAVE);
         }
         super.draw();
      }
      
      private function §_-n0§(param1:Event) : void
      {
         invalidate(§_-dU§.§_-i1t§);
      }
   }
}

import feathers.controls.Button;
import feathers.controls.Label;
import feathers.controls.LayoutGroup;
import feathers.controls.TextInput;

class Binder
{
   
   public var _container:LayoutGroup;
   
   public var _treasuryLabel:Label;
   
   public var _treasuryInfoTip1:Label;
   
   public var _treasuryInfoTip2:Label;
   
   public var _medalsLabel:Label;
   
   public var _nextMedalLabel:Label;
   
   public var _madalInfoTip:Label;
   
   public var _medalPriceLabel:Label;
   
   public var _medalPriceInfoTip1:Label;
   
   public var _treasuryValue:Label;
   
   public var _medalsValue:Label;
   
   public var _nextMedalValue:Label;
   
   public var _medalPriceInput:TextInput;
   
   public var _clanDonationButtton:Button;
   
   public var _medalChangeButton:Button;
   
   public var _medalPriceSaveButtton:Button;
   
   public function Binder()
   {
      super();
   }
}
