package §_-Vg§
{
   import §_-E1N§.§_-H1p§;
   import §_-L1w§.§_-CD§;
   import §_-r1C§.§_-h2B§;
   import §_-x2Q§.§_-dU§;
   import §_-zI§.§_-X1q§;
   import §_-zI§.§_-sI§;
   import feathers.controls.Button;
   import feathers.controls.ScrollPolicy;
   import feathers.controls.text.TextFormatUtils;
   import feathers.events.FeathersEventType;
   import feathers.layout.AnchorLayout;
   import feathers.layout.VerticalAlign;
   import feathers.themes.FontColor;
   import feathers.themes.FontName;
   import feathers.themes.FontSize;
   import feathers.themes.styles.AlternateScrollBarStyles;
   import flash.text.TextFormatAlign;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import starling.events.Event;
   import starling.utils.Color;
   
   public class ClanEditView extends §_-03W§
   {
      
      public static const EDIT_EMBLEM:String = "emblem-edit";
      
      public static const §_-e1D§:String = "change-name";
      
      public static const §_-hP§:String = "change-description";
      
      public static const §_-Y2n§:String = "change-emblem";
      
      public static const §_-v2p§:String = "change-join-rating";
      
      public static const §_-vv§:String = "change-exit-type";
      
      public static const §_-xn§:String = "change-capacity";
      
      private var binder:Binder;
      
      private var §_-S1L§:Vector.<Button>;
      
      private var §_-fY§:§_-M11§;
      
      private var §_-c2h§:§_-sI§;
      
      private var §_-63q§:§_-H1p§;
      
      private var §_-z2g§:UserProfile;
      
      private var _clanName:String;
      
      private var §_-B3G§:String;
      
      private var §_-qq§:Vector.<uint>;
      
      private var §_-D27§:Vector.<uint>;
      
      private var §_-k2y§:int;
      
      private var §_-W29§:Boolean;
      
      private var §_-R2z§:int;
      
      private var §_-u1O§:Boolean = false;
      
      private var §_-I1G§:Boolean;
      
      private var §_-L3J§:int;
      
      private var §_-y23§:Boolean;
      
      public function ClanEditView()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         this.layout = new AnchorLayout();
         this.binder = new Binder();
         var _loc1_:Object = Application.assetManager.getObject("clan_edit_panel");
         Application.uiBuilder.create(_loc1_,true,this.binder);
         addChild(this.binder._panel);
         this.binder._panel.customVerticalScrollBarStyleName = AlternateScrollBarStyles.SIMPLE_NORMAL;
         this.binder._panel.verticalScrollPolicy = ScrollPolicy.AUTO;
         this.binder._saveNameButton.isEnabled = false;
         this.binder._saveDescButton.isEnabled = false;
         this.binder._saveEmblemButton.isEnabled = false;
         this.binder._saveJoinTypeButton.isEnabled = false;
         this.binder._saveExitTypeButton.isEnabled = false;
         this.§_-fY§ = new §_-M11§();
         this.§_-fY§.size = this.binder._clanEmblemContainer.height;
         this.binder._clanEmblemContainer.addChild(this.§_-fY§);
         this.binder._clanNameInput.promptProperties.textFormat = TextFormatUtils.createFlashTextFormat(FontName.WORMIX_NORMAL,FontSize.NORMAL,FontColor.TAB_UNSELECTED,TextFormatAlign.LEFT);
         this.binder._clanNameInput.textEditorProperties.color = FontColor.TAB_UNSELECTED;
         this.binder._clanNameInput.textEditorProperties.textAlign = TextFormatAlign.LEFT;
         this.binder._clanNameInput.verticalAlign = VerticalAlign.MIDDLE;
         this.binder._clanNameInput.text = "";
         this.binder._clanNameInput.paddingLeft = 5;
         this.binder._clanDescInput.text = "";
         this.binder._clanDescInput.padding = 5;
         this.binder._minJoinRatingInput.promptProperties.textFormat = TextFormatUtils.createFlashTextFormat(FontName.WORMIX_NORMAL,FontSize.NORMAL,FontColor.TAB_UNSELECTED,TextFormatAlign.LEFT);
         this.binder._minJoinRatingInput.textEditorProperties.color = FontColor.TAB_UNSELECTED;
         this.binder._minJoinRatingInput.textEditorProperties.textAlign = TextFormatAlign.LEFT;
         this.binder._minJoinRatingInput.verticalAlign = VerticalAlign.MIDDLE;
         this.binder._minJoinRatingInput.restrict = "0-9";
         this.binder._minJoinRatingInput.maxChars = 7;
         this.binder._minJoinRatingInput.text = "";
         this.binder._minJoinRatingInput.paddingLeft = 5;
         this.§_-S1L§ = new <Button>[this.binder._clanEmblemEditButton,this.binder._saveNameButton,this.binder._saveDescButton,this.binder._saveEmblemButton,this.binder._saveJoinTypeButton,this.binder._saveExitTypeButton,this.binder._saveCapacityButton,this.binder._prevJoinTypeButton,this.binder._nextJoinTypeButton,this.binder._prevExitTypeButton,this.binder._nextExitTypeButton];
         this.§_-4§();
         this.binder._clanNameInput.addEventListener(Event.CHANGE,this.§_-23B§);
         this.binder._clanDescInput.addEventListener(Event.CHANGE,this.§_-NW§);
         this.binder._minJoinRatingInput.addEventListener(Event.CHANGE,this.§_-r1I§);
         this.binder._minJoinRatingInput.addEventListener(FeathersEventType.FOCUS_OUT,this.§_-21C§);
         this.§_-63q§ = new §_-H1p§(this.binder._allCapacityValue,this.binder._allCapacityAddValue,this.binder._oficersCapacityValue,this.binder._oficersCapacityAddValue,this.binder._saveCapacityButton);
      }
      
      override public function dispose() : void
      {
         super.dispose();
         this.§_-fa§();
         this.binder._clanNameInput.removeEventListener(Event.CHANGE,this.§_-23B§);
         this.binder._clanDescInput.removeEventListener(Event.CHANGE,this.§_-NW§);
         this.binder._minJoinRatingInput.removeEventListener(Event.CHANGE,this.§_-r1I§);
      }
      
      override protected function draw() : void
      {
         var _loc2_:Boolean = false;
         var _loc3_:uint = 0;
         var _loc4_:Boolean = false;
         var _loc5_:Vector.<uint> = null;
         var _loc6_:Vector.<uint> = null;
         var _loc7_:int = 0;
         super.draw();
         if(!this.§_-u1O§)
         {
            return;
         }
         var _loc1_:Boolean = this.§_-z2g§.clanMember.rank == §_-X1q§.§_-O2V§;
         if(isInvalid(INVALIDATION_FLAG_DATA))
         {
            this.binder._clanNameInput.isEnabled = _loc1_;
            this.binder._clanEmblemEditButton.isEnabled = _loc1_;
            this.binder._clanDescInput.isEnabled = _loc1_;
            this.binder._nextJoinTypeButton.isEnabled = _loc1_;
            this.binder._prevJoinTypeButton.isEnabled = _loc1_;
            this.binder._minJoinRatingInput.isEnabled = _loc1_;
            this.binder._nextExitTypeButton.isEnabled = _loc1_;
            this.binder._prevExitTypeButton.isEnabled = _loc1_;
            this.binder._clanNameInput.text = this._clanName;
            this.binder._clanDescInput.text = this.§_-B3G§;
            this.§_-fY§.§_-6B§ = this.§_-D27§;
            this.§_-I1G§ = this.§_-k2y§ > -1;
            this.§_-L3J§ = this.§_-I1G§ ? this.§_-k2y§ : 0;
            this.§_-y23§ = this.§_-W29§;
            this.§_-63q§.§_-N1n§(this.§_-R2z§);
            invalidate(§_-dU§.CLAN_NAME);
            invalidate(§_-dU§.CLAN_DESCRIPTION);
            invalidate(§_-dU§.§_-Mf§);
            invalidate(§_-dU§.§_-M2L§);
            invalidate(§_-dU§.§_-F9§);
            invalidate(§_-dU§.CLAN_EMBLEM);
            invalidate(§_-dU§.§_-h26§);
         }
         if(isInvalid(§_-dU§.CLAN_NAME))
         {
            _loc2_ = this.§_-c2h§.§_-g1F§(this.binder._clanNameInput.text);
            _loc3_ = _loc2_ ? FontColor.TAB_UNSELECTED : Color.RED;
            this.binder._clanNameInput.textEditorProperties.color = _loc3_;
            this.binder._saveNameButton.isEnabled = _loc2_ && this.binder._clanNameInput.text != this._clanName;
         }
         if(isInvalid(§_-dU§.CLAN_DESCRIPTION))
         {
            this.binder._saveDescButton.isEnabled = this.binder._clanDescInput.text != this.§_-B3G§;
         }
         if(isInvalid(§_-dU§.CLAN_EMBLEM))
         {
            _loc4_ = true;
            _loc5_ = this.§_-qq§;
            _loc6_ = this.§_-D27§;
            _loc7_ = 0;
            while(_loc7_ < 4)
            {
               if(_loc5_[_loc7_] != _loc6_[_loc7_])
               {
                  _loc4_ = false;
                  break;
               }
               _loc7_++;
            }
            this.binder._saveEmblemButton.isEnabled = !_loc4_;
         }
         if(isInvalid(§_-dU§.§_-Mf§))
         {
            this.binder._clanJoinType.text = §_-s2a§.§_-K3t§(this.§_-I1G§ ? §_-s2a§.OPEN_CLAN : §_-s2a§.CLOSE_CLAN);
            this.binder._minJoinRatingInput.text = this.§_-I1G§ ? this.§_-L3J§.toString() : "";
            this.binder._minJoinRatingInput.isEditable = this.§_-I1G§;
            this.binder._minJoinRatingInput.isSelectable = this.§_-I1G§;
            invalidate(§_-dU§.§_-Au§);
         }
         if(isInvalid(§_-dU§.§_-Au§))
         {
            if(this.§_-I1G§)
            {
               this.§_-L3J§ = int(this.binder._minJoinRatingInput.text);
            }
            this.binder._saveJoinTypeButton.isEnabled = this.§_-A3C§() != this.§_-k2y§ && _loc1_;
         }
         if(isInvalid(§_-dU§.§_-M2L§))
         {
            this.binder._clanExitType.text = §_-s2a§.§_-K3t§(this.§_-y23§ ? §_-s2a§.CLAN_EXIT_CLOSED : §_-s2a§.CLAN_EXIT_OPENED);
            this.binder._saveExitTypeButton.isEnabled = this.§_-y23§ != this.§_-W29§;
         }
         if(isInvalid(§_-dU§.§_-F9§))
         {
            this.§_-63q§.update();
         }
         if(isInvalid(§_-dU§.§_-h26§))
         {
            this.binder._clanNameLabel.text = §_-s2a§.§_-K3t§(§_-s2a§.CLAN_NAME) + ":";
            this.binder._clanEmblemLabel.text = §_-s2a§.§_-K3t§(§_-s2a§.CLAN_EMBLEM) + ":";
            this.binder._clanDescLabel.text = §_-s2a§.§_-K3t§(§_-s2a§.CLAN_DESCRIPTION) + ":";
            this.binder._clanJoinLabel.text = §_-s2a§.§_-K3t§(§_-s2a§.JOIN_TO_CLAN_LABEL) + ":";
            this.binder._minJoinRatingLabel.text = §_-s2a§.§_-K3t§(§_-s2a§.JOIN_MINIMAL_RATING) + ":";
            this.binder._clanExitLabel.text = §_-s2a§.§_-K3t§(§_-s2a§.EXIT_FROM_CLAN_LABEL) + ":";
            this.binder._allCapacityLabel.text = §_-s2a§.§_-K3t§(§_-s2a§.CLAN_CAPACITY_LABEL) + ":";
            this.binder._oficersCapacityLabel.text = §_-s2a§.§_-K3t§(§_-s2a§.OFFICERS_POSITIONS) + ":";
            this.binder._clanJoinType.text = §_-s2a§.§_-K3t§(this.§_-I1G§ ? §_-s2a§.OPEN_CLAN : §_-s2a§.CLOSE_CLAN);
            this.binder._clanExitType.text = §_-s2a§.§_-K3t§(this.§_-y23§ ? §_-s2a§.CLAN_EXIT_CLOSED : §_-s2a§.CLAN_EXIT_OPENED);
            this.binder._clanNameInput.prompt = §_-s2a§.§_-K3t§(§_-s2a§.INPUT_MESSAGE);
            this.binder._clanDescInput.prompt = §_-s2a§.§_-K3t§(§_-s2a§.INPUT_MESSAGE);
            this.binder._clanEmblemEditButton.label = §_-s2a§.§_-K3t§(§_-s2a§.BUTTON_EDIT);
            this.binder._saveNameButton.label = §_-s2a§.§_-K3t§(§_-s2a§.BUTTON_SAVE);
            this.binder._saveDescButton.label = §_-s2a§.§_-K3t§(§_-s2a§.BUTTON_SAVE);
            this.binder._saveEmblemButton.label = §_-s2a§.§_-K3t§(§_-s2a§.BUTTON_SAVE);
            this.binder._saveJoinTypeButton.label = §_-s2a§.§_-K3t§(§_-s2a§.BUTTON_SAVE);
            this.binder._saveExitTypeButton.label = §_-s2a§.§_-K3t§(§_-s2a§.BUTTON_SAVE);
            this.binder._saveCapacityButton.label = §_-s2a§.§_-K3t§(§_-s2a§.BUTTON_INCREASE);
         }
      }
      
      private function §_-A3C§() : int
      {
         return this.§_-I1G§ ? this.§_-L3J§ : -1;
      }
      
      public function §_-o2M§(param1:§_-sI§) : void
      {
         this.§_-c2h§ = param1;
         this.binder._clanNameInput.maxChars = this.§_-c2h§.clanNameLengthMax;
         this.binder._clanNameInput.restrict = this.§_-c2h§.§_-Qn§();
         this.binder._clanDescInput.maxChars = this.§_-c2h§.clanDescriptionLengthMax;
      }
      
      public function §_-h2g§(param1:§_-CD§, param2:UserProfile) : void
      {
         this.§_-z2g§ = param2;
         this._clanName = param1.name;
         this.§_-B3G§ = param1.description;
         this.§_-qq§ = param1.§_-6B§;
         this.§_-D27§ = param1.§_-o9§;
         this.§_-k2y§ = param1.joinRating;
         this.§_-W29§ = param1.isExitClosed;
         this.§_-R2z§ = param1.level;
         this.§_-u1O§ = true;
         invalidate(INVALIDATION_FLAG_DATA);
      }
      
      private function §_-ZF§(param1:Event) : void
      {
         §_-h2B§.play(§_-d27§.§_-S29§);
         var _loc2_:EventDispatcher = param1.currentTarget;
         switch(_loc2_)
         {
            case this.binder._clanEmblemEditButton:
               §§push(0);
               break;
            case this.binder._saveNameButton:
               §§push(1);
               break;
            case this.binder._saveDescButton:
               §§push(2);
               break;
            case this.binder._saveEmblemButton:
               §§push(3);
               break;
            case this.binder._saveJoinTypeButton:
               §§push(4);
               break;
            case this.binder._saveExitTypeButton:
               §§push(5);
               break;
            case this.binder._saveCapacityButton:
               §§push(6);
               break;
            case this.binder._nextJoinTypeButton:
               §§push(7);
               break;
            case this.binder._prevJoinTypeButton:
               §§push(8);
               break;
            default:
               switch(_loc2_)
               {
                  case this.binder._nextExitTypeButton:
                     §§push(9);
                     break;
                  case this.binder._prevExitTypeButton:
                     §§push(10);
                     break;
                  default:
                     §§push(11);
               }
         }
         switch(§§pop())
         {
            case 0:
               dispatchEventWith(EDIT_EMBLEM,false,this.§_-fY§.§_-6B§);
               break;
            case 1:
               dispatchEventWith(§_-e1D§,false,this.binder._clanNameInput.text);
               break;
            case 2:
               dispatchEventWith(§_-hP§,false,this.binder._clanDescInput.text);
               break;
            case 3:
               dispatchEventWith(§_-Y2n§,false,this.§_-D27§);
               break;
            case 4:
               dispatchEventWith(§_-v2p§,false,this.§_-A3C§());
               break;
            case 5:
               dispatchEventWith(§_-vv§,false,this.§_-y23§);
               break;
            case 6:
               dispatchEventWith(§_-xn§);
               break;
            case 7:
            case 8:
               this.§_-I1G§ = !this.§_-I1G§;
               invalidate(§_-dU§.§_-Mf§);
               break;
            case 9:
            case 10:
               this.§_-y23§ = !this.§_-y23§;
               invalidate(§_-dU§.§_-M2L§);
         }
      }
      
      private function §_-23B§(param1:Event) : void
      {
         invalidate(§_-dU§.CLAN_NAME);
      }
      
      private function §_-NW§(param1:Event) : void
      {
         invalidate(§_-dU§.CLAN_DESCRIPTION);
      }
      
      private function §_-r1I§(param1:Event) : void
      {
         invalidate(§_-dU§.§_-Au§);
      }
      
      private function §_-21C§(param1:Event) : void
      {
         invalidate(§_-dU§.§_-Mf§);
      }
      
      private function §_-4§() : void
      {
         var _loc1_:Button = null;
         for each(_loc1_ in this.§_-S1L§)
         {
            _loc1_.addEventListener(Event.TRIGGERED,this.§_-ZF§);
         }
      }
      
      private function §_-fa§() : void
      {
         var _loc1_:Button = null;
         for each(_loc1_ in this.§_-S1L§)
         {
            _loc1_.removeEventListener(Event.TRIGGERED,this.§_-ZF§);
         }
      }
   }
}

import feathers.controls.Button;
import feathers.controls.Label;
import feathers.controls.LayoutGroup;
import feathers.controls.Panel;
import feathers.controls.ScrollContainer;
import feathers.controls.TextInput;

class Binder
{
   
   public var _panel:Panel;
   
   public var _scroll:ScrollContainer;
   
   public var _clanNameLabel:Label;
   
   public var _clanEmblemLabel:Label;
   
   public var _clanDescLabel:Label;
   
   public var _clanJoinLabel:Label;
   
   public var _clanJoinType:Label;
   
   public var _minJoinRatingLabel:Label;
   
   public var _allCapacityLabel:Label;
   
   public var _allCapacityValue:Label;
   
   public var _allCapacityAddValue:Label;
   
   public var _oficersCapacityLabel:Label;
   
   public var _oficersCapacityValue:Label;
   
   public var _oficersCapacityAddValue:Label;
   
   public var _clanExitLabel:Label;
   
   public var _clanExitType:Label;
   
   public var _clanNameInput:TextInput;
   
   public var _clanDescInput:TextInput;
   
   public var _minJoinRatingInput:TextInput;
   
   public var _clanEmblemContainer:LayoutGroup;
   
   public var _clanEmblemEditButton:Button;
   
   public var _prevJoinTypeButton:Button;
   
   public var _nextJoinTypeButton:Button;
   
   public var _prevExitTypeButton:Button;
   
   public var _nextExitTypeButton:Button;
   
   public var _saveNameButton:Button;
   
   public var _saveEmblemButton:Button;
   
   public var _saveDescButton:Button;
   
   public var _saveJoinTypeButton:Button;
   
   public var _saveExitTypeButton:Button;
   
   public var _saveCapacityButton:Button;
   
   public function Binder()
   {
      super();
   }
}
