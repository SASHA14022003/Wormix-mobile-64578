package §_-Vg§
{
   import §_-CF§.§_-x2t§;
   import §_-L1w§.§_-CD§;
   import §_-r1C§.§_-h2B§;
   import §_-x2Q§.§_-dU§;
   import §_-zI§.§_-sI§;
   import feathers.controls.text.TextFormatUtils;
   import feathers.layout.AnchorLayout;
   import feathers.layout.VerticalAlign;
   import feathers.themes.FontColor;
   import feathers.themes.FontName;
   import feathers.themes.FontSize;
   import flash.text.TextFormatAlign;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.model.§_-d27§;
   import starling.events.Event;
   import starling.utils.Color;
   
   public class ClanCreateView extends §_-03W§
   {
      
      public static const §_-Z2c§:String = "emblem-edit";
      
      public static const §_-d10§:String = "create-confirm";
      
      private var binder:Binder;
      
      private var _clanName:String;
      
      private var §_-B3G§:String;
      
      private var §_-qq§:Vector.<uint>;
      
      private var §_-k2y§:int;
      
      private var §_-u1O§:Boolean = false;
      
      private var §_-A3F§:§_-M11§;
      
      private var §_-c2h§:§_-sI§;
      
      private var §_-D2l§:int;
      
      public function ClanCreateView()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         this.layout = new AnchorLayout();
         this.binder = new Binder();
         var _loc1_:Object = Application.assetManager.getObject("clan_create_panel");
         Application.uiBuilder.create(_loc1_,true,this.binder);
         addChild(this.binder._container);
         this.binder._clanNameInput.promptProperties.textFormat = TextFormatUtils.createFlashTextFormat(FontName.WORMIX_NORMAL,FontSize.NORMAL,FontColor.TAB_UNSELECTED,TextFormatAlign.LEFT);
         this.binder._clanNameInput.textEditorProperties.color = FontColor.TAB_UNSELECTED;
         this.binder._clanNameInput.textEditorProperties.textAlign = TextFormatAlign.LEFT;
         this.binder._clanNameInput.verticalAlign = VerticalAlign.MIDDLE;
         this.binder._clanNameInput.text = "";
         this.binder._clanNameInput.paddingLeft = 5;
         this.binder._minJoinRatingInput.promptProperties.textFormat = TextFormatUtils.createFlashTextFormat(FontName.WORMIX_NORMAL,FontSize.NORMAL,FontColor.TAB_UNSELECTED,TextFormatAlign.LEFT);
         this.binder._minJoinRatingInput.textEditorProperties.color = FontColor.TAB_UNSELECTED;
         this.binder._minJoinRatingInput.textEditorProperties.textAlign = TextFormatAlign.LEFT;
         this.binder._minJoinRatingInput.verticalAlign = VerticalAlign.MIDDLE;
         this.binder._minJoinRatingInput.restrict = "0-9";
         this.binder._minJoinRatingInput.maxChars = 7;
         this.binder._minJoinRatingInput.text = "";
         this.binder._minJoinRatingInput.paddingLeft = 5;
         this.binder._clanDescInput.text = "";
         this.binder._clanDescInput.padding = 5;
         this.§_-A3F§ = new §_-M11§();
         this.§_-A3F§.size = this.binder._clanEmblemContainer.height;
         this.binder._clanEmblemContainer.addChild(this.§_-A3F§);
         this.binder._clanEmblemEditButton.addEventListener(Event.TRIGGERED,this.§_-y1l§);
         this.binder._clanCreateButton.addEventListener(Event.TRIGGERED,this.§_-y1l§);
         this.binder._nextJoinTypeButton.addEventListener(Event.TRIGGERED,this.§_-y1l§);
         this.binder._prevJoinTypeButton.addEventListener(Event.TRIGGERED,this.§_-y1l§);
         this.binder._clanNameInput.addEventListener(Event.CHANGE,this.§_-23B§);
         this.binder._clanDescInput.addEventListener(Event.CHANGE,this.§_-NW§);
         this.binder._minJoinRatingInput.addEventListener(Event.CHANGE,this.§_-r1I§);
      }
      
      override public function dispose() : void
      {
         super.dispose();
         this.binder._clanEmblemEditButton.removeEventListener(Event.TRIGGERED,this.§_-y1l§);
         this.binder._clanCreateButton.removeEventListener(Event.TRIGGERED,this.§_-y1l§);
         this.binder._nextJoinTypeButton.removeEventListener(Event.TRIGGERED,this.§_-y1l§);
         this.binder._prevJoinTypeButton.removeEventListener(Event.TRIGGERED,this.§_-y1l§);
         this.binder._clanNameInput.removeEventListener(Event.CHANGE,this.§_-23B§);
         this.binder._clanDescInput.removeEventListener(Event.CHANGE,this.§_-NW§);
         this.binder._clanDescInput.removeEventListener(Event.CHANGE,this.§_-r1I§);
      }
      
      override protected function draw() : void
      {
         var _loc1_:String = null;
         var _loc2_:Boolean = false;
         var _loc3_:uint = 0;
         var _loc4_:Boolean = false;
         var _loc5_:Boolean = false;
         if(this.§_-u1O§)
         {
            if(isInvalid(INVALIDATION_FLAG_DATA))
            {
               this.binder._clanNameInput.text = this._clanName;
               this.binder._clanDescInput.text = this.§_-B3G§;
               this.§_-A3F§.§_-6B§ = this.§_-qq§;
               invalidate(§_-dU§.§_-Mf§);
               invalidate(§_-dU§.§_-m§);
               invalidate(§_-dU§.§_-h26§);
            }
            if(isInvalid(§_-dU§.CLAN_NAME))
            {
               _loc1_ = this.binder._clanNameInput.text;
               _loc2_ = this.§_-c2h§.§_-g1F§(_loc1_);
               _loc3_ = _loc2_ ? FontColor.TAB_UNSELECTED : Color.RED;
               this.binder._clanNameInput.textEditorProperties.color = _loc3_;
               this._clanName = _loc1_;
               invalidate(§_-dU§.§_-m§);
            }
            if(isInvalid(§_-dU§.CLAN_DESCRIPTION))
            {
               this.§_-B3G§ = this.binder._clanDescInput.text;
            }
            if(isInvalid(§_-dU§.CLAN_EMBLEM))
            {
               this.§_-A3F§.§_-6B§ = this.§_-qq§;
            }
            if(isInvalid(§_-dU§.§_-Mf§))
            {
               _loc4_ = this.§_-k2y§ > -1;
               this.binder._clanJoinType.text = _loc4_ ? §_-s2a§.§_-K3t§(§_-s2a§.OPEN_CLAN) : §_-s2a§.§_-K3t§(§_-s2a§.CLOSE_CLAN);
               this.binder._minJoinRatingInput.text = _loc4_ ? this.§_-k2y§.toString() : "";
               this.binder._minJoinRatingInput.prompt = _loc4_ ? "0" : "";
               this.binder._minJoinRatingInput.isEditable = _loc4_;
               this.binder._minJoinRatingInput.isSelectable = _loc4_;
               this.binder._minJoinRatingInput.invalidate();
            }
            if(isInvalid(§_-dU§.§_-m§))
            {
               _loc5_ = this.§_-c2h§.§_-g1F§(this.binder._clanNameInput.text);
               this.binder._clanCreateButton.isEnabled = _loc5_;
            }
            if(isInvalid(§_-dU§.§_-h26§))
            {
               this.binder._clanNameLabel.text = §_-s2a§.§_-K3t§(§_-s2a§.CLAN_NAME) + ":";
               this.binder._clanEmblemLabel.text = §_-s2a§.§_-K3t§(§_-s2a§.CLAN_EMBLEM) + ":";
               this.binder._clanDescLabel.text = §_-s2a§.§_-K3t§(§_-s2a§.CLAN_DESCRIPTION) + ":";
               this.binder._clanJoinLabel.text = §_-s2a§.§_-K3t§(§_-s2a§.JOIN_TO_CLAN_LABEL) + ":";
               this.binder._minJoinRatingLabel.text = §_-s2a§.§_-K3t§(§_-s2a§.JOIN_MINIMAL_RATING) + ":";
               this.binder._clanNameInput.prompt = §_-s2a§.§_-K3t§(§_-s2a§.INPUT_MESSAGE);
               this.binder._clanDescInput.prompt = §_-s2a§.§_-K3t§(§_-s2a§.INPUT_MESSAGE);
               this.binder._clanEmblemEditButton.label = §_-s2a§.§_-K3t§(§_-s2a§.BUTTON_EDIT);
               this.binder._clanCreateAcceptLabel.text = §_-s2a§.§_-K3t§(§_-s2a§.CREATE_CLAN_BTN);
               this.binder._clanJoinType.text = this.§_-k2y§ > -1 ? §_-s2a§.§_-K3t§(§_-s2a§.OPEN_CLAN) : §_-s2a§.§_-K3t§(§_-s2a§.CLOSE_CLAN);
            }
         }
         super.draw();
      }
      
      public function §_-o2M§(param1:§_-sI§) : void
      {
         this.§_-c2h§ = param1;
         this.binder._clanNameInput.maxChars = this.§_-c2h§.clanNameLengthMax;
         this.binder._clanNameInput.restrict = this.§_-c2h§.§_-Qn§();
         this.binder._clanDescInput.maxChars = this.§_-c2h§.clanDescriptionLengthMax;
      }
      
      public function §_-e2D§(param1:§_-CD§) : void
      {
         this._clanName = param1.name;
         this.§_-B3G§ = param1.description;
         this.§_-qq§ = param1.§_-6B§;
         this.§_-k2y§ = param1.joinRating;
         this.§_-u1O§ = true;
         invalidate(INVALIDATION_FLAG_DATA);
      }
      
      public function §_-D1s§(param1:Vector.<uint>) : void
      {
         this.§_-qq§ = param1;
         this.§_-u1O§ = true;
         invalidate(INVALIDATION_FLAG_DATA);
      }
      
      public function §_-B20§(param1:§_-CD§) : void
      {
         param1.name = this._clanName;
         param1.description = this.§_-B3G§;
         param1.§_-6B§ = this.§_-qq§;
         param1.joinRating = this.§_-k2y§;
      }
      
      public function §_-318§(param1:§_-x2t§) : void
      {
         this.binder._clanCreateButton.label = param1.§_-R1T§.toString();
      }
      
      private function §_-y1l§(param1:Event) : void
      {
         §_-h2B§.play(§_-d27§.§_-S29§);
         var _loc2_:EventDispatcher = param1.currentTarget;
         switch(_loc2_)
         {
            case this.binder._clanEmblemEditButton:
               §§push(0);
               break;
            case this.binder._clanCreateButton:
               §§push(1);
               break;
            default:
               switch(_loc2_)
               {
                  case this.binder._nextJoinTypeButton:
                     §§push(2);
                     break;
                  case this.binder._prevJoinTypeButton:
                     §§push(3);
                     break;
                  default:
                     §§push(4);
               }
         }
         switch(§§pop())
         {
            case 0:
               dispatchEventWith(§_-Z2c§);
               break;
            case 1:
               dispatchEventWith(§_-d10§);
               break;
            case 2:
            case 3:
               if(this.§_-k2y§ > -1)
               {
                  this.§_-D2l§ = this.§_-k2y§ > -1 ? this.§_-k2y§ : 0;
                  this.§_-k2y§ = -1;
               }
               else
               {
                  this.§_-k2y§ = this.§_-D2l§;
                  this.§_-D2l§ = -1;
               }
               invalidate(§_-dU§.§_-Mf§);
         }
      }
      
      private function §_-23B§(param1:Event) : void
      {
         this.binder._clanNameInput.text = §_-X1j§.§_-sO§.§_-gO§(this.binder._clanNameInput.text);
         invalidate(§_-dU§.CLAN_NAME);
      }
      
      private function §_-NW§(param1:Event) : void
      {
         invalidate(§_-dU§.CLAN_DESCRIPTION);
      }
      
      private function §_-r1I§(param1:Event) : void
      {
         if(this.§_-k2y§ > -1)
         {
            this.§_-k2y§ = int(this.binder._minJoinRatingInput.text);
         }
      }
   }
}

import feathers.controls.Button;
import feathers.controls.Label;
import feathers.controls.LayoutGroup;
import feathers.controls.TextInput;

class Binder
{
   
   public var _container:LayoutGroup;
   
   public var _clanNameLabel:Label;
   
   public var _clanEmblemLabel:Label;
   
   public var _clanDescLabel:Label;
   
   public var _clanJoinLabel:Label;
   
   public var _clanJoinType:Label;
   
   public var _minJoinRatingLabel:Label;
   
   public var _clanCreateAcceptLabel:Label;
   
   public var _clanNameInput:TextInput;
   
   public var _clanDescInput:TextInput;
   
   public var _minJoinRatingInput:TextInput;
   
   public var _clanEmblemContainer:LayoutGroup;
   
   public var _prevJoinTypeButton:Button;
   
   public var _nextJoinTypeButton:Button;
   
   public var _clanEmblemEditButton:Button;
   
   public var _clanCreateButton:Button;
   
   public function Binder()
   {
      super();
   }
}
