package §_-Vg§
{
   import §_-Ly§.§_-81L§;
   import §_-jF§.ClanItemRenderer;
   import §_-q26§.§_-52J§;
   import §_-r1C§.§_-h2B§;
   import §_-x2Q§.§_-dU§;
   import §_-zI§.§_-sI§;
   import feathers.controls.ScrollPolicy;
   import feathers.controls.text.TextFormatUtils;
   import feathers.data.VectorCollection;
   import feathers.layout.AnchorLayout;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.VerticalAlign;
   import feathers.layout.VerticalLayout;
   import feathers.themes.FontColor;
   import feathers.themes.FontName;
   import feathers.themes.FontSize;
   import feathers.utils.textures.TextureCache;
   import flash.text.TextFormatAlign;
   import ru.pragmatix.wormix.gui.§_-eP§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import starling.events.Event;
   import starling.utils.Color;
   
   public class ClanSearchView extends §_-03W§
   {
      
      public static const §_-zQ§:String = "search-stroke-clear";
      
      public static const §_-L2E§:String = "search-triggered";
      
      public static const §_-G1t§:String = "clan-selected";
      
      private var binder:Binder;
      
      private var _textureCache:TextureCache;
      
      private var §_-c2h§:§_-sI§;
      
      public function ClanSearchView()
      {
         super();
         this._textureCache = new TextureCache();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         this.layout = new AnchorLayout();
         this.binder = new Binder();
         var _loc1_:Object = Application.assetManager.getObject("clan_search_panel");
         Application.uiBuilder.create(_loc1_,true,this.binder);
         addChild(this.binder._container);
         var _loc2_:VerticalLayout = new VerticalLayout();
         _loc2_.gap = 20;
         _loc2_.padding = 5;
         _loc2_.horizontalAlign = HorizontalAlign.LEFT;
         _loc2_.verticalAlign = VerticalAlign.TOP;
         this.binder._clansList.layout = _loc2_;
         this.binder._clansList.itemRendererType = ClanItemRenderer;
         this.binder._clansList.itemRendererProperties.textureCache = this._textureCache;
         this.binder._clansList.dataProvider = new VectorCollection();
         this.binder._clansList.addEventListener(Event.CHANGE,this.§_-J1g§);
         this.binder._clansList.verticalScrollBarFactory = §_-eP§.§_-M1B§;
         this.binder._clansList.horizontalScrollPolicy = ScrollPolicy.OFF;
         this.binder._clanNameInput.promptProperties.textFormat = TextFormatUtils.createFlashTextFormat(FontName.WORMIX_NORMAL,FontSize.NORMAL,FontColor.TAB_UNSELECTED,TextFormatAlign.LEFT);
         this.binder._clanNameInput.textEditorProperties.color = FontColor.TAB_UNSELECTED;
         this.binder._clanNameInput.verticalAlign = VerticalAlign.MIDDLE;
         this.binder._clanNameInput.text = "";
         this.binder._clanNameInput.paddingLeft = 5;
         this.binder._clanNameInput.maxChars = 128;
         this.binder._searchButton.addEventListener(Event.TRIGGERED,this.§_-Y12§);
         this.binder._clanNameInput.addEventListener(Event.CHANGE,this.§_-A1P§);
      }
      
      override protected function draw() : void
      {
         var _loc1_:String = null;
         var _loc2_:Boolean = false;
         var _loc3_:uint = 0;
         super.draw();
         if(isInvalid(INVALIDATION_FLAG_DATA))
         {
            this.binder._searchButton.label = §_-s2a§.§_-K3t§(§_-s2a§.SEARCH_BTN);
            this.binder._clanNameInput.prompt = §_-s2a§.§_-K3t§(§_-s2a§.SEARCH_CLAN_NAME_INPUT);
         }
         if(isInvalid(§_-dU§.CLAN_NAME) && Boolean(this.§_-c2h§))
         {
            _loc1_ = this.binder._clanNameInput.text;
            if(_loc1_)
            {
               _loc2_ = this.§_-c2h§.§_-g1F§(this.binder._clanNameInput.text);
               _loc3_ = _loc2_ ? FontColor.TAB_UNSELECTED : Color.RED;
               this.binder._clanNameInput.textEditorProperties.color = _loc3_;
               this.binder._searchButton.isEnabled = _loc2_;
            }
            else
            {
               this.binder._searchButton.isEnabled = false;
               dispatchEventWith(§_-zQ§);
            }
         }
      }
      
      private function §_-A1P§(param1:Event) : void
      {
         invalidate(§_-dU§.CLAN_NAME);
      }
      
      private function §_-Y12§(param1:Event) : void
      {
         §_-h2B§.play(§_-81L§.§_-o1Z§);
         var _loc2_:String = this.binder._clanNameInput.text;
         dispatchEventWith(§_-L2E§,false,_loc2_);
      }
      
      private function §_-J1g§(param1:Event) : void
      {
         var _loc2_:ClanTO = this.binder._clansList.selectedItem as ClanTO;
         if(_loc2_)
         {
            dispatchEventWith(§_-G1t§,false,_loc2_);
            this.binder._clansList.selectedIndex = -1;
         }
      }
      
      public function setData(param1:Vector.<ClanTO>) : void
      {
         (this.binder._clansList.dataProvider as VectorCollection).vectorData = param1;
         this.binder._clansList.verticalScrollPolicy = ScrollPolicy.AUTO;
      }
      
      public function init(param1:§_-sI§, param2:§_-52J§) : void
      {
         this.§_-c2h§ = param1;
         this.binder._clanNameInput.maxChars = param1.clanNameLengthMax;
         this.binder._clansList.itemRendererProperties.clanParamHelper = param2;
         invalidate(§_-dU§.CLAN_NAME);
      }
      
      override public function dispose() : void
      {
         super.dispose();
         this._textureCache.dispose();
         this.binder._searchButton.removeEventListener(Event.TRIGGERED,this.§_-Y12§);
         this.binder._clanNameInput.removeEventListener(Event.CHANGE,this.§_-A1P§);
      }
   }
}

import feathers.controls.Button;
import feathers.controls.LayoutGroup;
import feathers.controls.List;
import feathers.controls.TextInput;

class Binder
{
   
   public var _container:LayoutGroup;
   
   public var _searchContainer:LayoutGroup;
   
   public var _clanNameInput:TextInput;
   
   public var _searchButton:Button;
   
   public var _clansList:List;
   
   public function Binder()
   {
      super();
   }
}
