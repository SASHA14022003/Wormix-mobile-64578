package §_-Vg§
{
   import feathers.controls.Screen;
   
   public class §_-03W§ extends Screen
   {
      
      public function §_-03W§()
      {
         super();
      }
   }
}

