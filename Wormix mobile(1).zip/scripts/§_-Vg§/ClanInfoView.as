package §_-Vg§
{
   import §_-CR§.§_-72p§;
   import §_-DJ§.MessageBox;
   import §_-K35§.§_-99§;
   import §_-SP§.§_-M4§;
   import §_-TF§.§_-q1j§;
   import §_-jF§.ClanMemberItemRenderer;
   import §_-jF§.§_-U17§;
   import §_-q26§.§_-52J§;
   import §_-zI§.§_-A1s§;
   import §_-zI§.§_-X1q§;
   import feathers.controls.ScreenNavigator;
   import feathers.controls.ScreenNavigatorItem;
   import feathers.controls.ScrollPolicy;
   import feathers.data.ArrayCollection;
   import feathers.data.ListCollection;
   import feathers.layout.AnchorLayout;
   import feathers.layout.AnchorLayoutData;
   import feathers.layout.Direction;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.RelativePosition;
   import feathers.layout.TiledColumnsLayout;
   import feathers.layout.VerticalAlign;
   import feathers.layout.VerticalLayout;
   import feathers.themes.styles.AlternateButtonsStyles;
   import ru.pragmatix.wormix.gui.§_-eP§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.main.server.ClanInviteStructure;
   import ru.pragmatix.wormix.messages.clans.structures.ClanMemberTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.utils.§_-6A§;
   import starling.events.Event;
   
   public class ClanInfoView extends §_-03W§
   {
      
      public static const §_-vE§:String = "clan-edit";
      
      public static const §_-43i§:String = "clan-leave";
      
      public static const §_-w8§:String = "clan-join";
      
      private var binder:Binder;
      
      private var clanEmblem:§_-M11§;
      
      private var §_-X1J§:§_-X7§;
      
      private var §_-93m§:ClanTO;
      
      private var §_-z2g§:UserProfile;
      
      private var §_-a1g§:§_-52J§;
      
      private var §_-Kn§:ClanInviteStructure;
      
      private var §_-n7§:§_-72p§;
      
      public function ClanInfoView()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         this.layout = new AnchorLayout();
         this.binder = new Binder();
         var _loc1_:Object = Application.assetManager.getObject("clan_info_view");
         Application.uiBuilder.create(_loc1_,true,this.binder);
         addChild(this.binder._container);
         this.binder._nameContainer.visible = false;
         this.binder._emblemContainer.visible = false;
         this.clanEmblem = new §_-M11§();
         this.clanEmblem.size = this.binder._emblemContainer.height;
         this.binder._emblemContainer.addChild(this.clanEmblem);
         this.binder._paramsList.horizontalScrollPolicy = ScrollPolicy.OFF;
         this.binder._paramsList.verticalScrollPolicy = ScrollPolicy.OFF;
         var _loc2_:TiledColumnsLayout = new TiledColumnsLayout();
         _loc2_.requestedRowCount = 4;
         _loc2_.gap = 5;
         _loc2_.padding = 5;
         _loc2_.horizontalAlign = HorizontalAlign.CENTER;
         _loc2_.verticalAlign = VerticalAlign.TOP;
         _loc2_.tileHorizontalAlign = HorizontalAlign.LEFT;
         _loc2_.tileVerticalAlign = VerticalAlign.MIDDLE;
         _loc2_.distributeHeights = false;
         _loc2_.distributeWidths = true;
         _loc2_.paging = Direction.NONE;
         _loc2_.useSquareTiles = false;
         this.binder._paramsList.layout = _loc2_;
         this.binder._paramsList.itemRendererType = §_-U17§;
         this.binder._controls.buttonProperties.styleName = AlternateButtonsStyles.BUTTON_GREEN;
         this.binder._controls.buttonProperties.width = 200;
         this.binder._controls.distributeButtonSizes = false;
         this.binder._controls.horizontalAlign = HorizontalAlign.CENTER;
         this.binder._controls.verticalAlign = VerticalAlign.MIDDLE;
         this.binder._controls.direction = Direction.HORIZONTAL;
         this.binder._controls.gap = 10;
         var _loc3_:VerticalLayout = new VerticalLayout();
         _loc3_.gap = 2;
         _loc3_.horizontalAlign = HorizontalAlign.LEFT;
         this.binder._clanMembersList.layout = _loc3_;
         this.binder._clanMembersList.horizontalScrollPolicy = ScrollPolicy.OFF;
         this.binder._clanMembersList.verticalScrollBarFactory = §_-eP§.§_-M1B§;
         this.binder._clanMembersList.paddingTop = 10;
         this.binder._clanMembersList.paddingBottom = 10;
         this.binder._clanMembersList.itemRendererType = ClanMemberItemRenderer;
         this.binder._clanMembersList.dataProvider = new ArrayCollection();
         this.§_-X1J§ = new §_-X7§();
         §_-q1j§.register(this.§_-X1J§);
         this.binder._bannerPlace.addChild(this.§_-X1J§);
         this.binder._paramsList.addEventListener(Event.TRIGGERED,this.§_-d12§);
         this.§_-n7§ = new §_-72p§(this.binder._clanMembersList,this.§_-k2O§,[RelativePosition.LEFT,RelativePosition.RIGHT],true,Direction.VERTICAL);
         this.§_-n7§.§_-k1§([§_-99§.§_-97§]);
      }
      
      override protected function draw() : void
      {
         var _loc1_:§_-A1s§ = null;
         var _loc2_:Boolean = false;
         var _loc3_:ArrayCollection = null;
         var _loc4_:Vector.<ClanMemberTO> = null;
         var _loc5_:int = 0;
         var _loc6_:Array = null;
         var _loc7_:Boolean = false;
         var _loc8_:Boolean = false;
         var _loc9_:Boolean = false;
         var _loc10_:Boolean = false;
         var _loc11_:Array = null;
         if(isInvalid(INVALIDATION_FLAG_DATA) && Boolean(this.§_-93m§))
         {
            this.binder._nameContainer.visible = true;
            this.binder._emblemContainer.visible = true;
            this.binder._clanName.text = this.§_-93m§.name;
            this.clanEmblem.§_-6B§ = this.§_-93m§.emblem;
            _loc1_ = §_-6A§.§_-oy§(this.§_-93m§.prevSeasonTopPlace);
            if(_loc1_)
            {
               this.§_-X1J§.setData(this.§_-93m§.emblem,_loc1_);
            }
            _loc2_ = §_-6A§.§_-JU§(this.§_-z2g§,this.§_-93m§);
            _loc3_ = this.binder._clanMembersList.dataProvider as ArrayCollection;
            _loc3_.removeAll();
            _loc4_ = §_-6A§.§_-b1J§(this.§_-93m§.members);
            _loc5_ = 0;
            while(_loc5_ < _loc4_.length)
            {
               _loc3_.addItem({
                  "place":_loc5_ + 1,
                  "member":_loc4_[_loc5_],
                  "isViewersClan":_loc2_
               });
               _loc5_++;
            }
            this.binder._clanMembersList.verticalScrollPolicy = ScrollPolicy.AUTO;
            _loc6_ = [];
            _loc6_.push({
               "label":§_-s2a§.§_-K3t§(§_-s2a§.CLAN_COMPOSITION) + ":",
               "accessoryLabel":this.§_-93m§.getCapacityWithSize(),
               "isDigits":true
            });
            _loc6_.push({
               "label":§_-s2a§.§_-K3t§(§_-s2a§.CLAN_RATING_POINTS),
               "accessoryLabel":this.§_-93m§.seasonRating.toString(),
               "isDigits":true
            });
            _loc6_.push({
               "label":§_-s2a§.§_-K3t§(§_-s2a§.TAB_TREASURY_CLAN) + ":",
               "accessoryLabel":this.§_-93m§.treasury.toString(),
               "isDigits":true
            });
            _loc6_.push({
               "label":§_-s2a§.§_-K3t§(§_-s2a§.MEDAL_COST_LABEL) + ":",
               "accessoryLabel":this.§_-93m§.medalPrice.toString(),
               "isDigits":true
            });
            _loc6_.push({
               "label":§_-s2a§.§_-K3t§(§_-s2a§.PREV_SEASON_LABEL),
               "accessoryLabel":this.§_-a1g§.§_-71r§(this.§_-93m§),
               "isDigits":false
            });
            _loc6_.push({
               "label":§_-s2a§.§_-K3t§(§_-s2a§.JOIN_TO_CLAN_LABEL) + ":",
               "accessoryLabel":this.§_-a1g§.§_-b1X§(this.§_-93m§),
               "isDigits":false
            });
            _loc6_.push({
               "label":§_-s2a§.§_-K3t§(§_-s2a§.EXIT_FROM_CLAN_LABEL) + ":",
               "accessoryLabel":this.§_-a1g§.§_-13i§(this.§_-93m§),
               "isDigits":false
            });
            _loc6_.push({
               "label":§_-s2a§.§_-K3t§(§_-s2a§.CLAN_DESCRIPTION),
               "accessoryLabel":this.§_-93m§.clanDescription,
               "interactive":true,
               "isDigits":false
            });
            this.binder._paramsList.dataProvider = new ArrayCollection(_loc6_);
            _loc7_ = this.§_-z2g§.§_-ia§();
            _loc8_ = (_loc7_) && this.§_-z2g§.clanMember.clanId == this.§_-93m§.id;
            _loc9_ = (_loc8_) && this.§_-z2g§.clanMember.rank == §_-X1q§.§_-O2V§;
            _loc10_ = _loc8_ && this.§_-z2g§.clanMember.rank == §_-X1q§.OFFICER;
            _loc11_ = [];
            if(_loc8_)
            {
               if(_loc9_ || _loc10_)
               {
                  _loc11_.push({
                     "label":§_-s2a§.§_-K3t§(§_-s2a§.BUTTON_EDIT),
                     "triggered":this.§_-I2b§
                  });
               }
               _loc11_.push({
                  "label":§_-s2a§.§_-K3t§(§_-s2a§.BUTTON_LEAVE),
                  "triggered":this.§_-KV§
               });
            }
            else if(!_loc7_ && (this.§_-a1g§.§_-ZV§(this.§_-93m§) || this.§_-Kn§ != null))
            {
               _loc11_.push({
                  "label":§_-s2a§.§_-K3t§(§_-s2a§.JOIN_TO_CLAN_BTN),
                  "triggered":this.§_-l2R§
               });
            }
            this.binder._controls.dataProvider = new ArrayCollection(_loc11_);
         }
         super.draw();
      }
      
      override public function dispose() : void
      {
         this.binder._paramsList.removeEventListener(Event.TRIGGERED,this.§_-d12§);
         this.clanEmblem.dispose();
         §_-q1j§.remove(this.§_-X1J§);
         this.§_-X1J§.dispose();
         this.binder = null;
         this.§_-n7§.dispose();
         super.dispose();
      }
      
      public function setData(param1:ClanTO, param2:UserProfile, param3:§_-52J§, param4:Vector.<ClanInviteStructure>) : void
      {
         var _loc5_:ClanInviteStructure = null;
         this.§_-93m§ = param1;
         this.§_-z2g§ = param2;
         this.§_-a1g§ = param3;
         this.§_-Kn§ = null;
         var _loc6_:int = 0;
         var _loc7_:* = param4;
         for each(_loc6_ in _loc7_)
         {
            var _temp_2:* = _loc6_;
            _loc5_ = _loc6_;
            if(_loc5_.clanId == this.§_-93m§.id)
            {
               this.§_-Kn§ = _loc5_;
               break;
            }
         }
         invalidate(INVALIDATION_FLAG_DATA);
      }
      
      private function §_-I2b§(param1:Event) : void
      {
         dispatchEventWith(§_-vE§,false,this.§_-93m§);
      }
      
      private function §_-KV§(param1:Event) : void
      {
         dispatchEventWith(§_-43i§,false,this.§_-93m§);
      }
      
      private function §_-l2R§(param1:Event) : void
      {
         dispatchEventWith(§_-w8§,false,{
            "clan":this.§_-93m§,
            "invite":this.§_-Kn§
         });
      }
      
      private function §_-d12§(param1:Event) : void
      {
         if(Boolean(param1.data.interactive) && Boolean(param1.data.accessoryLabel))
         {
            new MessageBox(this.§_-93m§.name,param1.data.accessoryLabel).show();
         }
      }
      
      private function §_-k2O§(param1:Object) : int
      {
         var _loc2_:ClanMemberTO = param1.member as ClanMemberTO;
         return _loc2_ ? _loc2_.profileId : 0;
      }
      
      private function §_-23v§(param1:Object) : int
      {
         var _loc2_:ClanMemberTO = param1.member as ClanMemberTO;
         return _loc2_ ? int(parseInt(_loc2_.socialProfileId)) : 0;
      }
   }
}

import feathers.controls.ButtonGroup;
import feathers.controls.Label;
import feathers.controls.LayoutGroup;
import feathers.controls.List;
import feathers.controls.Panel;
import starling.display.Sprite;

class Binder
{
   
   public var _container:Panel;
   
   public var _emblemContainer:LayoutGroup;
   
   public var _nameContainer:LayoutGroup;
   
   public var _bannerPlace:Sprite;
   
   public var _clanName:Label;
   
   public var _paramsList:List;
   
   public var _clanMembersList:List;
   
   public var _controls:ButtonGroup;
   
   public function Binder()
   {
      super();
   }
}
