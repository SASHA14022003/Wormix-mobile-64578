package §_-Vg§
{
   import §_-937§.§_-n1b§;
   import §_-r1C§.§_-h2B§;
   import §_-x2Q§.§_-dU§;
   import §_-zI§.§_-sI§;
   import feathers.controls.Button;
   import feathers.controls.LayoutGroup;
   import feathers.controls.Slider;
   import feathers.layout.AnchorLayout;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.VerticalAlign;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.model.§_-d27§;
   import starling.events.Event;
   import starling.utils.Color;
   import starling.utils.MathUtil;
   
   public class ClanEditEmblemView extends §_-03W§
   {
      
      private var binder:Binder;
      
      private var §_-Pi§:§_-n1b§;
      
      private var §_-tl§:§_-n1b§;
      
      private var §_-A3F§:§_-M11§;
      
      private var §_-c2h§:§_-sI§;
      
      private var §_-zB§:Vector.<uint>;
      
      public function ClanEditEmblemView()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         this.layout = new AnchorLayout();
         this.binder = new Binder();
         var _loc1_:Object = Application.assetManager.getObject("clan_emblem_edit_panel");
         Application.uiBuilder.create(_loc1_,true,this.binder);
         addChild(this.binder._container);
         this.§_-Pi§ = this.§_-p2z§(this.binder._figureColorPickerContainer,Color.WHITE);
         this.§_-tl§ = this.§_-p2z§(this.binder._backColorPickerContainer,Color.WHITE);
         this.§_-Pi§.addEventListener(Event.CHANGE,this.§_-c2f§);
         this.§_-tl§.addEventListener(Event.CHANGE,this.§_-D2J§);
         this.binder._figureTypeSlider.thumbProperties.width = 80;
         this.binder._backTypeSlider.thumbProperties.width = 80;
         this.binder._figureTypeSlider.addEventListener(Event.CHANGE,this.§_-7Y§);
         this.binder._backTypeSlider.addEventListener(Event.CHANGE,this.§_-d2w§);
         this.binder._okButton.addEventListener(Event.TRIGGERED,this.§_-y1l§);
         this.binder._cancelButton.addEventListener(Event.TRIGGERED,this.§_-y1l§);
         this.binder._figureTypePrevButton.addEventListener(Event.TRIGGERED,this.§_-y1l§);
         this.binder._figureTypeNextButton.addEventListener(Event.TRIGGERED,this.§_-y1l§);
         this.binder._backTypePrevButton.addEventListener(Event.TRIGGERED,this.§_-y1l§);
         this.binder._backTypeNextButton.addEventListener(Event.TRIGGERED,this.§_-y1l§);
         this.§_-A3F§ = new §_-M11§();
         this.§_-A3F§.size = this.binder._emblemContainer.height;
         this.binder._emblemContainer.addChild(this.§_-A3F§);
      }
      
      override public function dispose() : void
      {
         super.dispose();
         this.§_-Pi§.removeEventListener(Event.CHANGE,this.§_-c2f§);
         this.§_-tl§.removeEventListener(Event.CHANGE,this.§_-D2J§);
         this.binder._figureTypeSlider.removeEventListener(Event.CHANGE,this.§_-7Y§);
         this.binder._backTypeSlider.removeEventListener(Event.CHANGE,this.§_-d2w§);
         this.binder._okButton.removeEventListener(Event.TRIGGERED,this.§_-y1l§);
         this.binder._cancelButton.removeEventListener(Event.TRIGGERED,this.§_-y1l§);
      }
      
      override protected function draw() : void
      {
         var _loc1_:Boolean = false;
         var _loc2_:Vector.<uint> = null;
         var _loc3_:int = 0;
         super.draw();
         if(isInvalid(INVALIDATION_FLAG_DATA))
         {
            invalidate(§_-dU§.§_-h26§);
            if(this.§_-zB§)
            {
               this.binder._backTypeSlider.value = this.§_-zB§[0];
               this.binder._figureTypeSlider.value = this.§_-zB§[1];
               this.§_-tl§.value = this.§_-zB§[2];
               this.§_-Pi§.value = this.§_-zB§[3];
               this.§_-A3F§.§_-r2i§ = this.§_-tl§.value;
               this.§_-A3F§.§_-Pr§ = this.§_-Pi§.value;
            }
         }
         if(isInvalid(§_-dU§.CLAN_EMBLEM) && Boolean(this.§_-zB§))
         {
            _loc1_ = false;
            _loc2_ = this.§_-A3F§.§_-6B§;
            _loc3_ = 0;
            while(_loc3_ < 4)
            {
               if(_loc2_[_loc3_] != this.§_-zB§[_loc3_])
               {
                  _loc1_ = true;
                  break;
               }
               _loc3_++;
            }
            this.binder._okButton.isEnabled = _loc1_;
         }
         if(isInvalid(§_-dU§.§_-h26§))
         {
            this.binder._backTypeLabel.text = §_-s2a§.§_-K3t§(§_-s2a§.PATTERN_LABEL_TEXT) + ":";
            this.binder._backColorLabel.text = §_-s2a§.§_-K3t§(§_-s2a§.PATTERN_COLOR_LABEL_TEXT) + ":";
            this.binder._figureTypeLabel.text = §_-s2a§.§_-K3t§(§_-s2a§.LOGO_LABEL_TEXT) + ":";
            this.binder._figureColorLabel.text = §_-s2a§.§_-K3t§(§_-s2a§.LOGO_COLOR_LABEL_TEXT) + ":";
            this.binder._okButton.label = §_-s2a§.§_-K3t§(§_-s2a§.BUTTON_SAVE);
            this.binder._cancelButton.label = §_-s2a§.§_-K3t§(§_-s2a§.BUTTON_CANCEL);
         }
      }
      
      private function §_-p2z§(param1:LayoutGroup, param2:uint) : §_-n1b§
      {
         var _loc3_:§_-n1b§ = new §_-n1b§(param1.width,param1.height,param2,HorizontalAlign.RIGHT,VerticalAlign.BOTTOM);
         param1.addChild(_loc3_);
         return _loc3_;
      }
      
      private function §_-c2f§(param1:Event) : void
      {
         var _loc2_:uint = uint(param1.data as uint);
         this.§_-A3F§.§_-Pr§ = _loc2_;
         invalidate(§_-dU§.CLAN_EMBLEM);
      }
      
      private function §_-D2J§(param1:Event) : void
      {
         var _loc2_:uint = uint(param1.data as uint);
         this.§_-A3F§.§_-r2i§ = _loc2_;
         invalidate(§_-dU§.CLAN_EMBLEM);
      }
      
      private function §_-7Y§(param1:Event) : void
      {
         this.§_-A3F§.§_-Uj§ = int(this.binder._figureTypeSlider.value);
         this.§_-q2h§(this.binder._figureTypeSlider);
         this.§_-Rb§(this.binder._figureTypeSlider,this.binder._figureTypePrevButton,this.binder._figureTypeNextButton);
         invalidate(§_-dU§.CLAN_EMBLEM);
      }
      
      private function §_-d2w§(param1:Event) : void
      {
         this.§_-A3F§.§_-83j§ = int(this.binder._backTypeSlider.value);
         this.§_-q2h§(this.binder._backTypeSlider);
         this.§_-Rb§(this.binder._backTypeSlider,this.binder._backTypePrevButton,this.binder._backTypeNextButton);
         invalidate(§_-dU§.CLAN_EMBLEM);
      }
      
      private function §_-y1l§(param1:Event) : void
      {
         §_-h2B§.play(§_-d27§.§_-S29§);
         var _loc2_:EventDispatcher = param1.currentTarget;
         switch(_loc2_)
         {
            case this.binder._okButton:
               §§push(0);
               break;
            case this.binder._cancelButton:
               §§push(1);
               break;
            case this.binder._figureTypePrevButton:
               §§push(2);
               break;
            case this.binder._figureTypeNextButton:
               §§push(3);
               break;
            default:
               switch(_loc2_)
               {
                  case this.binder._backTypePrevButton:
                     §§push(4);
                     break;
                  case this.binder._backTypeNextButton:
                     §§push(5);
                     break;
                  default:
                     §§push(6);
               }
         }
         switch(§§pop())
         {
            case 0:
               dispatchEventWith(Event.COMPLETE,false,this.§_-A3F§.§_-6B§);
               break;
            case 1:
               dispatchEventWith(Event.CANCEL);
               break;
            case 2:
               --this.binder._figureTypeSlider.value;
               break;
            case 3:
               this.binder._figureTypeSlider.value += 1;
               break;
            case 4:
               --this.binder._backTypeSlider.value;
               break;
            case 5:
               this.binder._backTypeSlider.value += 1;
         }
      }
      
      public function §_-o2M§(param1:§_-sI§) : void
      {
         this.§_-c2h§ = param1;
         this.§_-13S§(this.binder._figureTypeSlider,1,this.§_-c2h§.clanEmblemFiguresCount);
         this.§_-13S§(this.binder._backTypeSlider,1,this.§_-c2h§.clanEmblemBacksCount);
      }
      
      public function setData(param1:Vector.<uint>) : void
      {
         this.§_-zB§ = param1;
         invalidate(INVALIDATION_FLAG_DATA);
      }
      
      private function §_-13S§(param1:Slider, param2:int, param3:int) : void
      {
         param1.minimum = param2;
         param1.maximum = param3;
         param1.value = MathUtil.clamp(param1.value,param2,param3);
         this.§_-q2h§(param1);
      }
      
      private function §_-q2h§(param1:Slider) : void
      {
         param1.thumbProperties.label = int(param1.value).toString();
      }
      
      private function §_-Rb§(param1:Slider, param2:Button, param3:Button) : void
      {
         param2.isEnabled = param1.value > param1.minimum;
         param3.isEnabled = param1.value < param1.maximum;
      }
   }
}

import feathers.controls.Button;
import feathers.controls.Label;
import feathers.controls.LayoutGroup;
import feathers.controls.Panel;
import feathers.controls.Slider;

class Binder
{
   
   public var _container:Panel;
   
   public var _emblemContainer:LayoutGroup;
   
   public var _figureColorPickerContainer:LayoutGroup;
   
   public var _backColorPickerContainer:LayoutGroup;
   
   public var _figureTypeLabel:Label;
   
   public var _figureColorLabel:Label;
   
   public var _backTypeLabel:Label;
   
   public var _backColorLabel:Label;
   
   public var _figureTypeSlider:Slider;
   
   public var _backTypeSlider:Slider;
   
   public var _okButton:Button;
   
   public var _cancelButton:Button;
   
   public var _figureTypePrevButton:Button;
   
   public var _figureTypeNextButton:Button;
   
   public var _backTypePrevButton:Button;
   
   public var _backTypeNextButton:Button;
   
   public function Binder()
   {
      super();
   }
}
