package §_-Vg§
{
   import §_-H2g§.§_-di§;
   import §_-TF§.§_-P19§;
   import §_-TF§.§_-Z1U§;
   import §_-YF§.§_-L29§;
   import §_-l2r§.§_-K1t§;
   import §_-zI§.§_-A1s§;
   import dragonBones.Slot;
   import feathers.controls.ImageLoader;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.RelativePosition;
   import feathers.layout.VerticalAlign;
   import feathers.utils.textures.TextureCache;
   import starling.display.DisplayObject;
   import starling.display.Sprite;
   import starling.utils.ScaleMode;
   
   public class §_-X7§ extends Sprite implements §_-Z1U§
   {
      
      private static const §_-tA§:String = "ClanIcon";
      
      private var §_-GD§:String;
      
      private var icon:ImageLoader;
      
      private var armature:§_-di§;
      
      private var _textureCache:TextureCache;
      
      private var §_-v1I§:Vector.<uint>;
      
      private var §_-01A§:§_-A1s§;
      
      public function §_-X7§(param1:TextureCache = null)
      {
         super();
         this.§_-GD§ = §_-L29§.§_-f1N§("icons/clan/");
         this._textureCache = param1;
         this.initialize();
         this.draw();
      }
      
      override public function dispose() : void
      {
         super.dispose();
         this.armature.dispose();
      }
      
      protected function initialize() : void
      {
         this.armature = §_-K1t§.buildArmature("ClanBanner",§_-K1t§.§_-G1E§,§_-K1t§.§_-yr§);
         this.icon = new ImageLoader();
         this.icon.width = 60;
         this.icon.height = 60;
         this.icon.maintainAspectRatio = true;
         this.icon.scaleMode = ScaleMode.SHOW_ALL;
         this.icon.horizontalAlign = HorizontalAlign.CENTER;
         this.icon.verticalAlign = VerticalAlign.MIDDLE;
         this.icon.alignPivot();
         var _loc1_:Sprite = new Sprite();
         _loc1_.addChild(this.icon);
         this.armature.display.scale = 0.5;
         addChild(this.armature.display);
         var _loc2_:Slot = this.armature.getSlot("flag").childArmature.getSlot("icon");
         _loc2_.display = _loc1_;
         this.armature.getSlot("flag").childArmature.invalidUpdate();
         this.armature.invalidUpdate();
         this.§_-F2W§();
      }
      
      private function §_-F2W§() : void
      {
         this.icon.textureCache = this._textureCache;
      }
      
      protected function draw() : void
      {
         var anim_name:String = null;
         var visible:Boolean = this.§_-v1I§ != null;
         this.visible = visible;
         if(visible)
         {
            try
            {
               this.armature.getSlot("flag").childArmature.getSlot("flag").rawDisplay.color = this.§_-v1I§[2];
               anim_name = this.§_-01A§.id.value.toString();
               this.armature.getSlot("pole_left").childArmature.animation.gotoAndStop(anim_name);
               this.armature.getSlot("pole_right").childArmature.animation.gotoAndStop(anim_name);
               this.armature.getSlot("pole_bottom").childArmature.animation.gotoAndStop(anim_name);
               this.icon.source = this.§_-K3F§(this.§_-v1I§[1]);
               this.icon.color = this.§_-v1I§[3];
               this.armature.invalidUpdate();
            }
            catch(e:*)
            {
            }
         }
      }
      
      private function §_-K3F§(param1:uint = 1) : String
      {
         return this.§_-GD§ + §_-tA§ + param1.toString() + ".png";
      }
      
      public function setData(param1:Vector.<uint>, param2:§_-A1s§) : void
      {
         this.§_-01A§ = param2;
         if(param1 != null)
         {
            this.§_-v1I§ = param1.concat();
         }
         else
         {
            this.§_-v1I§ = null;
         }
         this.draw();
      }
      
      public function set textureCache(param1:TextureCache) : void
      {
         this._textureCache = param1;
         this.§_-F2W§();
      }
      
      public function getOrigin() : DisplayObject
      {
         return this;
      }
      
      public function §_-8I§() : DisplayObject
      {
         if(this.§_-01A§)
         {
            return new §_-P19§(this.§_-01A§.name,this.§_-01A§.description);
         }
         return null;
      }
      
      public function §_-52e§() : Object
      {
         return new <String>[RelativePosition.BOTTOM];
      }
   }
}

