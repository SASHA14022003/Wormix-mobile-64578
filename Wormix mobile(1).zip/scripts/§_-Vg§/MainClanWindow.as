package §_-Vg§
{
   import §_-DJ§.§_-V1Y§;
   import §_-J3L§.§_-h1D§;
   import §_-SP§.§_-M4§;
   import feathers.controls.ScreenNavigator;
   import feathers.controls.ScreenNavigatorItem;
   import feathers.controls.TabBar;
   import feathers.data.IListCollection;
   import feathers.data.ListCollection;
   import feathers.layout.AnchorLayoutData;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.model.§_-d27§;
   import starling.events.Event;
   
   public class MainClanWindow extends §_-V1Y§
   {
      
      private var binder:Binder;
      
      private var §_-bc§:ScreenNavigator;
      
      private var §_-H1I§:Array;
      
      private var §_-Z1s§:§_-K3K§;
      
      public function MainClanWindow(param1:Array, param2:§_-K3K§)
      {
         super();
         this.§_-H1I§ = param1.concat();
         this.§_-Z1s§ = param2;
      }
      
      public static function §_-K2F§(param1:Array, param2:§_-K3K§, param3:Function = null) : void
      {
         var _loc4_:MainClanWindow = new MainClanWindow(param1,param2);
         if(param3 != null)
         {
            _loc4_.addEventListener(§_-h1D§.WINDOW_CLOSE,param3);
         }
         _loc4_.show();
      }
      
      public static function §_-Fg§(param1:§_-K3K§, param2:Function = null) : void
      {
         var _loc3_:MainClanWindow = new MainClanWindow([param1],param1);
         if(param2 != null)
         {
            _loc3_.addEventListener(§_-h1D§.WINDOW_CLOSE,param2);
         }
         _loc3_.show();
      }
      
      override protected function initialize() : void
      {
         var _loc2_:§_-K3K§ = null;
         var _loc4_:ScreenNavigatorItem = null;
         var _loc5_:String = null;
         super.initialize();
         this.binder = new Binder();
         §_-Z1p§("clan_main_window",this.binder);
         addChild(this.binder._container);
         this.binder._tabBar.distributeTabSizes = false;
         this.binder._tabBar.tabProperties.width = 150;
         this.binder._tabBar.paddingLeft = 20;
         this.binder._tabBar.paddingTop = 10;
         this.binder._tabBar.gap = 5;
         var _loc1_:ListCollection = new ListCollection();
         var _loc3_:int = int(this.§_-H1I§.length);
         if(_loc3_ > 1)
         {
            this.binder._titlePanel.removeFromParent(true);
            for each(_loc2_ in this.§_-H1I§)
            {
               _loc1_.addItem({
                  "id":_loc2_.id,
                  "label":§_-s2a§.§_-K3t§(_loc2_.stringId)
               });
            }
            this.binder._tabBar.dataProvider = _loc1_;
         }
         else
         {
            this.binder._tabBar.removeFromParent();
            this.binder._titleLabel.text = §_-s2a§.§_-K3t§((this.§_-H1I§[0] as §_-K3K§).stringId);
         }
         this.binder._container.validate();
         this.§_-bc§ = new ScreenNavigator();
         this.§_-bc§.layoutData = new AnchorLayoutData(0,0,0,0);
         for each(_loc2_ in this.§_-H1I§)
         {
            _loc4_ = new ScreenNavigatorItem(_loc2_.cls);
            _loc4_.setFunctionForEvent(§_-M4§.WINDOW_CLOSE,this.§_-03a§);
            this.§_-bc§.addScreen(_loc2_.id,_loc4_);
         }
         this.binder._view.addChild(this.§_-bc§);
         _loc5_ = this.§_-Z1s§ ? this.§_-Z1s§.id : this.§_-H1I§[0].id;
         var _loc6_:int = this.§_-Z1s§ ? int(this.§_-H1I§.indexOf(this.§_-Z1s§)) : 0;
         this.§_-bc§.showScreen(_loc5_);
         if(_loc3_ > 1)
         {
            this.binder._tabBar.selectedIndex = _loc6_;
         }
         this.binder._view.addChild(this.§_-bc§);
         §_-J2N§(this.binder._closeButton,Event.TRIGGERED,this.§_-03a§);
         §_-J2N§(this.binder._tabBar,Event.CHANGE,this.§_-w2q§);
         §_-J2N§(this.binder._tabBar,Event.TRIGGERED,null,§_-d27§.§_-S29§);
      }
      
      public function §_-4r§() : void
      {
         var _loc3_:int = 0;
         var _loc1_:IListCollection = this.binder._tabBar.dataProvider;
         var _loc2_:Array = [§_-K3K§.INFO.id,§_-K3K§.TREASURY.id,§_-K3K§.§_-G1r§.id];
         if(Boolean(_loc1_) && _loc1_.length > 1)
         {
            _loc3_ = _loc1_.length;
            while(--_loc3_ > -1)
            {
               if(_loc2_.indexOf(_loc1_.getItemAt(_loc3_).id) != -1)
               {
                  _loc1_.removeItemAt(_loc3_);
               }
            }
         }
      }
      
      private function §_-03a§(param1:Event) : void
      {
         hide();
      }
      
      override public function dispose() : void
      {
         super.dispose();
         §_-jg§(this.binder._closeButton,Event.TRIGGERED);
         §_-jg§(this.binder._tabBar,Event.CHANGE);
         §_-jg§(this.binder._tabBar,Event.TRIGGERED);
         this.§_-H1I§ = null;
         this.§_-Z1s§ = null;
      }
      
      private function §_-w2q§(param1:Event) : void
      {
         var _loc2_:TabBar = TabBar(param1.currentTarget);
         this.§_-bc§.showScreen(_loc2_.selectedItem.id);
      }
   }
}

import feathers.controls.Button;
import feathers.controls.Label;
import feathers.controls.LayoutGroup;
import feathers.controls.TabBar;

class Binder
{
   
   public var _container:LayoutGroup;
   
   public var _titlePanel:LayoutGroup;
   
   public var _view:LayoutGroup;
   
   public var _tabBar:TabBar;
   
   public var _titleLabel:Label;
   
   public var _closeButton:Button;
   
   public function Binder()
   {
      super();
   }
}
