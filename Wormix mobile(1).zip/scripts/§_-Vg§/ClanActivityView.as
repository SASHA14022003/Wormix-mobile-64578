package §_-Vg§
{
   import §_-jF§.ClanActivityItemRenderer;
   import §_-jF§.§_-O2X§;
   import §_-u1T§.§_-a1D§;
   import §_-u1T§.§_-r1F§;
   import §_-zI§.§_-91X§;
   import feathers.controls.ScrollPolicy;
   import feathers.data.HierarchicalCollection;
   import feathers.layout.AnchorLayout;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.VerticalLayout;
   import feathers.themes.styles.AlternateScrollBarStyles;
   import flash.globalization.DateTimeFormatter;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.structures.ClanAuditActionTO;
   import ru.pragmatix.wormix.utils.§_-72u§;
   
   public class ClanActivityView extends §_-03W§ implements §_-r1F§
   {
      
      private var binder:Binder;
      
      private var §_-g2n§:§_-a1D§;
      
      public function ClanActivityView()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         this.layout = new AnchorLayout();
         this.binder = new Binder();
         var _loc1_:Object = Application.assetManager.getObject("clan_activity_view");
         Application.uiBuilder.create(_loc1_,true,this.binder);
         addChild(this.binder._container);
         var _loc2_:VerticalLayout = new VerticalLayout();
         _loc2_.gap = 2;
         _loc2_.padding = 5;
         _loc2_.paddingRight = 10;
         _loc2_.paddingLeft = 10;
         _loc2_.horizontalAlign = HorizontalAlign.LEFT;
         _loc2_.hasVariableItemDimensions = true;
         _loc2_.useVirtualLayout = true;
         this.binder._activityList.layout = _loc2_;
         this.binder._activityList.itemRendererType = ClanActivityItemRenderer;
         this.binder._activityList.headerRendererType = §_-O2X§;
         this.binder._activityList.dataProvider = new HierarchicalCollection();
         this.binder._activityList.customVerticalScrollBarStyleName = AlternateScrollBarStyles.SIMPLE_NORMAL;
         this.binder._activityList.verticalScrollPolicy = ScrollPolicy.AUTO;
         this.binder._activityList.horizontalScrollPolicy = ScrollPolicy.OFF;
      }
      
      override public function dispose() : void
      {
         this.§_-g2n§.removeObject(this.binder._activityLabel);
         this.binder = null;
         super.dispose();
      }
      
      public function §_-DW§(param1:§_-a1D§) : void
      {
         this.§_-g2n§ = param1;
         this.§_-g2n§.§_-I2k§(this.binder._activityLabel,"text",§_-s2a§.LOADING);
      }
      
      public function setData(param1:Vector.<ClanAuditActionTO>) : void
      {
         (this.binder._activityList.dataProvider as HierarchicalCollection).data = this.§_-I3S§(param1);
         if(param1.length == 0)
         {
            this.§_-g2n§.§_-83D§(this.binder._activityLabel,"text",§_-s2a§.CLAN_NO_ACTIVITY_THIS_MONTH);
         }
         else
         {
            this.§_-g2n§.§_-83D§(this.binder._activityLabel,"text","");
         }
      }
      
      private function §_-I3S§(param1:Vector.<ClanAuditActionTO>) : Array
      {
         var _loc3_:Object = null;
         var _loc7_:ClanAuditActionTO = null;
         var _loc8_:Date = null;
         var _loc9_:String = null;
         var _loc2_:Array = [];
         var _loc4_:DateTimeFormatter = new DateTimeFormatter("eu-EU");
         _loc4_.setDateTimePattern("dd.MM.yyyy");
         var _loc5_:DateTimeFormatter = new DateTimeFormatter("eu-EU");
         _loc5_.setDateTimePattern("HH:mm");
         var _loc6_:String = "";
         for each(_loc7_ in param1)
         {
            if(§_-91X§.§_-K2C§.indexOf(_loc7_.action) != -1)
            {
               _loc8_ = §_-72u§.§_-p2H§(_loc7_.date);
               _loc9_ = _loc4_.format(_loc8_);
               if(_loc9_ != _loc6_)
               {
                  _loc6_ = _loc9_;
                  _loc3_ = {
                     "header":_loc6_,
                     "children":[]
                  };
                  _loc2_.push(_loc3_);
               }
               _loc3_.children.push({
                  "date":_loc9_,
                  "time":_loc5_.format(_loc8_),
                  "action":_loc7_
               });
            }
         }
         return _loc2_;
      }
   }
}

import feathers.controls.GroupedList;
import feathers.controls.Label;
import feathers.controls.LayoutGroup;

class Binder
{
   
   public var _container:LayoutGroup;
   
   public var _activityLabel:Label;
   
   public var _activityList:GroupedList;
   
   public function Binder()
   {
      super();
   }
}
