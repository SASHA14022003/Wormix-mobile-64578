package §_-Vg§
{
   import §_-C3f§.§_-Z1Y§;
   import §_-YF§.§_-L29§;
   import feathers.controls.ImageLoader;
   import feathers.controls.LayoutGroup;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.VerticalAlign;
   import feathers.utils.textures.TextureCache;
   import starling.display.DisplayObject;
   import starling.display.Image;
   import starling.utils.Color;
   import starling.utils.ScaleMode;
   
   public class §_-M11§ extends LayoutGroup
   {
      
      private static const §_-Ab§:int = 113;
      
      private static const §_-o1d§:int = 111;
      
      private static const §_-ms§:int = 87;
      
      private static const §_-5i§:String = "ClanIconBackground.png";
      
      private static const §_-f2E§:String = "ClanIconShadow.png";
      
      private static const §_-L2P§:String = "ClanBack";
      
      private static const §_-tA§:String = "ClanIcon";
      
      private var §_-r1U§:String;
      
      private var §_-P2z§:ImageLoader;
      
      private var §_-q2A§:ImageLoader;
      
      private var §_-O1N§:ImageLoader;
      
      private var §_-i5§:ImageLoader;
      
      private var §_-62g§:Image;
      
      private var _textureCache:TextureCache;
      
      private var _scale:Number = 1;
      
      private var §_-v1I§:Vector.<uint>;
      
      public function §_-M11§(param1:TextureCache = null, param2:Vector.<uint> = null)
      {
         super();
         this.§_-r1U§ = §_-L29§.§_-f1N§("icons/clan/");
         this._textureCache = param1;
         if(param2)
         {
            this.§_-v1I§ = param2.concat();
         }
         else
         {
            §§push(this);
            var _temp_1:* = new <uint>[1,1,Color.RED,Color.WHITE];
            §§pop().§_-v1I§ = new <uint>[1,1,Color.RED,Color.WHITE];
         }
      }
      
      public function set size(param1:Number) : void
      {
         this._scale = param1 / §_-o1d§;
         this.§_-R2q§();
      }
      
      override public function addChild(param1:DisplayObject) : DisplayObject
      {
         param1.scale = this._scale;
         return super.addChild(param1);
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         this.§_-P2z§ = new ImageLoader();
         this.§_-P2z§.source = this.§_-r1U§ + §_-5i§;
         this.§_-i5§ = new ImageLoader();
         this.§_-i5§.source = this.§_-r1U§ + §_-f2E§;
         this.§_-62g§ = new Image(Application.assetManager.getTexture("clan_emblem_border"));
         this.§_-q2A§ = this.§_-G3q§();
         this.§_-O1N§ = this.§_-G3q§();
         this.addChild(this.§_-P2z§);
         this.addChild(this.§_-q2A§);
         this.addChild(this.§_-O1N§);
         this.addChild(this.§_-i5§);
         this.addChild(this.§_-62g§);
         this.§_-R2q§();
         this.§_-F2W§();
      }
      
      private function §_-R2q§() : void
      {
         var _loc4_:DisplayObject = null;
         var _loc1_:Number = (§_-Ab§ - §_-ms§) / 2 * this._scale;
         var _loc2_:Number = (§_-o1d§ - §_-ms§) / 2 * this._scale;
         var _loc3_:int = 0;
         while(_loc3_ < numChildren)
         {
            _loc4_ = getChildAt(_loc3_);
            _loc4_.scale = this._scale;
            if(_loc4_ is ImageLoader)
            {
               _loc4_.x = _loc1_;
               _loc4_.y = _loc2_;
            }
            _loc3_++;
         }
      }
      
      private function §_-F2W§() : void
      {
         this.§_-P2z§.textureCache = this._textureCache;
         this.§_-q2A§.textureCache = this._textureCache;
         this.§_-O1N§.textureCache = this._textureCache;
         this.§_-i5§.textureCache = this._textureCache;
      }
      
      private function §_-G3q§() : ImageLoader
      {
         var _loc1_:ImageLoader = new ImageLoader();
         _loc1_.width = §_-ms§;
         _loc1_.height = §_-ms§;
         _loc1_.maintainAspectRatio = true;
         _loc1_.scaleMode = ScaleMode.NONE;
         _loc1_.horizontalAlign = HorizontalAlign.CENTER;
         _loc1_.verticalAlign = VerticalAlign.MIDDLE;
         return _loc1_;
      }
      
      override protected function draw() : void
      {
         var _loc2_:Boolean = false;
         var _loc1_:Boolean = isInvalid(INVALIDATION_FLAG_DATA);
         if(_loc1_)
         {
            _loc2_ = this.§_-v1I§ != null;
            this.§_-P2z§.visible = _loc2_;
            this.§_-q2A§.visible = _loc2_;
            this.§_-O1N§.visible = _loc2_;
            this.§_-i5§.visible = _loc2_;
            if(_loc2_)
            {
               this.§_-P2z§.color = this.§_-v1I§[2];
               this.§_-q2A§.source = this.§_-Y2i§(this.§_-v1I§[0]);
               this.§_-O1N§.source = this.§_-K3F§(this.§_-v1I§[1]);
               this.§_-O1N§.color = this.§_-v1I§[3];
            }
         }
         super.draw();
      }
      
      private function §_-Y2i§(param1:uint = 1) : String
      {
         return this.§_-r1U§ + §_-L2P§ + param1.toString() + ".png";
      }
      
      private function §_-K3F§(param1:uint = 1) : String
      {
         return this.§_-r1U§ + §_-tA§ + param1.toString() + ".png";
      }
      
      public function get §_-83j§() : uint
      {
         return this.§_-v1I§[0];
      }
      
      public function set §_-83j§(param1:uint) : void
      {
         this.§_-92d§(param1,0);
      }
      
      public function get §_-Uj§() : uint
      {
         return this.§_-v1I§[1];
      }
      
      public function set §_-Uj§(param1:uint) : void
      {
         this.§_-92d§(param1,1);
      }
      
      public function get §_-r2i§() : uint
      {
         return this.§_-v1I§[2];
      }
      
      public function set §_-r2i§(param1:uint) : void
      {
         this.§_-92d§(param1,2);
      }
      
      public function get §_-Pr§() : uint
      {
         return this.§_-v1I§[3];
      }
      
      public function set §_-Pr§(param1:uint) : void
      {
         this.§_-92d§(param1,3);
      }
      
      private function §_-92d§(param1:uint, param2:uint) : void
      {
         if(this.§_-v1I§[param2] != param1)
         {
            this.§_-v1I§[param2] = param1;
            if(_isInitialized)
            {
               invalidate(INVALIDATION_FLAG_DATA);
            }
         }
      }
      
      public function get §_-6B§() : Vector.<uint>
      {
         return this.§_-v1I§.concat();
      }
      
      public function set §_-6B§(param1:Vector.<uint>) : void
      {
         if(param1 != null)
         {
            this.§_-v1I§ = param1.concat();
         }
         else
         {
            this.§_-v1I§ = null;
         }
         invalidate(INVALIDATION_FLAG_DATA);
      }
      
      public function set textureCache(param1:TextureCache) : void
      {
         this._textureCache = param1;
         if(_isInitialized)
         {
            this.§_-F2W§();
         }
      }
   }
}

