package §_-Vg§
{
   import ru.pragmatix.wormix.gui.§_-s2a§;
   
   public class §_-K3K§
   {
      
      public static const SEARCH:§_-K3K§ = new §_-K3K§("SEARCH",§_-s2a§.TAB_SEARCH_CLAN,ClanSearchView);
      
      public static const CREATE:§_-K3K§ = new §_-K3K§("CREATE",§_-s2a§.TAB_CREATE_CLAN,ClanCreateView);
      
      public static const EDIT:§_-K3K§ = new §_-K3K§("EDIT",§_-s2a§.CLAN_EDIT_TAB,ClanEditView);
      
      public static const EDIT_EMBLEM:§_-K3K§ = new §_-K3K§("EDIT_EMBLEM",§_-s2a§.CLAN_EMBLEM,ClanEditEmblemView);
      
      public static const INFO:§_-K3K§ = new §_-K3K§("INFO",§_-s2a§.CLAN_INFO_TAB,ClanInfoView);
      
      public static const TREASURY:§_-K3K§ = new §_-K3K§("TREASURY",§_-s2a§.TAB_TREASURY_CLAN,ClanTreasuryView);
      
      public static const §_-G1r§:§_-K3K§ = new §_-K3K§("HISTORY",§_-s2a§.TAB_CLAN_ACTIVITY,ClanActivityView);
      
      private var _id:String;
      
      private var §_-E3u§:String;
      
      private var §_-x§:Class;
      
      public function §_-K3K§(param1:String, param2:String, param3:Class)
      {
         super();
         this._id = param1;
         this.§_-E3u§ = param2;
         this.§_-x§ = param3;
      }
      
      public function get id() : String
      {
         return this._id;
      }
      
      public function get stringId() : String
      {
         return this.§_-E3u§;
      }
      
      public function get cls() : Class
      {
         return this.§_-x§;
      }
   }
}

