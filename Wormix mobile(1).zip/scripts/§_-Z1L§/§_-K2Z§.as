package §_-Z1L§
{
   import §_-21p§.§_-4w§;
   import §_-63M§.§_-F3f§;
   import §_-73I§.*;
   import §_-931§.§_-i2r§;
   import §_-A1K§.SpeedhackDetectedEvent;
   import §_-A1K§.§_-TA§;
   import §_-B1y§.Cookie;
   import §_-B1y§.§_-83E§;
   import §_-B1y§.§_-bs§;
   import §_-Cl§.*;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-J31§.§_-e2J§;
   import §_-L1H§.§_-C3e§;
   import §_-R2S§.*;
   import §_-SP§.§_-M4§;
   import §_-YF§.§_-q2v§;
   import §_-Z1K§.§_-q24§;
   import §_-Z1w§.§_-s1x§;
   import §_-b1F§.§_-v2Q§;
   import §_-j22§.§_-5g§;
   import §_-l1g§.§_-L3Q§;
   import §_-p18§.§_-vd§;
   import §_-rM§.§_-61j§;
   import §_-s20§.§_-J2g§;
   import §_-s20§.§_-R1P§;
   import §_-sQ§.§_-f1z§;
   import §_-u1F§.§_-SE§;
   import §_-w2i§.§_-52k§;
   import §_-w2i§.§_-Ia§;
   import com.greensock.*;
   import com.greensock.core.*;
   import config.§_-vR§;
   import dragonBones.animation.WorldClock;
   import dragonBones.starling.StarlingFactory;
   import dragonBones.starling.StarlingTextureAtlasData;
   import dragonBones.textures.TextureAtlasData;
   import feathers.themes.styles.AlternateTextStyles;
   import flash.events.Event;
   import flash.events.EventDispatcher;
   import flash.events.TimerEvent;
   import flash.geom.Point;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import flash.utils.IDataOutput;
   import flash.utils.Timer;
   import flash.utils.getQualifiedClassName;
   import ru.pragmatix.flox.serialization.§_-616§;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.arena.boss.BossTypesTab;
   import ru.pragmatix.wormix.messages.clans.main.server.ClanInviteStructure;
   import ru.pragmatix.wormix.messages.clans.main.server.InviteFriendToClan;
   import ru.pragmatix.wormix.messages.client.SetHotkeys;
   import ru.pragmatix.wormix.messages.server.ArenaLocked;
   import ru.pragmatix.wormix.messages.server.StartBattleResult;
   import ru.pragmatix.wormix.model.user.*;
   import ru.pragmatix.wormix.objects.Waypoint;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.CollideType;
   import ru.pragmatix.wormix.serialization.SerializationUtils;
   import ru.pragmatix.wormix.utils.*;
   import ru.pragmatix.wormix.weapons.ammo.phase.PhaseAmmoWithArmature;
   import ru.pragmatix.wormix.weapons.ammo.type.grenade.cluster.ShellBurst;
   import starling.display.DisplayObject;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.textures.TextureAtlas;
   import starling.utils.AssetManager;
   import starling.utils.Pool;
   
   public class §_-K2Z§ extends EventDispatcher
   {
      
      private const §_-B2l§:uint = 1000;
      
      private const §_-E2J§:Number = 0.7;
      
      private const §_-L34§:Number = 20000;
      
      private const §_-F3r§:uint = 10;
      
      private var §_-S2g§:Timer;
      
      private var mark:Number;
      
      private var counter:uint = 0;
      
      public function §_-K2Z§()
      {
         super();
      }
      
      public function run() : void
      {
         if(this.§_-S2g§ == null)
         {
            this.counter = 0;
            this.mark = new Date().time;
            this.§_-S2g§ = new Timer(this.§_-B2l§);
            this.§_-S2g§.addEventListener(TimerEvent.TIMER,this.onTimer,false,0,true);
            this.§_-S2g§.start();
         }
      }
      
      public function stop() : void
      {
         if(this.§_-S2g§ != null)
         {
            this.§_-S2g§.stop();
            this.§_-S2g§ = null;
         }
      }
      
      public function §_-q2§() : Boolean
      {
         return this.§_-S2g§ != null;
      }
      
      public function §_-Qz§() : Boolean
      {
         var _loc1_:Number = Number(new Date().time);
         return _loc1_ - this.mark < this.§_-L34§;
      }
      
      private function onTimer(param1:flash.events.Event) : void
      {
         var _loc2_:Number = Number(new Date().time);
         if(_loc2_ - this.mark > this.§_-L34§)
         {
            dispatchEvent(new SpeedhackDetectedEvent());
            return;
         }
         var _loc3_:Number = (_loc2_ - this.mark - this.§_-B2l§) / this.§_-B2l§;
         if(_loc3_ < -this.§_-E2J§)
         {
            if(++this.counter == this.§_-F3r§)
            {
               dispatchEvent(new SpeedhackDetectedEvent());
            }
         }
         else
         {
            this.counter = 0;
         }
         this.mark = _loc2_;
      }
   }
}

