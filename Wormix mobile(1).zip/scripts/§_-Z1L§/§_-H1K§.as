package §_-Z1L§
{
   import §_-11L§.*;
   import §_-21A§.*;
   import §_-63M§.§_-F3f§;
   import §_-63U§.§_-c1e§;
   import §_-C2t§.§_-92W§;
   import §_-J31§.§_-R1h§;
   import §_-RE§.§_-52p§;
   import §_-W§.§_-Ap§;
   import §_-Z1w§.§_-s1x§;
   import §_-aM§.*;
   import §_-l1K§.§_-F3m§;
   import §_-l1K§.§_-I7§;
   import §_-l1K§.§_-m2§;
   import §_-q11§.§_-C2n§;
   import com.greensock.loading.*;
   import com.hurlant.crypto.tls.§_-21v§;
   import com.hurlant.util.§_-F2L§;
   import feathers.core.ToggleGroup;
   import flash.display.MovieClip;
   import flash.globalization.DateTimeFormatter;
   import flash.media.SoundTransform;
   import flash.utils.ByteArray;
   import ru.pragmatix.flox.gui.controls.§_-NY§;
   import ru.pragmatix.flox.social.model.SocialUserData;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.main.server.ClanInviteStructure;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.*;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   import starling.utils.SystemUtil;
   
   public class §_-H1K§ extends Event
   {
      
      public static const NAME:String = "CheatDetected";
      
      public var banType:uint;
      
      public var note:String;
      
      public function §_-H1K§(param1:uint, param2:String, param3:Boolean = false)
      {
         super(NAME,param3);
         this.banType = param1;
         this.note = param2;
      }
      
      public function clone() : Event
      {
         return new §_-H1K§(this.banType,this.note,bubbles);
      }
      
      override public function toString() : String
      {
         return "CheatDetectedEvent: type=" + type + ", bubbles=" + bubbles + ", banType=" + this.banType;
      }
   }
}

