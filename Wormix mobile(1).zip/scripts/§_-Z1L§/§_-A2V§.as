package §_-Z1L§
{
   import §_-5P§.§_-H1u§;
   import §_-62§.§_-F1D§;
   import §_-62§.§_-G1p§;
   import §_-63M§.§_-F3f§;
   import §_-82a§.*;
   import §_-A1K§.§_-6L§;
   import §_-A1K§.§_-TA§;
   import §_-A1K§.§_-U11§;
   import §_-A2U§.*;
   import §_-B1y§.*;
   import §_-C3f§.*;
   import §_-CF§.§_-x2t§;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.MessageBox;
   import §_-DJ§.§_-fH§;
   import §_-E1I§.§_-b2n§;
   import §_-F39§.§_-D14§;
   import §_-L1H§.§_-b2K§;
   import §_-P2i§.§_-b7§;
   import §_-S1N§.§_-C14§;
   import §_-S1N§.§_-zk§;
   import §_-Tm§.§_-RF§;
   import §_-Y1O§.§_-V23§;
   import §_-Y1b§.§_-22N§;
   import §_-YF§.§_-q2v§;
   import §_-aM§.*;
   import §_-j1w§.§_-B2i§;
   import §_-l1K§.§_-d2j§;
   import §_-l1K§.§_-m2§;
   import §_-l1g§.§_-L3Q§;
   import §_-nE§.§_-p16§;
   import §_-qH§.§_-5j§;
   import §_-qH§.§_-AC§;
   import §_-r1C§.§_-h2B§;
   import §_-rM§.§_-61j§;
   import §_-s20§.§_-J2g§;
   import §_-w2W§.AchieveRoomScreenDesktop;
   import §_-w2W§.ArmoryScreenDesktop;
   import §_-w2W§.CraftRoomScreenDesktop;
   import §_-w2W§.DesktopRaceRoomScreen;
   import §_-w2W§.MainMenuScreenDesktop;
   import §_-w2W§.TeamRoomScreenDesktop;
   import §_-w2W§.WardrobeRoomScreen;
   import §_-w2W§.§_-21w§;
   import §_-w2W§.§_-72M§;
   import §_-w2W§.§_-HV§;
   import §_-w2W§.§_-I2R§;
   import §_-w2W§.§_-I3c§;
   import §_-w2W§.§_-h1Z§;
   import §_-y1s§.*;
   import §_-zI§.§_-92Q§;
   import §_-zI§.§_-F3q§;
   import §_-zI§.§_-X1q§;
   import §_-zI§.§_-sI§;
   import com.distriqt.extension.inappbilling.InAppBilling;
   import com.distriqt.extension.inappbilling.Purchase;
   import com.greensock.*;
   import com.greensock.plugins.*;
   import com.hurlant.math.BigInteger;
   import com.hurlant.math.bi_internal;
   import config.§_-V2w§;
   import feathers.controls.Button;
   import feathers.controls.Scroller;
   import feathers.core.ToggleGroup;
   import feathers.layout.Direction;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.ILayout;
   import feathers.layout.VerticalLayout;
   import feathers.utils.touch.TapToTrigger;
   import flash.display.BitmapData;
   import flash.display.DisplayObject;
   import flash.events.Event;
   import flash.events.TimerEvent;
   import flash.utils.ByteArray;
   import flash.utils.Dictionary;
   import flash.utils.IDataInput;
   import flash.utils.Timer;
   import ru.pragmatix.flox.gui.controls.§_-NY§;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.flox.social.utils.id.IPlatformAccountController;
   import ru.pragmatix.wormix.Scene;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.sets.ControlSets;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.ClanMessages;
   import ru.pragmatix.wormix.messages.clans.response.*;
   import ru.pragmatix.wormix.messages.clans.structures.*;
   import ru.pragmatix.wormix.messages.client.CheatDetected;
   import ru.pragmatix.wormix.messages.client.Disconnect;
   import ru.pragmatix.wormix.messages.client.SteamTransactionInitRequest;
   import ru.pragmatix.wormix.messages.structures.UserProfileStructure;
   import ru.pragmatix.wormix.messages.structures.WeaponStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.items.craft.§_-6S§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-r1d§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.Force;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.pvp.messages.client.PvpEndTurn;
   import ru.pragmatix.wormix.pvp.messages.ex.ReconnectToBattle;
   import ru.pragmatix.wormix.pvp.messages.ex.StartPvpBattle;
   import ru.pragmatix.wormix.pvp.messages.server.BattleLoginError;
   import ru.pragmatix.wormix.scene.Weather;
   import ru.pragmatix.wormix.scene.tile.AtlasTileData;
   import ru.pragmatix.wormix.scene.tile.TileType;
   import ru.pragmatix.wormix.serialization.SerializationUtils;
   import ru.pragmatix.wormix.social.*;
   import ru.pragmatix.wormix.utils.StringUtil;
   import ru.pragmatix.wormix.utils.§_-6A§;
   import ru.pragmatix.wormix.utils.§_-J2h§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.weapons.*;
   import starling.animation.Transitions;
   import starling.animation.Tween;
   import starling.core.Starling;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   import starling.events.KeyboardEvent;
   import starling.extensions.ParticleAura;
   import starling.textures.Texture;
   import starling.utils.AssetManager;
   import starling.utils.Pool;
   import starling.utils.ScaleMode;
   
   use namespace bi_internal;
   
   public class §_-A2V§
   {
      
      public static const §_-A3T§:uint = 48;
      
      public static const §_-A2e§:uint = 49;
      
      private const §_-H1P§:int = -1231;
      
      private const §_-z2L§:int = 1043;
      
      private const §_-F3P§:Number = -78.6;
      
      private const §_-Z2T§:Number = 96.4;
      
      private var §_-03V§:Number;
      
      private var §_-A3G§:Array = [0.1,0.01,0.001];
      
      private var §_-323§:Array = [];
      
      private var §_-62o§:Array = [];
      
      private var §_-t2P§:Array = [];
      
      public function §_-A2V§()
      {
         super();
         var _loc1_:int = this.§_-H1P§;
         while(_loc1_ < this.§_-z2L§)
         {
            this.§_-323§.push(_loc1_);
            this.§_-t2P§.push(Number(_loc1_));
            _loc1_++;
         }
         var _loc2_:Number = this.§_-F3P§;
         this.§_-03V§ = 0.1;
         while(_loc2_ < this.§_-Z2T§)
         {
            this.§_-62o§.push(_loc2_);
            _loc2_ = Math.round((_loc2_ + this.§_-03V§) * 10) / 10;
         }
      }
      
      public function init() : void
      {
         §_-X1j§.§_-12n§.scene.addEventListener(§_-H1K§.NAME,this.§_-G1Q§);
      }
      
      public function clear() : void
      {
         §_-X1j§.§_-12n§.scene.removeEventListener(§_-H1K§.NAME,this.§_-G1Q§);
      }
      
      public function §_-Gb§() : Boolean
      {
         var _loc1_:String = this.checkState();
         if(_loc1_ != null)
         {
            §_-X1j§.§_-12n§.scene.dispatchEvent(new §_-H1K§(§_-A2e§,_loc1_));
         }
         return _loc1_ == null;
      }
      
      private function checkState() : String
      {
         if(Boolean(§_-X1j§.§_-12n§) && Boolean(§_-X1j§.§_-12n§.gameMaster))
         {
            if(Math.random() > 0.985 && !this.§_-g2H§())
            {
               return "trap values changed";
            }
         }
         return null;
      }
      
      private function §_-g2H§() : Boolean
      {
         var _loc1_:* = 0;
         _loc1_ = 0;
         while(_loc1_ < this.§_-323§.length)
         {
            if(this.§_-323§[_loc1_] != this.§_-H1P§ + _loc1_)
            {
               return false;
            }
            if(Math.abs(this.§_-t2P§[_loc1_] - (this.§_-H1P§ + _loc1_)) > Physics.EPSILON)
            {
               return false;
            }
            _loc1_++;
         }
         var _loc2_:Number = this.§_-F3P§;
         _loc1_ = 0;
         while(_loc2_ < this.§_-Z2T§)
         {
            if(Math.abs(this.§_-62o§[_loc1_++] - _loc2_) > Physics.EPSILON)
            {
               return false;
            }
            _loc2_ += this.§_-03V§;
         }
         return true;
      }
      
      private function §_-f21§() : Boolean
      {
         var _loc2_:§_-V23§ = null;
         var _loc3_:§_-01J§ = null;
         var _loc4_:uint = 0;
         var _loc5_:uint = 0;
         var _loc1_:Boolean = true;
         if(Boolean(§_-X1j§.§_-12n§) && Boolean(§_-X1j§.§_-12n§.gameMaster))
         {
            _loc2_ = §_-X1j§.§_-12n§.gameMaster.§_-vJ§(Application.userProfile);
            if(_loc2_ != null)
            {
               for each(_loc3_ in _loc2_.getUnits())
               {
                  _loc4_ = uint(Math.min(85,_loc3_.record.getLevel() * 2 + 140));
                  _loc5_ = _loc3_.attributes.armor.value + _loc3_.attributes.attack.value;
                  if(_loc3_.attributes.hp.§_-33H§() > 1100 || _loc3_.hp > 1200 || _loc5_ > _loc4_)
                  {
                     _loc1_ = false;
                     break;
                  }
               }
            }
         }
         return _loc1_;
      }
      
      private function §_-s1D§() : Boolean
      {
         var _loc1_:uint = 0;
         if(Boolean(§_-X1j§.§_-12n§) && Boolean(§_-X1j§.§_-12n§.gameMaster) && Boolean(§_-X1j§.§_-12n§.scene.gameInterface))
         {
            _loc1_ = §_-X1j§.§_-12n§.gameMaster.§_-W2j§().online ? 41 : 46;
            if(§_-X1j§.§_-12n§.gameMaster.§_-E3b§() && §_-X1j§.§_-12n§.scene.gameInterface.§_-fz§().time > _loc1_)
            {
               §_-J2g§.§_-i1N§.dispose();
               if(§_-X1j§.§_-41U§)
               {
                  §_-X1j§.§_-41U§.§_-A3u§();
               }
            }
         }
         return true;
      }
      
      private function §_-G1Q§(param1:§_-H1K§) : void
      {
         if(§_-X1j§.§_-12n§.gameMaster)
         {
            try
            {
               §_-X1j§.§_-12n§.gameMaster.§_-L2x§(param1.banType);
               this.§_-fe§(param1.banType,param1.note);
            }
            catch(e:Error)
            {
            }
         }
      }
      
      private function §_-fe§(param1:uint, param2:String) : void
      {
         var _loc3_:CheatDetected = new CheatDetected();
         _loc3_.banType = param1;
         _loc3_.banNote = param2;
         _loc3_.sessionKey = §_-J2g§.§_-i1N§.§_-yt§();
         §_-J2g§.§_-h18§(_loc3_);
      }
      
      public function §_-5T§() : void
      {
         var _loc1_:int = int(int(Cookie.getValue(Application.userProfile.getId().toString(),0)));
         if(_loc1_ != 0)
         {
            Cookie.setValue(Application.userProfile.getId().toString(),0);
         }
         if(_loc1_ == Application.userProfile.getId() % 100 + 42)
         {
            this.§_-fe§(§_-A2e§,"delayed ban");
            this.§_-A3u§();
         }
      }
      
      private function §_-A3u§() : void
      {
         var _loc1_:Timer = new Timer(3000,1);
         _loc1_.addEventListener(TimerEvent.TIMER,this.§_-oX§);
         _loc1_.start();
      }
      
      private function §_-oX§(param1:TimerEvent) : void
      {
         if(§_-J2g§.§_-i1N§.§_-928§())
         {
            Cookie.setValue(Application.userProfile.getId().toString(),Application.userProfile.getId() % 100 + 42);
            §_-J2g§.§_-i1N§.dispose();
         }
      }
   }
}

