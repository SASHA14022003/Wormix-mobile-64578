package §_-Om§
{
   import §_-12W§.*;
   import §_-31N§.§_-Yy§;
   import §_-62§.§_-L1r§;
   import §_-73I§.*;
   import §_-A1K§.§_-6L§;
   import §_-A1K§.§_-U11§;
   import §_-B1y§.*;
   import §_-B2z§.§_-82u§;
   import §_-CF§.§_-E19§;
   import §_-CF§.§_-x2t§;
   import §_-DJ§.§_-fH§;
   import §_-J3L§.§_-h1D§;
   import §_-L1H§.§_-b2K§;
   import §_-Ly§.§_-81L§;
   import §_-SP§.§_-M4§;
   import §_-T2h§.*;
   import §_-TF§.§_-Z1U§;
   import §_-TF§.§_-q1j§;
   import §_-TF§.§_-y2n§;
   import §_-Tm§.§_-RF§;
   import §_-U1i§.§_-hK§;
   import §_-Vg§.*;
   import §_-d26§.§_-c2E§;
   import §_-k1u§.§_-Oi§;
   import §_-k2s§.§_-e1U§;
   import §_-l1g§.§_-L3Q§;
   import §_-r1C§.§_-h2B§;
   import §_-rM§.§_-61j§;
   import §_-s20§.§_-J2g§;
   import §_-w2W§.§_-21w§;
   import §_-z1g§.§_-5c§;
   import com.greensock.*;
   import com.greensock.plugins.*;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import feathers.controls.text.BitmapFontTextRenderer;
   import feathers.data.IListCollection;
   import feathers.layout.RelativePosition;
   import feathers.text.BitmapFontTextFormat;
   import feathers.utils.touch.TapToTrigger;
   import flash.display.DisplayObject;
   import flash.display.MovieClip;
   import flash.errors.IllegalOperationError;
   import flash.events.Event;
   import flash.geom.ColorTransform;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import flash.utils.getQualifiedClassName;
   import ru.pragmatix.flox.gui.controls.MessageBox;
   import ru.pragmatix.flox.logger.§_-11S§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fonts.BitmapFonts;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.request.login.LoginJoinClanRequest;
   import ru.pragmatix.wormix.messages.clans.structures.ClanMemberTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.client.PumpReactionRate;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.pvp.messages.client.PvpCommand;
   import ru.pragmatix.wormix.utils.§_-2t§;
   import ru.pragmatix.wormix.utils.§_-6A§;
   import ru.pragmatix.wormix.utils.§_-F2L§;
   import ru.pragmatix.wormix.weapons.*;
   import starling.display.DisplayObject;
   import starling.display.Image;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.utils.Align;
   import starling.utils.Pool;
   
   public class §_-2T§ extends DefaultListItemRenderer implements §_-Z1U§
   {
      
      public static const §_-t1F§:int = 110;
      
      private var count:BitmapFontTextRenderer;
      
      private var iconContainer:Sprite;
      
      private var icon:starling.display.DisplayObject;
      
      public function §_-2T§()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         width = §_-t1F§;
         height = §_-t1F§;
         var _loc1_:Image = new Image(Application.assetManager.getTexture("InventoryTab_cellBack"));
         _loc1_.scale9Grid = Pool.getRectangle(17,18,1,1);
         this._defaultSkin = _loc1_;
         this.iconContainer = new Sprite();
         this.iconContainer.x = this.iconContainer.y = 55;
         addChild(this.iconContainer);
         this.count = new BitmapFontTextRenderer();
         this.count.textFormat = new BitmapFontTextFormat(BitmapFonts.GROBOLD_NORMAL,16,7362886,Align.RIGHT);
         this.count.x = 5;
         this.count.y = 75;
         this.count.width = 90;
         addChild(this.count);
         §_-q1j§.register(this);
      }
      
      override protected function commitData() : void
      {
         var _loc1_:§_-Oi§ = _data as §_-Oi§;
         if(this.icon)
         {
            this.icon.removeFromParent(true);
         }
         if(Boolean(_loc1_) && _loc1_.getCount() > 0)
         {
            this.count.text = _loc1_.getCount().toString();
            this.icon = §_-q15§.§_-71V§(_loc1_.getRecord());
         }
         else
         {
            this.count.text = "";
            this.icon = new Sprite();
         }
         this.icon.alignPivot();
         this.iconContainer.addChild(this.icon);
      }
      
      public function getOrigin() : starling.display.DisplayObject
      {
         return this.iconContainer;
      }
      
      public function §_-8I§() : starling.display.DisplayObject
      {
         if(_data as §_-Oi§)
         {
            return §_-y2n§.§_-i1N§.§_-X24§((_data as §_-Oi§).getRecord());
         }
         return null;
      }
      
      public function §_-52e§() : Object
      {
         return new <String>[RelativePosition.BOTTOM,RelativePosition.RIGHT,RelativePosition.LEFT];
      }
      
      override public function dispose() : void
      {
         §_-q1j§.remove(this);
         this.count = null;
         this.icon = null;
         this.iconContainer = null;
         super.dispose();
      }
   }
}

