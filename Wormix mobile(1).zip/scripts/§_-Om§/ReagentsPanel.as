package §_-Om§
{
   import §_-12W§.§_-X2w§;
   import §_-12W§.§_-l23§;
   import §_-23P§.*;
   import §_-31N§.§_-42G§;
   import §_-31Y§.§_-D3B§;
   import §_-63U§.*;
   import §_-A1K§.§_-6L§;
   import §_-A1K§.§_-TA§;
   import §_-A1K§.§_-U11§;
   import §_-Af§.§_-k1I§;
   import §_-C2t§.§_-i1V§;
   import §_-CF§.§_-E19§;
   import §_-CF§.§_-p2U§;
   import §_-Cl§.*;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-K3O§;
   import §_-F39§.*;
   import §_-J31§.§_-R1h§;
   import §_-L1H§.§_-C3e§;
   import §_-Ly§.§_-81L§;
   import §_-P2i§.§_-G3J§;
   import §_-T2V§.§_-13F§;
   import §_-TF§.§_-y2n§;
   import §_-Ta§.*;
   import §_-Tm§.§_-RF§;
   import §_-U1i§.§_-U16§;
   import §_-Vg§.*;
   import §_-Y1O§.*;
   import §_-Y1b§.§_-81l§;
   import §_-Z1w§.§_-s1x§;
   import §_-ZP§.§_-H1H§;
   import §_-aM§.*;
   import §_-j1w§.§_-B2i§;
   import §_-j1w§.§_-L1x§;
   import §_-j1w§.§_-T0§;
   import §_-j22§.§_-5g§;
   import §_-jF§.*;
   import §_-k1u§.§_-2m§;
   import §_-k1u§.§_-Oi§;
   import §_-l1g§.§_-L3Q§;
   import §_-l2r§.§_-K1t§;
   import §_-q11§.§_-C2n§;
   import §_-qH§.§_-S25§;
   import §_-r1C§.§_-h2B§;
   import §_-rM§.§_-61j§;
   import §_-s1Q§.Artifacts;
   import §_-z1g§.§_-M2v§;
   import §_-z1g§.§_-lp§;
   import §_-z1g§.§_-y1S§;
   import com.distriqt.extension.inappbilling.Product;
   import com.distriqt.extension.inappbilling.Purchase;
   import com.distriqt.extension.inappbilling.events.PurchaseEvent;
   import com.greensock.*;
   import com.greensock.core.*;
   import com.greensock.loading.*;
   import com.greensock.loading.core.LoaderItem;
   import config.§_-V2w§;
   import dragonBones.animation.WorldClock;
   import feathers.controls.List;
   import feathers.controls.PageIndicator;
   import feathers.controls.Screen;
   import feathers.controls.ScrollPolicy;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import feathers.data.IListCollection;
   import feathers.data.ListCollection;
   import feathers.layout.AnchorLayout;
   import feathers.layout.Direction;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.TiledRowsLayout;
   import feathers.layout.VerticalAlign;
   import flash.display.DisplayObject;
   import flash.display.DisplayObjectContainer;
   import flash.events.*;
   import flash.geom.Point;
   import flash.utils.*;
   import org.as3commons.zip.*;
   import ru.pragmatix.flox.gui.controls.§_-NY§;
   import ru.pragmatix.flox.serialization.§_-616§;
   import ru.pragmatix.flox.social.model.PaymentOption;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.Command;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.gui.*;
   import ru.pragmatix.wormix.messages.clans.request.PostToClanChatRequest;
   import ru.pragmatix.wormix.messages.clans.response.edit.CloseExitClanResponse;
   import ru.pragmatix.wormix.messages.clans.structures.ClanMemberTO;
   import ru.pragmatix.wormix.messages.client.CheatDetected;
   import ru.pragmatix.wormix.messages.server.ProfilesResult;
   import ru.pragmatix.wormix.messages.structures.RatingProfileStructure;
   import ru.pragmatix.wormix.messages.structures.UserProfileStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.objects.§_-i14§;
   import ru.pragmatix.wormix.serialization.server.*;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.utils.§_-6A§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.LaserLineAmmoController;
   import ru.pragmatix.wormix.weapons.ammo.LaserRay;
   import ru.pragmatix.wormix.weapons.ammo.dataStructures.LaserPair;
   import ru.pragmatix.wormix.weapons.interfaces.§_-O1c§;
   import starling.animation.Tween;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Image;
   import starling.events.Event;
   import starling.events.Touch;
   import starling.events.TouchEvent;
   import starling.events.TouchPhase;
   import starling.extensions.ParticleAura;
   
   public class ReagentsPanel extends Screen
   {
      
      private var binder:Binder;
      
      private var §_-q21§:int = -1;
      
      private var §_-v2S§:Object;
      
      public function ReagentsPanel()
      {
         super();
         this.binder = new Binder();
         Application.uiBuilder.create(Application.assetManager.getObject("reagents_panel"),true,this.binder);
      }
      
      override protected function initialize() : void
      {
         var layout:TiledRowsLayout;
         var pageIndicator:PageIndicator;
         var list:List = null;
         super.initialize();
         this.layout = new AnchorLayout();
         addChild(this.binder._panel);
         list = this.binder._list;
         layout = new TiledRowsLayout();
         layout.paging = Direction.HORIZONTAL;
         layout.horizontalAlign = HorizontalAlign.CENTER;
         layout.verticalAlign = VerticalAlign.TOP;
         list.layout = layout;
         list.snapToPages = true;
         list.verticalScrollPolicy = ScrollPolicy.OFF;
         list.horizontalScrollPolicy = ScrollPolicy.OFF;
         list.itemRendererType = §_-2T§;
         list.snapToPages = true;
         list.addEventListener(Event.SCROLL,this.§_-E1F§);
         list.dataProvider = new ListCollection();
         pageIndicator = this.binder._pageIndicator;
         pageIndicator.direction = Direction.HORIZONTAL;
         pageIndicator.gap = 20;
         pageIndicator.horizontalAlign = HorizontalAlign.CENTER;
         pageIndicator.verticalAlign = VerticalAlign.MIDDLE;
         pageIndicator.normalSymbolFactory = function():starling.display.DisplayObject
         {
            return new Image(Application.assetManager.getTexture("InventoryTab_pageNavigation_dot"));
         };
         pageIndicator.selectedSymbolFactory = function():starling.display.DisplayObject
         {
            return new Image(Application.assetManager.getTexture("InventoryTab_pageNavigation_selection"));
         };
         pageIndicator.addEventListener(Event.CHANGE,this.§_-TO§);
         this.binder._nextButton.addEventListener(Event.TRIGGERED,this.§_-E3y§);
         this.binder._prevButton.addEventListener(Event.TRIGGERED,this.§_-f1n§);
      }
      
      override protected function draw() : void
      {
         var _loc1_:UserProfile = null;
         var _loc2_:ListCollection = null;
         var _loc3_:§_-Oi§ = null;
         var _loc4_:Array = null;
         super.draw();
         if(isInvalid(INVALIDATION_FLAG_DATA) && Boolean(this.§_-v2S§.up))
         {
            _loc1_ = this.§_-v2S§.up;
            _loc2_ = this.binder._list.dataProvider as ListCollection;
            _loc2_.removeAll();
            _loc4_ = _loc1_.§_-E3H§().§_-P2l§();
            for each(_loc3_ in _loc4_)
            {
               if(§_-V2w§.§_-L2o§(_loc3_.getId()) && _loc3_.getCount() > 0)
               {
                  _loc2_.addItem(_loc3_);
               }
            }
            for each(_loc3_ in _loc4_)
            {
               if(§_-V2w§.§_-y2r§(_loc3_.getId()) && _loc3_.getCount() > 0)
               {
                  _loc2_.addItem(_loc3_);
               }
            }
            this.binder._list.dataProvider = _loc2_;
            this.§_-qs§(this.binder._list);
            this.binder._list.scrollToPageIndex(this.§_-v2S§.index,0,0);
         }
      }
      
      private function §_-qs§(param1:List) : void
      {
         var _loc2_:int = §_-2T§.§_-t1F§;
         var _loc3_:int = int(Math.floor(param1.height / _loc2_));
         var _loc4_:int = int(Math.floor(param1.width / _loc2_));
         var _loc5_:int = _loc3_ * _loc4_;
         var _loc6_:ListCollection = param1.dataProvider as ListCollection;
         var _loc7_:int = _loc6_.length % _loc5_;
         var _loc8_:int = _loc7_ > 0 ? int(_loc5_ - _loc6_.length % _loc5_) : 0;
         var _loc9_:int = 0;
         while(_loc9_ < _loc8_)
         {
            _loc6_.addItem({});
            _loc9_++;
         }
      }
      
      override public function dispose() : void
      {
         var _loc1_:List = null;
         super.dispose();
         if(_isInitialized)
         {
            _loc1_ = this.binder._list;
            _loc1_.removeEventListener(Event.SCROLL,this.§_-E1F§);
            this.binder._pageIndicator.removeEventListener(Event.CHANGE,this.§_-TO§);
            this.binder._nextButton.removeEventListener(Event.TRIGGERED,this.§_-E3y§);
            this.binder._prevButton.removeEventListener(Event.TRIGGERED,this.§_-f1n§);
         }
      }
      
      public function get sharedData() : Object
      {
         return this.§_-v2S§;
      }
      
      public function set sharedData(param1:Object) : void
      {
         if(this.§_-v2S§ != param1)
         {
            this.§_-v2S§ = param1;
            invalidate(INVALIDATION_FLAG_DATA);
         }
      }
      
      private function §_-E1F§(param1:Event) : void
      {
         if(this.binder._list.horizontalPageCount != this.§_-q21§)
         {
            this.§_-q21§ = this.binder._list.horizontalPageCount;
            this.binder._pageIndicator.pageCount = this.§_-q21§;
            this.binder._pageIndicator.visible = this.§_-q21§ > 1;
            this.§_-91L§(this.binder._list.horizontalPageIndex);
         }
      }
      
      private function §_-TO§(param1:Event) : void
      {
         var _loc2_:int = 0;
         if(this.binder._pageIndicator.selectedIndex != this.binder._list.horizontalPageIndex)
         {
            §_-h2B§.play(§_-d27§.§_-S29§);
            _loc2_ = this.binder._pageIndicator.selectedIndex;
            this.binder._list.scrollToPageIndex(_loc2_,0);
            this.§_-v2S§.index = _loc2_;
            this.§_-91L§(_loc2_);
         }
      }
      
      private function §_-91L§(param1:int) : void
      {
         this.binder._pageIndicator.selectedIndex = param1;
         this.binder._nextButton.visible = this.§_-q21§ - param1 > 1;
         this.binder._prevButton.visible = param1 > 0;
      }
      
      private function §_-E3y§(param1:Event) : void
      {
         §_-h2B§.play(§_-d27§.§_-S29§);
         this.§_-X2z§(1);
      }
      
      private function §_-f1n§(param1:Event) : void
      {
         §_-h2B§.play(§_-d27§.§_-S29§);
         this.§_-X2z§(-1);
      }
      
      private function §_-X2z§(param1:int) : void
      {
         var _loc2_:int = 0;
         if(param1 > 0)
         {
            _loc2_ = int(Math.min(this.§_-q21§ - 1,this.binder._list.horizontalPageIndex + param1));
         }
         else
         {
            _loc2_ = int(Math.max(0,this.§_-v2S§.index + param1));
         }
         this.binder._list.scrollToPageIndex(_loc2_,0);
         this.§_-v2S§.index = _loc2_;
         this.§_-91L§(_loc2_);
      }
   }
}

import feathers.controls.LayoutGroup;
import feathers.controls.List;
import feathers.controls.PageIndicator;
import starlingbuilder.extensions.uicomponents.ContainerButtonWithStates;

class Binder
{
   
   public var _panel:LayoutGroup;
   
   public var _prevButton:ContainerButtonWithStates;
   
   public var _nextButton:ContainerButtonWithStates;
   
   public var _list:List;
   
   public var _pageIndicator:PageIndicator;
   
   public function Binder()
   {
      super();
   }
}
