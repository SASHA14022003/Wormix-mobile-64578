package §_-f1Q§
{
   import §_-62§.§_-F1D§;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-O2H§;
   import §_-9e§.§_-73e§;
   import §_-9e§.§_-8O§;
   import §_-9e§.§_-A18§;
   import §_-A2U§.*;
   import §_-B1y§.§_-bs§;
   import §_-B2z§.§_-63i§;
   import §_-C3f§.§_-yG§;
   import §_-CF§.§_-E19§;
   import §_-CF§.§_-x2t§;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.MessageBox;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-F39§.*;
   import §_-J3L§.§_-h1D§;
   import §_-P2i§.§_-b7§;
   import §_-U1i§.§_-J1§;
   import §_-U1i§.§_-XA§;
   import §_-W§.§_-ix§;
   import §_-Z1K§.§_-A2n§;
   import §_-Z1K§.§_-I1T§;
   import §_-ZP§.§_-H1H§;
   import §_-b1F§.§_-v2Q§;
   import §_-fo§.*;
   import §_-j1w§.§_-B2i§;
   import §_-k1u§.§_-F3H§;
   import §_-k1u§.§_-Oi§;
   import §_-l1g§.§_-L3Q§;
   import §_-l2r§.§_-K1t§;
   import §_-r1C§.§_-h2B§;
   import §_-v2t§.§_-73F§;
   import §_-w2i§.§_-Ia§;
   import §_-z1g§.§_-4l§;
   import §_-z1g§.§_-522§;
   import §_-zI§.§_-92Q§;
   import §_-zI§.§_-F3q§;
   import §_-zI§.§_-X1q§;
   import §_-zI§.§_-sI§;
   import com.greensock.*;
   import com.greensock.core.*;
   import com.greensock.events.LoaderEvent;
   import com.greensock.loading.LoaderMax;
   import com.greensock.loading.LoaderStatus;
   import com.greensock.loading.core.*;
   import config.§_-V2w§;
   import dragonBones.animation.WorldClock;
   import feathers.controls.Label;
   import feathers.controls.Panel;
   import feathers.events.FeathersEventType;
   import flash.display.MovieClip;
   import flash.display.Shape;
   import flash.events.*;
   import flash.utils.*;
   import org.as3commons.zip.*;
   import ru.pragmatix.flox.gui.controls.MessageBox;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.flox.social.model.*;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.shop.§_-6s§;
   import ru.pragmatix.wormix.messages.clans.main.server.ClanInviteStructure;
   import ru.pragmatix.wormix.messages.clans.request.QuitClanRequest;
   import ru.pragmatix.wormix.messages.clans.request.edit.ChangeClanDescriptionRequest;
   import ru.pragmatix.wormix.messages.clans.response.QuitClanResponse;
   import ru.pragmatix.wormix.messages.clans.response.edit.ChangeClanDescriptionResponse;
   import ru.pragmatix.wormix.messages.clans.structures.ClanChatMessageTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanMemberTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.structures.ReconnectToSimpleBattleResultStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.*;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.pvp.messages.server.PvpSystemMessage;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.StringUtil;
   import ru.pragmatix.wormix.utils.§_-6A§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.weapons.ammo.DamageType;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Image;
   import starling.events.Event;
   import starling.text.TextFieldAutoSize;
   import starling.textures.Texture;
   import starling.utils.Align;
   import starling.utils.ScaleMode;
   
   public class DesktopBankClanDonationInfoPanel extends §_-6s§
   {
      
      protected var binder:Binder;
      
      public function DesktopBankClanDonationInfoPanel()
      {
         super();
         this.binder._buyButton.addEventListener(Event.TRIGGERED,this.§_-N1X§);
      }
      
      override protected function §_-l1P§() : DisplayObjectContainer
      {
         this.binder = new Binder();
         Application.uiBuilder.create(Application.assetManager.getObject("bank_buy_info"),true,this.binder);
         this.binder._icon.maintainAspectRatio = true;
         this.binder._icon.scaleContent = true;
         this.binder._icon.scaleMode = ScaleMode.SHOW_ALL;
         return this.binder._panel;
      }
      
      override protected function clearAll() : void
      {
         this.binder._icon.source = null;
         super.clearAll();
      }
      
      override protected function §_-X1S§(param1:Object) : void
      {
         var _loc2_:PaymentOption = null;
         _loc2_ = param1.option;
         this.binder._itemName.text = param1.title;
         this.binder._icon.source = Application.assetManager.getTexture(param1.icon);
         this.§_-V2e§().text = §_-H1H§.§_-p1§(_loc2_.name);
         this.§_-A1O§(_loc2_.count,_loc2_.moneyType);
         this.§_-33L§(_loc2_.bonus,_loc2_.moneyType);
         this.§_-zK§(_loc2_.price);
         super.§_-X1S§(param1);
      }
      
      private function §_-zK§(param1:Number) : void
      {
         this.binder._buyButton.label = param1.toFixed(2) + " " + §_-N1V§.§_-42k§.§_-71P§();
      }
      
      private function §_-A1O§(param1:uint, param2:§_-E19§) : void
      {
         var _loc3_:Number = this.binder._value.width;
         this.binder._value.text = param1.toString();
         this.binder._value.autoSize = TextFieldAutoSize.HORIZONTAL;
         §_-YQ§.§_-42Z§(param2,this.binder._moneyIcon);
         this.binder._valueTitle.text = §_-s2a§.§_-K3t§(§_-s2a§.BANK_VALUE_TITLE);
         var _loc4_:Number = _loc3_ - this.binder._value.width;
         this.binder._moneyIcon.x -= _loc4_;
         this.binder._bonus.parent.x -= _loc4_;
      }
      
      private function §_-33L§(param1:uint, param2:§_-E19§) : void
      {
         if(Boolean(this.binder._bonus) && Boolean(this.binder._bonus.parent))
         {
            if(param1)
            {
               this.binder._moneyIcon.parent.addChildAt(this.binder._bonus.parent,this.binder._moneyIcon.parent.getChildIndex(this.binder._moneyIcon));
               this.binder._valueTitle.parent.addChild(this.binder._bonusText);
            }
            else
            {
               this.binder._bonus.parent.removeFromParent();
               this.binder._bonusText.removeFromParent();
            }
         }
         var _loc3_:Number = this.binder._bonus.width;
         this.binder._bonus.text = "+" + param1.toString();
         this.binder._bonus.autoSize = TextFieldAutoSize.HORIZONTAL;
         §_-YQ§.§_-42Z§(param2,this.binder._bonusMoneyIcon);
         this.binder._bonusText.text = "";
         var _loc4_:Number = _loc3_ - this.binder._bonus.width;
         this.binder._bonus.x += _loc4_ * 0.5;
         this.binder._bonusMoneyIcon.x -= _loc4_ * 0.5;
      }
      
      private function §_-N1X§(param1:Event) : void
      {
         §_-h2B§.play(§_-d27§.§_-sg§);
         §_-N1V§.§_-42k§.§_-F1I§(§_-W14§.option.name);
      }
      
      override protected function §_-F2I§() : Panel
      {
         return this.binder._itemInfo;
      }
      
      override protected function §_-V2e§() : Label
      {
         return this.binder._description;
      }
      
      override protected function §_-pn§() : Label
      {
         return this.binder._itemName;
      }
      
      override public function destroy() : void
      {
         super.destroy();
         this.binder._buyButton.removeEventListener(Event.TRIGGERED,this.§_-N1X§);
         this.binder = null;
      }
   }
}

import feathers.controls.Button;
import feathers.controls.ImageLoader;
import feathers.controls.Label;
import feathers.controls.LayoutGroup;
import feathers.controls.Panel;
import starling.display.Image;
import starling.text.TextField;

class Binder
{
   
   public var _panel:LayoutGroup;
   
   public var _itemInfo:Panel;
   
   public var _icon:ImageLoader;
   
   public var _itemName:Label;
   
   public var _description:Label;
   
   public var _buyButton:Button;
   
   public var _valueTitle:Label;
   
   public var _value:TextField;
   
   public var _moneyIcon:Image;
   
   public var _bonus:TextField;
   
   public var _bonusText:Label;
   
   public var _bonusMoneyIcon:Image;
   
   public function Binder()
   {
      super();
   }
}
