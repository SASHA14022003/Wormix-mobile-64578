package §_-f1Q§
{
   import §_-21p§.§_-4w§;
   import §_-31W§.*;
   import §_-B1y§.*;
   import §_-Bv§.§_-G3P§;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-J2l§;
   import §_-J31§.§_-e2J§;
   import §_-Ly§.§_-81L§;
   import §_-Ta§.VipInfoView;
   import §_-b1F§.*;
   import §_-j22§.§_-5g§;
   import §_-l1g§.§_-L3Q§;
   import §_-n1w§.*;
   import §_-nE§.SelectCraftWeaponScreen;
   import §_-r1C§.§_-h2B§;
   import §_-u13§.MD2;
   import §_-u13§.MD5;
   import §_-u13§.SHA1;
   import §_-u13§.§_-F3§;
   import §_-w2i§.§_-Zd§;
   import §_-z1g§.§_-F4§;
   import com.hurlant.math.*;
   import com.hurlant.util.der.Sequence;
   import com.hurlant.util.der.§_-cz§;
   import com.hurlant.util.der.§_-l1b§;
   import feathers.controls.Label;
   import feathers.controls.Panel;
   import flash.utils.ByteArray;
   import flash.utils.Dictionary;
   import flash.utils.IDataOutput;
   import org.swiftsuspenders.Injector;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.flox.social.model.SocialUserData;
   import ru.pragmatix.wormix.Scene;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.shop.*;
   import ru.pragmatix.wormix.messages.clans.request.PostClanNewsRequest;
   import ru.pragmatix.wormix.messages.clans.request.login.LoginClanBase;
   import ru.pragmatix.wormix.messages.clans.response.PostClanNewsResponse;
   import ru.pragmatix.wormix.messages.client.StartBattle;
   import ru.pragmatix.wormix.model.items.craft.CraftedEquipFamily;
   import ru.pragmatix.wormix.model.user.*;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.objects.§_-Qi§;
   import ru.pragmatix.wormix.utils.*;
   import starling.core.Starling;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.utils.Pool;
   
   use namespace bi_internal;
   
   public class §_-03x§ extends §_-6s§
   {
      
      private var info:VipInfoView;
      
      public function §_-03x§()
      {
         super();
      }
      
      override protected function §_-l1P§() : DisplayObjectContainer
      {
         this.info = new VipInfoView(true);
         var _loc1_:DisplayObjectContainer = this.info.§_-l1P§("bank_vip_info");
         this.info.§_-V2e§().textRendererProperties.isHTML = true;
         return _loc1_;
      }
      
      override protected function §_-X1S§(param1:Object) : void
      {
         super.§_-X1S§(param1);
         this.info.setItem(param1);
      }
      
      override protected function §_-F2I§() : Panel
      {
         return this.info.§_-F2I§();
      }
      
      override protected function §_-pn§() : Label
      {
         return this.info.§_-pn§();
      }
      
      override protected function §_-V2e§() : Label
      {
         return this.info.§_-V2e§();
      }
      
      override public function destroy() : void
      {
         if(this.info)
         {
            this.info.dispose();
            this.info = null;
         }
         super.destroy();
      }
   }
}

