package §_-f1Q§
{
   import §_-12W§.*;
   import §_-31W§.*;
   import §_-5Y§.§_-h2c§;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-W1r§;
   import §_-73d§.§_-pT§;
   import §_-937§.§_-BO§;
   import §_-A1K§.§_-7u§;
   import §_-A2U§.*;
   import §_-C2t§.§_-92W§;
   import §_-C3f§.§_-Z1Y§;
   import §_-CF§.§_-E19§;
   import §_-CF§.§_-x2t§;
   import §_-Cl§.*;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-H2g§.§_-di§;
   import §_-J31§.§_-R1h§;
   import §_-J3L§.§_-h1D§;
   import §_-L1H§.§_-b2K§;
   import §_-Ly§.§_-81L§;
   import §_-TF§.§_-y2n§;
   import §_-Ta§.§_-j2m§;
   import §_-Tm§.§_-RF§;
   import §_-U1i§.§_-81M§;
   import §_-U1i§.§_-b1k§;
   import §_-Vg§.MainClanWindow;
   import §_-Vg§.§_-K3K§;
   import §_-Y1b§.§_-OP§;
   import §_-YF§.*;
   import §_-aM§.*;
   import §_-dS§.§_-D3a§;
   import §_-g2r§.§_-x8§;
   import §_-gG§.§_-M2S§;
   import §_-hv§.*;
   import §_-j1w§.§_-B2i§;
   import §_-k2s§.§_-Go§;
   import §_-k2s§.§_-b0§;
   import §_-l1K§.§_-W2f§;
   import §_-l1g§.§_-L3Q§;
   import §_-lh§.§_-z2A§;
   import §_-r1C§.§_-h2B§;
   import §_-rM§.§_-61j§;
   import §_-w2i§.§_-Ia§;
   import §_-y1s§.§_-p6§;
   import com.distriqt.extension.inappbilling.InAppBilling;
   import com.distriqt.extension.inappbilling.Purchase;
   import com.greensock.OverwriteManager;
   import com.greensock.TweenLite;
   import com.greensock.TweenMax;
   import com.greensock.events.LoaderEvent;
   import com.greensock.loading.LoaderMax;
   import com.greensock.loading.LoaderStatus;
   import com.greensock.loading.core.*;
   import com.greensock.plugins.AutoAlphaPlugin;
   import com.greensock.plugins.BevelFilterPlugin;
   import com.greensock.plugins.BezierPlugin;
   import com.greensock.plugins.BezierThroughPlugin;
   import com.greensock.plugins.BlurFilterPlugin;
   import com.greensock.plugins.ColorMatrixFilterPlugin;
   import com.greensock.plugins.ColorTransformPlugin;
   import com.greensock.plugins.DropShadowFilterPlugin;
   import com.greensock.plugins.EndArrayPlugin;
   import com.greensock.plugins.FrameLabelPlugin;
   import com.greensock.plugins.FramePlugin;
   import com.greensock.plugins.GlowFilterPlugin;
   import com.greensock.plugins.HexColorsPlugin;
   import com.greensock.plugins.RemoveTintPlugin;
   import com.greensock.plugins.RoundPropsPlugin;
   import com.greensock.plugins.ShortRotationPlugin;
   import com.greensock.plugins.TintPlugin;
   import com.greensock.plugins.TweenPlugin;
   import com.greensock.plugins.VisiblePlugin;
   import com.greensock.plugins.VolumePlugin;
   import com.hurlant.math.BigInteger;
   import com.hurlant.math.bi_internal;
   import dragonBones.animation.WorldClock;
   import feathers.controls.Button;
   import feathers.controls.GroupedList;
   import feathers.controls.Label;
   import feathers.controls.List;
   import feathers.controls.Panel;
   import feathers.controls.ScrollPolicy;
   import feathers.controls.Scroller;
   import feathers.controls.renderers.DefaultGroupedListHeaderOrFooterRenderer;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import feathers.core.FeathersControl;
   import feathers.core.ITextRenderer;
   import feathers.data.ListCollection;
   import feathers.events.FeathersEventType;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.HorizontalLayout;
   import feathers.layout.VerticalLayout;
   import flash.errors.IllegalOperationError;
   import flash.events.Event;
   import flash.geom.Point;
   import flash.geom.Rectangle;
   import flash.net.Socket;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import flash.utils.getTimer;
   import ru.pragmatix.flox.social.model.PaymentOption;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.sets.ControlSets;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.gui.*;
   import ru.pragmatix.wormix.gui.menu.*;
   import ru.pragmatix.wormix.gui.menu.shop.*;
   import ru.pragmatix.wormix.gui.menu.shop.mobile.*;
   import ru.pragmatix.wormix.gui.screenOverlay.view.§_-B1m§;
   import ru.pragmatix.wormix.messages.clans.structures.ClanChatMessageTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanNewsTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.server.ShowSystemMessage;
   import ru.pragmatix.wormix.messages.server.VerifyPaymentResult;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.rewards.*;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.Force;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.§_-L2i§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.utils.§_-c1S§;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.Bullet;
   import ru.pragmatix.wormix.weapons.ammo.InvisibleGuardingBot;
   import ru.pragmatix.wormix.weapons.ammo.StaticCharge;
   import ru.pragmatix.wormix.weapons.ammo.phase.HealPhase;
   import ru.pragmatix.wormix.weapons.ammo.type.RopeHook;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Image;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.events.TouchEvent;
   import starling.events.TouchPhase;
   import starling.text.TextFieldAutoSize;
   import starling.textures.Texture;
   import starling.utils.Align;
   import starling.utils.Pool;
   import starling.utils.RectangleUtil;
   import starling.utils.ScaleMode;
   
   use namespace bi_internal;
   
   public class DesktopBankDepositInfoPanel extends §_-6s§
   {
      
      protected var binder:Binder;
      
      public function DesktopBankDepositInfoPanel()
      {
         super();
         this.binder._buyButton.addEventListener(starling.events.Event.TRIGGERED,this.§_-N1X§);
         this.§_-wU§(this.binder._days);
         this.binder._days.dataProvider = new ListCollection([]);
         this.binder._days.verticalScrollPolicy = ScrollPolicy.OFF;
      }
      
      override protected function §_-l1P§() : DisplayObjectContainer
      {
         this.binder = new Binder();
         Application.uiBuilder.create(Application.assetManager.getObject("bank_deposit_info"),true,this.binder);
         this.binder._icon.maintainAspectRatio = true;
         this.binder._icon.scaleContent = true;
         this.binder._icon.scaleMode = ScaleMode.SHOW_ALL;
         return this.binder._panel;
      }
      
      private function §_-wU§(param1:List) : void
      {
         param1.itemRendererType = DepositDayItemRenderer;
      }
      
      override protected function clearAll() : void
      {
         this.binder._days.dataProvider.removeAll();
         this.binder._icon.source = null;
         super.clearAll();
      }
      
      override protected function §_-X1S§(param1:Object) : void
      {
         var _loc2_:PaymentOption = param1.option;
         this.binder._itemName.text = param1.title;
         this.binder._icon.source = Application.assetManager.getTexture(param1.icon);
         this.§_-J2X§();
         this.§_-Q1q§(_loc2_.count,_loc2_.bonus,_loc2_.moneyType);
         this.§_-Cv§(_loc2_.count,_loc2_.moneyType);
         this.§_-t2i§(_loc2_.bonus);
         this.binder._overallTitle.text = §_-s2a§.§_-K3t§(§_-s2a§.DEPOSIT_OVERALL_TITLE);
         this.§_-zK§(_loc2_.price);
         super.§_-X1S§(param1);
      }
      
      private function §_-Q1q§(param1:uint, param2:uint, param3:§_-E19§) : void
      {
         this.binder._days.dataProvider.removeAll();
         var _loc4_:int = 1;
         while(_loc4_ <= 5)
         {
            this.binder._days.dataProvider.addItem({
               "title":§_-s2a§.§_-K3t§(§_-s2a§.DAILY_BONUS_DAY) + " " + _loc4_ + " " + (_loc4_ == 1 ? §_-s2a§.§_-K3t§(§_-s2a§.BANK_DEPOSIT_FIRST_DAY) : ""),
               "value":param1 / 5,
               "bonus":(_loc4_ == 5 ? "+" + param2 : 0),
               "moneyType":param3
            });
            _loc4_++;
         }
         this.binder._days.invalidate(FeathersControl.INVALIDATION_FLAG_DATA);
      }
      
      private function §_-zK§(param1:Number) : void
      {
         this.binder._buyButton.label = param1.toFixed(2) + " " + §_-N1V§.§_-42k§.§_-71P§();
      }
      
      private function §_-J2X§() : void
      {
         this.§_-V2e§().text = §_-s2a§.§_-K3t§(§_-s2a§.DEPOSIT_DAYS_TITLE);
      }
      
      private function §_-Cv§(param1:uint, param2:§_-E19§) : void
      {
         this.binder._value.text = §_-j2m§.§_-M2m§(param1);
         this.binder._value.autoSize = TextFieldAutoSize.HORIZONTAL;
         §_-YQ§.§_-42Z§(param2,this.binder._moneyIcon);
      }
      
      private function §_-t2i§(param1:uint) : void
      {
         this.binder._bonus.text = "+" + param1.toString();
         this.binder._bonus.autoSize = TextFieldAutoSize.HORIZONTAL;
         DepositDayItemRenderer.§_-Re§(param1 != 0,this.binder._value,this.binder._bonus,this.binder._moneyIcon);
      }
      
      private function §_-N1X§(param1:starling.events.Event) : void
      {
         if(§_-X1j§.§_-Rr§.§_-j1j§)
         {
            §_-h2B§.play(§_-d27§.§_-sg§);
            §_-N1V§.§_-42k§.§_-F1I§(§_-W14§.option.name);
         }
      }
      
      override protected function §_-F2I§() : Panel
      {
         return this.binder._itemInfo;
      }
      
      override protected function §_-V2e§() : Label
      {
         return this.binder._description;
      }
      
      override protected function §_-pn§() : Label
      {
         return this.binder._itemName;
      }
      
      override public function destroy() : void
      {
         super.destroy();
         this.binder._buyButton.removeEventListener(starling.events.Event.TRIGGERED,this.§_-N1X§);
         this.binder = null;
      }
   }
}

import feathers.controls.Button;
import feathers.controls.ImageLoader;
import feathers.controls.Label;
import feathers.controls.LayoutGroup;
import feathers.controls.List;
import feathers.controls.Panel;
import starling.display.Image;
import starling.text.TextField;

class Binder
{
   
   public var _panel:LayoutGroup;
   
   public var _itemInfo:Panel;
   
   public var _icon:ImageLoader;
   
   public var _itemName:Label;
   
   public var _description:Label;
   
   public var _buyButton:Button;
   
   public var _days:List;
   
   public var _value:TextField;
   
   public var _bonus:TextField;
   
   public var _moneyIcon:Image;
   
   public var _overallTitle:Label;
   
   public function Binder()
   {
      super();
   }
}
