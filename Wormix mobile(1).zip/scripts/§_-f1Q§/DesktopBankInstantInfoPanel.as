package §_-f1Q§
{
   import §_-11L§.*;
   import §_-12a§.KamikazeBuff;
   import §_-62§.§_-W1r§;
   import §_-63U§.§_-41y§;
   import §_-82a§.*;
   import §_-92a§.ArenaMenu;
   import §_-Af§.§_-k1I§;
   import §_-B1y§.Cookie;
   import §_-B2z§.§_-63i§;
   import §_-CF§.§_-E19§;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-73y§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-G2H§.*;
   import §_-J3L§.§_-h1D§;
   import §_-Ly§.§_-I2K§;
   import §_-Ta§.*;
   import §_-Vg§.*;
   import §_-W§.§_-ix§;
   import §_-Y1O§.§_-V23§;
   import §_-Y1b§.§_-81l§;
   import §_-Y1b§.§_-OP§;
   import §_-Z1K§.§_-q24§;
   import §_-ZP§.§_-H1H§;
   import §_-aM§.*;
   import §_-gG§.§_-M2S§;
   import §_-gG§.§_-Z2z§;
   import §_-hO§.§_-v24§;
   import §_-j1w§.§_-L1x§;
   import §_-k1u§.§_-F3H§;
   import §_-k1u§.§_-Oi§;
   import §_-l1g§.§_-L3Q§;
   import §_-lh§.§_-z2A§;
   import §_-m0§.§_-X1F§;
   import §_-qH§.§_-S25§;
   import §_-r1C§.§_-h2B§;
   import §_-rM§.§_-61j§;
   import §_-x2Q§.§_-dU§;
   import §_-zI§.§_-X1q§;
   import com.hurlant.math.*;
   import feathers.controls.Button;
   import feathers.controls.ButtonState;
   import feathers.controls.Label;
   import feathers.controls.Panel;
   import feathers.controls.ToggleButton;
   import feathers.themes.FontColor;
   import flash.display.BitmapData;
   import flash.geom.ColorTransform;
   import flash.geom.Point;
   import flash.text.TextField;
   import flash.text.TextFormat;
   import flash.utils.IDataInput;
   import flash.utils.IDataOutput;
   import ru.pragmatix.flox.social.model.PaymentOption;
   import ru.pragmatix.wormix.controller.§_-I3A§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.EffectType;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.gui.§_-Q2v§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.shop.§_-6s§;
   import ru.pragmatix.wormix.gui.menu.shop.§_-7D§;
   import ru.pragmatix.wormix.messages.client.GetWhoPumpedReaction;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.pvp.messages.ex.BattleCreationFailure;
   import ru.pragmatix.wormix.pvp.messages.ex.CallToBattleResultType;
   import ru.pragmatix.wormix.pvp.messages.ex.PvpBattleType;
   import ru.pragmatix.wormix.pvp.messages.server.PvpSystemMessage;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.*;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.AtomBomb;
   import ru.pragmatix.wormix.weapons.ammo.FreezingMissile;
   import ru.pragmatix.wormix.weapons.ammo.ammoFactory.AmmosFactory;
   import ru.pragmatix.wormix.weapons.ammo.ammoFactory.IPooledAmmo;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   import starling.text.TextFieldAutoSize;
   import starling.utils.Color;
   import starling.utils.ScaleMode;
   
   use namespace bi_internal;
   
   public class DesktopBankInstantInfoPanel extends §_-6s§
   {
      
      protected var binder:Binder;
      
      public function DesktopBankInstantInfoPanel()
      {
         super();
         this.binder._buyButton.addEventListener(Event.TRIGGERED,this.§_-N1X§);
      }
      
      override protected function §_-l1P§() : DisplayObjectContainer
      {
         this.binder = new Binder();
         Application.uiBuilder.create(Application.assetManager.getObject("bank_buy_info"),true,this.binder);
         this.binder._icon.maintainAspectRatio = true;
         this.binder._icon.scaleContent = true;
         this.binder._icon.scaleMode = ScaleMode.SHOW_ALL;
         return this.binder._panel;
      }
      
      override protected function clearAll() : void
      {
         this.binder._icon.source = null;
         super.clearAll();
      }
      
      override protected function §_-X1S§(param1:Object) : void
      {
         var _loc2_:PaymentOption = null;
         _loc2_ = param1.option;
         this.binder._itemName.text = param1.title;
         this.binder._icon.source = Application.assetManager.getTexture(param1.icon);
         this.§_-V2e§().text = §_-H1H§.§_-p1§(_loc2_.name);
         this.§_-A1O§(_loc2_.count,_loc2_.moneyType);
         this.§_-33L§(_loc2_.bonus,_loc2_.moneyType);
         this.§_-zK§(_loc2_.price);
         super.§_-X1S§(param1);
      }
      
      private function §_-zK§(param1:Number) : void
      {
         this.binder._buyButton.label = param1.toFixed(2) + " " + §_-N1V§.§_-42k§.§_-71P§();
      }
      
      private function §_-A1O§(param1:uint, param2:§_-E19§) : void
      {
         var _loc3_:Number = this.binder._value.width;
         this.binder._value.text = param1.toString();
         this.binder._value.autoSize = TextFieldAutoSize.HORIZONTAL;
         §_-YQ§.§_-42Z§(param2,this.binder._moneyIcon);
         this.binder._valueTitle.text = §_-s2a§.§_-K3t§(§_-s2a§.BANK_VALUE_TITLE);
         var _loc4_:Number = _loc3_ - this.binder._value.width;
         this.binder._moneyIcon.x -= _loc4_;
         this.binder._bonus.parent.x -= _loc4_;
      }
      
      private function §_-33L§(param1:uint, param2:§_-E19§) : void
      {
         if(Boolean(this.binder._bonus) && Boolean(this.binder._bonus.parent))
         {
            if(param1)
            {
               this.binder._moneyIcon.parent.addChildAt(this.binder._bonus.parent,this.binder._moneyIcon.parent.getChildIndex(this.binder._moneyIcon));
               this.binder._valueTitle.parent.addChild(this.binder._bonusText);
            }
            else
            {
               this.binder._bonus.parent.removeFromParent();
               this.binder._bonusText.removeFromParent();
            }
         }
         var _loc3_:Number = this.binder._bonus.width;
         this.binder._bonus.text = "+" + param1.toString();
         this.binder._bonus.autoSize = TextFieldAutoSize.HORIZONTAL;
         §_-YQ§.§_-42Z§(param2,this.binder._bonusMoneyIcon);
         this.binder._bonusText.text = §_-s2a§.§_-K3t§(§_-s2a§.BANK_BONUS_INFO);
         var _loc4_:Number = _loc3_ - this.binder._bonus.width;
         this.binder._bonus.x += _loc4_ * 0.5;
         this.binder._bonusMoneyIcon.x -= _loc4_ * 0.5;
      }
      
      private function §_-N1X§(param1:Event) : void
      {
         §_-h2B§.play(§_-d27§.§_-sg§);
         §_-N1V§.§_-42k§.§_-F1I§(§_-W14§.option.name);
      }
      
      override protected function §_-F2I§() : Panel
      {
         return this.binder._itemInfo;
      }
      
      override protected function §_-V2e§() : Label
      {
         return this.binder._description;
      }
      
      override protected function §_-pn§() : Label
      {
         return this.binder._itemName;
      }
      
      override public function destroy() : void
      {
         super.destroy();
         this.binder._buyButton.removeEventListener(Event.TRIGGERED,this.§_-N1X§);
         this.binder = null;
      }
   }
}

import feathers.controls.Button;
import feathers.controls.ImageLoader;
import feathers.controls.Label;
import feathers.controls.LayoutGroup;
import feathers.controls.Panel;
import starling.display.Image;
import starling.text.TextField;

class Binder
{
   
   public var _panel:LayoutGroup;
   
   public var _itemInfo:Panel;
   
   public var _icon:ImageLoader;
   
   public var _itemName:Label;
   
   public var _description:Label;
   
   public var _buyButton:Button;
   
   public var _valueTitle:Label;
   
   public var _value:TextField;
   
   public var _moneyIcon:Image;
   
   public var _bonus:TextField;
   
   public var _bonusText:Label;
   
   public var _bonusMoneyIcon:Image;
   
   public function Binder()
   {
      super();
   }
}
