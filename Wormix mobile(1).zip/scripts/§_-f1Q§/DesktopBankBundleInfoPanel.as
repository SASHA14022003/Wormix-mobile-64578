package §_-f1Q§
{
   import §_-2U§.*;
   import §_-52L§.§_-u2x§;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-zF§;
   import §_-A2U§.§_-A23§;
   import §_-B1y§.§_-bs§;
   import §_-B2z§.§_-63i§;
   import §_-H16§.*;
   import §_-H2g§.§_-di§;
   import §_-RE§.*;
   import §_-TF§.§_-P19§;
   import §_-Ta§.*;
   import §_-Y1Q§.§_-vx§;
   import §_-Y1b§.§_-OP§;
   import §_-YF§.§_-Zi§;
   import §_-ZP§.§_-H1H§;
   import §_-aM§.§_-4u§;
   import §_-aM§.§_-P1N§;
   import §_-b1F§.§_-G4§;
   import §_-jF§.BundleDescriptionFeatureRenderer;
   import §_-k2s§.§_-8c§;
   import §_-k2s§.§_-C3A§;
   import §_-k2s§.§_-fG§;
   import §_-l1K§.§_-W2f§;
   import §_-l1g§.§_-L3Q§;
   import §_-q26§.*;
   import §_-r1C§.§_-h2B§;
   import §_-sQ§.§_-H3D§;
   import §_-w2i§.§_-Zd§;
   import §_-z1g§.§_-C32§;
   import com.greensock.loading.core.*;
   import com.worlize.websocket.*;
   import dragonBones.animation.WorldClock;
   import feathers.controls.Label;
   import feathers.controls.Panel;
   import feathers.controls.ScrollPolicy;
   import feathers.data.ListCollection;
   import feathers.layout.VerticalLayout;
   import flash.events.Event;
   import flash.net.URLRequest;
   import flash.net.URLVariables;
   import flash.utils.ByteArray;
   import flash.utils.getDefinitionByName;
   import org.swiftsuspenders.Injector;
   import ru.pragmatix.flox.social.model.PaymentOption;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.EffectType;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.shop.§_-6s§;
   import ru.pragmatix.wormix.messages.clans.main.IncomingClanMessage;
   import ru.pragmatix.wormix.messages.clans.main.server.InviteFriendToClan;
   import ru.pragmatix.wormix.messages.clans.request.treasury.CashMedalsClanRequest;
   import ru.pragmatix.wormix.messages.clans.response.*;
   import ru.pragmatix.wormix.messages.clans.response.treasury.CashMedalsClanResponse;
   import ru.pragmatix.wormix.messages.clans.structures.ClanChatMessageTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanMemberTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanNewsTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.structures.HeroicMissionStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.items.craft.*;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-8K§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.Force;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.pvp.messages.client.PvpActionEx;
   import ru.pragmatix.wormix.pvp.messages.client.PvpEndTurn;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.*;
   import ru.pragmatix.wormix.weapons.ammo.GuardingBot;
   import ru.pragmatix.wormix.weapons.ammo.phase.PhaseAmmo;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   
   public class DesktopBankBundleInfoPanel extends §_-6s§
   {
      
      private var binder:Binder;
      
      public function DesktopBankBundleInfoPanel()
      {
         super();
      }
      
      override protected function §_-l1P§() : DisplayObjectContainer
      {
         this.binder = new Binder();
         Application.uiBuilder.create(Application.assetManager.getObject("bank_bundle_info"),true,this.binder);
         this.binder._buyButton.addEventListener(starling.events.Event.TRIGGERED,this.§_-N1X§);
         this.binder._featuresList.layout = new VerticalLayout();
         this.binder._featuresList.itemRendererType = BundleDescriptionFeatureRenderer;
         this.binder._featuresList.horizontalScrollPolicy = ScrollPolicy.OFF;
         return this.binder._panel;
      }
      
      override protected function §_-X1S§(param1:Object) : void
      {
         var _loc2_:PaymentOption = param1.option;
         this.binder._icon.source = Application.assetManager.getTexture(param1.icon);
         this.binder._title.text = param1.title;
         this.binder._description.text = §_-H1H§.§_-p1§(_loc2_.name);
         this.binder._buyButton.label = _loc2_.price.toFixed(2) + " " + §_-N1V§.§_-42k§.§_-71P§();
         var _loc3_:int = int(_loc2_.count);
         var _loc4_:ListCollection = new ListCollection();
         _loc4_.push({
            "count":1 * _loc3_,
            "icon":"DailyBonusPanel_question",
            "note":§_-s2a§.§_-K3t§(§_-s2a§.RANDOM_RARE_REAGENT_NOTE)
         });
         _loc4_.push({
            "count":2500 * _loc3_,
            "icon":"icon_fuzy",
            "note":""
         });
         _loc4_.push({
            "count":25 * _loc3_,
            "icon":"icon_ruby",
            "note":""
         });
         _loc4_.push({
            "count":5 * _loc3_,
            "icon":"IconBadge",
            "note":""
         });
         this.binder._featuresList.dataProvider = _loc4_;
         super.§_-X1S§(param1);
      }
      
      override protected function §_-F2I§() : Panel
      {
         return this.binder._itemInfo;
      }
      
      override protected function §_-pn§() : Label
      {
         return this.binder._title;
      }
      
      override protected function §_-V2e§() : Label
      {
         return this.binder._description;
      }
      
      private function §_-N1X§(param1:starling.events.Event) : void
      {
         §_-h2B§.play(§_-d27§.§_-sg§);
         §_-N1V§.§_-42k§.§_-F1I§(§_-W14§.option.name);
      }
   }
}

import feathers.controls.Button;
import feathers.controls.ImageLoader;
import feathers.controls.Label;
import feathers.controls.LayoutGroup;
import feathers.controls.List;
import feathers.controls.Panel;

class Binder
{
   
   public var _panel:LayoutGroup;
   
   public var _icon:ImageLoader;
   
   public var _title:Label;
   
   public var _buyButton:Button;
   
   public var _description:Label;
   
   public var _itemInfo:Panel;
   
   public var _timerPanelContainer:LayoutGroup;
   
   public var _featuresList:List;
   
   public function Binder()
   {
      super();
   }
}
