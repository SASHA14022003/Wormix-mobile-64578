package §_-f1Q§
{
   import §_-73I§.*;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-J2l§;
   import §_-F39§.§_-r2l§;
   import §_-P1z§.*;
   import §_-Y1O§.§_-V23§;
   import §_-Y1O§.§_-y1o§;
   import §_-Y1b§.§_-81l§;
   import §_-aM§.*;
   import §_-b1F§.§_-v2Q§;
   import §_-j1w§.§_-L1x§;
   import §_-l1g§.§_-L3Q§;
   import §_-p18§.§_-83X§;
   import §_-qH§.§_-S25§;
   import §_-r1C§.§_-h2B§;
   import com.greensock.OverwriteManager;
   import com.greensock.TweenLite;
   import com.greensock.events.LoaderEvent;
   import com.greensock.loading.LoaderMax;
   import com.greensock.loading.LoaderStatus;
   import com.greensock.loading.core.*;
   import com.greensock.plugins.AutoAlphaPlugin;
   import com.greensock.plugins.BevelFilterPlugin;
   import com.greensock.plugins.BezierPlugin;
   import com.greensock.plugins.BezierThroughPlugin;
   import com.greensock.plugins.BlurFilterPlugin;
   import com.greensock.plugins.ColorMatrixFilterPlugin;
   import com.greensock.plugins.ColorTransformPlugin;
   import com.greensock.plugins.DropShadowFilterPlugin;
   import com.greensock.plugins.EndArrayPlugin;
   import com.greensock.plugins.FrameLabelPlugin;
   import com.greensock.plugins.FramePlugin;
   import com.greensock.plugins.GlowFilterPlugin;
   import com.greensock.plugins.HexColorsPlugin;
   import com.greensock.plugins.RemoveTintPlugin;
   import com.greensock.plugins.RoundPropsPlugin;
   import com.greensock.plugins.ShortRotationPlugin;
   import com.greensock.plugins.TintPlugin;
   import com.greensock.plugins.TweenPlugin;
   import com.greensock.plugins.VisiblePlugin;
   import com.greensock.plugins.VolumePlugin;
   import com.hurlant.math.BigInteger;
   import com.hurlant.math.bi_internal;
   import dragonBones.animation.WorldClock;
   import feathers.controls.NumericStepper;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import feathers.controls.text.TextFieldTextRenderer;
   import feathers.controls.text.TextInstanceCreator;
   import feathers.core.ITextRenderer;
   import flash.events.*;
   import flash.geom.ColorTransform;
   import flash.geom.Point;
   import flash.geom.Rectangle;
   import flash.text.TextFormatAlign;
   import flash.utils.*;
   import org.as3commons.zip.*;
   import ru.pragmatix.flox.social.controller.ICustomInviter;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Image;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.text.TextField;
   import starling.textures.Texture;
   import starling.utils.Align;
   import starling.utils.Pool;
   import starling.utils.RectangleUtil;
   import starling.utils.ScaleMode;
   import starling.utils.SystemUtil;
   
   use namespace bi_internal;
   
   public class DepositDayItemRenderer extends DefaultListItemRenderer
   {
      
      public static const §_-Z2f§:Number = 3;
      
      private var binder:Binder;
      
      public function DepositDayItemRenderer()
      {
         super();
      }
      
      public static function §_-Re§(param1:Boolean, param2:TextField, param3:TextField, param4:Image) : void
      {
         if(param1)
         {
            param3.visible = true;
            param3.x = param4.x - param3.width - §_-Z2f§;
            param2.x = param3.x - param2.width - §_-Z2f§;
         }
         else
         {
            param3.visible = false;
            param2.x = param4.x - param2.width - §_-Z2f§;
         }
      }
      
      override protected function initialize() : void
      {
         var _loc1_:DisplayObjectContainer = null;
         super.initialize();
         this.binder = new Binder();
         _loc1_ = Application.uiBuilder.create(Application.assetManager.getObject("bank_deposit_day"),true,this.binder) as DisplayObjectContainer;
         addChild(_loc1_);
         width = _loc1_.width;
         height = _loc1_.height;
      }
      
      override protected function commitData() : void
      {
         this.binder._day.text = _data.title;
         this.binder._value.text = _data.value;
         this.binder._bonus.text = _data.bonus;
         §_-YQ§.§_-42Z§(_data.moneyType,this.binder._moneyIcon);
         §_-Re§(_data.bonus != 0,this.binder._value,this.binder._bonus,this.binder._moneyIcon);
      }
      
      override public function dispose() : void
      {
         this.binder = null;
         super.dispose();
      }
   }
}

import feathers.controls.Label;
import starling.display.Image;
import starling.text.TextField;

class Binder
{
   
   public var _day:Label;
   
   public var _value:TextField;
   
   public var _bonus:TextField;
   
   public var _moneyIcon:Image;
   
   public function Binder()
   {
      super();
   }
}
