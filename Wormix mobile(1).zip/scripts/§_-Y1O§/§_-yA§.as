package §_-Y1O§
{
   import feathers.controls.text.TextInstanceCreator;
   import feathers.themes.FontColor;
   import feathers.themes.FontSize;
   import flash.text.TextFormatAlign;
   import ru.pragmatix.wormix.model.user.UserProfile;
   
   public class §_-yA§
   {
      
      public static const §_-F1v§:int = 0;
      
      public static const §_-v2X§:int = 1;
      
      public static const §_-uF§:int = 2;
      
      public static const §_-02F§:int = 3;
      
      public static const §_-e2e§:int = 4;
      
      public static const §_-n2Y§:int = 5;
      
      public function §_-yA§()
      {
         super();
      }
      
      public static function §_-Cf§(param1:UserProfile) : Boolean
      {
         return §_-JH§(param1.§_-t2I§());
      }
      
      public static function §_-JH§(param1:int) : Boolean
      {
         return param1 == §_-uF§ || param1 == §_-02F§ || param1 == §_-n2Y§;
      }
      
      public static function §_-Hd§(param1:UserProfile) : Boolean
      {
         var _loc2_:int = param1.§_-t2I§();
         return _loc2_ == §_-02F§ || _loc2_ == §_-n2Y§;
      }
      
      public static function §_-u18§(param1:UserProfile) : Boolean
      {
         return param1.§_-t2I§() == §_-e2e§;
      }
      
      public static function §_-M1d§(param1:UserProfile) : Boolean
      {
         return param1.§_-t2I§() == §_-v2X§;
      }
   }
}

