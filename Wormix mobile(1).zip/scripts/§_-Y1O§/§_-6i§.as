package §_-Y1O§
{
   import §_-A1K§.§_-TA§;
   import §_-A2U§.§_-A23§;
   import §_-l1g§.§_-L3Q§;
   import §_-x2Q§.§_-dU§;
   import §_-zI§.§_-8D§;
   import §_-zI§.§_-X1q§;
   import flash.utils.Dictionary;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.structures.ClanMemberTO;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.utils.StringUtil;
   import ru.pragmatix.wormix.utils.§_-6A§;
   import ru.pragmatix.wormix.utils.§_-z1x§;
   import starling.events.Event;
   
   public class §_-6i§
   {
      
      private static var §_-V0§:Vector.<§_-01J§>;
      
      private static var §_-73V§:Dictionary;
      
      private static var §_-m1M§:Dictionary;
      
      private static const §_-t20§:Vector.<§_-01J§> = new Vector.<§_-01J§>(0);
      
      private static const UNDEFINED:§_-TA§ = new §_-TA§(42);
      
      private var §_-32V§:Boolean;
      
      private var §_-93U§:Boolean;
      
      private var §_-u1n§:Vector.<§_-42h§>;
      
      private var §_-fw§:Array;
      
      private var §_-Q2q§:§_-TA§;
      
      private var §_-b2B§:§_-TA§;
      
      private var §_-E13§:§_-TA§;
      
      private var §_-E1L§:Array;
      
      public function §_-6i§(param1:Vector.<§_-V23§>, param2:Boolean, param3:Boolean)
      {
         var _loc4_:§_-V23§ = null;
         var _loc5_:uint = 0;
         this.§_-u1n§ = new Vector.<§_-42h§>(0);
         this.§_-Q2q§ = new §_-TA§(UNDEFINED.value);
         this.§_-b2B§ = new §_-TA§(0);
         this.§_-E13§ = new §_-TA§(0);
         this.§_-E1L§ = [];
         super();
         this.§_-32V§ = param2;
         this.§_-93U§ = param3;
         for each(_loc4_ in param1)
         {
            _loc5_ = _loc4_.getTeamId();
            if(this.§_-u1n§.length > _loc5_ && this.§_-u1n§[_loc5_] != null)
            {
               this.§_-u1n§[_loc5_].§_-l1G§(_loc4_);
            }
            else
            {
               this.§_-u1n§[_loc5_] = new §_-42h§(_loc5_,_loc4_);
               this.§_-b2B§.value += 1;
            }
            this.§_-E1L§[_loc4_.getNumber()] = _loc4_.§_-r2g§();
         }
         this.§_-D3X§();
         this.§_-I12§();
         §_-X1j§.§_-12n§.scene.addEventListener(§_-L3Q§.NEW_UNIT_ADDED,this.§_-fZ§);
      }
      
      public function §_-HR§(param1:uint) : §_-71D§
      {
         var _loc7_:§_-42h§ = null;
         var _loc8_:§_-71D§ = null;
         var _loc9_:§_-V23§ = null;
         var _loc2_:uint = 0;
         var _loc3_:uint = 0;
         var _loc4_:uint = 0;
         var _loc5_:uint = 0;
         var _loc6_:uint = 0;
         for each(_loc7_ in this.§_-u1n§)
         {
            for each(_loc9_ in _loc7_.squads)
            {
               if(_loc7_.id == param1)
               {
                  _loc6_ += _loc9_.getOwnerProfile().getLevel();
                  _loc2_ += _loc9_.getLevel();
                  _loc3_++;
               }
               else
               {
                  _loc4_ += _loc9_.getLevel();
                  _loc5_++;
               }
            }
         }
         _loc8_ = new §_-71D§();
         _loc8_.ratio = _loc4_ / _loc5_ / (_loc2_ / _loc3_);
         _loc8_.§_-fK§ = _loc6_ / _loc3_;
         _loc8_.§_-FN§ = (_loc2_ - _loc6_) / _loc3_;
         return _loc8_;
      }
      
      public function §_-V1Q§() : §_-01J§
      {
         this.§_-Q2q§.value = this.§_-J34§();
         var _loc1_:§_-V23§ = this.§_-u1n§[this.§_-Q2q§.value].§_-O1a§();
         return _loc1_.§_-V2z§();
      }
      
      public function §_-vJ§(param1:UserProfile) : §_-V23§
      {
         var _loc2_:§_-42h§ = null;
         var _loc3_:§_-V23§ = null;
         for each(_loc2_ in this.§_-u1n§)
         {
            for each(_loc3_ in _loc2_.squads)
            {
               if(_loc3_.getOwnerProfile().equals(param1))
               {
                  return _loc3_;
               }
            }
         }
         return null;
      }
      
      public function §_-51H§(param1:UserProfile) : §_-V23§
      {
         var _loc2_:§_-42h§ = null;
         var _loc3_:§_-V23§ = null;
         for each(_loc2_ in this.§_-u1n§)
         {
            for each(_loc3_ in _loc2_.squads)
            {
               if(!_loc3_.getOwnerProfile().equals(param1))
               {
                  return _loc3_;
               }
            }
         }
         return null;
      }
      
      public function §_-J1a§() : Array
      {
         return this.§_-fw§;
      }
      
      public function §_-7q§(param1:int) : Vector.<§_-V23§>
      {
         return this.§_-u1n§[param1].squads;
      }
      
      public function §_-o11§() : Vector.<§_-42h§>
      {
         var _loc2_:§_-42h§ = null;
         var _loc1_:Vector.<§_-42h§> = new Vector.<§_-42h§>(0);
         for each(_loc2_ in this.§_-u1n§)
         {
            if(_loc2_.isActive())
            {
               _loc1_.push(_loc2_);
            }
         }
         return _loc1_;
      }
      
      public function §_-D3n§(param1:Boolean = false) : Vector.<§_-01J§>
      {
         var _loc3_:§_-42h§ = null;
         var _loc4_:§_-V23§ = null;
         var _loc2_:Vector.<§_-01J§> = new Vector.<§_-01J§>(0);
         for each(_loc3_ in this.§_-u1n§)
         {
            for each(_loc4_ in _loc3_.squads)
            {
               _loc2_ = _loc2_.concat(_loc4_.getUnits(param1));
            }
         }
         return _loc2_;
      }
      
      public function §_-t4§(param1:§_-z1x§, param2:Boolean = false) : void
      {
         var _loc3_:§_-42h§ = null;
         var _loc4_:§_-V23§ = null;
         for each(_loc3_ in this.§_-u1n§)
         {
            for each(_loc4_ in _loc3_.squads)
            {
               _loc4_.§_-13w§(param1,param2);
            }
         }
      }
      
      public function §_-b2W§(param1:§_-01J§, param2:Boolean = false, param3:Boolean = false) : Vector.<§_-01J§>
      {
         var _loc5_:uint = 0;
         var _loc6_:§_-42h§ = null;
         var _loc7_:§_-V23§ = null;
         var _loc8_:§_-01J§ = null;
         var _loc4_:Vector.<§_-01J§> = new Vector.<§_-01J§>(0);
         if(Boolean(param1.squad) && Boolean(this.§_-u1n§))
         {
            _loc5_ = param1.squad.getTeamId();
            for each(_loc6_ in this.§_-u1n§)
            {
               for each(_loc7_ in _loc6_.squads)
               {
                  if(_loc7_.getTeamId() == _loc5_)
                  {
                     for each(_loc8_ in _loc7_.getUnits(param2))
                     {
                        if(!(!param3 && _loc8_ == param1))
                        {
                           _loc4_.push(_loc8_);
                        }
                     }
                  }
               }
            }
         }
         return _loc4_;
      }
      
      public function §_-83I§(param1:§_-01J§, param2:Boolean = false) : Vector.<§_-01J§>
      {
         var _loc5_:§_-42h§ = null;
         var _loc6_:§_-V23§ = null;
         if(!param1 || !param1.squad || !this.§_-u1n§)
         {
            return new Vector.<§_-01J§>(0);
         }
         var _loc3_:uint = param1.squad.getTeamId();
         var _loc4_:Vector.<§_-01J§> = new Vector.<§_-01J§>(0);
         for each(_loc5_ in this.§_-u1n§)
         {
            for each(_loc6_ in _loc5_.squads)
            {
               if(_loc6_.getTeamId() != _loc3_)
               {
                  _loc4_ = _loc4_.concat(_loc6_.getUnits(param2));
               }
            }
         }
         return _loc4_;
      }
      
      public function §_-M1e§() : void
      {
         var _loc1_:§_-42h§ = null;
         for each(_loc1_ in this.§_-u1n§)
         {
            _loc1_.§_-M1e§(this.§_-93U§);
         }
      }
      
      public function §_-F5§() : Vector.<Array>
      {
         var _loc2_:§_-42h§ = null;
         var _loc3_:§_-V23§ = null;
         var _loc1_:Vector.<Array> = new Vector.<Array>(0);
         for each(_loc2_ in this.§_-u1n§)
         {
            _loc1_[_loc2_.id] = [];
            for each(_loc3_ in _loc2_.squads)
            {
               _loc1_[_loc2_.id] = _loc1_[_loc2_.id].concat(_loc3_.§_-A3z§());
            }
         }
         return _loc1_;
      }
      
      public function §_-D1j§() : Array
      {
         var _loc2_:§_-42h§ = null;
         var _loc1_:Array = [];
         for each(_loc2_ in this.§_-u1n§)
         {
            _loc1_ = _loc1_.concat(_loc2_.§_-D1j§());
         }
         this.§_-D3X§();
         return _loc1_;
      }
      
      public function §_-12R§() : Array
      {
         var _loc3_:§_-V23§ = null;
         var _loc1_:Array = [];
         var _loc2_:int = 0;
         while(_loc2_ < this.§_-E1L§.length)
         {
            _loc1_.push(0);
            _loc2_++;
         }
         for each(_loc3_ in this.§_-fw§)
         {
            _loc2_ = int(_loc3_.getNumber());
            _loc1_[_loc2_] = int(100 * _loc3_.§_-r2g§() / this.§_-E1L§[_loc2_]);
         }
         return _loc1_;
      }
      
      public function dispose() : void
      {
         var _loc1_:§_-42h§ = null;
         for each(_loc1_ in this.§_-u1n§)
         {
            _loc1_.clear();
         }
         this.§_-u1n§ = null;
         this.§_-fw§ = null;
         this.§_-53F§();
      }
      
      public function §_-wB§() : Vector.<§_-01J§>
      {
         return §_-V0§;
      }
      
      public function §_-D2A§(param1:§_-01J§) : Vector.<§_-01J§>
      {
         var _loc2_:uint = 0;
         var _loc3_:Vector.<§_-01J§> = null;
         if(!param1 || !param1.squad || !this.§_-u1n§)
         {
            return §_-t20§;
         }
         _loc2_ = param1.squad.getTeamId();
         _loc3_ = §_-73V§[_loc2_];
         if(_loc3_ == null)
         {
            §_-73V§[_loc2_] = _loc3_ = this.§_-83I§(param1,true);
         }
         return _loc3_;
      }
      
      public function §_-939§(param1:§_-01J§) : Vector.<§_-01J§>
      {
         var _loc2_:uint = param1.squad.getTeamId();
         var _loc3_:Vector.<§_-01J§> = §_-m1M§[_loc2_];
         if(_loc3_ == null)
         {
            §_-m1M§[_loc2_] = _loc3_ = this.§_-b2W§(param1,false,true);
         }
         return _loc3_;
      }
      
      private function §_-I12§() : void
      {
         §_-V0§ = this.§_-D3n§(true);
         §_-m1M§ = new Dictionary();
         §_-73V§ = new Dictionary();
      }
      
      private function §_-53F§() : void
      {
         §_-V0§ = null;
         §_-73V§ = §_-m1M§ = null;
      }
      
      private function §_-fZ§(param1:Event) : void
      {
         var _loc4_:Vector.<§_-01J§> = null;
         var _loc5_:§_-42h§ = null;
         var _loc6_:int = 0;
         var _loc2_:§_-01J§ = param1.data as §_-01J§;
         var _loc3_:int = int(_loc2_.squad.getTeamId());
         §_-V0§.push(_loc2_);
         for each(_loc5_ in this.§_-u1n§)
         {
            _loc6_ = int(_loc5_.id);
            _loc4_ = §_-73V§[_loc6_];
            if((Boolean(_loc4_)) && _loc6_ != _loc3_)
            {
               _loc4_.push(_loc2_);
            }
            _loc4_ = §_-m1M§[_loc6_];
            if((Boolean(_loc4_)) && _loc6_ == _loc3_)
            {
               _loc4_.push(_loc2_);
            }
         }
      }
      
      private function §_-J34§() : uint
      {
         if(!this.§_-32V§ && this.§_-Q2q§.value != UNDEFINED.value && !this.§_-u1n§[this.§_-Q2q§.value].§_-P2j§())
         {
            return this.§_-Q2q§.value;
         }
         var _loc1_:uint = this.§_-Q2q§.value + 1;
         while(_loc1_ < this.§_-u1n§.length)
         {
            if(this.§_-u1n§[_loc1_].isActive())
            {
               return _loc1_;
            }
            _loc1_++;
         }
         _loc1_ = 0;
         while(_loc1_ < this.§_-u1n§.length)
         {
            if(this.§_-u1n§[_loc1_].isActive())
            {
               return _loc1_;
            }
            _loc1_++;
         }
         return 0;
      }
      
      private function §_-16§(param1:§_-V23§) : Boolean
      {
         return !param1.eliminated && !param1.§_-Z7§();
      }
      
      private function §_-D3X§() : void
      {
         var _loc1_:§_-42h§ = null;
         var _loc2_:§_-V23§ = null;
         this.§_-fw§ = [];
         for each(_loc1_ in this.§_-u1n§)
         {
            for each(_loc2_ in _loc1_.squads)
            {
               this.§_-fw§.push(_loc2_);
            }
         }
      }
      
      public function §_-QS§() : uint
      {
         return this.§_-b2B§.value - this.§_-E13§.value;
      }
      
      public function §_-Q8§() : Boolean
      {
         var _loc2_:§_-42h§ = null;
         var _loc1_:Boolean = true;
         for each(_loc2_ in this.§_-u1n§)
         {
            _loc1_ &&= _loc2_.§_-Z1m§();
         }
         return _loc1_;
      }
   }
}

