package §_-Y1O§
{
   import §_-A1K§.§_-TA§;
   
   public class §_-y1o§
   {
      
      public static const §_-F2p§:§_-y1o§ = new §_-y1o§(new §_-TA§(-100));
      
      public static const §_-Y2B§:§_-y1o§ = new §_-y1o§(new §_-TA§(-101));
      
      public static const §_-28§:§_-y1o§ = new §_-y1o§(new §_-TA§(-102));
      
      private var type:§_-TA§;
      
      public function §_-y1o§(param1:§_-TA§)
      {
         super();
         this.type = new §_-TA§(param1.value);
      }
      
      public function get §_-010§() : int
      {
         return this.type.value;
      }
   }
}

