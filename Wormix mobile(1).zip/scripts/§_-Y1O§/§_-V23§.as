package §_-Y1O§
{
   import §_-l1g§.§_-L3Q§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-8K§;
   import ru.pragmatix.wormix.utils.§_-z1x§;
   
   public class §_-V23§
   {
      
      private static const UNDEFINED:uint = 42;
      
      public var §_-Wb§:String;
      
      private var units:Array = [];
      
      private var §_-O2T§:int = 42;
      
      private var number:uint;
      
      private var §_-9W§:uint = 0;
      
      private var §_-D3k§:uint;
      
      private var playerType:§_-y1o§;
      
      private var profile:UserProfile;
      
      private var §_-3R§:UserProfile = null;
      
      private var inactive:Boolean = false;
      
      public function §_-V23§(param1:String, param2:uint, param3:§_-y1o§, param4:uint)
      {
         super();
         this.§_-Wb§ = param1;
         this.number = param2;
         this.playerType = param3;
         this.§_-D3k§ = param4;
      }
      
      public function getNumber() : uint
      {
         return this.number;
      }
      
      public function §_-V2z§() : §_-01J§
      {
         if(!this.eliminated)
         {
            this.§_-O2T§ = this.§_-O2T§ >= this.units.length - 1 ? 0 : int(this.§_-O2T§ + 1);
            return this.units[this.§_-O2T§];
         }
         return null;
      }
      
      public function §_-D3t§(param1:§_-01J§, param2:Boolean = true) : void
      {
         this.units.push(param1);
         param1.squad = this;
         if(param2)
         {
            §_-X1j§.§_-12n§.scene.dispatchEventWith(§_-L3Q§.NEW_UNIT_ADDED,false,param1);
         }
      }
      
      public function getUnits(param1:Boolean = false) : Vector.<§_-01J§>
      {
         var _loc3_:§_-01J§ = null;
         var _loc2_:Vector.<§_-01J§> = new Vector.<§_-01J§>(0);
         for each(_loc3_ in this.units)
         {
            if(!_loc3_.disposed || param1)
            {
               _loc2_.push(_loc3_);
            }
         }
         return _loc2_;
      }
      
      public function §_-13w§(param1:§_-z1x§, param2:Boolean = false) : void
      {
         var _loc3_:§_-01J§ = null;
         for each(_loc3_ in this.units)
         {
            if(!_loc3_.disposed || param2)
            {
               if(param1.processUnit(_loc3_))
               {
                  break;
               }
            }
         }
      }
      
      public function §_-r2g§() : uint
      {
         var _loc2_:§_-01J§ = null;
         var _loc1_:uint = 0;
         for each(_loc2_ in this.getUnits())
         {
            _loc1_ += _loc2_.hp;
         }
         return _loc1_;
      }
      
      public function §_-Z2G§() : uint
      {
         var _loc2_:§_-01J§ = null;
         var _loc1_:uint = 0;
         for each(_loc2_ in this.units)
         {
            if(!_loc2_.disposed)
            {
               _loc1_++;
            }
         }
         return _loc1_;
      }
      
      public function getTeamId() : uint
      {
         return this.§_-D3k§;
      }
      
      public function §_-A3z§() : Array
      {
         var _loc2_:§_-01J§ = null;
         var _loc1_:Array = [];
         for each(_loc2_ in this.units)
         {
            if(_loc2_.disposed)
            {
               _loc1_.push(_loc2_);
            }
         }
         return _loc1_;
      }
      
      public function §_-ZT§() : void
      {
         var _loc2_:§_-01J§ = null;
         var _loc1_:Array = [];
         for each(_loc2_ in this.units)
         {
            if(_loc2_.disposed)
            {
               ++this.§_-9W§;
            }
            else
            {
               _loc1_.push(_loc2_);
            }
         }
         this.units = _loc1_;
      }
      
      public function §_-4H§() : void
      {
         var _loc1_:§_-01J§ = null;
         for each(_loc1_ in this.units)
         {
            _loc1_.§_-r8§();
         }
         this.§_-ZT§();
      }
      
      public function get eliminated() : Boolean
      {
         return this.units.length == 0;
      }
      
      public function clear() : void
      {
         var _loc1_:§_-01J§ = null;
         for each(_loc1_ in this.units)
         {
            _loc1_ = null;
         }
         this.units = [];
      }
      
      public function get §_-p2D§() : uint
      {
         return this.§_-9W§;
      }
      
      public function isLocal() : Boolean
      {
         return this.playerType == §_-y1o§.§_-F2p§;
      }
      
      public function isAi() : Boolean
      {
         return this.playerType == §_-y1o§.§_-Y2B§;
      }
      
      public function §_-31M§() : Boolean
      {
         return this.playerType == §_-y1o§.§_-28§;
      }
      
      public function §_-F3S§(param1:§_-y1o§) : void
      {
         this.playerType = param1;
      }
      
      public function §_-U2d§() : §_-y1o§
      {
         return this.playerType;
      }
      
      public function §_-m1r§(param1:Boolean) : void
      {
         this.inactive = param1;
      }
      
      public function §_-Z7§() : Boolean
      {
         return this.inactive;
      }
      
      public function getOwnerProfile() : UserProfile
      {
         return this.profile;
      }
      
      public function §_-uR§(param1:UserProfile) : void
      {
         this.profile = param1;
      }
      
      public function §_-B2M§() : UserProfile
      {
         return this.§_-3R§ ? this.§_-3R§ : this.profile;
      }
      
      public function §_-B3F§(param1:UserProfile) : void
      {
         this.§_-3R§ = param1;
      }
      
      public function getLevel() : uint
      {
         var _loc2_:§_-01J§ = null;
         var _loc1_:uint = 0;
         for each(_loc2_ in this.units)
         {
            _loc1_ += _loc2_.record.getLevel();
         }
         return _loc1_;
      }
      
      public function §_-K24§() : §_-01J§
      {
         var _loc1_:§_-8K§ = null;
         for each(_loc1_ in this.units)
         {
            if(_loc1_.record.equals(this.profile))
            {
               return _loc1_;
            }
         }
         return null;
      }
   }
}

