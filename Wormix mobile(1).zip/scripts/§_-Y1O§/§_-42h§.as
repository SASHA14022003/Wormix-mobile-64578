package §_-Y1O§
{
   import §_-A1K§.§_-TA§;
   
   public class §_-42h§
   {
      
      private static const UNDEFINED:uint = 42;
      
      private var _id:uint;
      
      private var §_-nI§:uint = 42;
      
      private var §_-uC§:uint = 42;
      
      private var §_-K37§:Vector.<§_-V23§>;
      
      private var §_-Y1E§:§_-TA§;
      
      public function §_-42h§(param1:uint, ... rest)
      {
         var _loc3_:§_-V23§ = null;
         this.§_-K37§ = new Vector.<§_-V23§>(0);
         this.§_-Y1E§ = new §_-TA§(0);
         super();
         this._id = param1;
         for each(_loc3_ in rest)
         {
            this.§_-l1G§(_loc3_);
         }
      }
      
      public static function §_-16§(param1:§_-V23§) : Boolean
      {
         return !param1.eliminated && !param1.§_-Z7§();
      }
      
      public function §_-l1G§(param1:§_-V23§) : void
      {
         this.§_-K37§.push(param1);
         this.§_-Y1E§.value += 1;
      }
      
      public function get id() : uint
      {
         return this._id;
      }
      
      public function get squads() : Vector.<§_-V23§>
      {
         return this.§_-K37§;
      }
      
      public function §_-O1a§() : §_-V23§
      {
         var _loc1_:Boolean = false;
         var _loc2_:int = -1;
         var _loc3_:uint = 0;
         while(_loc3_ < this.§_-K37§.length)
         {
            if(§_-16§(this.§_-K37§[_loc3_]))
            {
               if(this.§_-K37§[_loc3_].getNumber() > this.§_-uC§)
               {
                  this.§_-nI§ = _loc3_;
                  _loc1_ = true;
                  break;
               }
               if(_loc2_ == -1)
               {
                  _loc2_ = int(_loc3_);
               }
            }
            _loc3_++;
         }
         if(!_loc1_)
         {
            this.§_-nI§ = _loc2_;
         }
         this.§_-uC§ = this.§_-K37§[this.§_-nI§].getNumber();
         return this.§_-K37§[this.§_-nI§];
      }
      
      public function §_-P2j§() : Boolean
      {
         var _loc1_:uint = 0;
         if(this.§_-nI§ != UNDEFINED)
         {
            _loc1_ = 0;
            while(_loc1_ < this.§_-K37§.length)
            {
               if(§_-16§(this.§_-K37§[_loc1_]) && this.§_-K37§[_loc1_].getNumber() > this.§_-uC§)
               {
                  return false;
               }
               _loc1_++;
            }
            return true;
         }
         return false;
      }
      
      public function isActive() : Boolean
      {
         var _loc1_:Boolean = false;
         var _loc2_:Boolean = false;
         var _loc3_:§_-V23§ = null;
         if(this.§_-K37§.length > 0)
         {
            _loc1_ = false;
            _loc2_ = false;
            for each(_loc3_ in this.§_-K37§)
            {
               if(!_loc3_.§_-Z7§())
               {
                  _loc1_ = true;
               }
               if(!_loc3_.eliminated)
               {
                  _loc2_ = true;
               }
               if(_loc1_ && _loc2_)
               {
                  return true;
               }
            }
         }
         return false;
      }
      
      public function §_-M1e§(param1:Boolean) : void
      {
         var _loc2_:§_-V23§ = null;
         var _loc3_:§_-V23§ = null;
         if(!this.isActive() || param1)
         {
            for each(_loc2_ in this.§_-K37§)
            {
               if(_loc2_.§_-Z7§() && !_loc2_.eliminated)
               {
                  _loc2_.§_-4H§();
               }
            }
         }
         else
         {
            for each(_loc2_ in this.§_-K37§)
            {
               if(!_loc2_.§_-Z7§())
               {
                  _loc3_ = _loc2_;
               }
            }
            for each(_loc2_ in this.§_-K37§)
            {
               if(!_loc2_.eliminated && _loc2_.§_-Z7§())
               {
                  _loc2_.§_-F3S§(_loc3_.§_-U2d§());
                  _loc2_.§_-B3F§(_loc3_.getOwnerProfile());
                  _loc2_.§_-m1r§(false);
               }
            }
         }
      }
      
      public function §_-D1j§() : Array
      {
         var _loc1_:Array = [];
         var _loc2_:int = 0;
         while(_loc2_ < this.§_-K37§.length)
         {
            if(!this.§_-K37§[_loc2_].eliminated)
            {
               this.§_-K37§[_loc2_].§_-ZT§();
               if(this.§_-K37§[_loc2_].eliminated)
               {
                  _loc1_.push(this.§_-K37§[_loc2_].getNumber());
               }
            }
            _loc2_++;
         }
         return _loc1_;
      }
      
      public function clear() : void
      {
         var _loc1_:§_-V23§ = null;
         for each(_loc1_ in this.§_-K37§)
         {
            _loc1_.clear();
         }
         this.§_-K37§ = null;
         this.§_-Y1E§.value = 0;
      }
      
      public function §_-US§() : uint
      {
         return this.§_-nI§;
      }
      
      public function §_-Z1m§() : Boolean
      {
         var _loc1_:uint = this.§_-K37§ ? uint(this.§_-K37§.length) : 0;
         return _loc1_ == this.§_-Y1E§.value;
      }
   }
}

