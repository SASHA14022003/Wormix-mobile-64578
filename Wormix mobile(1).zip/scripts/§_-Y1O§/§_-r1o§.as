package §_-Y1O§
{
   public class §_-r1o§
   {
      
      public var teamMemberId:int;
      
      public var state:Boolean = false;
      
      public function §_-r1o§(param1:int, param2:Boolean)
      {
         super();
         this.teamMemberId = param1;
         this.state = param2;
      }
   }
}

