package §_-Y1O§
{
   import ru.pragmatix.wormix.messages.structures.ChatMessage;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   
   public class §_-71D§
   {
      
      public var ratio:Number;
      
      public var §_-fK§:Number;
      
      public var §_-FN§:Number;
      
      public function §_-71D§()
      {
         super();
      }
      
      public function toString() : String
      {
         return "LevelInfoObject{" + "ratio=" + this.ratio + ",playerLevel=" + this.§_-fK§ + ",teamLevel=" + this.§_-FN§ + "}";
      }
   }
}

