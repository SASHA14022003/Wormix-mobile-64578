package §_-ZB§
{
   public interface §_-GG§
   {
      
      function §_-YL§() : void;
      
      function §_-H1§() : Boolean;
   }
}

