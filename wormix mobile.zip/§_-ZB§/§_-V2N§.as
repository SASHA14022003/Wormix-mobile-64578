package §_-ZB§
{
   public interface §_-V2N§
   {
      
      function §_-K1V§() : void;
   }
}

