package §_-ZB§
{
   import ru.pragmatix.flox.social.model.PaymentOption;
   
   public interface §_-W2Q§
   {
      
      function dispose() : void;
      
      function setUserId(param1:String) : void;
      
      function trackPurchased(param1:PaymentOption) : void;
      
      function trackEvent(param1:String, param2:String) : void;
      
      function setCurrency(param1:String) : void;
      
      function trackSubscribe(param1:PaymentOption, param2:Boolean = false) : void;
      
      function track(param1:String, param2:Object) : void;
      
      function trackLevelup() : void;
      
      function trackAchieve(param1:int, param2:String) : void;
      
      function trackMoney(param1:int, param2:int, param3:String, param4:String = "", param5:String = "") : void;
      
      function getUID() : String;
      
      function set isEnabled(param1:Boolean) : void;
   }
}

