package §_-ZB§
{
   import ru.pragmatix.flox.social.model.PaymentOption;
   
   public interface §_-R2Y§
   {
      
      function §_-B1f§(param1:int = -1) : void;
      
      function get isBankOpened() : Boolean;
      
      function §_-O1W§() : void;
      
      function §_-I19§() : void;
      
      function §_-F1I§(param1:String) : void;
      
      function dispose() : void;
      
      function §_-j1E§() : void;
      
      function §_-71P§() : String;
      
      function §_-L2T§(param1:String) : PaymentOption;
      
      function §_-B12§(param1:String) : PaymentOption;
      
      function §_-G1j§(param1:String) : String;
      
      function §_-71Z§(param1:uint) : Array;
      
      function §_-WE§() : Array;
      
      function get §_-51y§() : Boolean;
      
      function updateSubscribe() : void;
   }
}

