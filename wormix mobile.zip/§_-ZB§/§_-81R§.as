package §_-ZB§
{
   import §_-31W§.§_-8§;
   import §_-62§.§_-W1r§;
   import §_-U1i§.§_-J1§;
   import §_-U1i§.§_-O2i§;
   import §_-U1i§.§_-hK§;
   import §_-j1w§.§_-B2i§;
   import §_-z1g§.§_-4l§;
   import flash.display.BitmapData;
   import ru.pragmatix.wormix.messages.clans.structures.ClanMemberTO;
   import ru.pragmatix.wormix.model.rewards.§_-d2F§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   
   public interface §_-81R§
   {
      
      function §_-Ez§() : Boolean;
      
      function §_-n2r§(param1:§_-B2i§) : void;
      
      function §_-g1w§(param1:§_-W1r§) : void;
      
      function §_-3G§(param1:§_-W1r§) : void;
      
      function §_-Z2v§(param1:Array) : void;
      
      function §_-h2J§(param1:§_-O2i§, param2:§_-hK§, param3:Function) : void;
      
      function callToPvp(param1:UserProfile, param2:UserProfile) : void;
      
      function newTeamMate(param1:UserProfile) : void;
      
      function §_-41I§() : Boolean;
      
      function §_-hh§() : Boolean;
      
      function §_-lT§(param1:§_-O2i§, param2:§_-hK§, param3:Function) : void;
      
      function requestPumpReaction(param1:UserProfile, param2:Boolean) : void;
      
      function activityPumpFriendsReaction(param1:UserProfile, param2:uint) : void;
      
      function §_-Y2o§(param1:§_-O2i§, param2:§_-hK§) : void;
      
      function §_-d2f§(param1:UserProfile, param2:Function) : void;
      
      function rubyFoundInHouse(param1:UserProfile) : void;
      
      function kickTeamMate(param1:UserProfile) : void;
      
      function §_-A2C§(param1:String) : void;
      
      function enter4DaySequence() : void;
      
      function share4DayBonus() : void;
      
      function share5DaySequence(param1:§_-4l§) : void;
      
      function enter5DaySequence(param1:§_-4l§) : void;
      
      function §_-91Y§(param1:§_-8§, param2:int, param3:BitmapData = null) : void;
      
      function §_-q1s§(param1:§_-W1r§) : void;
      
      function §_-n2J§(param1:uint) : void;
      
      function §_-Kq§(param1:Boolean, param2:§_-O2i§, param3:§_-J1§, param4:Function = null) : void;
      
      function §_-z1j§(param1:String, param2:Function = null) : void;
      
      function §_-25§(param1:UserProfile, param2:String) : void;
      
      function §_-B38§() : void;
      
      function §_-H3y§() : void;
      
      function §_-WF§() : void;
      
      function §_-xW§() : void;
      
      function §_-x1P§(param1:String, param2:String) : void;
      
      function §_-N2F§(param1:String, param2:String, param3:String, param4:Object, param5:Object) : void;
      
      function §_-eN§(param1:§_-d2F§) : void;
      
      function §_-415§(param1:ClanMemberTO) : void;
      
      function §_-h1P§(param1:int, param2:String) : void;
      
      function §_-f1Y§() : void;
      
      function dispose() : void;
   }
}

