package §_-ZB§
{
   import §_-52L§.§_-Pk§;
   import §_-52L§.§_-u2x§;
   import §_-62§.§_-W1r§;
   import §_-E29§.§_-32G§;
   import §_-T1t§.§_-A2h§;
   import §_-Yk§.§_-m2w§;
   import §_-Z1K§.§_-I1T§;
   import §_-j1w§.§_-B2i§;
   import §_-qH§.§_-5j§;
   import §_-z20§.§_-I3q§;
   import §_-z20§.§_-V7§;
   
   public interface §_-32D§
   {
      
      function §_-X16§(param1:String) : Boolean;
      
      function §_-51U§(param1:§_-B2i§) : Boolean;
      
      function §_-f2b§(param1:§_-W1r§) : Boolean;
      
      function §_-81s§(param1:uint) : Boolean;
      
      function §_-d2c§() : §_-I1T§;
      
      function §_-3X§() : §_-5j§;
      
      function §_-y1r§() : Boolean;
      
      function §_-Xc§() : §_-Pk§;
      
      function §_-R1m§() : §_-u2x§;
      
      function §_-OG§() : §_-A2h§;
      
      function §_-X1P§() : §_-32G§;
      
      function §_-N1i§() : §_-m2w§;
      
      function §_-12I§() : §_-V7§;
      
      function §_-O12§() : §_-I3q§;
   }
}

