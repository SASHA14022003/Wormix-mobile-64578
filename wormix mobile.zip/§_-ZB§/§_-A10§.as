package §_-ZB§
{
   import §_-CF§.§_-p2U§;
   import §_-j1w§.§_-B2i§;
   import §_-z1g§.§_-5c§;
   
   public interface §_-A10§
   {
      
      function §_-L37§() : String;
      
      function §_-Y1o§() : String;
      
      function §_-Z1N§() : String;
      
      function §_-M1N§() : String;
      
      function §_-V1G§(param1:§_-B2i§) : Boolean;
      
      function §_-bB§() : Boolean;
      
      function §_-L2e§() : Array;
      
      function §_-e2n§() : §_-p2U§;
      
      function §_-r1u§() : void;
      
      function §_-hF§() : int;
      
      function §_-l9§() : Boolean;
      
      function dispose() : void;
      
      function §_-1n§() : Boolean;
      
      function §_-21D§() : Vector.<§_-5c§>;
      
      function §_-k2A§() : Boolean;
      
      function §_-A1w§() : Array;
      
      function §_-p2G§() : Date;
      
      function get §_-03F§() : Boolean;
   }
}

